# Motor 2D

Motor de juegos 2D para Android. Objetos con componentes (estilo Unity), scripts en GDScript simplificado (estilo Godot), botón Ejecutar dentro de la app.

## Compilar el APK
1. Sube esta carpeta a un repositorio de GitHub (rama `main`).
2. En la pestaña Actions se ejecuta «Compilar APK» (o lanza «Run workflow»).
3. Descarga el artefacto `Motor2D-apk`, descomprímelo e instala `app-debug.apk`.

## Estructura
- `core/ script/ engine/ editor/`: motor, intérprete y modelo del editor (Kotlin puro, con pruebas en `tests/`).
- `app/`: interfaz de Android (editor, paneles, escena, editor de scripts).
- Cada proyecto de juego guarda `scenes/`, `scripts/` y `assets/` en el almacenamiento de la app.

## Qué incluye
- **Bloques visuales**: Inspector > Añadir componente > Bloques visuales. Se convierten solos a GDScript.
- **Editor de sprites**: píxeles, paleta, espejo, papel cebolla, animación por cuadros.
- **Tiempos**: `after`, `every`, `tween_to` en scripts y bloques de la categoría Tiempo.
- **Teclado y mouse**: atajos en el editor (F5, Ctrl+S/Z/Y/D, Supr), rueda para zoom, clic derecho para mover la vista; API `Input.mouse_*` en scripts.
- **Exportar APK**: menú ⋮ > Exportar APK. Crea el APK firmado en Descargas, sin internet ni GitHub.
- 77 comportamientos prefabricados (ver BIBLIOTECA.md).
