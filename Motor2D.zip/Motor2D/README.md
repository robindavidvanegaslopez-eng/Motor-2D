# Motor 2D

Motor de juegos 2D para Android. Objetos con componentes (estilo Unity), scripts en GDScript simplificado (estilo Godot), botón Ejecutar dentro de la app.

## Compilar el APK
1. Sube esta carpeta a un repositorio de GitHub (rama `main`).
2. En la pestaña Actions se ejecuta «Compilar APK» (o lanza «Run workflow»).
3. Descarga el artefacto `Motor2D-apk`, descomprímelo e instala `app-debug.apk`.

## Estructura
- `core/ script/ engine/ editor/`: motor, intérprete y modelo del editor (Kotlin puro, con pruebas en `tests/`).
- `app/`: interfaz de Android (editor, paneles, escena, editor de scripts).
- Cada proyecto de juego guarda `scenes/`, `scripts/` y `assets/` en el almacenamiento de la app.
