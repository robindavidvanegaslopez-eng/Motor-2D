import com.motor2d.core.Vec2
import com.motor2d.engine.*

var failures = 0
fun check(name: String, cond: Boolean) {
    if (!cond) { failures++; println("FAIL: $name") } else println("ok:   $name")
}

class MemFiles(val m: Map<String, String>) : ProjectFiles {
    override fun readText(path: String) = m[path]
}

class Log : LogSink {
    val lines = ArrayList<String>()
    override fun log(text: String, isError: Boolean) { lines.add((if (isError) "E:" else "") + text) }
}

fun world(script: String, extra: Map<String, String> = emptyMap()): Triple<World, GameObject, Log> {
    val log = Log()
    val w = World(MemFiles(mapOf("s.gd" to script) + extra), log)
    w.viewW = 1280.0; w.viewH = 720.0
    val cam = w.addObject(GameObject("Camara")); cam.position = Vec2(640.0, 360.0); cam.addComponent(Camera2D())
    val o = w.addObject(GameObject("Obj"))
    o.addComponent(SpriteRenderer().also { it.values["size"] = Vec2(40.0, 40.0) })
    o.addComponent(ScriptComponent().also { it.values["path"] = "s.gd" })
    w.start()
    return Triple(w, o, log)
}

fun run(w: World, seconds: Double, each: ((Int) -> Unit)? = null) {
    val n = (seconds * 60.0).toInt()
    for (f in 0 until n) { each?.invoke(f); w.update(1.0 / 60.0); if (w.error != null) return }
}

fun main() {
    // after: una sola vez, en el momento justo
    run {
        val (w, o, _) = world("""
extends Node2D
var hits = 0
func _ready():
    after(1.0, "ping")
func ping():
    hits += 1
""".trimStart())
        run(w, 0.9)
        check("after no dispara antes de tiempo", o.getProp("hits") == 0L)
        run(w, 0.3)
        check("after dispara una vez", o.getProp("hits") == 1L)
        run(w, 2.0)
        check("after no se repite", o.getProp("hits") == 1L)
    }
    // every: se repite; cancel_timer lo detiene
    run {
        val (w, o, _) = world("""
extends Node2D
var hits = 0
var id = 0
func _ready():
    id = every(0.5, "ping")
func ping():
    hits += 1
    if hits == 4:
        cancel_timer(id)
""".trimStart())
        run(w, 1.1)
        check("every se repite", o.getProp("hits") == 2L)
        run(w, 3.0)
        check("cancel_timer detiene el temporizador", o.getProp("hits") == 4L)
    }
    // every con tiempo no válido
    run {
        val (w, _, _) = world("extends Node2D\nfunc _ready():\n    every(0, \"x\")\n")
        check("every(0) da error claro", w.error != null && (w.error!!.message ?: "").contains("mayor que 0"))
    }
    // El temporizador de un objeto destruido no dispara
    run {
        val (w, o, log) = world("""
extends Node2D
func _ready():
    after(0.5, "boom")
    after(0.2, "bye")
func bye():
    destroy(self)
func boom():
    print("BOOM")
""".trimStart())
        run(w, 1.0)
        check("un objeto destruido no ejecuta sus temporizadores", o.destroyed && log.lines.none { it.contains("BOOM") })
    }
    // tween de posición con easing
    run {
        val (w, o, _) = world("""
extends Node2D
func _ready():
    position = Vector2(0, 0)
    tween_to("position", Vector2(100, 50), 1.0, "linear")
""".trimStart())
        run(w, 0.5)
        check("tween llega a la mitad", Math.abs(o.position.x - 50.0) < 3.0 && Math.abs(o.position.y - 25.0) < 3.0)
        run(w, 0.6)
        check("tween termina exacto", o.position == Vec2(100.0, 50.0))
    }
    // tween global sobre otro objeto, rotación y escala
    run {
        val (w, o, _) = world("""
extends Node2D
func _ready():
    var c = get_object("Camara")
    tween(c, "position", Vector2(0, 0), 0.5, "ease_out")
    tween(self, "rotation", 90, 0.5, "ease_in_out")
    tween(self, "scale", Vector2(2, 2), 0.5, "bounce")
""".trimStart())
        run(w, 0.6)
        val cam = w.findByName("Camara")!!
        check("tween mueve otro objeto", cam.position == Vec2(0.0, 0.0))
        check("tween de rotación", Math.abs(o.rotation - 90.0) < 0.01)
        check("tween de escala", o.scale == Vec2(2.0, 2.0))
    }
    // tween de color
    run {
        val (w, o, _) = world("""
extends Node2D
func _ready():
    tween_to("color", Color(1, 0, 0), 0.4)
""".trimStart())
        run(w, 0.5)
        check("tween de color llega al rojo", (o.sprite!!.c("color") and 0x00FFFFFF) == 0x00FF0000)
    }
    // propiedad no animable
    run {
        val (w, _, _) = world("extends Node2D\nfunc _ready():\n    tween_to(\"nombre_raro\", 5, 1)\n")
        check("tween con propiedad inválida da error claro", w.error != null && (w.error!!.message ?: "").contains("no se puede animar"))
    }
    // tween nuevo reemplaza al anterior en la misma propiedad
    run {
        val (w, o, _) = world("""
extends Node2D
func _ready():
    position = Vector2(0, 0)
    tween_to("position", Vector2(1000, 0), 1.0)
    tween_to("position", Vector2(10, 0), 0.2)
""".trimStart())
        run(w, 1.2)
        check("el último tween manda", o.position == Vec2(10.0, 0.0))
    }
    // Curvas de easing
    check("ease linear", TimerSystem.ease("linear", 0.5) == 0.5)
    check("ease_in empieza lento", TimerSystem.ease("ease_in", 0.5) < 0.5)
    check("ease_out empieza rápido", TimerSystem.ease("ease_out", 0.5) > 0.5)
    check("ease_in_out simétrica", Math.abs(TimerSystem.ease("ease_in_out", 0.5) - 0.5) < 1e-9)
    check("bounce termina en 1", Math.abs(TimerSystem.ease("bounce", 1.0) - 1.0) < 1e-9)
    check("todas las curvas valen 0 y 1 en los extremos", TimerSystem.EASINGS.all { TimerSystem.ease(it, 0.0) == 0.0 && Math.abs(TimerSystem.ease(it, 1.0) - 1.0) < 1e-9 })

    // Mouse y teclado en scripts
    run {
        val (w, o, _) = world("""
extends Node2D
var clicks = 0
var rclicks = 0
var wheel = 0.0
var held = false
var mpos = Vector2(0, 0)
var mworld = Vector2(0, 0)
func _process(delta):
    if Input.just_clicked("left"):
        clicks += 1
    if Input.is_mouse_button_just_pressed("right"):
        rclicks += 1
    wheel += Input.mouse_wheel()
    held = Input.is_mouse_button_pressed("left")
    mpos = Input.mouse_position()
    mworld = Input.mouse_world_position()
""".trimStart())
        w.input.mouseMove(Vec2(100.0, 200.0))
        run(w, 0.05)
        check("posición del mouse", o.getProp("mpos") == Vec2(100.0, 200.0))
        check("posición del mouse en el mundo", o.getProp("mworld") == Vec2(100.0, 200.0))
        w.input.mouseDown("left", Vec2(10.0, 10.0))
        run(w, 0.05)
        check("clic izquierdo detectado una vez", o.getProp("clicks") == 1L)
        check("botón izquierdo sostenido", o.getProp("held") == true)
        run(w, 0.1)
        check("el clic no se repite mientras se mantiene", o.getProp("clicks") == 1L)
        w.input.mouseUp("left")
        w.input.mouseDown("right", Vec2(10.0, 10.0))
        run(w, 0.05)
        check("clic derecho detectado", o.getProp("rclicks") == 1L)
        w.input.mouseScroll(3.0)
        run(w, 0.05)
        check("rueda del mouse", o.getProp("wheel") == 3.0)
        run(w, 0.1)
        check("la rueda no se acumula sola", o.getProp("wheel") == 3.0)
    }

    println(if (failures == 0) "TODO BIEN" else "$failures FALLOS")
    if (failures > 0) System.exit(1)
}
