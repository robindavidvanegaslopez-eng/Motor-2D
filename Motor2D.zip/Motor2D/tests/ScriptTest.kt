import com.motor2d.core.Vec2
import com.motor2d.script.*

class FakeOwner : HostObject {
    override val typeName = "Fake"
    var position = Vec2(10.0, 20.0)
    var hp = 3L
    override fun getProp(name: String): Any? = when (name) {
        "position" -> position
        "hp" -> hp
        else -> NoSuch
    }
    override fun setProp(name: String, value: Any?): Boolean = when (name) {
        "position" -> { position = value as Vec2; true }
        "hp" -> { hp = value as Long; true }
        else -> false
    }
    override fun callMethod(name: String, args: List<Any?>): Any? = when (name) {
        "hurt" -> { hp -= args[0] as Long; null }
        else -> NoSuch
    }
}

var failures = 0
fun check(name: String, cond: Boolean) {
    if (!cond) { failures++; println("FAIL: $name") } else println("ok:   $name")
}

fun runScript(src: String, fn: String = "run", args: List<Any?> = emptyList(), owner: HostObject? = null, out: StringBuilder? = null): Pair<ScriptInstance, Any?> {
    val toks = Lexer(src, "test.gd").tokenize()
    val cls = Parser(toks, "test.gd").parseScript()
    val ip = Interpreter(null)
    if (out != null) ip.out = { out.append(it).append('\n') }
    val inst = ScriptInstance(cls, ip, owner)
    inst.init()
    val r = inst.call(fn, args)
    return Pair(inst, r)
}

fun main() {
    // Aritmética y tipos
    var (_, r) = runScript("func run():\n\treturn 7 / 2\n")
    check("int division", r == 3L)
    r = runScript("func run():\n\treturn 7 / 2.0\n").second
    check("float division", r == 3.5)
    r = runScript("func run():\n\treturn 2 ** 10\n").second
    check("power", r == 1024L)
    r = runScript("func run():\n\treturn -7 % 3\n").second
    check("mod trunc", r == -1L)

    // variables miembro, tipos, exports, constantes
    val src1 = """
extends Node2D
const MAX = 5
@export var speed: float = 200.0
var count := 0
var names = ["a", "b"]
var d = {"x": 1, "y": 2}

func bump(n = 1):
    count += n
    return count

func run():
    bump()
    bump(4)
    return count + MAX
"""
    r = runScript(src1).second
    check("members + default args", r == 10L)

    // control de flujo
    val src2 = """
func run():
    var total = 0
    for i in range(10):
        if i == 3:
            continue
        if i == 8:
            break
        total += i
    var j = 0
    while j < 3:
        j += 1
    var s = "no"
    if total > 100:
        s = "big"
    elif total > 20:
        s = "mid"
    else:
        s = "small"
    return [total, j, s]
"""
    r = runScript(src2).second
    check("flow control", r.toString() == "[25, 3, mid]" || (r as List<*>)[0] == 25L)
    println("   -> " + Fmt.str(r))

    // match
    val src3 = """
func name(x):
    match x:
        1:
            return "uno"
        2, 3:
            return "dos o tres"
        _:
            return "otro"

func run():
    return [name(1), name(3), name(9)]
"""
    r = runScript(src3).second
    check("match", Fmt.str(r) == "[\"uno\", \"dos o tres\", \"otro\"]")

    // Vector2 operaciones y asignación de componentes en host
    val owner = FakeOwner()
    val src4 = """
func run():
    position.x += 5
    position = position + Vector2(1, 1) * 2
    var v = Vector2(3, 4)
    v.y = 0
    hurt(1)
    hp -= 1
    return [v.length(), position.x, position.y, hp]
"""
    r = runScript(src4, owner = owner).second
    println("   -> " + Fmt.str(r))
    check("host props / vector assign", Fmt.str(r) == "[3, 17, 22, 1]")

    // print, formato y strings
    val out = StringBuilder()
    runScript("func run():\n\tprint(\"hola \", 5, \" \", 2.5, \" \", Vector2(1,2))\n\tprint(\"%d items, %.2f%%\" % [3, 45.678])\n\tprint(\"a,b,c\".split(\",\").size())\n", out = out)
    check("print/format", out.toString() == "hola 5 2.5 (1, 2)\n3 items, 45.68%\n3\n")
    println(out)

    // diccionarios y listas
    val src5 = """
func run():
    var d = {"a": 1}
    d["b"] = 2
    d.c = 3
    var l = [3, 1, 2]
    l.sort()
    l.append(9)
    var keys = d.keys()
    return [d.size(), l, keys, "b" in d, l[-1], d.get("zz", 7)]
"""
    r = runScript(src5).second
    println("   -> " + Fmt.str(r))
    check("dict/list", Fmt.str(r) == "[3, [1, 2, 3, 9], [\"a\", \"b\", \"c\"], true, 9, 7]")

    // ternario y lógica
    r = runScript("func run():\n\tvar a = 5\n\treturn \"x\" if a > 3 and not a == 4 else \"y\"\n").second
    check("ternary", r == "x")

    // recursión y budget
    r = runScript("func fib(n):\n\tif n < 2:\n\t\treturn n\n\treturn fib(n-1) + fib(n-2)\nfunc run():\n\treturn fib(15)\n").second
    check("fib", r == 610L)

    try {
        runScript("func run():\n\twhile true:\n\t\tpass\n")
        check("infinite loop caught", false)
    } catch (e: ScriptError) {
        check("infinite loop caught", true); println("   -> " + e.describe())
    }

    // errores con línea
    try {
        runScript("func run():\n\tvar a = 1\n\treturn a.foo\n")
        check("error line", false)
    } catch (e: ScriptError) {
        println("   -> " + e.describe())
        check("error line", e.line == 3)
    }
    try {
        runScript("func run():\n\treturn nope + 1\n")
        check("undefined name", false)
    } catch (e: ScriptError) { println("   -> " + e.describe()); check("undefined name", e.line == 2) }
    try {
        runScript("func run(:\n\treturn 1\n")
        check("syntax error", false)
    } catch (e: ScriptError) { println("   -> " + e.describe()); check("syntax error", e.line == 1) }
    try {
        runScript("func run():\n\tif true:\n\t\tx = 1\n\t  y = 2\n")
        check("indent error", false)
    } catch (e: ScriptError) { println("   -> " + e.describe()); check("indent error", true) }

    // enum, onready, extends, comentarios, strings con '#'
    val src6 = """
extends Node
# comentario
enum { A, B = 5, C }
@onready var late = B + 1
var s = "no # comentario"   # sí comentario
func run():
    return [A, B, C, late, s]
"""
    val toks = Lexer(src6, "t.gd").tokenize()
    val cls = Parser(toks, "t.gd").parseScript()
    val ip = Interpreter(null)
    val inst = ScriptInstance(cls, ip, null)
    inst.init(); inst.initOnReady()
    r = inst.call("run")
    println("   -> " + Fmt.str(r))
    check("enum/onready/comment", Fmt.str(r) == "[0, 5, 6, 6, \"no # comentario\"]")

    println(if (failures == 0) "ALL SCRIPT TESTS PASSED" else "$failures FAILURES")
}
