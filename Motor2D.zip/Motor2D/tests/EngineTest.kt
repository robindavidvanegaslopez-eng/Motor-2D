import com.motor2d.core.Vec2
import com.motor2d.engine.*
import com.motor2d.script.ScriptError

var failures = 0
fun check(name: String, cond: Boolean) {
    if (!cond) { failures++; println("FAIL: $name") } else println("ok:   $name")
}

class MemFiles(val m: Map<String, String>) : ProjectFiles {
    override fun readText(path: String) = m[path]
}

class Log : LogSink {
    val lines = ArrayList<String>()
    override fun log(text: String, isError: Boolean) { lines.add((if (isError) "E:" else "") + text) }
}

fun newWorld(files: Map<String, String> = emptyMap()): Pair<World, Log> {
    val log = Log()
    val w = World(MemFiles(files), log)
    return Pair(w, log)
}

fun box(w: World, name: String, x: Double, y: Double, sw: Double, sh: Double, body: String?): GameObject {
    val o = GameObject(name)
    o.position = Vec2(x, y)
    o.addComponent(SpriteRenderer().also { it.values["size"] = Vec2(sw, sh) })
    o.addComponent(BoxCollider2D().also { it.values["size"] = Vec2(sw, sh) })
    if (body != null) o.addComponent(Rigidbody2D().also { it.values["body_type"] = body })
    return w.addObject(o)
}

fun circle(w: World, name: String, x: Double, y: Double, r: Double, bounce: Double = 0.0): GameObject {
    val o = GameObject(name)
    o.position = Vec2(x, y)
    o.addComponent(SpriteRenderer().also { it.values["shape"] = "circle"; it.values["size"] = Vec2(r * 2, r * 2) })
    o.addComponent(CircleCollider2D().also { it.values["radius"] = r; it.values["bounciness"] = bounce })
    o.addComponent(Rigidbody2D())
    return w.addObject(o)
}

fun runFrames(w: World, n: Int) { repeat(n) { w.update(1.0 / 60.0) } }

fun main() {
    // 1. Una caja cae sobre el suelo y se queda quieta
    run {
        val (w, _) = newWorld()
        val floor = box(w, "Suelo", 360.0, 1000.0, 600.0, 40.0, "static")
        val b = box(w, "Caja", 360.0, 500.0, 60.0, 60.0, "dynamic")
        w.start(); runFrames(w, 240)
        val y = b.worldPosition().y
        println("   caja y=$y vel=${b.rigidbody!!.velocity}")
        check("caja apoyada en el suelo", Math.abs(y - (1000.0 - 20.0 - 30.0)) < 2.0)
        check("caja en reposo", b.rigidbody!!.velocity.length() < 5.0)
        check("is_on_floor", b.rigidbody!!.onFloor)
    }

    // 2. Una bola con rebote
    run {
        val (w, _) = newWorld()
        box(w, "Suelo", 360.0, 1000.0, 600.0, 40.0, "static")
        val ball = circle(w, "Bola", 360.0, 400.0, 20.0, bounce = 0.8)
        w.start()
        var maxAfter = 0.0
        var hit = false
        var minY = 1e9
        for (i in 0 until 400) {
            w.update(1.0 / 60.0)
            val y = ball.worldPosition().y
            if (ball.rigidbody!!.velocity.y < -100) hit = true
            if (hit) minY = minOf(minY, y)
        }
        println("   rebote: hit=$hit minY tras rebote=$minY")
        check("la bola rebota", hit && minY < 900.0)
    }

    // 3. Apilado de cajas (estabilidad)
    run {
        val (w, _) = newWorld()
        box(w, "Suelo", 360.0, 1000.0, 600.0, 40.0, "static")
        val a = box(w, "A", 360.0, 940.0, 60.0, 60.0, "dynamic")
        val b = box(w, "B", 360.0, 870.0, 60.0, 60.0, "dynamic")
        val c = box(w, "C", 360.0, 800.0, 60.0, 60.0, "dynamic")
        w.start(); runFrames(w, 300)
        println("   pila: A=${a.worldPosition()} B=${b.worldPosition()} C=${c.worldPosition()}")
        check("pila estable x", Math.abs(c.worldPosition().x - 360.0) < 3.0 && Math.abs(a.worldPosition().x - 360.0) < 3.0)
        check("pila estable y", Math.abs(a.worldPosition().y - 950.0) < 3.0 && Math.abs(c.worldPosition().y - 830.0) < 6.0)
    }

    // 4. Caja inclinada rueda/cae sobre el suelo sin atravesarlo
    run {
        val (w, _) = newWorld()
        box(w, "Suelo", 360.0, 1000.0, 800.0, 40.0, "static")
        val b = box(w, "Caja", 300.0, 700.0, 80.0, 40.0, "dynamic")
        b.rotation = 35.0
        w.start(); runFrames(w, 360)
        val y = b.worldPosition().y
        println("   caja rotada y=$y rot=${b.rotation}")
        check("no atraviesa el suelo", y < 985.0 && y > 900.0)
    }

    // 5. Triggers y eventos desde scripts
    run {
        val script = """
extends Node2D
var entered = 0
var hits = 0
func _on_trigger_enter(other):
    entered += 1
    print("trigger con ", other.name)
func _on_collision_enter(other):
    hits += 1
"""
        val (w, log) = newWorld(mapOf("coin.gd" to script))
        val zone = box(w, "Zona", 360.0, 600.0, 100.0, 100.0, null)
        zone.findComponent("BoxCollider2D")!!.values["is_trigger"] = true
        zone.addComponent(ScriptComponent().also { it.values["path"] = "coin.gd" })
        box(w, "Suelo", 360.0, 1000.0, 600.0, 40.0, "static")
        val ball = circle(w, "Bola", 360.0, 300.0, 20.0)
        ball.addComponent(ScriptComponent().also { it.values["path"] = "coin.gd" })
        w.start(); runFrames(w, 200)
        println("   log=${log.lines}")
        check("trigger enter llamado", log.lines.any { it == "trigger con Bola" })
        val zv = zone.scripts[0].instance!!.vars
        val bv = ball.scripts[0].instance!!.vars
        check("trigger no produce choque", (zv["hits"] as Long) == 0L)
        check("bola choca con suelo", (bv["hits"] as Long) >= 1L)
    }

    // 6. Script: movimiento con Input, _process, export, get_object, instantiate, destroy
    run {
        val script = """
extends Node2D
@export var speed = 100.0
var timer = 0.0
func _ready():
    print("listo ", name)
func _process(delta):
    var j = Input.joystick
    position += j * speed * delta
    timer += delta
    if timer > 0.5 and get_object("Bala") != null:
        var b = instantiate("Bala", position)
        b.position.x += 10
        timer = -100
"""
        val (w, log) = newWorld(mapOf("player.gd" to script))
        val p = GameObject("Jugador"); p.position = Vec2(100.0, 100.0)
        p.addComponent(ScriptComponent().also { it.values["path"] = "player.gd"; it.exports["speed"] = 200.0 })
        w.addObject(p)
        val bala = box(w, "Bala", 0.0, 0.0, 10.0, 10.0, null)
        w.start()
        w.input.joystick = Vec2(1.0, 0.0)
        runFrames(w, 60)
        println("   jugador=${p.position} objetos=${w.objects.size} log=${log.lines}")
        check("joystick mueve con @export speed", Math.abs(p.position.x - 300.0) < 5.0)
        check("instantiate crea copia", w.objects.count { it.name == "Bala" } == 2)
        check("_ready imprimió", log.lines.contains("listo Jugador"))
    }

    // 7. Errores de script paran el juego y se reportan con línea
    run {
        val (w, log) = newWorld(mapOf("bad.gd" to "func _process(delta):\n    var x = 1\n    x.foo()\n"))
        val o = GameObject("Malo"); o.addComponent(ScriptComponent().also { it.values["path"] = "bad.gd" })
        w.addObject(o)
        w.start(); runFrames(w, 3)
        println("   log=${log.lines}")
        check("error reportado con línea", log.lines.any { it.startsWith("E:[bad.gd:3]") })
        check("el juego queda detenido por el error", w.error != null)
    }

    // 8. Jerarquía padre-hijo
    run {
        val (w, _) = newWorld()
        val p = GameObject("Padre"); p.position = Vec2(100.0, 100.0); p.rotation = 90.0
        w.addObject(p)
        val c = GameObject("Hijo"); c.position = Vec2(50.0, 0.0)
        w.addObject(c)
        c.reparent(p)   // conserva posición mundial
        val wp0 = c.worldPosition()
        check("reparent conserva posición mundial", Math.abs(wp0.x - 50.0) < 1e-6 && Math.abs(wp0.y) < 1e-6)
        c.position = Vec2(50.0, 0.0)
        val wp = c.worldPosition()
        check("hijo rota con el padre", Math.abs(wp.x - 100.0) < 1e-6 && Math.abs(wp.y - 150.0) < 1e-6)
    }

    // 9. Guardar/cargar escena
    run {
        val (w, _) = newWorld()
        box(w, "Suelo", 360.0, 1000.0, 600.0, 40.0, "static")
        val s = GameObject("Jugador"); s.tag = "player"; s.position = Vec2(5.0, 6.0)
        s.addComponent(ScriptComponent().also { it.values["path"] = "p.gd"; it.exports["speed"] = 7.5; it.exports["dir"] = Vec2(1.0, 2.0) })
        w.addObject(s)
        val json = SceneIO.sceneToJson(w)
        val (w2, _) = newWorld()
        SceneIO.loadInto(w2, SceneIO.parseScene(json), true)
        val s2 = w2.findByName("Jugador")!!
        check("escena: nº de objetos", w2.objects.size == 2)
        check("escena: tag/posición", s2.tag == "player" && s2.position == Vec2(5.0, 6.0))
        val sc = s2.scripts[0]
        check("escena: exports", sc.exports["speed"] == 7.5 && sc.exports["dir"] == Vec2(1.0, 2.0))
        check("escena: roundtrip idéntico", SceneIO.sceneToJson(w2) == json)
    }

    // 10. Presupuesto: bucle infinito en _process no congela
    run {
        val (w, log) = newWorld(mapOf("loop.gd" to "func _process(d):\n    while true:\n        pass\n"))
        val o = GameObject("Loop"); o.addComponent(ScriptComponent().also { it.values["path"] = "loop.gd" })
        w.addObject(o); w.start()
        val t0 = System.currentTimeMillis()
        runFrames(w, 2)
        check("bucle infinito controlado", System.currentTimeMillis() - t0 < 3000 && log.lines.any { it.contains("tard") })
    }

    // 11. Rendimiento: 150 cuerpos
    run {
        val (w, _) = newWorld()
        box(w, "Suelo", 360.0, 1200.0, 2000.0, 40.0, "static")
        box(w, "Pared1", 0.0, 800.0, 40.0, 900.0, "static")
        box(w, "Pared2", 720.0, 800.0, 40.0, 900.0, "static")
        for (i in 0 until 150) {
            if (i % 2 == 0) circle(w, "c$i", 60.0 + (i % 12) * 50.0, 100.0 + (i / 12) * 45.0, 18.0)
            else box(w, "b$i", 60.0 + (i % 12) * 50.0, 100.0 + (i / 12) * 45.0, 32.0, 32.0, "dynamic")
        }
        w.start()
        val t0 = System.nanoTime()
        runFrames(w, 180)
        val ms = (System.nanoTime() - t0) / 1e6 / 180
        println("   150 cuerpos: %.2f ms por fotograma".format(ms))
        val out = w.objects.count { it.worldPosition().y > 1250 || it.worldPosition().x < -50 || it.worldPosition().x > 770 }
        check("ningún cuerpo escapa del recinto", out == 0)
        check("rendimiento razonable (<16ms)", ms < 16.0)
    }

    println(if (failures == 0) "ALL ENGINE TESTS PASSED" else "$failures FAILURES")
}
