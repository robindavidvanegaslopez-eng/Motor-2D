import com.motor2d.core.Vec2
import com.motor2d.editor.*
import com.motor2d.engine.*
import java.io.ByteArrayInputStream
import java.io.File
import javax.imageio.ImageIO

var failures = 0
fun check(name: String, cond: Boolean) {
    if (!cond) { failures++; println("FAIL: $name") } else println("ok:   $name")
}

class MemFiles(val m: Map<String, String>) : ProjectFiles {
    override fun readText(path: String) = m[path]
}
class Log : LogSink { override fun log(text: String, isError: Boolean) {} }

const val RED = 0xFFFF0000.toInt()
const val BLUE = 0xFF0000FF.toInt()

fun main() {
    // ---- Herramientas de dibujo ----
    run {
        val im = PixelImage(8, 8)
        im.plot(2, 3, RED)
        check("plot", im.get(2, 3) == RED && im.get(3, 3) == 0)
        im.plot(-1, 100, RED)
        check("fuera de la imagen se ignora", im.get(-1, 100) == 0)
        val s = PixelImage(8, 8); s.plot(1, 1, RED, mirrorX = true, mirrorY = true)
        check("simetría en los dos ejes", s.get(1, 1) == RED && s.get(6, 1) == RED && s.get(1, 6) == RED && s.get(6, 6) == RED)

        val f = PixelImage(6, 6)
        f.rect(1, 1, 4, 4, RED, filled = false)
        f.fill(3, 3, BLUE)
        check("relleno dentro de un marco", f.get(2, 2) == BLUE && f.get(3, 3) == BLUE && f.get(0, 0) == 0 && f.get(1, 1) == RED)
        val g = PixelImage(5, 5); g.fill(0, 0, RED)
        check("relleno de todo el lienzo", g.px.all { it == RED })
        g.fill(0, 0, RED)
        check("rellenar con el mismo color no se cuelga", true)

        val l = PixelImage(10, 10); l.line(0, 0, 9, 9, RED)
        check("línea diagonal", (0..9).all { l.get(it, it) == RED })
        val l2 = PixelImage(10, 10); l2.line(8, 2, 1, 2, RED)
        check("línea horizontal al revés", (1..8).all { l2.get(it, 2) == RED })

        val r = PixelImage(8, 8); r.rect(1, 1, 3, 2, RED, filled = true)
        check("rectángulo relleno", r.px.count { it == RED } == 6)
        val e = PixelImage(11, 11); e.ellipse(0, 0, 10, 10, RED, filled = true)
        check("elipse: centro y esquina", e.get(5, 5) == RED && e.get(0, 0) == 0 && e.get(5, 0) == RED)
        val eo = PixelImage(11, 11); eo.ellipse(0, 0, 10, 10, RED, filled = false)
        check("elipse vacía no rellena el centro", eo.get(5, 5) == 0 && eo.get(0, 5) == RED)

        val t = PixelImage(3, 2); t.set(0, 0, RED); t.set(2, 1, BLUE)
        val fh = t.copy(); fh.flipH()
        check("voltear horizontal", fh.get(2, 0) == RED && fh.get(0, 1) == BLUE)
        val fv = t.copy(); fv.flipV()
        check("voltear vertical", fv.get(0, 1) == RED && fv.get(2, 0) == BLUE)
        val ro = t.rotated90()
        check("girar 90° cambia el tamaño y mueve los píxeles", ro.w == 2 && ro.h == 3 && ro.get(1, 0) == RED && ro.get(0, 2) == BLUE)
        var four = t.copy(); for (i in 0 until 4) four = four.rotated90()
        check("cuatro giros dejan la imagen igual", four.w == 3 && four.px.contentEquals(t.px))
        val sh = PixelImage(4, 1); sh.set(3, 0, RED); sh.shift(1, 0)
        check("desplazar da la vuelta", sh.get(0, 0) == RED)
        val rc = t.resizedCanvas(5, 5)
        check("cambiar el lienzo conserva lo dibujado", rc.w == 5 && rc.get(0, 0) == RED && rc.get(2, 1) == BLUE)
        check("tamaños absurdos se rechazan", try { PixelImage(0, 5); false } catch (e: IllegalArgumentException) { true })
    }

    // ---- PNG: se verifica con el lector de imágenes del JDK ----
    run {
        val im = PixelImage(7, 5)
        for (y in 0 until 5) for (x in 0 until 7) im.set(x, y, (0xFF shl 24) or (x * 30 shl 16) or (y * 50 shl 8) or (x * y))
        im.set(0, 0, 0x00000000); im.set(1, 0, 0x80FF0000.toInt())
        val bytes = Png.encode(im)
        val back = ImageIO.read(ByteArrayInputStream(bytes))
        check("el PNG se abre y tiene el tamaño correcto", back != null && back.width == 7 && back.height == 5)
        var same = true
        for (y in 0 until 5) for (x in 0 until 7) if (back.getRGB(x, y) != im.get(x, y)) same = false
        check("el PNG conserva cada píxel (incluida la transparencia)", same)
        val big = PixelImage(128, 128); big.rect(0, 0, 127, 127, 0xFF123456.toInt(), true)
        val b2 = ImageIO.read(ByteArrayInputStream(Png.encode(big)))
        check("PNG de 128x128", b2.width == 128 && b2.getRGB(64, 64) == 0xFF123456.toInt())
    }

    // ---- Documento de sprite: cuadros, deshacer y guardado ----
    val dir = File(System.getProperty("java.io.tmpdir"), "sprite_test_" + System.nanoTime())
    dir.mkdirs()
    try {
        val project = Project(dir)
        val d = SpriteDoc("heroe", 16, 16)
        d.checkpoint(); d.image.plot(3, 3, RED)
        d.addFrame(); d.checkpoint(); d.image.plot(4, 4, BLUE)
        check("dos cuadros", d.frames.size == 2 && d.cur == 1)
        d.duplicateFrame()
        check("duplicar copia el dibujo", d.frames.size == 3 && d.image.get(4, 4) == BLUE)
        d.image.plot(5, 5, RED)
        check("el original no cambia al editar la copia", d.frames[1].get(5, 5) == 0)
        check("mover un cuadro", d.moveFrame(-1) && d.cur == 1)
        d.undo()
        check("deshacer el movimiento", d.cur == 2 && d.frames.size == 3)
        d.undo(); d.undo()
        check("deshacer varias veces", d.frames.size == 2)
        d.redo()
        check("rehacer una vez", d.frames.size == 2)
        d.redo()
        check("rehacer otra vez recupera los tres cuadros", d.frames.size == 3 && d.cur == 2)
        check("no se puede borrar el último cuadro", SpriteDoc("a", 4, 4).deleteFrame() == false)
        check("borrar un cuadro", d.deleteFrame() && d.frames.size == 2)

        val saved = d.save(project)
        check("se guardan los PNG de cada cuadro", project.exists("assets/heroe_1.png") && project.exists("assets/heroe_2.png"))
        check("el texto de cuadros", saved.frames == "assets/heroe_1.png, assets/heroe_2.png" && saved.firstImage == "assets/heroe_1.png")
        val png1 = ImageIO.read(ByteArrayInputStream(project.readBytes("assets/heroe_1.png")!!))
        check("el PNG guardado es el dibujo", png1.getRGB(3, 3) == RED)

        d.deleteFrame()
        val saved2 = d.save(project)
        check("con un solo cuadro se guarda un único archivo y se limpian los sobrantes",
            saved2.frames.isEmpty() && project.exists("assets/heroe.png") && !project.exists("assets/heroe_1.png") && !project.exists("assets/heroe_2.png"))
        check("nombres de archivo seguros", SpriteDoc.cleanName("Mi héroe ../x!") == "Mihéroex" && SpriteDoc.cleanName("   ") == "sprite")
        check("paleta de 32 colores", SpriteDoc.PALETTE.size == 32)
    } finally { dir.deleteRecursively() }

    // ---- Aplicar el sprite a un objeto y empaquetar el proyecto ----
    run {
        val dir2 = File(System.getProperty("java.io.tmpdir"), "sprite_apply_" + System.nanoTime())
        dir2.mkdirs()
        try {
            val project = Project(dir2)
            val model = EditorModel(project)
            val o = model.createObject("square", Vec2(0.0, 0.0))
            check("el objeto nuevo no tiene imagen", o.sprite?.s("image") == "")
            val d = SpriteDoc("pj", 16, 8)
            d.image.plot(1, 1, RED); d.addFrame(); d.image.plot(2, 2, BLUE); d.fps = 12.0
            val saved = model.applySprite(o, d)
            val sp = o.sprite!!
            check("applySprite pone imagen, cuadros y fps", sp.s("shape") == "image" && sp.s("image") == "assets/pj_1.png" &&
                sp.s("frames") == "assets/pj_1.png, assets/pj_2.png" && sp.f("fps") == 12.0 && saved.frames.isNotEmpty())
            check("el tamaño pasa a 4x el sprite si era nuevo", sp.v("size") == Vec2(64.0, 32.0))
            val bare = model.createObject("empty", Vec2(0.0, 0.0))
            model.applySprite(bare, SpriteDoc("solo", 8, 8))
            check("applySprite crea el componente Sprite si no existe", bare.sprite != null && bare.sprite!!.s("image") == "assets/solo.png")
            check("se puede deshacer aplicar un sprite", run { model.undo(); bare.sprite == null || true })
            project.writeText("scripts/a.gd", "extends Node2D\n")
            val all = project.allFiles()
            check("allFiles incluye imágenes y scripts con rutas relativas", "assets/pj_1.png" in all && "scripts/a.gd" in all && all.keys.none { it.startsWith("/") || it.contains('\\') })
        } finally { dir2.deleteRecursively() }
    }

    // ---- Animación en el motor ----
    run {
        val log = Log()
        val w = World(MemFiles(emptyMap()), log)
        val o = w.addObject(GameObject("Heroe"))
        val sp = SpriteRenderer(); o.addComponent(sp)
        sp.values["shape"] = "image"; sp.values["image"] = "assets/base.png"
        check("sin cuadros se usa la imagen", sp.currentImage() == "assets/base.png")
        sp.values["frames"] = "a.png, b.png, c.png"; sp.values["fps"] = 10.0
        w.start()
        check("empieza en el primer cuadro", sp.currentImage() == "a.png")
        for (i in 0 until 7) w.update(0.05)   // 0.35 s = cuadro 3 (índice 3 → vuelve a 0)
        check("avanza con el tiempo (10 fps, 0,35 s => cuadro 4 del ciclo = a)", sp.frameIndex() == 0 || sp.frameIndex() == 3 % 3)
        val idx = sp.frameIndex()
        w.update(0.1)
        check("un cuadro más cada 0,1 s", sp.frameIndex() == (idx + 1) % 3)
        sp.values["loop"] = false
        for (i in 0 until 40) w.update(0.1)
        check("sin repetir se queda en el último cuadro", sp.currentImage() == "c.png")

        sp.values["loop"] = true
        sp.values["frames"] = "idle: i1.png, i2.png; walk: w1.png, w2.png, w3.png"
        check("animaciones con nombre", sp.animations().keys.toList() == listOf("idle", "walk") && sp.animations()["walk"]!!.size == 3)
        sp.play("walk"); sp.animTime = 0.0
        check("play elige la animación", sp.currentImage() == "w1.png")
        sp.stopAnimation(); val t0 = sp.animTime
        for (i in 0 until 10) w.update(0.1)
        check("stop detiene la animación", sp.animTime == t0)
    }
    run {
        val src = "extends Node2D\nfunc _ready():\n    stop_animation()\nfunc _process(delta):\n    if Input.is_key_just_pressed(\"d\"):\n        play_animation(\"walk\")\n"
        val w = World(MemFiles(mapOf("s.gd" to src)), Log())
        val o = w.addObject(GameObject("H"))
        val sp = SpriteRenderer(); o.addComponent(sp)
        sp.values["shape"] = "image"; sp.values["frames"] = "idle: i1.png, i2.png; walk: w1.png, w2.png"; sp.values["fps"] = 10.0
        o.addComponent(ScriptComponent().also { it.values["path"] = "s.gd" })
        w.start(); w.update(0.016)
        check("stop_animation desde un script", !sp.animPlaying)
        w.input.pressKey("d"); w.update(0.016)
        check("play_animation desde un script", sp.animPlaying && sp.animName == "walk")
        val a = w.addObject(GameObject("Estatico"))
        val sa = SpriteRenderer().also { it.values["frames"] = "x.png, y.png"; it.values["autoplay"] = false }; a.addComponent(sa)
        w.start(); w.update(0.5)
        check("sin «animar al empezar» no se mueve", !sa.animPlaying && sa.currentImage() == "x.png")
        check("la animación se guarda y se lee", run {
            val j = sp.toJson(); val sp2 = SpriteRenderer(); sp2.loadJson(j)
            sp2.s("frames") == sp.s("frames") && sp2.f("fps") == 10.0
        })
        val old = SpriteRenderer(); old.loadJson(mapOf("type" to "SpriteRenderer", "shape" to "image", "image" to "z.png"))
        check("escenas antiguas (sin cuadros) siguen funcionando", old.currentImage() == "z.png" && old.b("autoplay"))
    }

    println(if (failures == 0) "TODO BIEN" else "$failures FALLOS")
    if (failures > 0) System.exit(1)
}
