import com.motor2d.export.*
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.KeyFactory
import java.security.KeyStore
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.Signature
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.X509EncodedKeySpec
import java.util.Base64
import java.util.Random
import java.util.jar.JarFile
import java.util.jar.Manifest
import java.util.zip.CRC32
import java.util.zip.Inflater
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

// Verificación independiente del exportador de APK (paquete com.motor2d.export). Solo usa la API pública.
// Uso: ExportTest <directorio de trabajo> <directorio con key.pk8 y cert.der>

var failures = 0
var oks = 0
fun check(name: String, cond: Boolean) {
    if (!cond) { failures++; println("FAIL: $name") } else { oks++; println("ok:   $name") }
}
fun checkNull(name: String, problem: String?) {
    if (problem != null) { failures++; println("FAIL: $name -> $problem") } else { oks++; println("ok:   $name") }
}
fun guard(name: String, f: () -> Unit) {
    try { f() } catch (t: Throwable) { failures++; println("FAIL: $name (excepción ${t.javaClass.simpleName}: ${t.message})"); t.printStackTrace(System.out) }
}

val LE = ByteOrder.LITTLE_ENDIAN
fun u16(b: ByteArray, p: Int) = ByteBuffer.wrap(b).order(LE).getShort(p).toInt() and 0xffff
fun i32(b: ByteArray, p: Int) = ByteBuffer.wrap(b).order(LE).getInt(p)
fun u32(b: ByteArray, p: Int) = i32(b, p).toLong() and 0xffffffffL
fun u64(b: ByteArray, p: Int) = ByteBuffer.wrap(b).order(LE).getLong(p)
fun sha256(b: ByteArray): ByteArray = MessageDigest.getInstance("SHA-256").digest(b)
fun b64(b: ByteArray): String = Base64.getEncoder().encodeToString(b)

// ===================================================================================================
// Constructor de AXML binario (independiente del código bajo prueba)
// ===================================================================================================
sealed class V
class VS(val s: String) : V()
class VRef(val id: Int) : V()
class VBool(val b: Boolean) : V()
class VInt(val i: Int) : V()
class A(val android: Boolean, val name: String, val v: V)
class El(val name: String, val attrs: List<A> = emptyList(), val kids: List<El> = emptyList())

const val ANS = "http://schemas.android.com/apk/res/android"
val RES_IDS = mapOf(
    "versionCode" to 0x0101021b, "versionName" to 0x0101021c, "minSdkVersion" to 0x0101020c,
    "name" to 0x01010003, "label" to 0x01010001, "icon" to 0x01010002, "exported" to 0x01010010,
    "authorities" to 0x01010018, "value" to 0x01010024, "theme" to 0x01010000
)

class Out {
    val bo = ByteArrayOutputStream()
    fun u8(v: Int) { bo.write(v and 0xff) }
    fun u16(v: Int) { u8(v); u8(v ushr 8) }
    fun i32(v: Int) { u16(v and 0xffff); u16(v ushr 16) }
    fun bytes(b: ByteArray) { bo.write(b) }
    fun size() = bo.size()
    fun toByteArray(): ByteArray = bo.toByteArray()
}

fun buildAxml(root: El, utf8: Boolean): ByteArray {
    val strings = LinkedHashMap<String, Int>()
    fun s(x: String): Int = strings.getOrPut(x) { strings.size }
    val usedRes = java.util.TreeMap<Int, String>()
    fun scan(e: El) { for (a in e.attrs) if (a.android) usedRes[RES_IDS.getValue(a.name)] = a.name; e.kids.forEach { scan(it) } }
    scan(root)
    val resIds = ArrayList<Int>()
    for ((id, n) in usedRes) { s(n); resIds.add(id) }
    val prefix = s("android"); val uri = s(ANS)

    val body = Out()
    // START_NAMESPACE
    body.u16(0x0100); body.u16(16); body.i32(24); body.i32(1); body.i32(-1); body.i32(prefix); body.i32(uri)
    var line = 2
    fun visit(e: El) {
        val nameIdx = s(e.name)
        body.u16(0x0102); body.u16(16); body.i32(36 + 20 * e.attrs.size); body.i32(line++); body.i32(-1)
        body.i32(-1); body.i32(nameIdx); body.u16(20); body.u16(20); body.u16(e.attrs.size); body.u16(0); body.u16(0); body.u16(0)
        for (a in e.attrs) {
            body.i32(if (a.android) uri else -1); body.i32(s(a.name))
            when (val v = a.v) {
                is VS -> { val i = s(v.s); body.i32(i); body.u16(8); body.u8(0); body.u8(0x03); body.i32(i) }
                is VRef -> { body.i32(-1); body.u16(8); body.u8(0); body.u8(0x01); body.i32(v.id) }
                is VBool -> { body.i32(-1); body.u16(8); body.u8(0); body.u8(0x12); body.i32(if (v.b) -1 else 0) }
                is VInt -> { body.i32(-1); body.u16(8); body.u8(0); body.u8(0x10); body.i32(v.i) }
            }
        }
        e.kids.forEach { visit(it) }
        body.u16(0x0103); body.u16(16); body.i32(24); body.i32(line++); body.i32(-1); body.i32(-1); body.i32(nameIdx)
    }
    visit(root)
    body.u16(0x0101); body.u16(16); body.i32(24); body.i32(line); body.i32(-1); body.i32(prefix); body.i32(uri)

    // string pool
    val enc = ArrayList<ByteArray>()
    for (str in strings.keys) {
        val o = Out()
        if (utf8) {
            val bytes = str.toByteArray(Charsets.UTF_8)
            fun len(n: Int) { if (n > 0x7f) { o.u8((n shr 8) or 0x80); o.u8(n and 0xff) } else o.u8(n) }
            len(str.length); len(bytes.size); o.bytes(bytes); o.u8(0)
        } else {
            o.u16(str.length)
            for (c in str) o.u16(c.code)
            o.u16(0)
        }
        enc.add(o.toByteArray())
    }
    val sc = enc.size
    val stringsStart = 28 + 4 * sc
    var blob = 0
    for (e in enc) blob += e.size
    val padded = (blob + 3) and 3.inv()
    val pool = Out()
    pool.u16(0x0001); pool.u16(28); pool.i32(stringsStart + padded); pool.i32(sc); pool.i32(0)
    pool.i32(if (utf8) 0x100 else 0); pool.i32(stringsStart); pool.i32(0)
    var off = 0
    for (e in enc) { pool.i32(off); off += e.size }
    for (e in enc) pool.bytes(e)
    repeat(padded - blob) { pool.u8(0) }

    val resmap = Out()
    resmap.u16(0x0180); resmap.u16(8); resmap.i32(8 + 4 * resIds.size)
    for (id in resIds) resmap.i32(id)

    val all = Out()
    val total = 8 + pool.size() + resmap.size() + body.size()
    all.u16(0x0003); all.u16(8); all.i32(total)
    all.bytes(pool.toByteArray()); all.bytes(resmap.toByteArray()); all.bytes(body.toByteArray())
    return all.toByteArray()
}

const val OLD = "com.motor2d.engine2d"

fun manifestTree(label: String?, versionName: String = "1.0", relNames: Boolean = true, withVersionName: Boolean = true): El {
    val appAttrs = ArrayList<A>()
    if (label != null) appAttrs.add(A(true, "label", VS(label)))
    appAttrs.add(A(true, "icon", VRef(0x7f080000)))
    appAttrs.add(A(true, "theme", VRef(0x7f0f0001)))
    val actName = if (relNames) ".app.MainActivity" else "com.motor2d.app.MainActivity"
    val otherName = if (relNames) "Other" else "com.motor2d.app.Other"
    val manAttrs = ArrayList<A>()
    manAttrs.add(A(false, "package", VS(OLD)))
    if (withVersionName) manAttrs.add(A(true, "versionName", VS(versionName)))
    manAttrs.add(A(true, "versionCode", VInt(1)))
    return El("manifest", manAttrs, listOf(
        El("uses-sdk", listOf(A(true, "minSdkVersion", VInt(24)))),
        El("permission", listOf(A(true, "name", VS("$OLD.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION")))),
        El("uses-permission", listOf(A(true, "name", VS("$OLD.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION")))),
        El("uses-permission", listOf(A(true, "name", VS("android.permission.VIBRATE")))),
        El("application", appAttrs, listOf(
            El("activity", listOf(A(true, "name", VS(actName)), A(true, "exported", VBool(true))), listOf(
                El("intent-filter", emptyList(), listOf(
                    El("action", listOf(A(true, "name", VS("android.intent.action.MAIN")))),
                    El("category", listOf(A(true, "name", VS("android.intent.category.LAUNCHER"))))
                ))
            )),
            El("activity", listOf(A(true, "name", VS(otherName)))),
            El("provider", listOf(A(true, "name", VS("androidx.startup.InitializationProvider")),
                A(true, "authorities", VS("$OLD.androidx-startup")), A(true, "exported", VBool(false)))),
            El("meta-data", listOf(A(true, "name", VS("ver")), A(true, "value", VS("1.0"))))
        ))
    ))
}

// ===================================================================================================
// Lector AXML independiente y estricto
// ===================================================================================================
class RAttr(val ns: String?, val name: String, val type: Int, val data: Int, val raw: Int, val str: String?)
class REl(val name: String, val attrs: List<RAttr>)
class RDoc(val strings: List<String>, val resIds: List<Int>, val els: List<REl>)

fun parseAxml(b: ByteArray): RDoc {
    fun fail(m: String): Nothing = throw IllegalStateException("AXML inválido: $m")
    if (b.size < 8 || u16(b, 0) != 3 || u16(b, 2) != 8) fail("cabecera")
    if (i32(b, 4) != b.size) fail("tamaño ${i32(b, 4)} != ${b.size}")
    if (b.size % 4 != 0) fail("tamaño no múltiplo de 4")
    var p = 8
    var strings: List<String>? = null
    var resIds: List<Int> = emptyList()
    val els = ArrayList<REl>()
    val stack = ArrayList<String>()
    var sawNs = 0
    var endNs = 0
    var sawResMap = false
    var first = true
    while (p < b.size) {
        if (p + 8 > b.size) fail("chunk truncado en $p")
        val type = u16(b, p); val hs = u16(b, p + 2); val sz = i32(b, p + 4)
        if (sz < 8 || sz % 4 != 0 || p + sz > b.size) fail("chunk 0x${type.toString(16)} tamaño $sz en $p")
        if (first && type != 1) fail("el primer chunk no es el string pool"); first = false
        when (type) {
            0x0001 -> {
                if (strings != null) fail("dos string pools")
                if (hs != 28) fail("hs pool=$hs")
                val sc = i32(b, p + 8); val stc = i32(b, p + 12); val flags = i32(b, p + 16)
                val ss = i32(b, p + 20); val sts = i32(b, p + 24)
                if (sc < 0 || stc < 0) fail("recuentos")
                if (28 + 4 * sc + 4 * stc > sz) fail("tabla de offsets fuera del pool")
                if (sc > 0 && (ss < 28 + 4 * sc + 4 * stc || ss > sz)) fail("stringsStart $ss")
                if (stc > 0 && sts <= ss) fail("stylesStart")
                if (sc > 0 && ss % 4 != 0) fail("stringsStart no alineado")
                val utf8 = flags and 0x100 != 0
                val list = ArrayList<String>()
                val strEnd = if (stc > 0) p + sts else p + sz
                for (i in 0 until sc) {
                    val off = i32(b, p + 28 + 4 * i)
                    var q = p + ss + off
                    if (off < 0 || q >= strEnd) fail("offset de cadena $i")
                    if (utf8) {
                        fun len(): Int { val x = b[q++].toInt() and 0xff; return if (x and 0x80 != 0) (((x and 0x7f) shl 8) or (b[q++].toInt() and 0xff)) else x }
                        val chars = len(); val nb = len()
                        if (q + nb + 1 > strEnd) fail("cadena $i fuera del pool")
                        val s = String(b, q, nb, Charsets.UTF_8)
                        if (b[q + nb].toInt() != 0) fail("cadena $i sin terminador")
                        if (s.length != chars) fail("cadena $i: longitud UTF-16 declarada $chars, real ${s.length}")
                        list.add(s)
                    } else {
                        var n = u16(b, q); q += 2
                        if (n and 0x8000 != 0) { n = ((n and 0x7fff) shl 16) or u16(b, q); q += 2 }
                        if (q + 2 * n + 2 > strEnd) fail("cadena $i fuera del pool")
                        val s = String(b, q, 2 * n, Charsets.UTF_16LE)
                        if (u16(b, q + 2 * n) != 0) fail("cadena $i sin terminador")
                        list.add(s)
                    }
                }
                strings = list
            }
            0x0180 -> {
                if (strings == null) fail("resource map antes del pool")
                if (sawResMap) fail("dos resource maps")
                sawResMap = true
                val n = (sz - 8) / 4
                if (n > strings.size) fail("resource map con $n ids > ${strings.size} cadenas")
                resIds = (0 until n).map { i32(b, p + 8 + 4 * it) }
            }
            0x0100, 0x0101 -> {
                if (hs != 16 || sz != 24) fail("namespace tamaño")
                val pre = i32(b, p + 16); val uri = i32(b, p + 20)
                if (pre !in 0 until strings!!.size || uri !in 0 until strings.size) fail("namespace índices")
                if (type == 0x0100) sawNs++ else endNs++
            }
            0x0102 -> {
                val st = strings ?: fail("elemento antes del pool")
                if (hs != 16) fail("hs elemento")
                val ext = p + 16
                val nm = i32(b, ext + 4)
                if (nm !in 0 until st.size) fail("nombre de elemento fuera de rango")
                val aStart = u16(b, ext + 8); val aSize = u16(b, ext + 10); val aCount = u16(b, ext + 12)
                if (aStart != 20 || aSize != 20) fail("attributeStart/Size = $aStart/$aSize")
                if (sz != 16 + 20 + aCount * 20) fail("tamaño de elemento incoherente con $aCount atributos")
                val attrs = ArrayList<RAttr>()
                for (k in 0 until aCount) {
                    val ap = ext + aStart + k * aSize
                    val ns = i32(b, ap); val an = i32(b, ap + 4); val raw = i32(b, ap + 8)
                    if (ns != -1 && ns !in 0 until st.size) fail("ns de atributo")
                    if (an !in 0 until st.size) fail("nombre de atributo")
                    if (u16(b, ap + 12) != 8) fail("typedValue.size != 8")
                    if (b[ap + 14].toInt() != 0) fail("res0 != 0")
                    val ty = b[ap + 15].toInt() and 0xff
                    val data = i32(b, ap + 16)
                    var sv: String? = null
                    if (ty == 3) {
                        if (data !in 0 until st.size) fail("valor de cadena fuera de rango")
                        if (raw != data) fail("rawValue $raw != data $data en tipo cadena")
                        sv = st[data]
                    } else if (raw != -1) fail("rawValue != -1 en tipo $ty")
                    attrs.add(RAttr(if (ns == -1) null else st[ns], st[an], ty, data, raw, sv))
                }
                // los nombres de atributo con id de recurso deben seguir mapeando al mismo índice
                els.add(REl(st[nm], attrs))
                stack.add(st[nm])
            }
            0x0103 -> {
                val st = strings ?: fail("fin de elemento antes del pool")
                val nm = i32(b, p + 20)
                if (stack.isEmpty() || stack.removeAt(stack.size - 1) != st.getOrNull(nm)) fail("elemento sin cerrar/desbalanceado")
            }
            else -> fail("chunk desconocido 0x${type.toString(16)}")
        }
        p += sz
    }
    if (p != b.size) fail("el último chunk no cubre el archivo")
    if (strings == null) fail("sin string pool")
    if (stack.isNotEmpty()) fail("elementos sin cerrar")
    if (sawNs != 1 || endNs != 1) fail("namespaces")
    return RDoc(strings, resIds, els)
}

fun RDoc.attr(el: String, name: String, nth: Int = 0): RAttr? =
    els.filter { it.name == el }.getOrNull(nth)?.attrs?.firstOrNull { it.name == name }

fun resolveCls(n: String, pkg: String) = if (n.startsWith(".")) pkg + n else if (!n.contains('.')) "$pkg.$n" else n

// ===================================================================================================
// ZIP: análisis propio y estricto
// ===================================================================================================
class ZE(val name: String, val method: Int, val flags: Int, val crc: Long, val csize: Long, val usize: Long, val lho: Int, val dataStart: Int)
class ZipInfo(val bytes: ByteArray, val entries: List<ZE>, val cdOff: Int, val cdSize: Int, val eocd: Int, val problems: List<String>, val dataEnd: Int)

fun findEocd(b: ByteArray): Int {
    var p = b.size - 22
    while (p >= 0 && p >= b.size - 22 - 65535) {
        if (u32(b, p) == 0x06054b50L && u16(b, p + 20) == b.size - p - 22) return p
        p--
    }
    throw IllegalStateException("EOCD no encontrado")
}

fun parseZip(b: ByteArray): ZipInfo {
    val pr = ArrayList<String>()
    val eocd = findEocd(b)
    val n = u16(b, eocd + 10)
    if (u16(b, eocd + 8) != n || u16(b, eocd + 4) != 0 || u16(b, eocd + 6) != 0) pr.add("EOCD: discos/recuentos")
    val cdSize = u32(b, eocd + 12).toInt(); val cdOff = u32(b, eocd + 16).toInt()
    if (cdOff + cdSize > eocd) pr.add("CD se sale por encima del EOCD")
    val list = ArrayList<ZE>()
    var p = cdOff
    for (i in 0 until n) {
        if (u32(b, p) != 0x02014b50L) { pr.add("CD: firma inválida en entrada $i"); break }
        val flags = u16(b, p + 8); val method = u16(b, p + 10)
        val crc = u32(b, p + 16); val cs = u32(b, p + 20); val us = u32(b, p + 24)
        val nl = u16(b, p + 28); val el = u16(b, p + 30); val cl = u16(b, p + 32)
        val lho = u32(b, p + 42).toInt()
        val name = String(b, p + 46, nl, Charsets.UTF_8)
        if (u32(b, lho) != 0x04034b50L) { pr.add("local: firma inválida para $name"); p += 46 + nl + el + cl; continue }
        val lflags = u16(b, lho + 6); val lm = u16(b, lho + 8)
        val lcrc = u32(b, lho + 14); val lcs = u32(b, lho + 18); val lus = u32(b, lho + 22)
        val lnl = u16(b, lho + 26); val lel = u16(b, lho + 28)
        if (lflags != flags || lm != method || lcrc != crc || lcs != cs || lus != us) pr.add("local != CD en $name")
        if (flags and 0x8 != 0) pr.add("descriptor de datos en $name")
        if (String(b, lho + 30, lnl, Charsets.UTF_8) != name) pr.add("nombre local != CD en $name")
        // campos extra bien formados
        var q = lho + 30 + lnl; val qe = q + lel
        while (q < qe) { if (q + 4 > qe) { pr.add("extra truncado en $name"); break }; q += 4 + u16(b, q + 2) }
        if (q != qe) pr.add("extra mal formado en $name")
        list.add(ZE(name, method, flags, crc, cs, us, lho, lho + 30 + lnl + lel))
        p += 46 + nl + el + cl
    }
    if (p != cdOff + cdSize) pr.add("CD: tamaño declarado $cdSize no coincide con el recorrido")
    if (list.map { it.name }.toSet().size != list.size) pr.add("nombres duplicados en el zip")
    // las entradas deben ser contiguas desde el offset 0
    var expect = 0
    for (e in list.sortedBy { it.lho }) {
        if (e.lho != expect) pr.add("hueco/solape antes de ${e.name}: esperado $expect, real ${e.lho}")
        expect = (e.dataStart + e.csize).toInt()
    }
    return ZipInfo(b, list, cdOff, cdSize, eocd, pr, expect)
}

fun ZipInfo.entry(name: String) = entries.firstOrNull { it.name == name }
fun ZipInfo.content(e: ZE): ByteArray {
    val raw = bytes.copyOfRange(e.dataStart, (e.dataStart + e.csize).toInt())
    val data = if (e.method == 0) raw else {
        val inf = Inflater(true); inf.setInput(raw)
        val out = ByteArray(e.usize.toInt()); var n = 0
        while (n < out.size) { val r = inf.inflate(out, n, out.size - n); if (r == 0) break; n += r }
        if (out.isEmpty()) inf.inflate(ByteArray(1)) // entrada vacía: hay que consumir el bloque final para que finished() sea cierto
        if (n != out.size || !inf.finished()) throw IllegalStateException("inflate incompleto en ${e.name}")
        inf.end(); out
    }
    val c = CRC32(); c.update(data)
    if (c.value != e.crc) throw IllegalStateException("CRC incorrecto en ${e.name}")
    return data
}
fun ZipInfo.content(name: String): ByteArray? = entry(name)?.let { content(it) }

// ===================================================================================================
// Firma v2 (APK Signature Scheme v2): verificador propio según la especificación pública
// ===================================================================================================
class Cur(val b: ByteArray, var p: Int, val end: Int) {
    fun u32(): Int { if (p + 4 > end) throw IllegalStateException("lectura u32 fuera de rango"); val v = i32(b, p); p += 4; return v }
    fun lp(): ByteArray {
        val l = u32()
        if (l < 0 || p + l > end) throw IllegalStateException("prefijo de longitud inválido ($l)")
        val r = b.copyOfRange(p, p + l); p += l; return r
    }
    fun cur(): Cur { val x = lp(); return Cur(x, 0, x.size) }
    fun more() = p < end
}

fun chunkDigests(md: MessageDigest, data: ByteArray, off: Int, len: Int, out: ByteArrayOutputStream): Int {
    var n = 0; var p = off; val end = off + len
    while (p < end) {
        val l = minOf(1 shl 20, end - p)
        md.reset()
        md.update(0xa5.toByte()); md.update(ByteBuffer.allocate(4).order(LE).putInt(l).array()); md.update(data, p, l)
        out.write(md.digest()); p += l; n++
    }
    return n
}

/** Devuelve null si la firma v2 es válida, o la descripción del fallo. */
fun verifyV2(apk: ByteArray, expectCert: X509Certificate?): String? {
    try {
        val eocd = findEocd(apk)
        val cdSize = u32(apk, eocd + 12).toInt(); val cdOff = u32(apk, eocd + 16).toInt()
        if (cdOff + cdSize != eocd) return "el directorio central no termina en el EOCD"
        if (cdOff < 24) return "demasiado corto para un bloque"
        if (String(apk, cdOff - 16, 16, Charsets.US_ASCII) != "APK Sig Block 42") return "sin magic APK Sig Block 42 antes del CD"
        val size2 = u64(apk, cdOff - 24)
        val blockStart = cdOff - 8 - size2
        if (size2 < 24 || blockStart < 0) return "tamaño de bloque absurdo"
        val bs = blockStart.toInt()
        if (u64(apk, bs) != size2) return "los dos campos de tamaño del bloque difieren"
        var p = bs + 8; val pend = cdOff - 24
        var v2: ByteArray? = null
        while (p < pend) {
            val len = u64(apk, p)
            if (len < 4 || p + 8 + len > pend) return "par id-valor mal formado"
            val id = u32(apk, p + 8)
            if (id == 0x7109871aL) { if (v2 != null) return "dos bloques v2"; v2 = apk.copyOfRange(p + 12, (p + 8 + len).toInt()) }
            p += (8 + len).toInt()
        }
        if (p != pend) return "los pares no llenan el bloque"
        if (v2 == null) return "no hay par 0x7109871a"

        val signers = Cur(v2, 0, v2.size).cur()
        var nSigners = 0
        // digest esperado
        val md = MessageDigest.getInstance("SHA-256")
        val dg = ByteArrayOutputStream()
        var count = chunkDigests(md, apk, 0, bs, dg)
        count += chunkDigests(md, apk, cdOff, cdSize, dg)
        val eocdCopy = apk.copyOfRange(eocd, apk.size)
        ByteBuffer.wrap(eocdCopy).order(LE).putInt(16, bs)
        count += chunkDigests(md, eocdCopy, 0, eocdCopy.size, dg)
        md.reset(); md.update(0x5a.toByte()); md.update(ByteBuffer.allocate(4).order(LE).putInt(count).array()); md.update(dg.toByteArray())
        val expected = md.digest()

        while (signers.more()) {
            nSigners++
            val signer = signers.cur()
            val signedDataBytes = signer.lp()
            val sigs = signer.cur()
            val pub = signer.lp()
            if (signer.more()) return "bytes sobrantes en el signer"
            val sd = Cur(signedDataBytes, 0, signedDataBytes.size)
            val digests = sd.cur(); val certs = sd.cur(); val attrs = sd.lp()
            if (sd.more()) return "bytes sobrantes en signed data"
            if (attrs.isNotEmpty()) { /* atributos adicionales: permitidos */ }
            var digestOk = false
            val digestAlgs = HashSet<Int>()
            while (digests.more()) {
                val d = digests.cur(); val alg = d.u32(); val dv = d.lp()
                digestAlgs.add(alg)
                if (alg == 0x0103) { if (!dv.contentEquals(expected)) return "el digest del APK no coincide (contenido alterado)"; digestOk = true }
            }
            if (!digestOk) return "no hay digest 0x0103"
            var sigOk = false
            while (sigs.more()) {
                val s = sigs.cur(); val alg = s.u32(); val sv = s.lp()
                if (alg !in digestAlgs) return "firma con algoritmo $alg sin digest"
                if (alg == 0x0103) {
                    val sig = Signature.getInstance("SHA256withRSA")
                    sig.initVerify(KeyFactory.getInstance("RSA").generatePublic(X509EncodedKeySpec(pub)))
                    sig.update(signedDataBytes)
                    if (!sig.verify(sv)) return "la firma RSA de signed data no verifica"
                    sigOk = true
                }
            }
            if (!sigOk) return "no hay firma 0x0103"
            if (!certs.more()) return "sin certificados"
            val certBytes = certs.lp()
            val cert = CertificateFactory.getInstance("X.509").generateCertificate(ByteArrayInputStream(certBytes)) as X509Certificate
            if (!cert.publicKey.encoded.contentEquals(pub)) return "la clave pública del signer no coincide con la del certificado"
            if (expectCert != null && !certBytes.contentEquals(expectCert.encoded)) return "certificado distinto del esperado"
        }
        if (nSigners != 1) return "signers=$nSigners"
        return null
    } catch (t: Throwable) {
        return "excepción verificando v2: $t"
    }
}

// ===================================================================================================
// Firma v1 (JAR): verificación propia + JarFile + jarsigner
// ===================================================================================================
class Der(val tag: Int, val begin: Int, val start: Int, val end: Int)
fun der(b: ByteArray, p: Int): Der {
    val tag = b[p].toInt() and 0xff
    val l = b[p + 1].toInt() and 0xff
    var q = p + 2; var len = l
    if (l and 0x80 != 0) { val n = l and 0x7f; len = 0; repeat(n) { len = (len shl 8) or (b[q++].toInt() and 0xff) } }
    if (q + len > b.size) throw IllegalStateException("DER truncado")
    return Der(tag, p, q, q + len)
}
fun derKids(b: ByteArray, t: Der): List<Der> {
    val r = ArrayList<Der>(); var p = t.start
    while (p < t.end) { val k = der(b, p); r.add(k); p = k.end }
    if (p != t.end) throw IllegalStateException("DER hijos no cuadran")
    return r
}

fun sections(raw: ByteArray): List<ByteArray> { // cada sección incluye su línea en blanco final
    val s = String(raw, Charsets.ISO_8859_1)
    val res = ArrayList<ByteArray>(); var from = 0
    while (true) {
        val i = s.indexOf("\r\n\r\n", from)
        if (i < 0) break
        res.add(raw.copyOfRange(from, i + 4)); from = i + 4
    }
    if (from != raw.size) throw IllegalStateException("el archivo no termina en línea en blanco")
    return res
}
fun sectionName(sec: ByteArray): String? {
    val unfolded = String(sec, Charsets.ISO_8859_1).replace("\r\n ", "")
    val line = unfolded.split("\r\n").firstOrNull { it.startsWith("Name: ") } ?: return null
    return String(line.substring(6).toByteArray(Charsets.ISO_8859_1), Charsets.UTF_8)
}

fun verifyV1(zi: ZipInfo, expectCert: X509Certificate): String? {
    try {
        val mf = zi.content("META-INF/MANIFEST.MF") ?: return "sin MANIFEST.MF"
        val sf = zi.content("META-INF/CERT.SF") ?: return "sin CERT.SF"
        val rsa = zi.content("META-INF/CERT.RSA") ?: return "sin CERT.RSA"
        for ((nm, raw) in listOf("MF" to mf, "SF" to sf)) {
            if (raw.any { it == '\n'.code.toByte() && false }) return "?"
            var lineStart = 0
            val str = String(raw, Charsets.ISO_8859_1)
            for (ln in str.split("\r\n")) {
                if (ln.length > 72) return "línea de más de 72 bytes en $nm: ${ln.length}"
                lineStart += ln.length + 2
            }
            if (str.replace("\r\n", "").contains('\n') || str.replace("\r\n", "").contains('\r')) return "saltos de línea sueltos en $nm"
        }
        val signed = zi.entries.map { it.name }.filter { it != "META-INF/MANIFEST.MF" && it != "META-INF/CERT.SF" && it != "META-INF/CERT.RSA" }
        val man = Manifest(ByteArrayInputStream(mf))
        if (man.entries.keys.toSet() != signed.toSet()) return "MANIFEST.MF no cubre exactamente las entradas (mf=${man.entries.size}, zip=${signed.size})"
        for (nm in signed) {
            val d = man.entries[nm]!!.getValue("SHA-256-Digest") ?: return "sin digest para $nm"
            if (d != b64(sha256(zi.content(nm)!!))) return "digest incorrecto en MANIFEST.MF para $nm"
        }
        val msecs = sections(mf)
        if (msecs.size != signed.size + 1) return "secciones MF=${msecs.size}"
        val mfByName = HashMap<String, String>()
        for (s in msecs.drop(1)) mfByName[sectionName(s)!!] = b64(sha256(s))
        val sfMan = Manifest(ByteArrayInputStream(sf))
        if (sfMan.mainAttributes.getValue("SHA-256-Digest-Manifest") != b64(sha256(mf))) return "SHA-256-Digest-Manifest incorrecto"
        if (sfMan.mainAttributes.getValue("Signature-Version") != "1.0") return "Signature-Version"
        if (sfMan.entries.size != signed.size) return "CERT.SF cubre ${sfMan.entries.size} entradas, hay ${signed.size}"
        for ((nm, at) in sfMan.entries) if (at.getValue("SHA-256-Digest") != mfByName[nm]) return "digest de sección incorrecto en CERT.SF para $nm"
        // PKCS#7
        val top = der(rsa, 0)
        if (top.tag != 0x30 || top.end != rsa.size) return "PKCS7: raíz"
        val tk = derKids(rsa, top)
        val sdWrap = tk[1]; if (sdWrap.tag != 0xA0) return "PKCS7: falta [0]"
        val sd = derKids(rsa, sdWrap)[0]
        val sdk = derKids(rsa, sd)
        // version, digestAlgs, contentInfo, [0] certs, signerInfos
        if (sdk.size != 5 || sdk[3].tag != 0xA0 || sdk[4].tag != 0x31) return "PKCS7: estructura SignedData (${sdk.map { it.tag }})"
        val certTlv = derKids(rsa, sdk[3])[0]
        val certBytes = rsa.copyOfRange(certTlv.begin, certTlv.end)
        if (!certBytes.contentEquals(expectCert.encoded)) return "certificado en CERT.RSA distinto"
        val si = derKids(rsa, derKids(rsa, sdk[4])[0])
        if (si.size != 5) return "SignerInfo con ${si.size} campos"
        val sigTlv = si[4]; if (sigTlv.tag != 0x04) return "SignerInfo: firma no es OCTET STRING"
        val sigBytes = rsa.copyOfRange(sigTlv.start, sigTlv.end)
        val v = Signature.getInstance("SHA256withRSA"); v.initVerify(expectCert.publicKey); v.update(sf)
        if (!v.verify(sigBytes)) return "firma PKCS7 sobre CERT.SF no verifica"
        // issuer y serie del SignerInfo coinciden con el certificado
        val iss = derKids(rsa, si[1])
        if (!rsa.copyOfRange(iss[0].begin, iss[0].end).contentEquals(expectCert.issuerX500Principal.encoded)) return "issuer del SignerInfo distinto"
        if (java.math.BigInteger(rsa.copyOfRange(iss[1].start, iss[1].end)) != expectCert.serialNumber) return "serie del SignerInfo distinta"
        if (sfMan.mainAttributes.getValue("X-Android-APK-Signed") != "2") return "falta X-Android-APK-Signed: 2 (protección contra rollback de v2)"
        return null
    } catch (t: Throwable) { return "excepción verificando v1: $t" }
}

fun jarFileCheck(f: File, cert: X509Certificate): String? {
    try {
        JarFile(f, true).use { jf ->
            val buf = ByteArray(8192)
            for (e in jf.entries().asSequence().toList()) {
                jf.getInputStream(e).use { s -> while (s.read(buf) >= 0) { } }
                if (e.isDirectory || e.name.startsWith("META-INF/") && (e.name.endsWith(".MF") || e.name.endsWith(".SF") || e.name.endsWith(".RSA"))) continue
                val cs = e.codeSigners ?: return "entrada sin firmar según JarFile: ${e.name}"
                if (cs.size != 1 || (cs[0].signerCertPath.certificates[0] as X509Certificate).encoded.contentEquals(cert.encoded).not()) return "firmante inesperado en ${e.name}"
            }
        }
        return null
    } catch (t: Throwable) { return "JarFile: $t" }
}

fun run(vararg cmd: String): Pair<Int, String> {
    val pb = ProcessBuilder(*cmd).redirectErrorStream(true)
    val pr = pb.start()
    val out = pr.inputStream.readBytes().toString(Charsets.UTF_8)
    return Pair(pr.waitFor(), out)
}
val jarsignerBin = File(System.getProperty("java.home"), "bin/jarsigner").path
fun jarsignerOk(f: File): Pair<Boolean, String> {
    val (code, out) = run(jarsignerBin, "-verify", f.path)
    return Pair(code == 0 && out.contains("jar verified"), out.lines().take(6).joinToString(" | "))
}

// ===================================================================================================
// Plantilla sintética
// ===================================================================================================
class Tpl(val file: File, val manifest: ByteArray, val contents: Map<String, ByteArray>)

fun randBytes(n: Int, seed: Long): ByteArray = ByteArray(n).also { Random(seed).nextBytes(it) }

fun makeTemplate(file: File, utf8Pool: Boolean, label: String? = "Motor 2D", relNames: Boolean = true,
                 withVersionName: Boolean = true, bigStored: Int = 0): Tpl {
    val man = buildAxml(manifestTree(label, "1.0", relNames, withVersionName), utf8Pool)
    val dex = "dex\n035\u0000".toByteArray() + randBytes(3000, 1)
    val contents = linkedMapOf<String, ByteArray>(
        "AndroidManifest.xml" to man,
        "resources.arsc" to randBytes(1001, 2),
        "classes.dex" to dex,
        "lib/arm64-v8a/libx.so" to ("\u007fELF".toByteArray() + randBytes(5003, 3)),
        "res/drawable/ic_launcher.png" to randBytes(777, 4),
        "assets/a.txt" to "hola ñandú".toByteArray(),
        "META-INF/version.properties" to "version=1\n".toByteArray(),
        "META-INF/MANIFEST.MF" to "Manifest-Version: 1.0\r\nFAKE-OLD-SIGNATURE: yes\r\n\r\n".toByteArray(),
        "META-INF/CERT.SF" to "Signature-Version: 1.0\r\nFAKE-OLD-SIGNATURE: yes\r\n\r\n".toByteArray(),
        "META-INF/CERT.RSA" to "FAKE-OLD-SIGNATURE".toByteArray(),
        "META-INF/OLD.DSA" to "FAKE-OLD-SIGNATURE".toByteArray()
    )
    if (bigStored > 0) contents["res/raw/big.bin"] = randBytes(bigStored, 9)
    val stored = setOf("resources.arsc", "lib/arm64-v8a/libx.so", "res/drawable/ic_launcher.png", "res/raw/big.bin")
    ZipOutputStream(file.outputStream().buffered()).use { z ->
        z.putNextEntry(ZipEntry("assets/")); z.closeEntry()
        for ((n, d) in contents) {
            val e = ZipEntry(n)
            if (n in stored) {
                e.method = ZipEntry.STORED; e.size = d.size.toLong(); e.compressedSize = d.size.toLong()
                val c = CRC32(); c.update(d); e.crc = c.value
            } else e.method = ZipEntry.DEFLATED
            z.putNextEntry(e); z.write(d); z.closeEntry()
        }
        // una .so deflactada (no se alinea) y otra entrada con nombre unicode
        val e = ZipEntry("lib/armeabi-v7a/liby.so"); e.method = ZipEntry.DEFLATED
        z.putNextEntry(e); z.write(randBytes(100, 5)); z.closeEntry()
    }
    contents["lib/armeabi-v7a/liby.so"] = randBytes(100, 5)
    return Tpl(file, man, contents)
}

fun doExport(tpl: File, extras: Map<String, ByteArray>, cfg: ExportConfig, key: PrivateKey, cert: X509Certificate): ByteArray {
    val bo = ByteArrayOutputStream()
    ApkExporter.export(tpl, bo, extras, cfg, key, cert)
    return bo.toByteArray()
}

fun cfgOf(pkg: String, label: String, ver: String = "1.0") =
    ExportConfig(packageName = pkg, appName = label, versionName = ver, oldPackageName = OLD, oldAppName = "Motor 2D")

// ===================================================================================================
// Comprobación completa de un APK exportado
// ===================================================================================================
fun verifyApk(tag: String, apk: ByteArray, work: File, tpl: Tpl, extras: Map<String, ByteArray>, cfg: ExportConfig,
              cert: X509Certificate, jar: Boolean, templateHasLabel: Boolean = true) {
    val f = File(work, "out_${tag.replace(Regex("[^A-Za-z0-9]"), "_")}.apk")
    f.writeBytes(apk)
    // (a) zip válido
    guard("$tag: zip") {
        val zi = parseZip(apk)
        checkNull("$tag: estructura zip (CD, locales, contiguidad, sin duplicados)", zi.problems.firstOrNull())
        var allOk = true
        for (e in zi.entries) try { zi.content(e) } catch (t: Throwable) { allOk = false; println("   ${t.message}") }
        check("$tag: todas las entradas se descomprimen con CRC correcto", allOk)
        guard("$tag: java.util.zip.ZipFile") {
            ZipFile(f).use { z -> var n = 0; for (e in z.entries()) { z.getInputStream(e).readBytes(); n++ }; check("$tag: ZipFile lee ${n} entradas", n == zi.entries.size) }
        }
        val py = run("python3", "-I", "-c", "import zipfile,sys; z=zipfile.ZipFile(sys.argv[1]); print('BAD' if z.testzip() else 'GOOD', len(z.namelist()))", f.path)
        check("$tag: python zipfile.testzip", py.second.startsWith("GOOD"))
        check("$tag: el relleno de datos termina justo donde empieza el bloque de firma", zi.dataEnd == zi.cdOff - (u64(apk, zi.cdOff - 24) + 8).toInt())
        // (c) extras y firma antigua
        var extrasOk = true
        for ((n, d) in extras) { val c = zi.content(n); if (c == null || !c.contentEquals(d)) { extrasOk = false; println("   extra mal: $n") } }
        check("$tag: ${extras.size} extras presentes e idénticos", extrasOk)
        val sigNames = zi.entries.map { it.name }.filter { it.startsWith("META-INF/") }.toSet()
        check("$tag: META-INF = firma nueva + version.properties (${sigNames.sorted()})",
            sigNames == setOf("META-INF/MANIFEST.MF", "META-INF/CERT.SF", "META-INF/CERT.RSA", "META-INF/version.properties"))
        check("$tag: firma antigua descartada", zi.entries.none { String(zi.content(it)!!, Charsets.ISO_8859_1).contains("FAKE-OLD-SIGNATURE") })
        check("$tag: sin entradas de directorio", zi.entries.none { it.name.endsWith("/") })
        var kept = true
        for ((n, d) in tpl.contents) {
            if (n == "AndroidManifest.xml" || n.startsWith("META-INF/") || n in extras) continue
            val c = zi.content(n); if (c == null || !c.contentEquals(d)) { kept = false; println("   plantilla perdida: $n") }
        }
        check("$tag: entradas de la plantilla (dex, arsc, .so, res, assets) intactas", kept)
        check("$tag: META-INF/version.properties conservado", zi.content("META-INF/version.properties")?.contentEquals(tpl.contents["META-INF/version.properties"]!!) == true)
        // (d) alineación
        var align = true
        for (e in zi.entries) if (e.method == 0) {
            val a = if (e.name.endsWith(".so")) 4096 else 4
            if (e.dataStart % a != 0) { align = false; println("   desalineada: ${e.name} dataStart=${e.dataStart} (a=$a)") }
        }
        check("$tag: STORED alineados (.so a 4096, resto a 4)", align)
        check("$tag: resources.arsc STORED", zi.entry("resources.arsc")?.method == 0)
        check("$tag: libx.so STORED y alineada a 4096", zi.entry("lib/arm64-v8a/libx.so").let { it != null && it.method == 0 && it.dataStart % 4096 == 0 })
        // (b) manifiesto
        guard("$tag: manifiesto") { verifyManifest(tag, zi.content("AndroidManifest.xml")!!, tpl, cfg, templateHasLabel) }
        // (e) v1
        checkNull("$tag: firma v1 (verificación propia de MF/SF/RSA)", verifyV1(zi, cert))
        checkNull("$tag: firma v1 vía JarFile del JDK", jarFileCheck(f, cert))
        if (jar) { val (ok, msg) = jarsignerOk(f); check("$tag: jarsigner -verify ($msg)", ok) }
    }
    // (f) v2
    checkNull("$tag: firma v2 (verificación propia)", verifyV2(apk, cert))
}

fun verifyManifest(tag: String, newM: ByteArray, tpl: Tpl, cfg: ExportConfig, hadLabel: Boolean) {
    val o = parseAxml(tpl.manifest)
    val n = parseAxml(newM)
    val pkg = cfg.packageName
    check("$tag: AXML parchado se relee y es estructuralmente válido", true)
    check("$tag: mismos elementos en el mismo orden", o.els.map { it.name } == n.els.map { it.name })
    check("$tag: resource map idéntico", o.resIds == n.resIds)
    check("$tag: nombres de atributo con id de recurso en los mismos índices", n.strings.take(o.resIds.size) == o.strings.take(o.resIds.size))
    check("$tag: package = ${pkg.take(40)}", n.attr("manifest", "package")?.str == pkg && n.attr("manifest", "package")?.ns == null)
    check("$tag: label = '${cfg.appName.take(20)}'", n.attr("application", "label")?.let { it.type == 3 && it.str == cfg.appName } == true)
    check("$tag: versionName = ${cfg.versionName}", n.attr("manifest", "versionName")?.str == cfg.versionName)
    check("$tag: versionCode/minSdk/icon/theme/exported intactos",
        n.attr("manifest", "versionCode")?.let { it.type == 0x10 && it.data == 1 } == true &&
            n.attr("uses-sdk", "minSdkVersion")?.let { it.type == 0x10 && it.data == 24 } == true &&
            n.attr("application", "icon")?.let { it.type == 1 && it.data == 0x7f080000 } == true &&
            n.attr("application", "theme")?.let { it.type == 1 && it.data == 0x7f0f0001 } == true &&
            n.attr("activity", "exported")?.let { it.type == 0x12 && it.data == -1 } == true &&
            n.attr("provider", "exported")?.let { it.type == 0x12 && it.data == 0 } == true)
    // nombres de clase: lo que Android resolvería con el paquete NUEVO debe ser la clase de la plantilla (resuelta con el VIEJO)
    for (k in 0..1) {
        val oc = resolveCls(o.attr("activity", "name", k)!!.str!!, OLD)
        val nc = resolveCls(n.attr("activity", "name", k)!!.str!!, pkg)
        check("$tag: activity #$k resuelve a $oc (resuelve a $nc con el paquete nuevo)", oc == nc)
    }
    check("$tag: provider InitializationProvider intacto", n.attr("provider", "name")?.str == "androidx.startup.InitializationProvider")
    check("$tag: permiso propio y uses-permission propio con el paquete nuevo",
        n.attr("permission", "name")?.str == "$pkg.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION" &&
            n.attr("uses-permission", "name", 0)?.str == "$pkg.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION")
    check("$tag: permiso ajeno android.permission.VIBRATE intacto", n.attr("uses-permission", "name", 1)?.str == "android.permission.VIBRATE")
    check("$tag: authorities con el paquete nuevo", n.attr("provider", "authorities")?.str == "$pkg.androidx-startup")
    check("$tag: meta-data con '1.0' compartido NO cambia", n.attr("meta-data", "value")?.str == "1.0" && n.attr("meta-data", "name")?.str == "ver")
    check("$tag: intent-filter MAIN/LAUNCHER intacto",
        n.attr("action", "name")?.str == "android.intent.action.MAIN" && n.attr("category", "name")?.str == "android.intent.category.LAUNCHER")
    check("$tag: ninguna cadena del pool usa ya el paquete viejo como valor de atributo",
        // (los nombres de clase de activity/application conservan el paquete viejo A PROPÓSITO: es donde está el código)
        n.els.flatMap { e -> e.attrs.filter { !(it.name == "name" && e.name in setOf("application", "activity", "activity-alias", "service", "receiver")) } }
            .none { it.type == 3 && (it.str == OLD || it.str!!.startsWith("$OLD.")) && !(pkg == OLD) })
}

// ===================================================================================================
// Claves
// ===================================================================================================
fun genKey(dir: File, alg: String, size: Int, name: String): Pair<PrivateKey, X509Certificate> {
    val ks = File(dir, "$name.p12"); ks.delete()
    val (c, out) = run("keytool", "-genkeypair", "-alias", "k", "-keyalg", alg, "-keysize", size.toString(), "-validity", "10000",
        "-dname", "CN=Test $name", "-keystore", ks.path, "-storetype", "PKCS12", "-storepass", "password", "-keypass", "password")
    if (c != 0) throw IllegalStateException("keytool: $out")
    val k = KeyStore.getInstance("PKCS12"); ks.inputStream().use { k.load(it, "password".toCharArray()) }
    return Pair(k.getKey("k", "password".toCharArray()) as PrivateKey, k.getCertificate("k") as X509Certificate)
}

fun flip(b: ByteArray, pos: Int): ByteArray { val c = b.copyOf(); c[pos] = (c[pos].toInt() xor 0x01).toByte(); return c }

// ===================================================================================================
fun main(args: Array<String>) {
    val work = File(args[0]).also { it.mkdirs() }
    val keyDir = File(args[1])
    val (key, cert) = ExportKeys.load(File(keyDir, "key.pk8").readBytes(), File(keyDir, "cert.der").readBytes())
    check("clave y certificado de prueba cargan", key.algorithm == "RSA")

    // ------------------------------------------------------------------ AXML de la propia prueba
    for (u8 in listOf(false, true)) {
        val m = buildAxml(manifestTree("Motor 2D"), u8)
        guard("autoprueba AXML utf8=$u8") {
            val d = parseAxml(m)
            check("autoprueba: lector lee mi AXML (utf8=$u8, ${d.strings.size} cadenas, ${d.els.size} elementos)", d.attr("application", "label")?.str == "Motor 2D")
        }
    }

    // ------------------------------------------------------------------ matriz paquete/etiqueta x pool UTF-16/UTF-8
    val label200 = "Ñ".repeat(100) + "🎮".repeat(50) // 100 + 100 unidades UTF-16 (200 > 127), 400 bytes UTF-8
    val scenarios = listOf(
        Triple("base", "com.motor2d.game.demo", "Mi Juego"),
        Triple("mismoLargo", "com.motor2d.engine3d", "Mi Juego"),
        Triple("corto", "com.a.b", "J"),
        Triple("largo", "com.motor2d.game." + "x".repeat(180), "Mi Juego"),
        Triple("acentos", "com.motor2d.game.nino", "Niño Ágil ñandú — çüé"),
        Triple("emoji", "com.motor2d.game.emoji", "🎮 Súper Juego 🚀👨‍👩‍👧"),
        Triple("etiqueta200", "com.motor2d.game.l200", label200),
        Triple("xml", "com.motor2d.game.xml", "<A&B> \"q\" 'r'"),
        Triple("igualAlViejo", OLD, "Motor 2D"),
        Triple("ceroCambio", "com.motor2d.engine2d", "Otro")
    )
    for (u8 in listOf(false, true)) {
        val pool = if (u8) "u8" else "u16"
        val tpl = makeTemplate(File(work, "tpl_$pool.apk"), u8)
        for ((nm, pkg, label) in scenarios) guard("$pool/$nm") {
            val cfg = cfgOf(pkg, label, if (nm == "acentos") "1.0-ñ" else "2.${nm.length}.7")
            val extras = linkedMapOf(
                "assets/game/project.json" to "{\"a\":1}".toByteArray(),
                "assets/game/img/ñandú_🎮.png" to randBytes(5000, 7),
                "assets/game/" + "d".repeat(40) + "/" + "f".repeat(100) + ".bin" to randBytes(300, 8),
                "assets/a.txt" to "sustituido".toByteArray()
            )
            val apk = doExport(tpl.file, extras, cfg, key, cert)
            verifyApk("$pool/$nm", apk, work, tpl, extras, cfg, cert, jar = nm in setOf("base", "emoji", "etiqueta200", "largo", "corto"))
        }
    }

    // ------------------------------------------------------------------ extras de varios tamaños y cruce del límite de 1 MB
    run {
        val tpl = makeTemplate(File(work, "tpl_big.apk"), false)
        val sizes = listOf(0, 1, 4095, 4096, 4097, 65535, (1 shl 20) - 1, 1 shl 20, (1 shl 20) + 1, 2_500_000, 3 shl 20)
        val extras = LinkedHashMap<String, ByteArray>()
        for (s in sizes) extras["assets/game/sz_$s.bin"] = randBytes(s, s.toLong())
        extras["assets/game/zeros.bin"] = ByteArray(2_000_000) // muy compresible
        val cfg = cfgOf("com.motor2d.game.big", "Grande")
        guard("tamaños") {
            val apk = doExport(tpl.file, extras, cfg, key, cert)
            println("   (APK de ${apk.size} bytes)")
            verifyApk("tamaños", apk, work, tpl, extras, cfg, cert, jar = true)
        }
    }
    // el bloque de datos termina exactamente en múltiplos de 1 MB (y +-1)
    for ((label, target) in listOf("1MB" to (1 shl 20), "1MB-1" to (1 shl 20) - 1, "1MB+1" to (1 shl 20) + 1, "2MB" to (2 shl 20), "3MB+1" to (3 shl 20) + 1)) guard("frontera $label") {
        val extras = mapOf("assets/game/p.json" to "{}".toByteArray())
        val cfg = cfgOf("com.motor2d.game.edge", "Borde")
        var s = target - 12000
        var hit = false; var last: ByteArray? = null; var lastTpl: Tpl? = null; var lastEx: Map<String, ByteArray> = extras
        // la sección de entradas es s + constante + relleno de alineación (saw-tooth); se apunta un poco por debajo y se ajusta
        // el último byte con la longitud del nombre de un extra de relleno (deflactado, sin alineación)
        for (iter in 0 until 12) {
            val tpl = makeTemplate(File(work, "tpl_edge.apk"), false, bigStored = s)
            val apk0 = doExport(tpl.file, extras, cfg, key, cert)
            val zi0 = parseZip(apk0)
            val start0 = zi0.cdOff - (u64(apk0, zi0.cdOff - 24) + 8).toInt()
            val gap = target - start0
            if (gap in 150..320) {
                // la longitud de nombre cambia también el MANIFEST.MF deflactado (no lineal): se barre g hasta caer exacto
                for (ds in 0..6) {
                    val tpl2 = if (ds == 0) tpl else makeTemplate(File(work, "tpl_edge.apk"), false, bigStored = s + ds)
                    for (g in 0..160) {
                        val ex2 = LinkedHashMap(extras); ex2["assets/game/pad" + "x".repeat(g)] = ByteArray(0)
                        val apk = doExport(tpl2.file, ex2, cfg, key, cert)
                        val z = parseZip(apk); val st = z.cdOff - (u64(apk, z.cdOff - 24) + 8).toInt()
                        last = apk; lastTpl = tpl2; lastEx = LinkedHashMap(ex2);
                        if (st == target) { hit = true; break }
                        if (st > target) break
                    }
                    if (hit) break
                }
                if (hit) break
            }
            s += (target - 235) - start0
            if (s < 0) s = 0
        }
        if (last == null) { val tpl = makeTemplate(File(work, "tpl_edge.apk"), false, bigStored = s); last = doExport(tpl.file, extras, cfg, key, cert); lastTpl = tpl }
        println("   (sección 1 ${if (hit) "= exactamente" else "NO exacta, cerca de"} $target)")
        check("frontera $label: sección de entradas con longitud exacta alcanzada", hit)
        verifyApk("frontera_$label", last!!, work, lastTpl!!, lastEx, cfg, cert, jar = false)
    }
    // directorio central > 1 MB (muchas entradas pequeñas)
    guard("CD grande") {
        val tpl = makeTemplate(File(work, "tpl_cd.apk"), false)
        val extras = LinkedHashMap<String, ByteArray>()
        for (i in 0 until 16000) extras["assets/game/scenes/scene_number_%05d.json".format(i)] = "{\"i\":$i}".toByteArray()
        val cfg = cfgOf("com.motor2d.game.many", "Muchos")
        val apk = doExport(tpl.file, extras, cfg, key, cert)
        val zi = parseZip(apk)
        println("   (CD de ${zi.cdSize} bytes, ${zi.entries.size} entradas)")
        check("CD grande: el directorio central supera 1 MB", zi.cdSize > (1 shl 20))
        verifyApk("CDgrande", apk, work, tpl, extras, cfg, cert, jar = false)
    }

    // ------------------------------------------------------------------ otra clave (RSA 3072 generada con keytool) y re-exportación
    guard("clave 3072") {
        val (k2, c2) = genKey(work, "RSA", 3072, "rsa3072")
        val tpl = makeTemplate(File(work, "tpl_k2.apk"), true)
        val extras = mapOf("assets/game/x.bin" to randBytes(1500000, 11))
        val cfg = cfgOf("com.motor2d.game.k2", "Clave Dos")
        val apk = doExport(tpl.file, extras, cfg, k2, c2)
        verifyApk("rsa3072", apk, work, tpl, extras, cfg, c2, jar = true)
        check("rsa3072: el certificado esperado NO es el de prueba (la verificación distingue)", verifyV2(apk, cert) != null)

        // re-exportación: el APK exportado vuelve a usarse como plantilla (ya trae firma y bloque v2)
        val f1 = File(work, "reexport_in.apk"); f1.writeBytes(apk)
        val cfg2 = ExportConfig("com.motor2d.game.again", "Otra Vez", "3.0", oldPackageName = "com.motor2d.game.k2", oldAppName = "Clave Dos")
        val apk2 = doExport(f1, mapOf("assets/game/y.txt" to "y".toByteArray()), cfg2, key, cert)
        val f2 = File(work, "reexport_out.apk"); f2.writeBytes(apk2)
        val zi2 = parseZip(apk2)
        checkNull("re-export: zip válido", zi2.problems.firstOrNull())
        checkNull("re-export: v1", verifyV1(zi2, cert))
        checkNull("re-export: v2", verifyV2(apk2, cert))
        check("re-export: jarsigner", jarsignerOk(f2).first)
        val m2 = parseAxml(zi2.content("AndroidManifest.xml")!!)
        check("re-export: paquete y etiqueta nuevos", m2.attr("manifest", "package")?.str == "com.motor2d.game.again" && m2.attr("application", "label")?.str == "Otra Vez" && m2.attr("manifest", "versionName")?.str == "3.0")
        check("re-export: la clase de la activity sigue resolviéndose a la original",
            resolveCls(m2.attr("activity", "name", 0)!!.str!!, "com.motor2d.game.again") == "$OLD.app.MainActivity")
        check("re-export: contenido previo conservado y extra nuevo", zi2.content("assets/game/x.bin")!!.contentEquals(extras.getValue("assets/game/x.bin")) && zi2.content("assets/game/y.txt") != null)
    }
    guard("clave EC y desajustada") {
        val (kec, cec) = genKey(work, "EC", 256, "ec256")
        val tpl = makeTemplate(File(work, "tpl_ec.apk"), false)
        val bo = ByteArrayOutputStream()
        val r = runCatching { ApkExporter.export(tpl.file, bo, emptyMap(), cfgOf("com.motor2d.game.ec", "EC"), kec, cec) }
        check("clave EC rechazada con IllegalArgumentException y sin salida", r.exceptionOrNull() is IllegalArgumentException && bo.size() == 0)
        val (kr, _) = genKey(work, "RSA", 2048, "rsaA")
        val (_, cr) = genKey(work, "RSA", 2048, "rsaB")
        val r2 = runCatching { ExportKeys.load(kr.encoded, cr.encoded) }
        check("ExportKeys.load rechaza clave que no corresponde al certificado", r2.exceptionOrNull() is IllegalArgumentException)
        val r3 = runCatching { ExportKeys.load(ByteArray(10), cert.encoded) }
        check("ExportKeys.load rechaza clave basura", r3.isFailure)
    }

    // ------------------------------------------------------------------ manipulación: v2 debe FALLAR
    guard("manipulación") {
        val tpl = makeTemplate(File(work, "tpl_t.apk"), false)
        val extras = mapOf("assets/game/big.bin" to randBytes(2_500_000, 5), "assets/game/s.txt" to "hola".toByteArray())
        val cfg = cfgOf("com.motor2d.game.tamper", "Manip")
        val apk = doExport(tpl.file, extras, cfg, key, cert)
        checkNull("manipulación: original válido en v2", verifyV2(apk, cert))
        val zi = parseZip(apk)
        val arsc = zi.entry("resources.arsc")!!
        val big = zi.entry("assets/game/big.bin")!!
        val blockStart = zi.dataEnd
        val tamper = listOf(
            "byte de resources.arsc (STORED)" to arsc.dataStart + 10,
            "byte del primer MB del extra grande" to big.dataStart + 1000,
            "byte del segundo MB del extra grande" to big.dataStart + (1 shl 20) + 5000,
            "byte del tercer MB (último trozo parcial) del extra grande" to big.dataStart + (2 * (1 shl 20)) + 100,
            "cabecera local de una entrada" to zi.entry("classes.dex")!!.lho + 3,
            "nombre en el directorio central" to zi.cdOff + 46 + 2,
            "campo de recuento del EOCD" to zi.eocd + 10,
            "bloque de firma: firma RSA" to blockStart + 8 + 12 + 300,
            "bloque de firma: digest" to blockStart + 8 + 12 + 4 + 4 + 4 + 4 + 4 + 4 + 8
        )
        for ((n, pos) in tamper) {
            val bad = flip(apk, pos)
            val r = verifyV2(bad, cert)
            check("v2 falla al modificar $n (pos $pos): ${r ?: "NO DETECTADO"}".take(110), r != null)
        }
        // truncar o añadir basura tras el EOCD
        check("v2 falla con bytes añadidos tras el EOCD", verifyV2(apk + byteArrayOf(0), cert) != null)
        // el zip sigue siendo legible pese a manipular STORED (v1 y JarFile deben detectarlo)
        val bad = flip(apk, arsc.dataStart + 10)
        val fb = File(work, "tampered.apk"); fb.writeBytes(bad)
        check("v1 (JarFile) detecta resources.arsc alterado", jarFileCheck(fb, cert) != null)
        check("jarsigner detecta resources.arsc alterado", !jarsignerOk(fb).first)
        check("verificador v1 propio detecta resources.arsc alterado", verifyV1(parseZip(bad), cert) != null)
    }

    // ------------------------------------------------------------------ errores
    run {
        val tpl = makeTemplate(File(work, "tpl_err.apk"), false)
        fun expectIAE(name: String, extras: Map<String, ByteArray> = emptyMap(), cfg: ExportConfig = cfgOf("com.motor2d.game.ok", "Ok"),
                      template: File = tpl.file, k: PrivateKey = key) {
            val bo = ByteArrayOutputStream()
            val r = runCatching { ApkExporter.export(template, bo, extras, cfg, k, cert) }
            val e = r.exceptionOrNull()
            check("rechaza $name (${e?.javaClass?.simpleName}: ${e?.message?.take(60)}) sin escribir nada", e is IllegalArgumentException && bo.size() == 0)
        }
        for (p in listOf("foo", "", "Com.Foo.bar", "com.1abc", "com.class.x", "com..x", "com.x.", ".com.x", "com.motor2d.é", "com.motor2d.a-b",
            "com.motor2d.a b", "com.${"a".repeat(260)}", "a.b\u0000", "com.motor2d.game.x\n", "com.new.x", "com._x.y"))
            expectIAE("paquete inválido '${p.replace("\n", "\\n").replace("\u0000", "\\0").take(24)}'", cfg = cfgOf(p, "Ok"))
        for (n in listOf("../x", "a/../b", "/abs/x", "..", "a/./b", "a//b", "dir/", "a\\b", "META-INF/x.SF", "META-INF/MANIFEST.MF", "META-INF/a/b",
            "AndroidManifest.xml", "", "a\u0000b", "assets/x\r\nName: evil\r\nSHA-256-Digest: AAAA", "assets/x\ny", "assets/tab\tx", "assets/\u007fx"))
            expectIAE("extra peligroso '${n.replace("\r", "\\r").replace("\n", "\\n").replace("\u0000", "\\0").replace("\t", "\\t").take(30)}'", extras = mapOf(n to byteArrayOf(1)))
        expectIAE("appName vacío", cfg = cfgOf("com.motor2d.game.ok", ""))
        expectIAE("appName con NUL", cfg = cfgOf("com.motor2d.game.ok", "a\u0000b"))
        expectIAE("appName con salto de línea", cfg = cfgOf("com.motor2d.game.ok", "a\nb"))
        expectIAE("versionName con NUL", cfg = cfgOf("com.motor2d.game.ok", "Ok", "1\u00002"))
        expectIAE("oldPackageName vacío", cfg = ExportConfig("com.motor2d.game.ok", "Ok", "1.0", "", "Motor 2D"))
        expectIAE("oldPackageName que no está en el manifiesto", cfg = ExportConfig("com.motor2d.game.ok", "Ok", "1.0", "com.otra.cosa", "Motor 2D"))
        val noLabel = makeTemplate(File(work, "tpl_nolabel.apk"), false, label = null)
        expectIAE("manifiesto sin android:label", template = noLabel.file)
        val noMan = File(work, "tpl_noman.apk")
        ZipOutputStream(noMan.outputStream()).use { z -> z.putNextEntry(ZipEntry("classes.dex")); z.write(1); z.closeEntry() }
        expectIAE("plantilla sin AndroidManifest.xml", template = noMan)
        val junk = File(work, "tpl_junk.apk")
        ZipOutputStream(junk.outputStream()).use { z -> z.putNextEntry(ZipEntry("AndroidManifest.xml")); z.write("<manifest/>".toByteArray()); z.closeEntry() }
        expectIAE("manifiesto que no es AXML (texto XML)", template = junk)
        val trunc = File(work, "tpl_trunc.apk")
        val tm = tpl.manifest
        ZipOutputStream(trunc.outputStream()).use { z -> z.putNextEntry(ZipEntry("AndroidManifest.xml")); z.write(tm, 0, tm.size - 12); z.closeEntry() }
        expectIAE("AXML truncado", template = trunc)

        // etiqueta enorme: o bien se escribe correctamente o bien se rechaza, nunca un AXML corrupto
        for (u8 in listOf(false, true)) {
            val t = makeTemplate(File(work, "tpl_hugelabel.apk"), u8)
            val big = "ñ".repeat(40000)
            val cfg = cfgOf("com.motor2d.game.huge", big)
            val r = runCatching { doExport(t.file, emptyMap(), cfg, key, cert) }
            if (r.isSuccess) {
                val zi = parseZip(r.getOrThrow())
                val d = runCatching { parseAxml(zi.content("AndroidManifest.xml")!!) }
                check("etiqueta de 40000 caracteres (u8=$u8) aceptada y releíble", d.isSuccess && d.getOrThrow().attr("application", "label")?.str == big)
            } else check("etiqueta de 40000 caracteres (u8=$u8) rechazada limpiamente (${r.exceptionOrNull()?.javaClass?.simpleName})", r.exceptionOrNull() is IllegalArgumentException)
        }
        // sin versionName en el manifiesto: el diseño lo deja tal cual (no estricto) y el APK sigue siendo válido
        val nv = makeTemplate(File(work, "tpl_nover.apk"), false, withVersionName = false)
        guard("sin versionName") {
            val cfg = cfgOf("com.motor2d.game.nover", "SinVer", "9.9")
            val apk = doExport(nv.file, emptyMap(), cfg, key, cert)
            val d = parseAxml(parseZip(apk).content("AndroidManifest.xml")!!)
            check("sin versionName en plantilla: exporta, AXML válido, sin versionName inventado", d.attr("manifest", "versionName") == null && d.attr("manifest", "package")?.str == "com.motor2d.game.nover")
            checkNull("sin versionName: v2", verifyV2(apk, cert))
        }
        // nombres de clase completamente cualificados (como deja AGP en el APK final) siguen intactos
        val fq = makeTemplate(File(work, "tpl_fq.apk"), false, relNames = false)
        guard("nombres cualificados") {
            val cfg = cfgOf("com.motor2d.game.fq", "FQ")
            val apk = doExport(fq.file, emptyMap(), cfg, key, cert)
            val d = parseAxml(parseZip(apk).content("AndroidManifest.xml")!!)
            check("nombres de clase totalmente cualificados se conservan", d.attr("activity", "name", 0)?.str == "com.motor2d.app.MainActivity" && d.attr("activity", "name", 1)?.str == "com.motor2d.app.Other")
        }
        // extras que sustituyen entradas con nombre de la plantilla; extra resources.arsc debe seguir STORED
        guard("extra resources.arsc") {
            val cfg = cfgOf("com.motor2d.game.arsc", "Arsc")
            val apk = doExport(tpl.file, mapOf("resources.arsc" to randBytes(2000, 33)), cfg, key, cert)
            val zi = parseZip(apk)
            check("extra que sustituye resources.arsc queda STORED y alineado (Android 11+ lo exige)", zi.entry("resources.arsc")!!.let { it.method == 0 && it.dataStart % 4 == 0 })
        }
        // el APK exportado dos veces con las mismas entradas es válido y determinista en tamaño
        guard("repetible") {
            val cfg = cfgOf("com.motor2d.game.rep", "Rep")
            val a = doExport(tpl.file, mapOf("assets/game/p" to byteArrayOf(1, 2)), cfg, key, cert)
            val b = doExport(tpl.file, mapOf("assets/game/p" to byteArrayOf(1, 2)), cfg, key, cert)
            check("dos exportaciones idénticas dan los mismos bytes (RSA PKCS1 determinista)", a.contentEquals(b))
        }
    }

    println()
    println("RESUMEN ExportTest: $oks ok, $failures FAIL")
    if (failures > 0) System.exit(1)
}
