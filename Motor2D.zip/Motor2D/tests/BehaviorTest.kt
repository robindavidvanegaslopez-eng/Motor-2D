import com.motor2d.core.Vec2
import com.motor2d.editor.Behavior
import com.motor2d.editor.Behaviors
import com.motor2d.engine.*
import java.io.File

var failures = 0
fun check(name: String, cond: Boolean) {
    if (!cond) { failures++; println("FAIL: $name") } else println("ok:   $name")
}

class MemFiles(val m: Map<String, String>) : ProjectFiles {
    override fun readText(path: String) = m[path]
}

class Log : LogSink {
    val lines = ArrayList<String>()
    override fun log(text: String, isError: Boolean) { lines.add((if (isError) "E:" else "") + text) }
}

lateinit var all: Map<String, Behavior>

fun box(w: World, name: String, x: Double, y: Double, sw: Double, sh: Double, body: String?): GameObject {
    val o = w.addObject(GameObject(name))
    o.position = Vec2(x, y)
    o.addComponent(SpriteRenderer().also { it.values["size"] = Vec2(sw, sh) })
    o.addComponent(BoxCollider2D().also { it.values["size"] = Vec2(sw, sh) })
    if (body != null) o.addComponent(Rigidbody2D().also { it.values["body_type"] = body })
    return o
}

fun use(o: GameObject, id: String, vararg exports: Pair<String, Any?>) {
    val b = all[id] ?: error("no existe $id")
    Behaviors.applyTo(o, b)
    val sc = o.scripts.last()
    for ((k, v) in exports) sc.exports[k] = v
}

fun field(o: GameObject, name: String): Any? = o.getProp(name)

/** Escena de pruebas: suelo, jugador con varios comportamientos, marcadores, plantillas y un sujeto. */
fun build(subject: String?, sx: Double, sy: Double, setup: ((World, GameObject) -> Unit)? = null): Triple<World, Log, GameObject?> {
    val files = all.values.associate { it.path to it.source }
    val log = Log()
    val w = World(MemFiles(files), log)
    w.viewW = 1280.0; w.viewH = 720.0

    val cam = w.addObject(GameObject("Camara")); cam.position = Vec2(640.0, 360.0); cam.addComponent(Camera2D())
    val floor = box(w, "Suelo", 640.0, 700.0, 2400.0, 60.0, "static")

    val player = box(w, "Jugador", 400.0, 640.0, 40.0, 60.0, "dynamic")
    player.rigidbody!!.values["freeze_rotation"] = true
    use(player, "plataformas")
    use(player, "salud")
    use(player, "reaparecer")

    val pts = w.addObject(GameObject("Puntos")); pts.addComponent(Label()); use(pts, "puntuacion")
    val lives = w.addObject(GameObject("Vidas")); lives.addComponent(Label()); use(lives, "vidas")
    val msg = w.addObject(GameObject("Mensaje")); msg.addComponent(Label()); use(msg, "mensaje_temporal")

    // Plantillas desactivadas para instantiate
    val bullet = box(w, "Bala", -500.0, -500.0, 12.0, 12.0, "dynamic"); bullet.active = false
    bullet.colliders.first().values["is_trigger"] = true
    bullet.rigidbody!!.values["gravity_scale"] = 0.0
    use(bullet, "proyectil")
    val enemyT = box(w, "Enemigo", -600.0, -500.0, 40.0, 40.0, "dynamic"); enemyT.active = false
    use(enemyT, "salud")
    val coinT = box(w, "Moneda", -700.0, -500.0, 20.0, 20.0, null); coinT.active = false
    use(coinT, "coleccionable")

    // Objetos con etiquetas que otros comportamientos buscan
    val enemy = box(w, "Enemigo1", 800.0, 640.0, 40.0, 40.0, "dynamic"); enemy.tag = "enemigo"
    use(enemy, "salud")
    val coin = box(w, "Moneda1", 900.0, 500.0, 20.0, 20.0, null); coin.tag = "coleccionable"
    val crate = box(w, "Caja1", 700.0, 640.0, 40.0, 40.0, "dynamic"); crate.tag = "fisico"
    val door = box(w, "Puerta", 1000.0, 600.0, 30.0, 140.0, "kinematic"); use(door, "puerta")
    val portal2 = box(w, "Portal2", 1100.0, 600.0, 40.0, 40.0, null)
    portal2.colliders.first().values["is_trigger"] = true
    use(portal2, "teletransporte", "target_name" to "Sujeto")

    var s: GameObject? = null
    if (subject != null) {
        s = w.addObject(GameObject("Sujeto"))
        s.position = Vec2(sx, sy)
        use(s, subject)
    }
    setup?.invoke(w, s ?: player)
    return Triple(w, log, s)
}

fun runFrames(w: World, n: Int, inputFn: ((Int) -> Unit)? = null): String? {
    for (f in 0 until n) {
        inputFn?.invoke(f)
        w.update(1.0 / 60.0)
        val e = w.error
        if (e != null) return e.message
    }
    return null
}

/** Entrada variada: joystick, botones A/B y toques, para activar casi todas las ramas. */
fun noisyInput(w: World, at: Vec2): (Int) -> Unit = { f ->
    val i = w.input
    i.joystick = Vec2(Math.sin(f / 30.0), Math.cos(f / 45.0))
    i.tilt = Vec2(Math.sin(f / 50.0) * 0.5, 0.2)
    if (f % 50 == 10) i.pressButton("A")
    if (f % 50 == 12) i.releaseButton("A")
    if (f % 70 == 20) i.pressButton("B")
    if (f % 70 == 40) i.releaseButton("B")
    if (f == 100) i.touchDown(w.worldToScreen(at))
    if (f == 101) i.touchUp()
    if (f == 140) i.touchDown(w.worldToScreen(Vec2(300.0, 300.0)))
    if (f == 150) i.touchMove(w.worldToScreen(Vec2(500.0, 200.0)))
    if (f == 160) i.touchUp()
}

fun main(args: Array<String>) {
    val dir = File(args[0])
    all = dir.listFiles { f -> f.name.endsWith(".gd") }!!.sortedBy { it.name }
        .map { Behaviors.parse(it.name.removeSuffix(".gd"), it.readText()) }.associateBy { it.id }
    println("Comportamientos cargados: ${all.size}")
    check("hay más de 70 comportamientos", all.size > 70)
    check("todos tienen nombre, categoría y descripción", all.values.all { it.name != it.id && it.category != "Otros" && it.description.length > 20 })
    check("categorías", Behaviors.categories(all.values.toList()).size >= 7)

    // ---- Genérico: cada comportamiento corre sin errores, solo y junto al jugador ----
    for (b in all.values) {
        for ((label, x, y) in listOf(Triple("junto al jugador", 400.0, 640.0), Triple("lejos", 900.0, 300.0))) {
            val (w, log, s) = build(b.id, x, y)
            w.start()
            val err = runFrames(w, 360, noisyInput(w, Vec2(x, y)))
            val benign = err != null && err.startsWith("No existe la escena")
            val logErrors = log.lines.filter { it.startsWith("E:") && !it.contains("No existe la escena") }
            check("${b.id} ($label) sin errores" + (if (err != null && !benign) ": $err" else ""), (err == null || benign) && logErrors.isEmpty())
        }
    }

    // ---- Comportamiento concreto ----
    // Plataformas: cae, aterriza y salta con A
    run {
        val (w, _, _) = build(null, 0.0, 0.0)
        w.start()
        val p = w.findByName("Jugador")!!
        runFrames(w, 60)
        check("el jugador se apoya en el suelo", p.rigidbody!!.onFloor || Math.abs(p.position.y - 640.0) < 6.0)
        val y0 = p.position.y
        var minY = y0
        runFrames(w, 40) { f -> if (f == 0) w.input.pressButton("A"); if (f == 2) w.input.releaseButton("A"); if (p.position.y < minY) minY = p.position.y }
        check("A hace saltar al jugador", minY < y0 - 40.0)
    }
    // Movimiento con el joystick
    run {
        val (w, _, _) = build(null, 0.0, 0.0)
        w.start()
        val p = w.findByName("Jugador")!!
        val x0 = p.position.x
        runFrames(w, 60) { w.input.joystick = Vec2(1.0, 0.0) }
        check("el joystick mueve al jugador", p.position.x > x0 + 100.0)
    }
    // Moneda suma al marcador y desaparece
    run {
        val (w, _, s) = build("coleccionable", 400.0, 640.0)
        w.start()
        runFrames(w, 30)
        check("la moneda suma un punto", field(w.findByName("Puntos")!!, "score") == 1L)
        check("la moneda desaparece", s!!.destroyed)
    }
    // Daño por contacto reduce la salud
    run {
        val (w, _, _) = build("dano_contacto", 400.0, 640.0)
        w.start()
        runFrames(w, 30)
        val p = w.findByName("Jugador")!!
        check("el contacto daña al jugador", (field(p, "health") as Long) < 5L)
    }
    // Salud: curar y morir
    run {
        val (w, _, _) = build(null, 0.0, 0.0)
        w.start(); runFrames(w, 2)
        val e = w.findByName("Enemigo1")!!
        e.callMethod("hurt", listOf(2L))
        check("hurt baja la salud", field(e, "health") == 3L)
        e.callMethod("heal", listOf(1L))
        check("heal la sube", field(e, "health") == 4L)
        runFrames(w, 60)
        e.callMethod("hurt", listOf(10L))
        runFrames(w, 3)
        check("sin salud el objeto se destruye", e.destroyed)
    }
    // Disparar crea balas que se mueven
    run {
        val (w, _, _) = build("disparar", 400.0, 500.0)
        w.start()
        val n0 = w.objects.size
        runFrames(w, 30) { f -> if (f == 3) w.input.pressButton("B") }
        val bullets = w.objects.filter { it.tag == "bala" && it.active }
        check("disparar crea proyectiles", w.objects.size > n0 && bullets.isNotEmpty())
        check("el proyectil avanza", bullets.any { Math.abs(it.rigidbody!!.velocity.x) > 100.0 })
    }
    // Proyectil daña a un enemigo con salud
    run {
        val (w, _, _) = build(null, 0.0, 0.0) { w2, _ ->
            val b = w2.findByName("Bala")!!
            val inst = w2.instantiate(b, Vec2(745.0, 640.0))
            inst.rotation = 0.0
        }
        w.start()
        val e = w.findByName("Enemigo1")!!
        runFrames(w, 120)
        check("la bala daña al enemigo", (field(e, "health") as Long) < 5L)
    }
    // Patrullar se mueve y vuelve
    run {
        val (w, _, s) = build("patrullar", 300.0, 200.0)
        w.start()
        var maxX = 0.0; var minX = 9999.0
        runFrames(w, 600) { maxX = Math.max(maxX, s!!.position.x); minX = Math.min(minX, s.position.x) }
        check("patrullar recorre la distancia", maxX - minX > 150.0)
        check("patrullar vuelve atrás", s!!.position.x < maxX - 50.0 || maxX - minX < 260.0)
    }
    // Generador crea objetos
    run {
        val (w, _, _) = build("generador_enemigos", 640.0, 100.0)
        w.start()
        val n0 = w.objects.count { it.name.startsWith("Enemigo") }
        runFrames(w, 400)
        check("el generador crea copias", w.objects.count { it.name.startsWith("Enemigo") } > n0)
    }
    // Llave abre la puerta
    run {
        val (w, _, _) = build("llave", 400.0, 640.0)
        w.start()
        val d = w.findByName("Puerta")!!
        val y0 = d.position.y
        runFrames(w, 90)
        check("la llave abre la puerta", d.position.y < y0 - 30.0)
    }
    // Cámara sigue al jugador
    run {
        val (w, _, s) = build("camara_seguir", 640.0, 360.0)
        w.start()
        val p = w.findByName("Jugador")!!
        runFrames(w, 120) { w.input.joystick = Vec2(1.0, 0.0) }
        check("la cámara sigue al jugador", Math.abs(s!!.position.x - p.position.x) < 80.0)
    }
    // Trampolín lanza hacia arriba
    run {
        val (w, _, _) = build("trampolin", 400.0, 680.0)
        w.start()
        val p = w.findByName("Jugador")!!
        var minY = 9999.0
        runFrames(w, 90) { if (p.position.y < minY) minY = p.position.y }
        check("el trampolín lanza al jugador", minY < 500.0)
    }
    // Portal teletransporta
    run {
        val (w, _, s) = build("teletransporte", 400.0, 640.0)
        w.start()
        runFrames(w, 10)
        val p = w.findByName("Jugador")!!
        check("el portal mueve al jugador", p.position.x > 1000.0)
    }
    // Temporizador y fin
    run {
        val (w, _, _) = build("autodestruir", 100.0, 100.0)
        w.start()
        runFrames(w, 200)
        check("autodestruir elimina el objeto", w.findByName("Sujeto") == null)
    }
    // Zona de viento empuja
    run {
        val (w, _, _) = build("zona_de_viento", 400.0, 600.0)
        w.start()
        val p = w.findByName("Jugador")!!
        var minY = 9999.0
        runFrames(w, 60) { if (p.position.y < minY) minY = p.position.y }
        check("el viento levanta al jugador", minY < 560.0)
    }
    // Girar constante
    run {
        val (w, _, s) = build("girar_constante", 100.0, 100.0)
        w.start(); runFrames(w, 60)
        check("girar_constante gira", Math.abs(s!!.rotation) > 100.0)
    }
    // Bomba empuja y desaparece
    run {
        val (w, _, s) = build("bomba", 650.0, 640.0)
        w.start(); runFrames(w, 240)
        check("la bomba desaparece", s!!.destroyed)
        check("la bomba empuja la caja cercana", w.findByName("Caja1")!!.position.x > 760.0)
    }

    // ---- applyTo prepara componentes ----
    run {
        val o = GameObject("X")
        val msg = Behaviors.applyTo(o, all["perseguir"]!!)
        check("applyTo añade física y collider", o.rigidbody != null && o.colliders.isNotEmpty() && o.scripts.size == 1)
        check("applyTo pone la etiqueta", o.tag == "enemigo")
        check("applyTo avisa de lo añadido", msg.contains("Rigidbody"))
        val o2 = GameObject("Y")
        Behaviors.applyTo(o2, all["coleccionable"]!!)
        check("coleccionable usa collider disparador", o2.colliders.first().values["is_trigger"] == true)
        val o3 = GameObject("Z")
        Behaviors.applyTo(o3, all["patrullar"]!!)
        check("patrullar usa cuerpo kinematic", o3.rigidbody!!.values["body_type"] == "kinematic")
        val o4 = GameObject("T")
        Behaviors.applyTo(o4, all["puntuacion"]!!)
        check("puntuacion añade un texto", o4.label != null && o4.sprite == null)
    }

    println(if (failures == 0) "TODO BIEN" else "$failures FALLOS")
    if (failures > 0) System.exit(1)
}
