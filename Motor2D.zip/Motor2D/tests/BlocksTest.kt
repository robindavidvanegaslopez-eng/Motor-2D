import com.motor2d.core.Vec2
import com.motor2d.editor.*
import com.motor2d.engine.*
import com.motor2d.script.Lexer
import com.motor2d.script.Parser
import com.motor2d.script.ScriptError

var failures = 0
fun check(name: String, cond: Boolean) {
    if (!cond) { failures++; println("FAIL: $name") } else println("ok:   $name")
}

class MemFiles(val m: MutableMap<String, String>) : ProjectFiles {
    override fun readText(path: String) = m[path]
}

class Log : LogSink {
    val lines = ArrayList<String>()
    override fun log(text: String, isError: Boolean) { lines.add((if (isError) "E:" else "") + text) }
}

fun blk(type: String, vararg args: Pair<String, String>, children: List<Block> = emptyList(), els: List<Block> = emptyList()): Block {
    val b = BlockCatalog.create(type)
    for ((k, v) in args) b.args[k] = v
    b.children.addAll(children)
    b.elseChildren.addAll(els)
    return b
}

fun parses(src: String): String? = try {
    Parser(Lexer(src, "b.gd").tokenize(), "b.gd").parseScript(); null
} catch (e: ScriptError) { e.message }

/** Mundo con un objeto «Sujeto» que lleva el script de bloques y otro «Jugador». */
fun world(script: BlockScript, setup: ((World, GameObject) -> Unit)? = null): Triple<World, Log, GameObject> {
    val text = BlockCompiler.compile(script).text
    val files = mutableMapOf("scripts/bloques/t.gd" to text)
    val log = Log()
    val w = World(MemFiles(files), log)
    w.viewW = 1280.0; w.viewH = 720.0
    val cam = w.addObject(GameObject("Camara")); cam.position = Vec2(640.0, 360.0); cam.addComponent(Camera2D())
    val p = w.addObject(GameObject("Jugador")); p.position = Vec2(400.0, 300.0)
    p.addComponent(SpriteRenderer()); p.addComponent(BoxCollider2D())
    p.addComponent(Rigidbody2D().also { it.values["gravity_scale"] = 0.0 })
    val tpl = w.addObject(GameObject("Bala")); tpl.active = false; tpl.addComponent(SpriteRenderer())
    val s = w.addObject(GameObject("Sujeto")); s.position = Vec2(100.0, 100.0)
    s.addComponent(SpriteRenderer()); s.addComponent(Label()); s.addComponent(BoxCollider2D())
    s.addComponent(Rigidbody2D().also { it.values["gravity_scale"] = 0.0 })
    s.addComponent(ScriptComponent().also { it.values["path"] = "scripts/bloques/t.gd" })
    setup?.invoke(w, s)
    return Triple(w, log, s)
}

fun run(w: World, frames: Int, f: ((Int) -> Unit)? = null): String? {
    for (i in 0 until frames) { f?.invoke(i); w.update(1.0 / 60.0); w.error?.let { return it.message } }
    return null
}

fun script(vararg events: Block, vars: Map<String, String> = emptyMap()): BlockScript {
    val s = BlockScript(); s.events.addAll(events); s.vars.putAll(vars); return s
}

fun main() {
    // ---- Todos los bloques compilan a GDScript válido y se ejecutan sin error ----
    val hats = BlockCatalog.defs.filter { it.kind == BKind.HAT }
    val others = BlockCatalog.defs.filter { it.kind != BKind.HAT }
    check("hay eventos y bloques", hats.size >= 12 && others.size >= 40)
    check("las categorías tienen bloques", BlockCatalog.categories.all { BlockCatalog.inCategory(it).isNotEmpty() })

    for (d in others) {
        val inner = if (d.kind == BKind.CONTAINER) listOf(blk("jg_print")) else emptyList()
        val ev = blk("ev_frame", children = listOf(blk(d.type, children = inner)))
        val c = BlockCompiler.compile(script(ev))
        val perr = parses(c.text)
        check("compila ${d.type}" + (perr?.let { ": $it" } ?: ""), perr == null)
    }
    for (d in hats) {
        val c = BlockCompiler.compile(script(blk(d.type, children = listOf(blk("jg_print")))))
        val perr = parses(c.text)
        check("evento ${d.type} compila" + (perr?.let { ": $it" } ?: ""), perr == null)
    }

    // Ejecutar cada bloque tal como viene por defecto dentro de «Al empezar» y «En cada fotograma»
    run {
        var bad = 0
        for (d in others) {
            if (d.type == "ob_destroy_other" || d.type == "ct_quit" || d.type == "jg_scene" || d.type == "jg_reload" || d.type == "ct_while") continue
            val inner = if (d.kind == BKind.CONTAINER) listOf(blk("jg_print")) else emptyList()
            val sc = script(blk("ev_start", children = listOf(blk(d.type, children = inner))), blk("ev_frame", children = listOf(blk(d.type, children = inner))),
                blk("ev_func", "name" to "mi_funcion"))
            val (w, log, _) = world(sc)
            w.start()
            val err = run(w, 90)
            val logErr = log.lines.filter { it.startsWith("E:") }
            if (err != null || logErr.isNotEmpty()) { bad++; println("   ${d.type}: ${err ?: logErr.first()}") }
        }
        check("todos los bloques se ejecutan con sus valores por defecto", bad == 0)
    }

    // ---- Comportamiento concreto ----
    run {
        val sc = script(
            blk("ev_start", children = listOf(
                blk("va_set", "var" to "puntos", "value" to "5"),
                blk("va_change", "var" to "puntos", "value" to "3"),
                blk("ap_text_value", "expr" to "puntos")
            ))
        )
        val (w, _, s) = world(sc); w.start(); run(w, 3)
        check("variables: poner, sumar y mostrar", s.label!!.s("text") == "8")
    }
    run {
        val sc = script(blk("ev_start", children = listOf(
            blk("ct_repeat", "n" to "4", children = listOf(blk("va_change", "var" to "n4", "value" to "2"))),
            blk("ct_repeat", "n" to "2", children = listOf(
                blk("ct_repeat", "n" to "3", children = listOf(blk("va_change", "var" to "total", "value" to "1")))))
        )))
        val (w, _, s) = world(sc); w.start(); run(w, 3)
        check("repetir cuenta bien", s.getProp("n4") == 8L)
        check("repetir anidado usa variables distintas", s.getProp("total") == 6L)
    }
    run {
        val sc = script(blk("ev_start", children = listOf(
            blk("va_set", "var" to "x", "value" to "7"),
            blk("ct_ifelse", "cond" to "x > 5", children = listOf(blk("va_set", "var" to "r", "value" to "1")), els = listOf(blk("va_set", "var" to "r", "value" to "2"))),
            blk("ct_if", "cond" to "x > 100", children = listOf(blk("va_set", "var" to "r", "value" to "99")))
        )))
        val (w, _, s) = world(sc); w.start(); run(w, 3)
        check("si / si no", s.getProp("r") == 1L)
    }
    run {
        val sc = script(blk("ev_start", children = listOf(
            blk("va_set", "var" to "i", "value" to "0"),
            blk("ct_while", "cond" to "i < 5", children = listOf(blk("va_change", "var" to "i", "value" to "1")))
        )))
        val (w, _, s) = world(sc); w.start(); run(w, 3)
        check("mientras", s.getProp("i") == 5L)
    }
    run {
        val sc = script(blk("ev_start", children = listOf(
            blk("ct_after", "n" to "1", children = listOf(blk("va_set", "var" to "listo", "value" to "1")))
        )))
        val (w, _, s) = world(sc); w.start()
        run(w, 30)
        val antes = s.getProp("listo")
        run(w, 60)
        check("esperar: no pasa antes", antes == 0L)
        check("esperar: ocurre después", s.getProp("listo") == 1L)
    }
    run {
        val sc = script(
            blk("ev_every", "n" to "0.5", children = listOf(blk("va_change", "var" to "tics", "value" to "1"))),
            blk("ev_after", "n" to "1", children = listOf(blk("va_set", "var" to "uno", "value" to "1")))
        )
        val (w, _, s) = world(sc); w.start(); run(w, 125)
        check("cada 0.5 s en 2 s son 4", s.getProp("tics") == 4L)
        check("1 s después de empezar", s.getProp("uno") == 1L)
    }
    run {
        val sc = script(blk("ev_start", children = listOf(blk("mv_tween", "x" to "500", "y" to "100", "s" to "1", "ease" to "linear"))))
        val (w, _, s) = world(sc); w.start(); run(w, 70)
        check("mover suavemente llega al destino", Math.abs(s.position.x - 500.0) < 1.0 && Math.abs(s.position.y - 100.0) < 1.0)
    }
    run {
        val sc = script(
            blk("ev_key", "key" to "space", children = listOf(blk("va_change", "var" to "saltos", "value" to "1"))),
            blk("ev_key_held", "key" to "d", children = listOf(blk("mv_move", "dx" to "2", "dy" to "0"))),
            blk("ev_button", "button" to "A", children = listOf(blk("va_change", "var" to "botonA", "value" to "1"))),
            blk("ev_click", "button" to "left", children = listOf(blk("va_change", "var" to "clics", "value" to "1")))
        )
        val (w, _, s) = world(sc); w.start()
        val x0 = s.position.x
        run(w, 20) { f ->
            if (f == 2) w.input.pressKey("space"); if (f == 3) w.input.releaseKey("space")
            if (f == 5) w.input.pressKey("d"); if (f == 15) w.input.releaseKey("d")
            if (f == 6) w.input.pressButton("A"); if (f == 7) w.input.releaseButton("A")
            if (f == 8) w.input.mouseDown("left", Vec2(10.0, 10.0)); if (f == 9) w.input.mouseUp("left")
        }
        check("tecla pulsada una vez", s.getProp("saltos") == 1L)
        check("tecla mantenida mueve", s.position.x > x0 + 15.0)
        check("botón de pantalla", s.getProp("botonA") == 1L)
        check("clic del mouse", s.getProp("clics") == 1L)
    }
    run {
        val sc = script(blk("ev_collide", "who" to "Jugador", children = listOf(blk("va_change", "var" to "golpes", "value" to "1"))))
        val (w, _, s) = world(sc) { w2, subj ->
            subj.position = Vec2(400.0, 300.0)
            subj.colliders.first().values["size"] = Vec2(40.0, 40.0)
            w2.findByName("Jugador")!!.colliders.first().values["size"] = Vec2(40.0, 40.0)
        }
        w.start(); run(w, 20)
        check("al chocar con un objeto concreto", (s.getProp("golpes") as Long) >= 1L)
    }
    run {
        val sc = script(blk("ev_collide", "who" to "Otro", children = listOf(blk("va_change", "var" to "golpes", "value" to "1"))))
        val (w, _, s) = world(sc) { w2, subj ->
            subj.position = Vec2(400.0, 300.0)
            w2.findByName("Jugador")!!.colliders.first().values["size"] = Vec2(40.0, 40.0)
        }
        w.start(); run(w, 20)
        check("el filtro por nombre ignora a otros", s.getProp("golpes") == 0L)
    }
    run {
        val sc = script(
            blk("ev_start", children = listOf(blk("ct_call", "name" to "saluda"))),
            blk("ev_func", "name" to "saluda", children = listOf(blk("ap_text", "text" to "Hola \"mundo\"")))
        )
        val (w, _, s) = world(sc); w.start(); run(w, 3)
        check("funciones propias y comillas en el texto", s.label!!.s("text") == "Hola \"mundo\"")
    }
    run {
        val sc = script(blk("ev_start", children = listOf(blk("ob_spawn_here", "name" to "Sujeto"))))
        val (w, _, _) = world(sc); w.start()
        val n0 = w.objects.size; run(w, 3)
        check("crear una copia", w.objects.size > n0)
    }
    run {
        val sc = script(blk("ev_start", children = listOf(blk("ap_color", "color" to "red"), blk("ap_scale", "k" to "2"))))
        val (w, _, s) = world(sc); w.start(); run(w, 3)
        check("cambiar color y tamaño", s.scale.x == 2.0 && s.sprite!!.c("color") != 0xFF4FC3F7.toInt())
    }

    run {
        val sc = script(blk("ev_start", children = listOf(blk("ct_if", "cond" to "vidas > 2 and Input.is_touching()", children = listOf(blk("jg_print"))))))
        val c = BlockCompiler.compile(sc).text
        check("una variable sin declarar se declara sola", c.contains("var vidas = 0") && !c.contains("var Input") && !c.contains("var and"))
        val (w, _, _) = world(sc); w.start()
        check("y el juego no da error", run(w, 5) == null)
    }
    run {
        val sc = script(blk("ev_collide", children = listOf(blk("ob_destroy_other"))))
        val (w, _, _) = world(sc) { w2, subj ->
            subj.position = Vec2(400.0, 300.0)
            subj.colliders.first().values["size"] = Vec2(40.0, 40.0)
            w2.findByName("Jugador")!!.colliders.first().values["size"] = Vec2(40.0, 40.0)
        }
        w.start(); run(w, 20)
        check("eliminar el otro objeto", w.findByName("Jugador") == null)
    }

    // ---- Texto generado ----
    run {
        val sc = script(blk("ev_start"), blk("ev_start", children = listOf(blk("jg_print"))))
        val t = BlockCompiler.compile(sc).text
        check("dos «Al empezar» se juntan en un _ready", Regex("func _ready").findAll(t).count() == 1)
        val c = BlockCompiler.compile(script(blk("ev_frame", children = listOf(blk("mv_move")))))
        check("cada línea tiene dueño o es estructura", c.owners.size == c.text.trimEnd('\n').lines().size)
        val line = c.text.lines().indexOfFirst { it.contains("position = position") } + 1
        check("la línea de código apunta a su bloque", c.ownerOfLine(line)?.type == "mv_move")
        check("variables simples son @export", BlockCompiler.compile(script(vars = mapOf("vida" to "3"))).text.contains("@export var vida = 3"))
        check("nombres peligrosos se limpian", BlockCompiler.ident("mi var-2!") == "mi_var_2_" && BlockCompiler.ident("9x") == "_9x")
        val inj = BlockCompiler.compile(script(blk("ev_start", children = listOf(blk("jg_print", "text" to "a\nb\" + quit() + \""))))).text
        check("un texto con saltos de línea o comillas no rompe el script", parses(inj) == null && !inj.contains("\n+ quit"))
    }

    // ---- Guardado ----
    run {
        val sc = script(blk("ev_start", children = listOf(
            blk("ct_ifelse", "cond" to "a > 1", children = listOf(blk("mv_move", "dx" to "3")), els = listOf(blk("jg_print", "text" to "no"))))),
            vars = mapOf("a" to "5"))
        val json = Blocks.toJson(sc)
        val back = Blocks.fromJson(json)
        check("guardar y leer conserva los bloques", BlockCompiler.compile(back).text == BlockCompiler.compile(sc).text)
        val broken = json.replace("mv_move", "bloque_que_no_existe")
        check("un bloque desconocido se ignora sin romper", Blocks.fromJson(broken).events.size == 1)
    }

    println(if (failures == 0) "TODO BIEN" else "$failures FALLOS")
    if (failures > 0) System.exit(1)
}
