import com.motor2d.core.Vec2
import com.motor2d.editor.*
import com.motor2d.engine.*
import java.io.File

var failures = 0
fun check(name: String, cond: Boolean) {
    if (!cond) { failures++; println("FAIL: $name") } else println("ok:   $name")
}

fun frames(w: World, n: Int) { repeat(n) { w.update(1.0 / 60.0) } }

fun main() {
    val tmp = File.createTempFile("m2d", "").let { it.delete(); it.mkdirs(); it }
    val store = ProjectStore(tmp)

    // Proyecto de ejemplo: se crea, se abre y se ejecuta sin errores
    val p = store.create("Mi juego", Templates.DEMO)
    check("proyecto creado", store.names() == listOf("Mi juego"))
    check("scripts creados", p.scripts().size == 4)
    check("nombre único", store.uniqueName("Mi juego") == "Mi juego 2")
    check("nombre limpio", store.cleanName("../../etc") == "etc")

    val m = EditorModel(p)
    check("escena cargada", m.world.objects.size >= 12)
    check("orientación horizontal", m.isLandscape)
    check("jerarquía plana", m.flatten().size == m.world.objects.size)

    check("iniciar juego", m.startPlay())
    val w = m.play!!
    val player = w.findByName("Jugador")!!
    frames(w, 90)   // cae al suelo
    check("sin errores al iniciar", w.error == null)
    check("jugador sobre el suelo", player.rigidbody!!.onFloor && Math.abs(player.position.y - (620.0 - 28.0)) < 3.0)

    w.input.joystick = Vec2(1.0, 0.0)
    val x0 = player.position.x
    frames(w, 30)
    check("joystick mueve al jugador", player.position.x > x0 + 100.0)
    w.input.joystick = Vec2.ZERO

    w.input.pressButton("A")
    frames(w, 1)
    w.input.releaseButton("A")
    frames(w, 10)
    check("botón A salta", player.position.y < 590.0)
    frames(w, 120)

    // Recoger la primera moneda: se coloca al jugador encima
    val coin = w.findByName("Moneda 1")!!
    player.position = coin.position
    frames(w, 5)
    check("moneda destruida", w.findByName("Moneda 1") == null)
    check("sin errores tras moneda", w.error == null)
    val hud = w.findByName("Puntos")!!
    check("marcador actualizado", hud.label!!.s("text") == "Monedas: 1")

    // Botón B crea una pelota
    val before = w.objects.size
    w.input.pressButton("B"); frames(w, 2); w.input.releaseButton("B")
    check("botón B instancia pelota", w.objects.size == before + 1)
    check("pelota activa", w.objects.last().active)

    // La cámara sigue al jugador
    player.position = Vec2(1500.0, 560.0)
    frames(w, 120)
    check("cámara sigue al jugador", Math.abs(w.camera().center.x - 1500.0) < 80.0)
    check("sin errores finales", w.error == null)
    m.stopPlay()
    check("detener", !m.isPlaying)
    check("la escena de edición no cambió", m.world.findByName("Moneda 1") != null)

    // Edición: crear, deshacer, rehacer
    val n0 = m.world.objects.size
    val o = m.createObject("ball", Vec2(100.4, 200.6))
    check("crear objeto", m.world.objects.size == n0 + 1 && o.position == Vec2(100.0, 201.0) && m.selected === o)
    check("nombre único al crear", m.createObject("ball", Vec2.ZERO).name != o.name)
    m.undo(); m.undo()
    check("deshacer", m.world.objects.size == n0)
    m.redo()
    check("rehacer", m.world.objects.size == n0 + 1)

    // Propiedades
    val ball = m.world.objects.last()
    val rb = ball.rigidbody!!
    val pm = rb.prop("mass")!!
    check("mass válida", m.setValue(rb, pm, "2,5") == null && rb.f("mass") == 2.5)
    check("mass inválida", m.setValue(rb, pm, "abc") != null && rb.f("mass") == 2.5)
    val ps = ball.sprite!!.prop("size")!!
    check("vec2 con coma", m.setValue(ball.sprite!!, ps, "10, 20") == null && ball.sprite!!.v("size") == Vec2(10.0, 20.0))
    check("vec2 con espacio", m.setValue(ball.sprite!!, ps, "30 40") == null && ball.sprite!!.v("size") == Vec2(30.0, 40.0))
    check("vec2 inválido", m.setValue(ball.sprite!!, ps, "1") != null)
    val pc = ball.sprite!!.prop("color")!!
    check("color", m.setValue(ball.sprite!!, pc, "#00ff00") == null && ball.sprite!!.c("color") == 0xFF00FF00.toInt())
    check("color inválido", m.setValue(ball.sprite!!, pc, "zzz") != null)
    val pt = rb.prop("body_type")!!
    check("enum", m.setValue(rb, pt, "static") == null && rb.s("body_type") == "static")
    check("enum inválido", m.setValue(rb, pt, "volando") != null)

    // Componentes
    check("no duplica Rigidbody", m.addComponent(ball, "Rigidbody2D") != null)
    check("un solo collider", m.addComponent(ball, "BoxCollider2D") != null)
    val sq = m.createObject("square", Vec2.ZERO)
    check("añade collider ajustado", m.addComponent(sq, "BoxCollider2D") == null && sq.get<BoxCollider2D>()!!.v("size") == sq.sprite!!.v("size"))
    check("añade script", m.addComponent(sq, "Script") == null && sq.scripts.size == 1)

    // Jerarquía
    val parent = m.createObject("empty", Vec2(50.0, 50.0))
    m.setParent(sq, parent)
    check("hijo en jerarquía", m.flatten().any { it.first === sq && it.second == 1 })
    m.delete(parent)
    check("borrar elimina hijos", !m.world.objects.contains(sq) && !m.world.objects.contains(parent))
    m.undo()
    check("deshacer borrado", m.world.objects.any { it.name == sq.name })

    // Duplicar
    val d = m.duplicate(m.world.findByName("Jugador")!!)
    check("duplicar", d.name != "Jugador" && d.scripts.size == 1 && d.rigidbody != null)

    // Scripts
    check("script correcto", m.saveScript("scripts/player.gd", Templates.PLAYER_GD) == null)
    val bad = m.saveScript("scripts/bad.gd", "func _process(delta):\n    var x = \n")
    check("error de sintaxis con línea", bad != null && bad.line == 2)
    val ns = m.createScript("Nuevo Enemigo")
    check("crear script", ns == "scripts/NuevoEnemigo.gd" && m.checkScript(ns, p.readText(ns)!!) == null)
    check("crear script único", m.createScript("NuevoEnemigo") == "scripts/NuevoEnemigo2.gd")

    // Exports
    val sc = m.world.findByName("Jugador")!!.scripts[0]
    val ex = m.exportsFor(sc)
    check("exports detectados", ex.map { it.name } == listOf("speed", "jump_force") && ex[0].value == 320.0)
    check("editar export", m.setExport(sc, ex[0], "500") == null && sc.exports["speed"] == 500.0)
    check("export inválido", m.setExport(sc, ex[0], "rápido") != null)
    check("export sobrescrito", m.exportsFor(sc)[0].overridden && m.exportsFor(sc)[0].value == 500.0)
    m.resetExport(sc, "speed")
    check("restablecer export", !sc.exports.containsKey("speed"))

    // Guardar y volver a abrir
    m.save()
    val m2 = EditorModel(p)
    check("guardar y abrir", m2.world.objects.size == m.world.objects.size && m2.world.findByName("Jugador")!!.scripts[0].exports.isEmpty())

    // Un error de script detiene el juego y se informa
    p.writeText("scripts/coin.gd", "extends Node2D\nfunc _ready():\n    var a = 1\n    a.nada()\n")
    m2.world.clearScriptCache()
    m2.startPlay()
    check("error de script informado", m2.play!!.error != null && m2.console.any { it.isError && it.text.contains("coin.gd") })

    // Pantalla y escenas
    m2.stopPlay()
    m2.setLandscape(false)
    check("vertical", !m2.isLandscape && m2.world.viewH == 1280.0)
    val sn = m2.newScene("nivel 2")
    check("nueva escena", sn == "nivel2" && m2.world.objects.size == 1 && p.scenes().containsAll(listOf("main", "nivel2")))

    // Imágenes
    val img = m2.importImage("Mi Foto!.PNG", byteArrayOf(1, 2, 3))
    check("importar imagen", img == "assets/MiFoto.png" && m2.imagePaths() == listOf(img))

    // Proyecto vacío
    val pe = store.create("Vacío", Templates.EMPTY)
    val me = EditorModel(pe)
    check("proyecto vacío", me.world.objects.size == 1 && !me.isLandscape)

    store.delete("Vacío")
    check("borrar proyecto", store.open("Vacío") == null)
    tmp.deleteRecursively()
    println(if (failures == 0) "ALL EDITOR TESTS PASSED" else "$failures FAILURES")
    if (failures > 0) System.exit(1)
}
