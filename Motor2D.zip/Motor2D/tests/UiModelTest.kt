import com.motor2d.editor.*
import com.motor2d.engine.*
import java.io.File

var failures = 0
fun check(name: String, cond: Boolean) {
    if (!cond) { failures++; println("FAIL: $name") } else println("ok:   $name")
}

fun main() {
    val dir = File.createTempFile("m2d", "").let { it.delete(); it.mkdirs(); it }
    val store = ProjectStore(dir)
    val p = store.create("Prueba", Templates.DEMO)
    val m = EditorModel(p)
    val o = m.world.objects.first { it.name == "Jugador" }

    val n = m.addBlocks(o)
    check("addBlocks devuelve un nombre limpio", n == "Jugador")
    check("crea el .blocks y el .gd", p.exists(Blocks.blocksPath(n)) && p.exists(Blocks.scriptPath(n)))
    check("añade un componente Script con ese .gd", o.scripts.any { it.path == Blocks.scriptPath(n) })
    check("blocksNameOf reconoce el script de bloques", m.blocksNameOf(Blocks.scriptPath(n)) == n)
    check("blocksNameOf ignora scripts normales", m.blocksNameOf("scripts/player.gd") == null)
    check("los scripts de bloques salen en la lista de scripts", Blocks.scriptPath(n) in p.scripts())

    val s = m.loadBlocks(n)!!
    check("loadBlocks recupera el evento inicial", s.events.size == 1 && s.events[0].type == "ev_start" && s.events[0].children.size == 1)
    s.events.add(BlockCatalog.create("ev_frame").also { it.children.add(BlockCatalog.create("mv_move")) })
    val err = m.saveBlocks(n, s)
    check("saveBlocks guarda sin errores de sintaxis", err == null)
    check("el .gd generado tiene _process", p.readText(Blocks.scriptPath(n))!!.contains("func _process"))

    val n2 = m.addBlocks(o)
    check("un segundo script de bloques no pisa al primero", n2 != n && p.exists(Blocks.blocksPath(n2)))
    check("deshacer devuelve el estado anterior de la escena", run { m.undo(); o.scripts.size >= 0 })

    // Ejecuta el juego con los bloques
    check("el juego con bloques arranca", m.startPlay())
    m.play!!.update(1.0 / 60.0)
    check("sin errores al ejecutar", m.play!!.error == null)
    m.stopPlay()

    dir.deleteRecursively()
    println(if (failures == 0) "TODO BIEN" else "$failures FALLOS")
    if (failures > 0) System.exit(1)
}
