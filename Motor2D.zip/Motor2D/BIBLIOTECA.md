# Biblioteca de comportamientos

Inspector > + Añadir componente > ★ Comportamiento prefabricado. Cada uno es un script GDScript con variables editables; si falta algo, añade un Script y prográmalo.


## Movimiento

- **Aleteo (toca para subir)**: Cada toque a la pantalla o botón A da un impulso hacia arriba. Estilo Flappy Bird (necesita gravedad).
- **Aparecer por el lado contrario**: Si sale por un borde de la pantalla, aparece por el opuesto (estilo Asteroids o Pac-Man).
- **Arrastrar con el dedo**: Toca el objeto y arrástralo por la pantalla. Al soltarlo cae si tiene física.
- **Avanzar en línea recta**: Se mueve siempre en la misma dirección. Con 'use_rotation' avanza hacia donde apunta el objeto.
- **Caminar y girar en las paredes**: Camina en horizontal y da la vuelta al chocar con una pared. Enemigo clásico de plataformas (necesita gravedad).
- **Embestida (dash) con el botón B**: Al pulsar B el objeto sale disparado un instante en la dirección del joystick. Añádelo DESPUÉS del script de movimiento.
- **Girar hacia un objetivo**: Gira el objeto para apuntar a otro objeto (por nombre) o al dedo si 'target_name' está vacío. Torretas, ojos, cañones.
- **Girar sin parar**: Rota el objeto continuamente. Hélices, sierras, monedas, ruedas.
- **Huir de un objetivo**: Se aleja del objeto indicado cuando este se acerca. Sirve para presas, fantasmas asustadizos o NPCs.
- **Invertir la gravedad con A**: Al pulsar A (estando en el suelo o techo) la gravedad de este objeto se invierte. Estilo Gravity Guy.
- **Jugador de plataformas (caminar y saltar)**: Joystick para caminar y botón A para saltar. 'max_jumps' = 2 da doble salto. Necesita gravedad. Tiene boost(multiplicador, segundos).
- **Limitar a una zona**: No deja que el objeto salga del rectángulo definido por 'min_pos' y 'max_pos'.
- **Mover con botones A y B**: A mueve el objeto en una dirección y B en la contraria. Paletas, ascensores, controles de un solo eje.
- **Mover con joystick (vista desde arriba)**: Mueve el objeto en cualquier dirección con el joystick. Sirve para juegos vistos desde arriba. Tiene boost(multiplicador, segundos) para potenciadores.
- **Mover inclinando el celular**: El objeto se mueve según la inclinación del celular (acelerómetro).
- **Nave espacial (girar y propulsar)**: Joystick izquierda/derecha gira la nave y el botón A la impulsa hacia adelante. Estilo Asteroids.
- **Orbitar alrededor de un punto**: Da vueltas en círculo. Si escribes 'center_name' gira alrededor de ese objeto; si no, alrededor del punto donde lo pusiste.
- **Oscilar (subir y bajar suave)**: Se mueve de un lado a otro con una onda suave. Puntos flotantes, enemigos voladores, monedas que flotan.
- **Paleta que sigue el dedo en un eje**: Se desliza por un eje siguiendo el dedo. Para Pong, Arkanoid y similares. Elige el eje 'horizontal' o 'vertical'.
- **Patrullar (ir y volver)**: Va de su posición inicial hasta 'distance' en la dirección indicada y regresa, una y otra vez. Ideal para plataformas móviles, sierras y enemigos voladores.
- **Perseguir a un objetivo**: Se acerca al objeto indicado (por nombre) cuando está a la vista. Con 'only_horizontal' solo camina de lado (para plataformas).
- **Rebotar en los bordes de la pantalla**: Se mueve sin parar y rebota en los bordes de la pantalla. Pelotas, protectores de pantalla, enemigos simples.
- **Saltar cada cierto tiempo**: Salta solo cada 'interval' segundos. Enemigos saltarines o ranas (necesita gravedad).
- **Seguir el dedo**: El objeto va hacia el punto de la pantalla que tocas y se detiene al llegar.
- **Seguir un camino de puntos**: Recorre una lista de puntos. Escribe el camino en 'path' como 'x,y; x,y; ...'. Con 'relative' los puntos se miden desde donde empieza el objeto.

## Combate y vida

- **Barra de vida (texto)**: Texto con corazones o barras que refleja la salud de otro objeto ('target_name'). Por ejemplo, el jugador.
- **Dañar al tocar**: Hace daño al objeto que lo toque si ese objeto tiene el script Salud. Pinchos, lava, enemigos. Funciona con collider normal o disparador.
- **Daño continuo en una zona**: Mientras el jugador permanece dentro del disparador recibe daño cada 'interval' segundos. Ácido, fuego, gas venenoso.
- **Desaparecer después de un tiempo**: El objeto se elimina solo pasados 'seconds' segundos. Balas, efectos, humo.
- **Disparar con el botón B**: Al pulsar B crea una copia del objeto 'projectile' (la plantilla, desactivada) y la lanza hacia donde mira. 'auto_fire' dispara solo.
- **Disparar hacia donde tocas**: Cada toque en la pantalla lanza una copia de 'projectile' desde el objeto hacia el punto tocado.
- **Eliminar al salir de la pantalla**: El objeto se elimina cuando sale del área indicada. Evita que balas y enemigos se acumulen.
- **Generador (spawner) de objetos**: Crea una copia de un objeto plantilla cada 'interval' segundos en una zona aleatoria. Enemigos, obstáculos, monedas que caen. 'max_alive' limita cuántos hay a la vez.
- **Proyectil (bala)**: Avanza hacia donde apunta (su rotación), daña lo que tenga Salud y desaparece. Ponlo en un objeto 'Bala' DESACTIVADO como plantilla para instantiate.
- **Salud (vida, daño y curación)**: Da vida al objeto: hurt(n) la baja, heal(n) la sube. Al llegar a 0: 'on_death' = destruir, reiniciar o nada. Parpadea al recibir daño y tiene un momento de invulnerabilidad.
- **Soltar un objeto al morir**: El script Salud llama a drop_now() cuando el objeto muere (también puedes llamarla tú) y suelta una copia de 'drop' donde estaba el objeto. Monedas de enemigos, restos.
- **Torreta (dispara al objetivo)**: Apunta al objetivo y le dispara cada 'rate' segundos cuando está a la vista.

## Objetos y coleccionables

- **Botiquín (cura al tocarlo)**: Cura al jugador con el script Salud y desaparece.
- **Interruptor de presión**: Activa otro objeto ('target_name') mientras el jugador está encima, o lo deja activado para siempre con 'stay_on'. El objetivo necesita activate()/deactivate() (por ejemplo, el script Puerta).
- **Llave**: Al tocarla el jugador, abre la puerta indicada en 'door_name' (objeto con el script Puerta) y la llave desaparece.
- **Meta / bandera de fin de nivel**: Cuando el jugador la toca carga 'next_scene' o, si está vacío, muestra un mensaje en el objeto 'Mensaje' (script Mensaje en pantalla) y detiene al jugador.
- **Moneda / coleccionable**: Al tocarla el jugador suma 'points' al objeto marcador y desaparece. Usa un collider tipo disparador.
- **Portal (teletransporte)**: Lleva al jugador al objeto 'target_name'. Pon el mismo script en el destino apuntando al primero para tener portales de ida y vuelta.
- **Potenciador temporal de velocidad**: Al tocarlo, el jugador va más rápido unos segundos (funciona con los scripts de movimiento del jugador).
- **Puerta (se abre con llave o interruptor)**: Bloquea el paso hasta que unlock() o activate() se llame (por una Llave o un Interruptor). Entonces se desliza fuera del camino.
- **Punto de reaparición (checkpoint)**: Cuando el jugador lo toca, ese lugar pasa a ser su punto de reaparición (el jugador necesita el script Reaparecer).
- **Reaparecer al caer o morir**: Si el objeto cae por debajo de 'fall_limit' vuelve a su punto de reaparición. También respawn() lo devuelve (lo usan Zona de muerte y Salud).
- **Zona de muerte**: Si el jugador entra, reaparece (si tiene el script Reaparecer) o se reinicia la escena. Abismos, agua mortal.

## Mundo y física

- **Bomba con cuenta atrás**: Explota tras 'fuse' segundos: empuja a los objetos con la etiqueta 'affect_tag' cercanos, daña lo que tenga Salud y desaparece.
- **Cinta transportadora**: Arrastra en la dirección indicada a lo que esté encima. Cambia 'speed' (negativo = al revés).
- **Desplazar y reciclar (tubos, runner)**: Se mueve hacia un lado y, al salir por el borde, reaparece al otro extremo con una altura al azar. Tubos de Flappy, suelos o fondos infinitos.
- **Enemigo vigilante (patrulla y persigue)**: Camina de un lado a otro; si el objetivo se acerca a 'sight' lo persigue; si lo pierde vuelve a patrullar. Para plataformas (necesita gravedad).
- **Escalera / enredadera**: Permite subir y bajar con el joystick mientras el jugador está dentro de la zona.
- **Imán de coleccionables**: Atrae hacia el objeto a todo lo que tenga la etiqueta 'attract_tag' (por defecto coleccionable) cuando está cerca.
- **Ladrillo (se rompe al golpearlo)**: Se rompe al ser golpeado por un objeto con la etiqueta 'hit_tag' y suma puntos. Arkanoid / Breakout.
- **Pelota que mantiene su velocidad (Pong)**: Sale lanzada al empezar y mantiene siempre la misma velocidad al rebotar. Dale un collider con 'Rebote' = 1.
- **Plataforma que aparece y desaparece**: Alterna entre visible (sólida) y oculta cada cierto tiempo.
- **Plataforma que se cae**: Tiembla y cae cuando alguien se sube, después de 'delay' segundos. Se elimina al caer muy lejos.
- **Trampolín**: Lanza hacia arriba a lo que caiga encima con 'force'.
- **Zona de agua (frena y flota)**: Frena el movimiento de lo que entra y lo empuja hacia arriba, como si flotara.
- **Zona de viento / fuerza**: Empuja con una fuerza constante a todo lo que tenga física dentro de la zona. Con una fuerza hacia arriba sirve de corriente de aire o baja gravedad.

## Reglas y marcadores

- **Cronómetro**: Cuenta el tiempo transcurrido desde que empieza el juego. Llama a stop_timer() para detenerlo.
- **Cuenta regresiva**: Muestra el tiempo que queda. Al llegar a cero reinicia la escena o carga otra.
- **Fin del juego (toca para reiniciar)**: Llama a game_over() para mostrar el texto y reiniciar la escena con un toque. Ponlo en un objeto de texto.
- **Ganar al eliminar a todos los enemigos**: Cuando ya no queda ningún objeto con la etiqueta indicada, carga la escena siguiente o muestra el mensaje de victoria.
- **Marcador de puntos**: Texto que lleva la cuenta. Otros objetos suman con get_object("Puntos").add(1). Al llegar a 'goal' carga 'next_scene' (o reinicia). Ponle el nombre 'Puntos' al objeto.
- **Mensaje en pantalla**: Texto oculto que se muestra con show_message("¡Hola!", 2) durante unos segundos. Útil para 'Nivel completado' o 'Game Over'.
- **Vidas del jugador**: Texto con las vidas. Llama a get_object("Vidas").lose_life() cuando el jugador muera. Sin vidas reinicia la escena. Ponle el nombre 'Vidas' al objeto.

## Cámara

- **Cámara que sigue a un objeto**: La cámara va suavemente detrás del objeto 'target' y respeta los límites del nivel. Ponlo en el objeto Cámara.
- **Fondo con parallax**: El objeto se mueve más lento que la cámara para dar sensación de profundidad. 'factor' 0 = fijo al mundo, 1 = pegado a la pantalla.
- **Temblor de cámara**: Llama a shake(fuerza, segundos) en la cámara para hacerla temblar (golpes, explosiones). No uses a la vez con Cámara que sigue (esa ya trae shake).

## Efectos visuales

- **Cambiar de color al tocarlo**: Cada vez que lo tocas toma un color distinto al azar.
- **Cambiar de color sin parar**: El color del dibujo recorre todos los tonos del arcoíris.
- **Eliminar al tocarlo**: Toca el objeto y desaparece, sumando puntos si quieres. Globos, topos, objetivos de tiro.
- **Latir (crecer y encoger)**: El objeto cambia de tamaño con un latido suave. Botones, corazones, llamadas de atención.
- **Parpadear**: El objeto se oculta y se muestra alternadamente. Alarmas, texto 'Toca para empezar', invulnerabilidad.

## Interfaz

- **Botón táctil**: Al tocarlo hace una acción: 'escena' carga la escena indicada en 'value', 'reiniciar' reinicia, 'activar' llama a activate() del objeto 'value', 'salir' cierra el juego.
