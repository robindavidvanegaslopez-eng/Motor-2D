# Prompt maestro: Motor 2D «Melo»

Este documento es la especificación sobre la que se construye el motor. Cualquier cambio o ampliación debe respetarlo; si algo entra en conflicto con él, se pregunta antes de decidir.

## 1. Rol y objetivo

Actúa como ingeniero principal de un motor de juegos 2D para Android escrito en Kotlin. El motor debe ser **completo pero entendible**: una persona sin ordenador, desde un celular, tiene que poder crear un juego de principio a fin (objetos, física, sprites propios, lógica por bloques o por código, tiempos y animaciones), probarlo con un botón y **convertirlo en un APK instalable sin salir de la app**.

## 2. Usuario y contexto

- Trabaja solo, desde un celular (Motorola Moto G86 Power 5G), a veces con teclado y mouse inalámbricos. La app se compila con GitHub Actions; no hay SDK de Android en el entorno de desarrollo, así que **el código de interfaz no se puede compilar localmente** y debe escribirse con disciplina de tipos (Float/Double explícitos, nulabilidad, imports).
- Interfaz y mensajes **en español**. Nada de jerga innecesaria: cada opción se explica con una frase.

## 3. Principios de diseño

1. **Entendible primero.** Pocas pantallas, nombres claros, ejemplos incluidos. Lo avanzado no estorba a lo básico.
2. **Tres niveles de programación que conviven:** (a) comportamientos prefabricados, (b) bloques visuales, (c) GDScript. Los bloques se compilan a GDScript legible, así se puede pasar de uno a otro.
3. **Un solo modelo de objeto:** GameObject con componentes (estilo Unity), con mecánicas y sintaxis de Godot.
4. **Táctil, teclado y mouse son ciudadanos de primera.** Todo se puede hacer con el dedo; con teclado y mouse se hace más rápido (atajos, rueda, botón derecho).
5. **Nunca perder trabajo:** guardado automático, deshacer/rehacer, errores de script sin cerrar la app.
6. **Probado.** Todo lo que no dependa de Android (intérprete, bloques, física, empaquetado) tiene pruebas automáticas en JVM.

## 4. Requisitos funcionales

### 4.1 Núcleo (ya existente)
Escenas con objetos y jerarquía, Sprite, Texto, Cámara, Rigidbody (dynamic/kinematic/static), colliders caja y círculo (con disparadores), física 2D con colisiones y eventos, intérprete de GDScript simplificado, 77 comportamientos prefabricados, editor con Inspector, deshacer, varias escenas por proyecto, botón Ejecutar.

### 4.2 Entrada: táctil, teclado y mouse
- Scripts: `Input.is_key_pressed("w")`, `Input.is_key_just_pressed("space")`, `Input.mouse_position()`, `Input.mouse_world_position()`, `Input.is_mouse_button_pressed("left"|"right"|"middle")`, `Input.just_clicked("left")`, `Input.mouse_wheel()`.
- El joystick y los botones en pantalla se siguen mostrando en táctil y las teclas WASD/flechas/espacio los reemplazan en teclado.
- Editor: rueda = zoom; botón central o derecho arrastrando = mover la vista; `Supr` borra; `Ctrl+Z`/`Ctrl+Y` deshacer/rehacer; `Ctrl+D` duplica; `Ctrl+S` guarda; `F5` ejecuta; `Esc` detiene; flechas mueven el objeto (con `Shift`, más rápido).

### 4.3 Tiempos
- Scripts: `after(segundos, "funcion")`, `every(segundos, "funcion")`, `cancel_timer(id)`, `tween(objeto, "propiedad", destino, segundos, "easing")`.
- Easings: linear, ease_in, ease_out, ease_in_out, bounce.
- Propiedades animables: position, rotation, scale, color.
- Bloques equivalentes: «Esperar», «Después de N segundos», «Cada N segundos», «Mover suavemente a».

### 4.4 Bloques visuales
- Cada objeto puede tener un componente Bloques (archivo `.blocks` en JSON) que se compila a `.gd` al guardar.
- Categorías: **Eventos** (al empezar, cada fotograma, al tocar, al chocar, al entrar en zona, al pulsar tecla/botón, cada N segundos), **Control** (si/si no, repetir, mientras, esperar, detener), **Movimiento** (mover, girar, ir a, mirar a, velocidad, saltar, empujar), **Apariencia** (color, texto, mostrar/ocultar, tamaño), **Objetos** (crear copia, eliminar, buscar por nombre/etiqueta), **Variables** (poner, sumar, leer), **Juego** (sumar puntos, cargar escena, reiniciar, terminar), **Entrada** (condiciones de joystick, botones, teclas, mouse).
- Edición táctil: lista vertical con sangría; tocar «+» abre la paleta; tocar un bloque edita sus valores; mantener pulsado = borrar/duplicar/mover arriba o abajo. Debe poder verse el GDScript resultante.

### 4.5 Creación de sprites
- Editor de píxeles integrado: lienzo de 8 a 128 píxeles, zoom y desplazamiento con dos dedos o rueda, herramientas (lápiz, borrador, relleno, línea, rectángulo, elipse, cuentagotas), paleta personalizable, simetría, voltear/rotar, deshacer.
- Guarda PNG en `assets/` del proyecto y lo asigna al objeto.
- Sprites animados: lista de cuadros + velocidad (fps); se previsualizan en el editor y se pueden controlar desde scripts (`play_animation`, `stop_animation`).

### 4.6 Exportar APK dentro de la app
- Botón «Exportar APK» en el menú del proyecto: pide nombre del juego y su identificador, y genera un APK **firmado e instalable**, sin ordenador ni GitHub.
- Funcionamiento: la app copia su propio APK, le añade el juego (`assets/game/`), cambia nombre y paquete del manifiesto, lo firma (esquema v2) y ofrece instalarlo o compartirlo. Al abrirse, ese APK detecta el juego incluido y lo ejecuta directamente, sin editor.
- La clave de firma se guarda en el Android Keystore del dispositivo y se reutiliza para poder actualizar el juego.

## 5. Requisitos técnicos

- Kotlin, `minSdk 24`, sin AndroidX, interfaz construida por código. Paquetes: `core`, `script`, `engine`, `editor`, `export` (sin dependencias de Android, probados en JVM) y `app` (Android).
- El intérprete debe tener presupuesto de instrucciones y no colgar la app; los errores muestran línea y mensaje claros en la consola.
- Estilo de código: simple, comentado donde no sea obvio, sin dependencias externas.

## 6. Criterios de aceptación

1. Un principiante crea un juego de plataformas con monedas y enemigos solo con comportamientos y bloques, sin escribir código.
2. Puede dibujar un sprite de 32×32, animarlo con 4 cuadros y verlo moverse en el juego.
3. Con teclado y mouse conectados puede trabajar sin tocar la pantalla.
4. Pulsa «Exportar APK», instala el resultado y el juego arranca solo, con otro nombre y paquete (el icono todavía es el del motor).
5. Todas las pruebas automáticas pasan antes de cada entrega y la compilación en GitHub Actions termina sin errores.

## 7. Hoja de ruta

| Fase | Contenido | Estado |
|---|---|---|
| 1 | Núcleo, física, scripts, editor, 77 comportamientos | Hecha |
| 2 | Tiempos, mouse/teclado en scripts, atajos del editor | Entregada (compilar en GitHub y probar en el celular) |
| 3 | Bloques visuales con compilador a GDScript y editor | Entregada (compilar en GitHub y probar en el celular) |
| 4 | Editor de sprites y animación por cuadros | Entregada (compilar en GitHub y probar en el celular) |
| 5 | Exportación de APK dentro de la app | Entregada; hay que probar la instalación en un dispositivo real |
| 6 | Sonido, partículas, mapas de tiles, línea de tiempo de animación | Pendiente |

## 7.1 Forma de trabajo

Cada fase se entrega como un ZIP compilable con GitHub Actions. Antes de entregar: pruebas en JVM, revisión independiente del código de Android y lista de lo que solo puede comprobarse en el celular.
