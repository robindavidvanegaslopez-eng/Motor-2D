# @nombre: Zona de agua (frena y flota)
# @categoria: Mundo y física
# @descripcion: Frena el movimiento de lo que entra y lo empuja hacia arriba, como si flotara.
# @requiere: BoxCollider2D
# @trigger: si
extends Node2D
@export var drag = 4.0
@export var buoyancy = 1800.0
var _in = []

func _on_trigger_enter(other):
    if other.rigidbody != null:
        _in.append(other)

func _on_trigger_exit(other):
    _in.erase(other)

func _physics_process(delta):
    for o in _in:
        if is_instance_valid(o) and o.rigidbody != null:
            var rb = o.rigidbody
            rb.velocity = rb.velocity * (1.0 - min(drag * delta, 0.9))
            rb.add_force(Vector2(0, -buoyancy))
