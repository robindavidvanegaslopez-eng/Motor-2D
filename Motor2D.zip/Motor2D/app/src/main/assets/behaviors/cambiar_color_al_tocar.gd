# @nombre: Cambiar de color al tocarlo
# @categoria: Efectos visuales
# @descripcion: Cada vez que lo tocas toma un color distinto al azar.
# @requiere: BoxCollider2D
extends Node2D

func _on_touched():
    set_color(Color(randf(), randf(), randf()))
