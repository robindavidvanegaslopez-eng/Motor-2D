# @nombre: Marcador de puntos
# @categoria: Reglas y marcadores
# @descripcion: Texto que lleva la cuenta. Otros objetos suman con get_object("Puntos").add(1). Al llegar a 'goal' carga 'next_scene' (o reinicia). Ponle el nombre 'Puntos' al objeto.
# @requiere: Label
extends Node2D
@export var prefix = "Puntos: "
@export var goal = 0
@export var next_scene = ""
@export var follow_camera = true
@export var offset = Vector2(0, -300)
var score = 0

func add(n):
    score += n
    _refresh()
    if goal > 0 and score >= goal:
        if next_scene != "":
            load_scene(next_scene)
        else:
            reload_scene()

func reset_score():
    score = 0
    _refresh()

func _refresh():
    label.text = prefix + str(score)

func _ready():
    _refresh()

func _process(delta):
    if follow_camera:
        var cam = get_object("Camara")
        if cam != null:
            position = cam.position + offset
