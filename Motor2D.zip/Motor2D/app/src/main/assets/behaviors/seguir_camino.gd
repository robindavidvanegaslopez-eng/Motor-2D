# @nombre: Seguir un camino de puntos
# @categoria: Movimiento
# @descripcion: Recorre una lista de puntos. Escribe el camino en 'path' como 'x,y; x,y; ...'. Con 'relative' los puntos se miden desde donde empieza el objeto.
# @requiere: Rigidbody2D, BoxCollider2D
# @cuerpo: kinematic
extends Node2D
@export var path = "200,0; 200,200; 0,200; 0,0"
@export var speed = 150.0
@export var loop = true
@export var relative = true
var _pts = []
var _i = 0
var _done = false

func _ready():
    var origin = global_position
    for part in path.split(";"):
        var xy = part.strip_edges().split(",")
        if xy.size() >= 2:
            var p = Vector2(xy[0].to_float(), xy[1].to_float())
            if relative:
                p = p + origin
            _pts.append(p)

func _set_vel(v, delta):
    if rigidbody != null:
        rigidbody.velocity = v
    else:
        global_position = global_position + v * delta

func _physics_process(delta):
    if _pts.size() == 0 or _done:
        _set_vel(Vector2(0, 0), delta)
        return
    var d = _pts[_i] - global_position
    if d.length() <= speed * delta + 1.0:
        _i += 1
        if _i >= _pts.size():
            if loop:
                _i = 0
            else:
                _i = _pts.size() - 1
                _done = true
        _set_vel(Vector2(0, 0), delta)
    else:
        _set_vel(d.normalized() * speed, delta)
