# @nombre: Aparecer por el lado contrario
# @categoria: Movimiento
# @descripcion: Si sale por un borde de la pantalla, aparece por el opuesto (estilo Asteroids o Pac-Man).
extends Node2D
@export var margin = 20.0

func _process(delta):
    var p = position
    var w = screen_size.x
    var h = screen_size.y
    if p.x < -margin:
        p = Vector2(w + margin, p.y)
    elif p.x > w + margin:
        p = Vector2(-margin, p.y)
    if p.y < -margin:
        p = Vector2(p.x, h + margin)
    elif p.y > h + margin:
        p = Vector2(p.x, -margin)
    position = p
