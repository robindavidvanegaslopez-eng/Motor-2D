# @nombre: Orbitar alrededor de un punto
# @categoria: Movimiento
# @descripcion: Da vueltas en círculo. Si escribes 'center_name' gira alrededor de ese objeto; si no, alrededor del punto donde lo pusiste.
extends Node2D
@export var center_name = ""
@export var radius = 120.0
@export var speed = 90.0
var _angle = 0.0
var _center = Vector2(0, 0)
var _target = null

func _ready():
    _center = global_position - Vector2(radius, 0)
    if center_name != "":
        _target = get_object(center_name)

func _process(delta):
    _angle += speed * delta
    var c = _center
    if _target != null and is_instance_valid(_target):
        c = _target.global_position
    var a = deg_to_rad(_angle)
    global_position = c + Vector2(cos(a), sin(a)) * radius
