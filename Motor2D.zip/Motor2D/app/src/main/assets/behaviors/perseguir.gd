# @nombre: Perseguir a un objetivo
# @categoria: Movimiento
# @descripcion: Se acerca al objeto indicado (por nombre) cuando está a la vista. Con 'only_horizontal' solo camina de lado (para plataformas).
# @requiere: Rigidbody2D, BoxCollider2D
# @bloquear_rotacion: si
# @tag: enemigo
extends Node2D
@export var target_name = "Jugador"
@export var speed = 120.0
@export var sight = 450.0
@export var stop_distance = 12.0
@export var only_horizontal = false
var _target = null

func _move(v, delta):
    if rigidbody != null:
        if only_horizontal:
            rigidbody.velocity = Vector2(v.x, rigidbody.velocity.y)
        else:
            rigidbody.velocity = v
    else:
        translate(v * delta)

func _process(delta):
    if _target == null or not is_instance_valid(_target):
        _target = get_object(target_name)
    var v = Vector2(0, 0)
    if _target != null:
        var d = _target.global_position - global_position
        if d.length() < sight and d.length() > stop_distance:
            v = d.normalized() * speed
    _move(v, delta)
