# @nombre: Meta / bandera de fin de nivel
# @categoria: Objetos y coleccionables
# @descripcion: Cuando el jugador la toca carga 'next_scene' o, si está vacío, muestra un mensaje en el objeto 'Mensaje' (script Mensaje en pantalla) y detiene al jugador.
# @requiere: BoxCollider2D
# @trigger: si
extends Node2D
@export var who = "Jugador"
@export var next_scene = ""
@export var message = "¡Nivel completado!"
var _done = false

func _on_trigger_enter(other):
    if _done:
        return
    if other.name == who or other.tag == who:
        _done = true
        if next_scene != "":
            load_scene(next_scene)
        else:
            var m = get_object("Mensaje")
            if m != null and m.has_method("show_message"):
                m.show_message(message, 99.0)
            else:
                print(message)
