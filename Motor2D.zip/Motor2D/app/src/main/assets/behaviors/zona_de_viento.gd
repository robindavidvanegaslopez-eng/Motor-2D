# @nombre: Zona de viento / fuerza
# @categoria: Mundo y física
# @descripcion: Empuja con una fuerza constante a todo lo que tenga física dentro de la zona. Con una fuerza hacia arriba sirve de corriente de aire o baja gravedad.
# @requiere: BoxCollider2D
# @trigger: si
extends Node2D
@export var force = Vector2(0, -2500)
var _in = []

func _on_trigger_enter(other):
    if other.rigidbody != null:
        _in.append(other)

func _on_trigger_exit(other):
    _in.erase(other)

func _physics_process(delta):
    for o in _in:
        if is_instance_valid(o) and o.rigidbody != null:
            o.rigidbody.add_force(force)
