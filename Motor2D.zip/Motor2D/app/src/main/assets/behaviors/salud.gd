# @nombre: Salud (vida, daño y curación)
# @categoria: Combate y vida
# @descripcion: Da vida al objeto: hurt(n) la baja, heal(n) la sube. Al llegar a 0: 'on_death' = destruir, reiniciar o nada. Parpadea al recibir daño y tiene un momento de invulnerabilidad.
# @requiere: BoxCollider2D
extends Node2D
@export var max_health = 5
@export var on_death = "destruir"
@export var invulnerable_time = 0.6
@export var flash_color = Color(1, 0.3, 0.3)
@export var points_on_death = 0
@export var score_object = "Puntos"
var health = 5
var _inv = 0.0
var _normal = null

func _ready():
    health = max_health
    if sprite != null:
        _normal = sprite.color

func hurt(n):
    if _inv > 0.0 or health <= 0:
        return
    health -= n
    _inv = invulnerable_time
    if sprite != null:
        set_color(flash_color)
    if health <= 0:
        die()

func heal(n):
    health = min(max_health, health + n)

func die():
    if points_on_death > 0:
        var s = get_object(score_object)
        if s != null and s.has_method("add"):
            s.add(points_on_death)
    if has_method("drop_now"):
        drop_now()
    if on_death == "destruir":
        destroy(self)
    elif on_death == "reiniciar":
        reload_scene()

func _process(delta):
    if _inv > 0.0:
        _inv -= delta
        if _inv <= 0.0 and sprite != null and _normal != null:
            set_color(_normal)
