# @nombre: Cuenta regresiva
# @categoria: Reglas y marcadores
# @descripcion: Muestra el tiempo que queda. Al llegar a cero reinicia la escena o carga otra.
# @requiere: Label
extends Node2D
@export var seconds = 60.0
@export var prefix = "Tiempo: "
@export var next_scene = ""
@export var follow_camera = true
@export var offset = Vector2(450, -300)
var _left = 0.0
var _done = false

func _ready():
    _left = seconds

func add_time(s):
    _left += s

func _process(delta):
    if _done:
        return
    _left -= delta
    if _left <= 0.0:
        _left = 0.0
        _done = true
        if next_scene != "":
            load_scene(next_scene)
        else:
            reload_scene()
    label.text = prefix + str(ceil(_left))
    if follow_camera:
        var cam = get_object("Camara")
        if cam != null:
            position = cam.position + offset
