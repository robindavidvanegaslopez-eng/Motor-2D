# @nombre: Jugador de plataformas (caminar y saltar)
# @categoria: Movimiento
# @descripcion: Joystick para caminar y botón A para saltar. 'max_jumps' = 2 da doble salto. Necesita gravedad. Tiene boost(multiplicador, segundos).
# @requiere: Rigidbody2D, BoxCollider2D
# @bloquear_rotacion: si
# @tag: jugador
extends Node2D
@export var speed = 300.0
@export var jump_force = 720.0
@export var max_jumps = 1
var _jumps = 0
var _boost = 1.0
var _boost_time = 0.0

func boost(mult, seconds):
    _boost = mult
    _boost_time = seconds

func _process(delta):
    var rb = rigidbody
    if _boost_time > 0.0:
        _boost_time -= delta
        if _boost_time <= 0.0:
            _boost = 1.0
    rb.velocity = Vector2(Input.joystick.x * speed * _boost, rb.velocity.y)
    if rb.is_on_floor():
        _jumps = 0
    if Input.is_button_just_pressed("A") and _jumps < max_jumps:
        rb.velocity = Vector2(rb.velocity.x, -jump_force)
        _jumps += 1
