# @nombre: Puerta (se abre con llave o interruptor)
# @categoria: Objetos y coleccionables
# @descripcion: Bloquea el paso hasta que unlock() o activate() se llame (por una Llave o un Interruptor). Entonces se desliza fuera del camino.
# @requiere: Rigidbody2D, BoxCollider2D
# @cuerpo: kinematic
extends Node2D
@export var open_offset = Vector2(0, -140)
@export var speed = 200.0
@export var start_open = false
var _closed_pos = Vector2(0, 0)
var _open = false

func _ready():
    _closed_pos = position
    _open = start_open

func unlock():
    _open = true

func activate():
    _open = true

func deactivate():
    _open = false

func _physics_process(delta):
    var goal = _closed_pos
    if _open:
        goal = _closed_pos + open_offset
    var d = goal - position
    if d.length() < speed * delta:
        position = goal
        if rigidbody != null:
            rigidbody.velocity = Vector2(0, 0)
    elif rigidbody != null:
        rigidbody.velocity = d.normalized() * speed
    else:
        position = position + d.normalized() * speed * delta
