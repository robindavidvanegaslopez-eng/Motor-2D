# @nombre: Torreta (dispara al objetivo)
# @categoria: Combate y vida
# @descripcion: Apunta al objetivo y le dispara cada 'rate' segundos cuando está a la vista.
extends Node2D
@export var target_name = "Jugador"
@export var projectile = "Bala"
@export var rate = 1.2
@export var sight = 600.0
@export var turn = true
var _cd = 0.0

func _process(delta):
    _cd -= delta
    var t = get_object(target_name)
    if t == null:
        return
    var d = t.global_position - global_position
    if turn:
        rotation = rad_to_deg(d.angle())
    if d.length() <= sight and _cd <= 0.0:
        _cd = rate
        var b = instantiate(projectile, global_position + d.normalized() * 40.0)
        b.rotation = rad_to_deg(d.angle())
