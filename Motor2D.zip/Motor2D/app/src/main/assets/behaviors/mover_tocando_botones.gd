# @nombre: Mover con botones A y B
# @categoria: Movimiento
# @descripcion: A mueve el objeto en una dirección y B en la contraria. Paletas, ascensores, controles de un solo eje.
# @requiere: Rigidbody2D
# @gravedad: 0
extends Node2D
@export var direction = Vector2(0, 1)
@export var speed = 350.0

func _process(delta):
    var k = 0.0
    if Input.is_button_pressed("A"):
        k += 1.0
    if Input.is_button_pressed("B"):
        k -= 1.0
    var v = direction.normalized() * k * speed
    if rigidbody != null:
        rigidbody.velocity = v
    else:
        translate(v * delta)
