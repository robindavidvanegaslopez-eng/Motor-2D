# @nombre: Bomba con cuenta atrás
# @categoria: Mundo y física
# @descripcion: Explota tras 'fuse' segundos: empuja a los objetos con la etiqueta 'affect_tag' cercanos, daña lo que tenga Salud y desaparece.
extends Node2D
@export var fuse = 2.0
@export var radius = 200.0
@export var power = 900.0
@export var damage = 2
@export var affect_tag = "fisico"
var _t = 0.0

func _process(delta):
    _t += delta
    if _t >= fuse:
        explode()

func explode():
    for o in find_objects_with_tag(affect_tag):
        if is_instance_valid(o):
            var d = o.global_position - global_position
            if d.length() < radius:
                if o.rigidbody != null:
                    o.rigidbody.velocity = o.rigidbody.velocity + d.normalized() * power
                if o.has_method("hurt"):
                    o.hurt(damage)
    destroy(self)
