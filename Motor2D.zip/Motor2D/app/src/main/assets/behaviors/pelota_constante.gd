# @nombre: Pelota que mantiene su velocidad (Pong)
# @categoria: Mundo y física
# @descripcion: Sale lanzada al empezar y mantiene siempre la misma velocidad al rebotar. Dale un collider con 'Rebote' = 1.
# @requiere: Rigidbody2D, CircleCollider2D
# @gravedad: 0
# @bloquear_rotacion: si
# @tag: pelota
extends Node2D
@export var speed = 450.0
@export var launch_angle = -60.0

func _ready():
    var a = deg_to_rad(launch_angle)
    rigidbody.velocity = Vector2(cos(a), sin(a)) * speed

func _physics_process(delta):
    var v = rigidbody.velocity
    if v.length() < 1.0:
        v = Vector2(1, -1)
    rigidbody.velocity = v.normalized() * speed
