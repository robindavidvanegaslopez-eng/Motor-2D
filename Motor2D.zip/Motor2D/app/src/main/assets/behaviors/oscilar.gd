# @nombre: Oscilar (subir y bajar suave)
# @categoria: Movimiento
# @descripcion: Se mueve de un lado a otro con una onda suave. Puntos flotantes, enemigos voladores, monedas que flotan.
extends Node2D
@export var direction = Vector2(0, 1)
@export var amplitude = 30.0
@export var frequency = 1.0
var _start = Vector2(0, 0)
var _t = 0.0

func _ready():
    _start = position

func _process(delta):
    _t += delta
    position = _start + direction.normalized() * sin(_t * frequency * 6.28318) * amplitude
