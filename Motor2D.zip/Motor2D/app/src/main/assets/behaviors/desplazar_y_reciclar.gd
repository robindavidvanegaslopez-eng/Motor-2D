# @nombre: Desplazar y reciclar (tubos, runner)
# @categoria: Mundo y física
# @descripcion: Se mueve hacia un lado y, al salir por el borde, reaparece al otro extremo con una altura al azar. Tubos de Flappy, suelos o fondos infinitos.
# @requiere: Rigidbody2D, BoxCollider2D
# @cuerpo: kinematic
extends Node2D
@export var speed = 200.0
@export var left_limit = -150.0
@export var respawn_x = 1500.0
@export var random_y = 120.0
var _y0 = 0.0

func _ready():
    _y0 = position.y

func _physics_process(delta):
    rigidbody.velocity = Vector2(-speed, 0)
    if position.x < left_limit:
        position = Vector2(respawn_x, _y0 + randf_range(-random_y, random_y))
