# @nombre: Disparar con el botón B
# @categoria: Combate y vida
# @descripcion: Al pulsar B crea una copia del objeto 'projectile' (la plantilla, desactivada) y la lanza hacia donde mira. 'auto_fire' dispara solo.
extends Node2D
@export var projectile = "Bala"
@export var rate = 0.3
@export var auto_fire = false
@export var spawn_offset = Vector2(40, 0)
@export var fixed_direction = Vector2(0, 0)
var _cd = 0.0
var _facing = 1.0

func _process(delta):
    _cd -= delta
    if abs(Input.joystick.x) > 0.3:
        _facing = sign(Input.joystick.x)
    var wants = auto_fire or Input.is_button_pressed("B")
    if wants and _cd <= 0.0:
        _cd = rate
        var dir = Vector2(_facing, 0)
        if fixed_direction.length() > 0.1:
            dir = fixed_direction.normalized()
        var b = instantiate(projectile, global_position + Vector2(spawn_offset.x * _facing, spawn_offset.y))
        b.rotation = rad_to_deg(dir.angle())
