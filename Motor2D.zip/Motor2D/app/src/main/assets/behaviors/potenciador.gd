# @nombre: Potenciador temporal de velocidad
# @categoria: Objetos y coleccionables
# @descripcion: Al tocarlo, el jugador va más rápido unos segundos (funciona con los scripts de movimiento del jugador).
# @requiere: CircleCollider2D
# @trigger: si
extends Node2D
@export var who = "Jugador"
@export var multiplier = 1.6
@export var seconds = 5.0

func _on_trigger_enter(other):
    if other.name == who or other.tag == who:
        if other.has_method("boost"):
            other.boost(multiplier, seconds)
            destroy(self)
