# @nombre: Botón táctil
# @categoria: Interfaz
# @descripcion: Al tocarlo hace una acción: 'escena' carga la escena indicada en 'value', 'reiniciar' reinicia, 'activar' llama a activate() del objeto 'value', 'salir' cierra el juego.
# @requiere: BoxCollider2D
extends Node2D
@export var action = "escena"
@export var value = "main"

func _on_touched():
    if action == "escena":
        load_scene(value)
    elif action == "reiniciar":
        reload_scene()
    elif action == "activar":
        var t = get_object(value)
        if t != null and t.has_method("activate"):
            t.activate()
    elif action == "salir":
        quit()
