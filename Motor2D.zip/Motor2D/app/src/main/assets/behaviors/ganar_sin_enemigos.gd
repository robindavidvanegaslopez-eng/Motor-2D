# @nombre: Ganar al eliminar a todos los enemigos
# @categoria: Reglas y marcadores
# @descripcion: Cuando ya no queda ningún objeto con la etiqueta indicada, carga la escena siguiente o muestra el mensaje de victoria.
extends Node2D
@export var enemy_tag = "enemigo"
@export var next_scene = ""
@export var message = "¡Victoria!"
@export var start_delay = 1.0
var _t = 0.0
var _done = false

func _process(delta):
    _t += delta
    if _done or _t < start_delay:
        return
    if find_objects_with_tag(enemy_tag).size() == 0:
        _done = true
        if next_scene != "":
            load_scene(next_scene)
        else:
            var m = get_object("Mensaje")
            if m != null and m.has_method("show_message"):
                m.show_message(message, 99.0)
            else:
                print(message)
