# @nombre: Reaparecer al caer o morir
# @categoria: Objetos y coleccionables
# @descripcion: Si el objeto cae por debajo de 'fall_limit' vuelve a su punto de reaparición. También respawn() lo devuelve (lo usan Zona de muerte y Salud).
# @requiere: Rigidbody2D
extends Node2D
@export var fall_limit = 1500.0
var _spawn = Vector2(0, 0)

func _ready():
    _spawn = global_position

func set_checkpoint(p):
    _spawn = p

func respawn():
    global_position = _spawn
    if rigidbody != null:
        rigidbody.stop()

func _process(delta):
    if global_position.y > fall_limit:
        respawn()
