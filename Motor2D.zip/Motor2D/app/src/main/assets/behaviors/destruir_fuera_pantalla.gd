# @nombre: Eliminar al salir de la pantalla
# @categoria: Combate y vida
# @descripcion: El objeto se elimina cuando sale del área indicada. Evita que balas y enemigos se acumulen.
extends Node2D
@export var margin = 200.0
@export var area_size = Vector2(1280, 720)

func _process(delta):
    var p = global_position
    if p.x < -margin or p.x > area_size.x + margin or p.y < -margin or p.y > area_size.y + margin:
        destroy(self)
