# @nombre: Caminar y girar en las paredes
# @categoria: Movimiento
# @descripcion: Camina en horizontal y da la vuelta al chocar con una pared. Enemigo clásico de plataformas (necesita gravedad).
# @requiere: Rigidbody2D, BoxCollider2D
# @bloquear_rotacion: si
# @tag: enemigo
extends Node2D
@export var speed = 90.0
var _dir = 1.0
var _cool = 0.0

func _physics_process(delta):
    _cool -= delta
    var rb = rigidbody
    if rb.is_on_wall() and _cool <= 0.0:
        _dir = -_dir
        _cool = 0.25
    rb.velocity = Vector2(_dir * speed, rb.velocity.y)
