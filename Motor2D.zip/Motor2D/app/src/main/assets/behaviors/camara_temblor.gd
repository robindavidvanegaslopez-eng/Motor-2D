# @nombre: Temblor de cámara
# @categoria: Cámara
# @descripcion: Llama a shake(fuerza, segundos) en la cámara para hacerla temblar (golpes, explosiones). No uses a la vez con Cámara que sigue (esa ya trae shake).
# @requiere: Camera2D
extends Node2D
var _power = 0.0
var _t = 0.0
var _home = Vector2(0, 0)
var _shaking = false

func shake(power, seconds):
    if not _shaking:
        _home = position
    _power = power
    _t = seconds
    _shaking = true

func _process(delta):
    if _shaking:
        _t -= delta
        if _t <= 0.0:
            position = _home
            _shaking = false
        else:
            position = _home + Vector2(randf_range(-_power, _power), randf_range(-_power, _power))
