# @nombre: Avanzar en línea recta
# @categoria: Movimiento
# @descripcion: Se mueve siempre en la misma dirección. Con 'use_rotation' avanza hacia donde apunta el objeto.
extends Node2D
@export var direction = Vector2(1, 0)
@export var speed = 200.0
@export var use_rotation = false

func _process(delta):
    var d = direction.normalized()
    if use_rotation:
        var a = deg_to_rad(rotation)
        d = Vector2(cos(a), sin(a))
    translate(d * speed * delta)
