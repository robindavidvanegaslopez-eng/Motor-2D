# @nombre: Interruptor de presión
# @categoria: Objetos y coleccionables
# @descripcion: Activa otro objeto ('target_name') mientras el jugador está encima, o lo deja activado para siempre con 'stay_on'. El objetivo necesita activate()/deactivate() (por ejemplo, el script Puerta).
# @requiere: BoxCollider2D
# @trigger: si
extends Node2D
@export var who = "Jugador"
@export var target_name = "Puerta"
@export var stay_on = false

func _on_trigger_enter(other):
    if other.name == who or other.tag == who:
        var t = get_object(target_name)
        if t != null and t.has_method("activate"):
            t.activate()
        if sprite != null:
            set_color(Color(0.4, 1, 0.4))

func _on_trigger_exit(other):
    if stay_on:
        return
    if other.name == who or other.tag == who:
        var t = get_object(target_name)
        if t != null and t.has_method("deactivate"):
            t.deactivate()
        if sprite != null:
            set_color(Color(1, 0.4, 0.4))
