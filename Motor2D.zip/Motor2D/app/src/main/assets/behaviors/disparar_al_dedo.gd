# @nombre: Disparar hacia donde tocas
# @categoria: Combate y vida
# @descripcion: Cada toque en la pantalla lanza una copia de 'projectile' desde el objeto hacia el punto tocado.
extends Node2D
@export var projectile = "Bala"
@export var rate = 0.2
var _cd = 0.0

func _process(delta):
    _cd -= delta
    if Input.is_touching() and _cd <= 0.0:
        _cd = rate
        var d = Input.touch_world_position() - global_position
        var b = instantiate(projectile, global_position + d.normalized() * 40.0)
        b.rotation = rad_to_deg(d.angle())
