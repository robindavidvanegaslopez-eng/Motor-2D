# @nombre: Soltar un objeto al morir
# @categoria: Combate y vida
# @descripcion: El script Salud llama a drop_now() cuando el objeto muere (también puedes llamarla tú) y suelta una copia de 'drop' donde estaba el objeto. Monedas de enemigos, restos.
extends Node2D
@export var drop = "Moneda"
@export var chance = 1.0

func drop_now():
    if randf() <= chance:
        instantiate(drop, global_position)
