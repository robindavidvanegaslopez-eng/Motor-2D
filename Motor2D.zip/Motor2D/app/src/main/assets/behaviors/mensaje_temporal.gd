# @nombre: Mensaje en pantalla
# @categoria: Reglas y marcadores
# @descripcion: Texto oculto que se muestra con show_message("¡Hola!", 2) durante unos segundos. Útil para 'Nivel completado' o 'Game Over'.
# @requiere: Label
extends Node2D
@export var follow_camera = true
@export var offset = Vector2(0, 0)
var _t = 0.0

func show_message(text, seconds):
    label.text = text
    visible = true
    _t = seconds

func _ready():
    visible = false

func _process(delta):
    if _t > 0.0:
        _t -= delta
        if _t <= 0.0:
            visible = false
    if follow_camera:
        var cam = get_object("Camara")
        if cam != null:
            position = cam.position + offset
