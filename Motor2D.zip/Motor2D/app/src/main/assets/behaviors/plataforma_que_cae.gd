# @nombre: Plataforma que se cae
# @categoria: Mundo y física
# @descripcion: Tiembla y cae cuando alguien se sube, después de 'delay' segundos. Se elimina al caer muy lejos.
# @requiere: Rigidbody2D, BoxCollider2D
# @cuerpo: kinematic
extends Node2D
@export var who = "Jugador"
@export var delay = 0.6
@export var fall_speed = 500.0
var _timer = -1.0
var _falling = false
var _home = Vector2(0, 0)

func _ready():
    _home = position

func _on_collision_enter(other):
    if _timer < 0.0 and not _falling and (other.name == who or other.tag == who):
        _timer = delay

func _physics_process(delta):
    if _falling:
        rigidbody.velocity = Vector2(0, fall_speed)
        if position.y > _home.y + 3000.0:
            destroy(self)
    elif _timer >= 0.0:
        _timer -= delta
        position = Vector2(_home.x + randf_range(-2.0, 2.0), _home.y)
        if _timer < 0.0:
            _falling = true
