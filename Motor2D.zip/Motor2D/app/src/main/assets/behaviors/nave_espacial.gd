# @nombre: Nave espacial (girar y propulsar)
# @categoria: Movimiento
# @descripcion: Joystick izquierda/derecha gira la nave y el botón A la impulsa hacia adelante. Estilo Asteroids.
# @requiere: Rigidbody2D, CircleCollider2D
# @gravedad: 0
extends Node2D
@export var turn_speed = 220.0
@export var thrust = 420.0
@export var drag = 0.6
@export var max_speed = 600.0

func _physics_process(delta):
    var rb = rigidbody
    rotation = rotation + Input.joystick.x * turn_speed * delta
    var v = rb.velocity
    if Input.is_button_pressed("A"):
        var a = deg_to_rad(rotation)
        v = v + Vector2(cos(a), sin(a)) * thrust * delta
    v = v * (1.0 - drag * delta)
    rb.velocity = v.limit_length(max_speed)
