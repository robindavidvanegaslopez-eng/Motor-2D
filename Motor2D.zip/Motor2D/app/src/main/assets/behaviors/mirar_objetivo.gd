# @nombre: Girar hacia un objetivo
# @categoria: Movimiento
# @descripcion: Gira el objeto para apuntar a otro objeto (por nombre) o al dedo si 'target_name' está vacío. Torretas, ojos, cañones.
extends Node2D
@export var target_name = "Jugador"
@export var offset_degrees = 0.0
@export var turn_speed = 360.0

func _process(delta):
    var p = null
    if target_name == "":
        if Input.is_touching():
            p = Input.touch_world_position()
    else:
        var t = get_object(target_name)
        if t != null:
            p = t.global_position
    if p == null:
        return
    var d = p - global_position
    var want = rad_to_deg(d.angle()) + offset_degrees
    var diff = fposmod(want - rotation + 180.0, 360.0) - 180.0
    var step = turn_speed * delta
    rotation = rotation + clamp(diff, -step, step)
