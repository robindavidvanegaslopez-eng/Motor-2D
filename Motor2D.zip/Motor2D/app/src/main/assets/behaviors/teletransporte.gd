# @nombre: Portal (teletransporte)
# @categoria: Objetos y coleccionables
# @descripcion: Lleva al jugador al objeto 'target_name'. Pon el mismo script en el destino apuntando al primero para tener portales de ida y vuelta.
# @requiere: CircleCollider2D
# @trigger: si
extends Node2D
@export var who = "Jugador"
@export var target_name = "Portal2"
var _skip = null

func ignore_once(o):
    _skip = o

func _on_trigger_enter(other):
    if other == _skip:
        return
    if other.name == who or other.tag == who:
        var t = get_object(target_name)
        if t == null:
            return
        if t.has_method("ignore_once"):
            t.ignore_once(other)
        other.global_position = t.global_position
        if other.rigidbody != null:
            other.rigidbody.velocity = Vector2(0, 0)

func _on_trigger_exit(other):
    if other == _skip:
        _skip = null
