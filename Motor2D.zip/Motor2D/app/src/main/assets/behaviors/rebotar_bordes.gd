# @nombre: Rebotar en los bordes de la pantalla
# @categoria: Movimiento
# @descripcion: Se mueve sin parar y rebota en los bordes de la pantalla. Pelotas, protectores de pantalla, enemigos simples.
extends Node2D
@export var start_velocity = Vector2(220, 160)
@export var margin = 20.0
var _v = Vector2(0, 0)

func _ready():
    _v = start_velocity

func _process(delta):
    var p = position + _v * delta
    var w = screen_size.x
    var h = screen_size.y
    if p.x < margin:
        p = Vector2(margin, p.y)
        _v = Vector2(abs(_v.x), _v.y)
    if p.x > w - margin:
        p = Vector2(w - margin, p.y)
        _v = Vector2(-abs(_v.x), _v.y)
    if p.y < margin:
        p = Vector2(p.x, margin)
        _v = Vector2(_v.x, abs(_v.y))
    if p.y > h - margin:
        p = Vector2(p.x, h - margin)
        _v = Vector2(_v.x, -abs(_v.y))
    position = p
