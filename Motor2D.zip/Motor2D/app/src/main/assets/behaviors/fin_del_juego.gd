# @nombre: Fin del juego (toca para reiniciar)
# @categoria: Reglas y marcadores
# @descripcion: Llama a game_over() para mostrar el texto y reiniciar la escena con un toque. Ponlo en un objeto de texto.
# @requiere: Label
extends Node2D
@export var text = "Fin del juego - toca para reintentar"
@export var follow_camera = true
@export var offset = Vector2(0, 0)
var _over = false

func game_over():
    _over = true
    label.text = text
    visible = true

func _ready():
    visible = false

func _process(delta):
    if follow_camera:
        var cam = get_object("Camara")
        if cam != null:
            position = cam.position + offset
    if _over and Input.just_touched():
        reload_scene()
