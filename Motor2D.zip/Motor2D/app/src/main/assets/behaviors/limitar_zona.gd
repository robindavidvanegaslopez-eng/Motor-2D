# @nombre: Limitar a una zona
# @categoria: Movimiento
# @descripcion: No deja que el objeto salga del rectángulo definido por 'min_pos' y 'max_pos'.
extends Node2D
@export var min_pos = Vector2(0, 0)
@export var max_pos = Vector2(1280, 720)

func _process(delta):
    var p = position
    position = Vector2(clamp(p.x, min_pos.x, max_pos.x), clamp(p.y, min_pos.y, max_pos.y))
