# @nombre: Botiquín (cura al tocarlo)
# @categoria: Objetos y coleccionables
# @descripcion: Cura al jugador con el script Salud y desaparece.
# @requiere: BoxCollider2D
# @trigger: si
extends Node2D
@export var who = "Jugador"
@export var amount = 2

func _on_trigger_enter(other):
    if other.name == who or other.tag == who:
        if other.has_method("heal"):
            other.heal(amount)
            destroy(self)
