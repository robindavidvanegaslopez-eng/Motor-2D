# @nombre: Paleta que sigue el dedo en un eje
# @categoria: Movimiento
# @descripcion: Se desliza por un eje siguiendo el dedo. Para Pong, Arkanoid y similares. Elige el eje 'horizontal' o 'vertical'.
# @requiere: Rigidbody2D, BoxCollider2D
# @cuerpo: kinematic
extends Node2D
@export var axis = "horizontal"
@export var speed = 900.0
@export var min_value = 60.0
@export var max_value = 1220.0

func _physics_process(delta):
    var rb = rigidbody
    var v = Vector2(0, 0)
    if Input.is_touching():
        var t = Input.touch_world_position()
        if axis == "horizontal":
            var tx = clamp(t.x, min_value, max_value)
            v = Vector2(clamp((tx - global_position.x) * 12.0, -speed, speed), 0)
        else:
            var ty = clamp(t.y, min_value, max_value)
            v = Vector2(0, clamp((ty - global_position.y) * 12.0, -speed, speed))
    rb.velocity = v
