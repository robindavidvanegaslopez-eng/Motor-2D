# @nombre: Mover con joystick (vista desde arriba)
# @categoria: Movimiento
# @descripcion: Mueve el objeto en cualquier dirección con el joystick. Sirve para juegos vistos desde arriba. Tiene boost(multiplicador, segundos) para potenciadores.
# @requiere: Rigidbody2D, BoxCollider2D
# @gravedad: 0
# @bloquear_rotacion: si
# @tag: jugador
extends Node2D
@export var speed = 300.0
var _boost = 1.0
var _boost_time = 0.0

func boost(mult, seconds):
    _boost = mult
    _boost_time = seconds

func _process(delta):
    if _boost_time > 0.0:
        _boost_time -= delta
        if _boost_time <= 0.0:
            _boost = 1.0
    var d = Input.joystick * speed * _boost
    if rigidbody != null:
        rigidbody.velocity = d
    else:
        translate(d * delta)
