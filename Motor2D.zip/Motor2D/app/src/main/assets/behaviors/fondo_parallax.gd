# @nombre: Fondo con parallax
# @categoria: Cámara
# @descripcion: El objeto se mueve más lento que la cámara para dar sensación de profundidad. 'factor' 0 = fijo al mundo, 1 = pegado a la pantalla.
extends Node2D
@export var factor = 0.5
var _home = Vector2(0, 0)
var _cam0 = Vector2(0, 0)
var _ready_ok = false

func _process(delta):
    var cam = get_object("Camara")
    if cam == null:
        return
    if not _ready_ok:
        _home = position
        _cam0 = cam.position
        _ready_ok = true
    position = _home + (cam.position - _cam0) * factor
