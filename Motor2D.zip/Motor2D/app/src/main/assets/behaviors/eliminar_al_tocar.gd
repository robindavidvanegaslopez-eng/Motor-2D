# @nombre: Eliminar al tocarlo
# @categoria: Efectos visuales
# @descripcion: Toca el objeto y desaparece, sumando puntos si quieres. Globos, topos, objetivos de tiro.
# @requiere: BoxCollider2D
extends Node2D
@export var points = 1
@export var score_object = "Puntos"

func _on_touched():
    var s = get_object(score_object)
    if s != null and s.has_method("add"):
        s.add(points)
    destroy(self)
