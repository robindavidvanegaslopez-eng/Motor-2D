# @nombre: Saltar cada cierto tiempo
# @categoria: Movimiento
# @descripcion: Salta solo cada 'interval' segundos. Enemigos saltarines o ranas (necesita gravedad).
# @requiere: Rigidbody2D, BoxCollider2D
# @bloquear_rotacion: si
# @tag: enemigo
extends Node2D
@export var interval = 1.5
@export var jump_force = 600.0
@export var sideways = 120.0
var _t = 0.0
var _dir = 1.0

func _physics_process(delta):
    _t += delta
    var rb = rigidbody
    if rb.is_on_floor():
        rb.velocity = Vector2(0, rb.velocity.y)
        if _t >= interval:
            _t = 0.0
            rb.velocity = Vector2(_dir * sideways, -jump_force)
            _dir = -_dir
