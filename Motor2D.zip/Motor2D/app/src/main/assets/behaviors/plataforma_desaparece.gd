# @nombre: Plataforma que aparece y desaparece
# @categoria: Mundo y física
# @descripcion: Alterna entre visible (sólida) y oculta cada cierto tiempo.
# @requiere: Rigidbody2D, BoxCollider2D
# @cuerpo: kinematic
extends Node2D
@export var visible_time = 2.0
@export var hidden_time = 1.5
var _t = 0.0
var _on = true
var _home = Vector2(0, 0)

func _ready():
    _home = position

func _physics_process(delta):
    _t += delta
    if _on and _t >= visible_time:
        _on = false
        _t = 0.0
        visible = false
        position = _home + Vector2(0, 100000.0)
    elif (not _on) and _t >= hidden_time:
        _on = true
        _t = 0.0
        visible = true
        position = _home
