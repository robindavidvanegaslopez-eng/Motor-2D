# @nombre: Huir de un objetivo
# @categoria: Movimiento
# @descripcion: Se aleja del objeto indicado cuando este se acerca. Sirve para presas, fantasmas asustadizos o NPCs.
# @requiere: Rigidbody2D, BoxCollider2D
# @gravedad: 0
# @bloquear_rotacion: si
extends Node2D
@export var target_name = "Jugador"
@export var speed = 160.0
@export var fear_distance = 300.0
@export var only_horizontal = false
var _target = null

func _move(v, delta):
    if rigidbody != null:
        if only_horizontal:
            rigidbody.velocity = Vector2(v.x, rigidbody.velocity.y)
        else:
            rigidbody.velocity = v
    else:
        translate(v * delta)

func _process(delta):
    if _target == null or not is_instance_valid(_target):
        _target = get_object(target_name)
    var v = Vector2(0, 0)
    if _target != null:
        var d = global_position - _target.global_position
        if d.length() < fear_distance:
            v = d.normalized() * speed
    _move(v, delta)
