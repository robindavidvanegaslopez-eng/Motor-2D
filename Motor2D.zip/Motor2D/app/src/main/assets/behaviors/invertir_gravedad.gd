# @nombre: Invertir la gravedad con A
# @categoria: Movimiento
# @descripcion: Al pulsar A (estando en el suelo o techo) la gravedad de este objeto se invierte. Estilo Gravity Guy.
# @requiere: Rigidbody2D, BoxCollider2D
# @bloquear_rotacion: si
extends Node2D
@export var speed = 300.0
var _flip = 1.0

func _process(delta):
    var rb = rigidbody
    rb.velocity = Vector2(Input.joystick.x * speed, rb.velocity.y)
    if Input.is_button_just_pressed("A") and (rb.is_on_floor() or rb.is_on_ceiling()):
        _flip = -_flip
        rb.velocity = Vector2(rb.velocity.x, 0.0)
        rb.gravity_scale = _flip
