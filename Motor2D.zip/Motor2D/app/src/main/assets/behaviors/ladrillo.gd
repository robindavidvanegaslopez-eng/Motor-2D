# @nombre: Ladrillo (se rompe al golpearlo)
# @categoria: Mundo y física
# @descripcion: Se rompe al ser golpeado por un objeto con la etiqueta 'hit_tag' y suma puntos. Arkanoid / Breakout.
# @requiere: BoxCollider2D
# @cuerpo: static
# @tag: ladrillo
extends Node2D
@export var hit_tag = "pelota"
@export var hits = 1
@export var points = 10
@export var score_object = "Puntos"

func _on_collision_enter(other):
    if other.tag == hit_tag or other.name == hit_tag:
        hits -= 1
        if hits <= 0:
            var s = get_object(score_object)
            if s != null and s.has_method("add"):
                s.add(points)
            destroy(self)
