# @nombre: Daño continuo en una zona
# @categoria: Combate y vida
# @descripcion: Mientras el jugador permanece dentro del disparador recibe daño cada 'interval' segundos. Ácido, fuego, gas venenoso.
# @requiere: BoxCollider2D
# @trigger: si
extends Node2D
@export var who = "Jugador"
@export var damage = 1
@export var interval = 1.0
var _inside = []
var _t = 0.0

func _on_trigger_enter(other):
    if other.name == who or other.tag == who:
        _inside.append(other)

func _on_trigger_exit(other):
    _inside.erase(other)

func _process(delta):
    _t += delta
    if _t >= interval:
        _t = 0.0
        for o in _inside:
            if is_instance_valid(o) and o.has_method("hurt"):
                o.hurt(damage)
