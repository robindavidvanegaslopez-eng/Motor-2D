# @nombre: Generador (spawner) de objetos
# @categoria: Combate y vida
# @descripcion: Crea una copia de un objeto plantilla cada 'interval' segundos en una zona aleatoria. Enemigos, obstáculos, monedas que caen. 'max_alive' limita cuántos hay a la vez.
extends Node2D
@export var template = "Enemigo"
@export var interval = 2.0
@export var area_size = Vector2(600, 0)
@export var max_alive = 10
@export var first_delay = 1.0
var _t = 0.0
var _made = []

func _ready():
    _t = interval - first_delay

func _process(delta):
    _t += delta
    if _t < interval:
        return
    _t = 0.0
    var alive = []
    for o in _made:
        if is_instance_valid(o):
            alive.append(o)
    _made = alive
    if _made.size() >= max_alive:
        return
    var p = global_position + Vector2(randf_range(-area_size.x / 2.0, area_size.x / 2.0), randf_range(-area_size.y / 2.0, area_size.y / 2.0))
    _made.append(instantiate(template, p))
