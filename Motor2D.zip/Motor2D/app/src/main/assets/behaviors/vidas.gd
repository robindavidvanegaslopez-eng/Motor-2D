# @nombre: Vidas del jugador
# @categoria: Reglas y marcadores
# @descripcion: Texto con las vidas. Llama a get_object("Vidas").lose_life() cuando el jugador muera. Sin vidas reinicia la escena. Ponle el nombre 'Vidas' al objeto.
# @requiere: Label
extends Node2D
@export var start_lives = 3
@export var prefix = "Vidas: "
@export var follow_camera = true
@export var offset = Vector2(-450, -300)
var lives = 3

func lose_life():
    lives -= 1
    _refresh()
    if lives <= 0:
        reload_scene()

func add_life(n):
    lives += n
    _refresh()

func _refresh():
    label.text = prefix + str(lives)

func _ready():
    lives = start_lives
    _refresh()

func _process(delta):
    if follow_camera:
        var cam = get_object("Camara")
        if cam != null:
            position = cam.position + offset
