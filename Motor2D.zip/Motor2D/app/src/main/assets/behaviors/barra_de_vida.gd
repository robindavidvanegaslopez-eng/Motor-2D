# @nombre: Barra de vida (texto)
# @categoria: Combate y vida
# @descripcion: Texto con corazones o barras que refleja la salud de otro objeto ('target_name'). Por ejemplo, el jugador.
# @requiere: Label
extends Node2D
@export var target_name = "Jugador"
@export var symbol = "♥"
@export var follow_camera = true
@export var offset = Vector2(-450, -260)
var _target = null

func _process(delta):
    if _target == null or not is_instance_valid(_target):
        _target = get_object(target_name)
    var h = 0
    if _target != null and _target.has_method("hurt"):
        h = _target.health
    var s = ""
    for i in range(max(h, 0)):
        s += symbol
    label.text = s
    if follow_camera:
        var cam = get_object("Camara")
        if cam != null:
            position = cam.position + offset
