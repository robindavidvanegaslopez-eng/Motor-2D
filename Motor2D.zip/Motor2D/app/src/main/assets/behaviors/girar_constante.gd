# @nombre: Girar sin parar
# @categoria: Movimiento
# @descripcion: Rota el objeto continuamente. Hélices, sierras, monedas, ruedas.
extends Node2D
@export var degrees_per_second = 180.0

func _process(delta):
    rotation = rotation + degrees_per_second * delta
