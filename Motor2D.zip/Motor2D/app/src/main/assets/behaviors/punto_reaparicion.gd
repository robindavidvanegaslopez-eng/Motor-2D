# @nombre: Punto de reaparición (checkpoint)
# @categoria: Objetos y coleccionables
# @descripcion: Cuando el jugador lo toca, ese lugar pasa a ser su punto de reaparición (el jugador necesita el script Reaparecer).
# @requiere: BoxCollider2D
# @trigger: si
extends Node2D
@export var who = "Jugador"

func _on_trigger_enter(other):
    if other.name == who or other.tag == who:
        if other.has_method("set_checkpoint"):
            other.set_checkpoint(global_position)
            if sprite != null:
                set_color(Color(0.4, 1, 0.4))
