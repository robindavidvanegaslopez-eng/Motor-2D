# @nombre: Cinta transportadora
# @categoria: Mundo y física
# @descripcion: Arrastra en la dirección indicada a lo que esté encima. Cambia 'speed' (negativo = al revés).
# @requiere: Rigidbody2D, BoxCollider2D
# @cuerpo: static
extends Node2D
@export var speed = 150.0
var _on = []

func _on_collision_enter(other):
    if other.rigidbody != null:
        _on.append(other)

func _on_collision_exit(other):
    _on.erase(other)

func _physics_process(delta):
    for o in _on:
        if is_instance_valid(o):
            o.global_position = o.global_position + Vector2(speed * delta, 0)
