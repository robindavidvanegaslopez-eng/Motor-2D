# @nombre: Desaparecer después de un tiempo
# @categoria: Combate y vida
# @descripcion: El objeto se elimina solo pasados 'seconds' segundos. Balas, efectos, humo.
extends Node2D
@export var seconds = 2.0
var _t = 0.0

func _process(delta):
    _t += delta
    if _t >= seconds:
        destroy(self)
