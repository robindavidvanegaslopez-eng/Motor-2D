# @nombre: Cámara que sigue a un objeto
# @categoria: Cámara
# @descripcion: La cámara va suavemente detrás del objeto 'target' y respeta los límites del nivel. Ponlo en el objeto Cámara.
# @requiere: Camera2D
extends Node2D
@export var target = "Jugador"
@export var smooth = 6.0
@export var offset = Vector2(0, 0)
@export var min_pos = Vector2(-100000, -100000)
@export var max_pos = Vector2(100000, 100000)
var _shake = 0.0
var _shake_t = 0.0

func shake(power, seconds):
    _shake = power
    _shake_t = seconds

func _process(delta):
    var t = get_object(target)
    if t == null:
        return
    var goal = t.global_position + offset
    var k = min(1.0, delta * smooth)
    var p = Vector2(lerp(position.x, goal.x, k), lerp(position.y, goal.y, k))
    p = Vector2(clamp(p.x, min_pos.x, max_pos.x), clamp(p.y, min_pos.y, max_pos.y))
    if _shake_t > 0.0:
        _shake_t -= delta
        p = p + Vector2(randf_range(-_shake, _shake), randf_range(-_shake, _shake))
    position = p
