# @nombre: Patrullar (ir y volver)
# @categoria: Movimiento
# @descripcion: Va de su posición inicial hasta 'distance' en la dirección indicada y regresa, una y otra vez. Ideal para plataformas móviles, sierras y enemigos voladores.
# @requiere: Rigidbody2D, BoxCollider2D
# @cuerpo: kinematic
extends Node2D
@export var direction = Vector2(1, 0)
@export var distance = 200.0
@export var speed = 100.0
var _start = Vector2(0, 0)
var _sign = 1.0

func _ready():
    _start = global_position

func _physics_process(delta):
    var dn = direction.normalized()
    var along = (global_position - _start).dot(dn)
    if along >= distance:
        _sign = -1.0
    elif along <= 0.0:
        _sign = 1.0
    if rigidbody != null:
        rigidbody.velocity = dn * speed * _sign
    else:
        global_position = global_position + dn * speed * _sign * delta
