# @nombre: Imán de coleccionables
# @categoria: Mundo y física
# @descripcion: Atrae hacia el objeto a todo lo que tenga la etiqueta 'attract_tag' (por defecto coleccionable) cuando está cerca.
extends Node2D
@export var attract_tag = "coleccionable"
@export var radius = 220.0
@export var pull_speed = 400.0

func _process(delta):
    for o in find_objects_with_tag(attract_tag):
        if is_instance_valid(o):
            var d = global_position - o.global_position
            if d.length() < radius:
                o.global_position = o.global_position + d.normalized() * pull_speed * delta
