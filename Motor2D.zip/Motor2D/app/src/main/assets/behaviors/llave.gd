# @nombre: Llave
# @categoria: Objetos y coleccionables
# @descripcion: Al tocarla el jugador, abre la puerta indicada en 'door_name' (objeto con el script Puerta) y la llave desaparece.
# @requiere: CircleCollider2D
# @trigger: si
extends Node2D
@export var who = "Jugador"
@export var door_name = "Puerta"

func _on_trigger_enter(other):
    if other.name == who or other.tag == who:
        var d = get_object(door_name)
        if d != null and d.has_method("unlock"):
            d.unlock()
        destroy(self)
