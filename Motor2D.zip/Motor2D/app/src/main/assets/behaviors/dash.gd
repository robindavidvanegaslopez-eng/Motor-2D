# @nombre: Embestida (dash) con el botón B
# @categoria: Movimiento
# @descripcion: Al pulsar B el objeto sale disparado un instante en la dirección del joystick. Añádelo DESPUÉS del script de movimiento.
# @requiere: Rigidbody2D
extends Node2D
@export var power = 900.0
@export var duration = 0.15
@export var cooldown = 0.6
@export var keep_height = true
var _t = 0.0
var _cd = 0.0
var _dir = Vector2(1, 0)

func _process(delta):
    _cd -= delta
    var j = Input.joystick
    if j.length() > 0.3:
        _dir = j.normalized()
    if _t > 0.0:
        _t -= delta
        var v = _dir * power
        if keep_height:
            var sx = 1.0 if _dir.x >= 0.0 else -1.0
            v = Vector2(sx * power, 0.0)
        rigidbody.velocity = v
    elif Input.is_button_just_pressed("B") and _cd <= 0.0:
        _t = duration
        _cd = cooldown
