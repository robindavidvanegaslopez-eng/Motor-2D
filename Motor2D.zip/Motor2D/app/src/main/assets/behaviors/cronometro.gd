# @nombre: Cronómetro
# @categoria: Reglas y marcadores
# @descripcion: Cuenta el tiempo transcurrido desde que empieza el juego. Llama a stop_timer() para detenerlo.
# @requiere: Label
extends Node2D
@export var prefix = "Tiempo: "
@export var follow_camera = true
@export var offset = Vector2(450, -300)
var elapsed = 0.0
var _running = true

func stop_timer():
    _running = false

func _process(delta):
    if _running:
        elapsed += delta
    label.text = prefix + str(snapped(elapsed, 0.1))
    if follow_camera:
        var cam = get_object("Camara")
        if cam != null:
            position = cam.position + offset
