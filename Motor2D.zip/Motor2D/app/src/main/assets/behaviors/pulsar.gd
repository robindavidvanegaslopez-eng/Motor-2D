# @nombre: Latir (crecer y encoger)
# @categoria: Efectos visuales
# @descripcion: El objeto cambia de tamaño con un latido suave. Botones, corazones, llamadas de atención.
extends Node2D
@export var amount = 0.15
@export var frequency = 1.5
var _base = Vector2(1, 1)
var _t = 0.0

func _ready():
    _base = scale

func _process(delta):
    _t += delta
    var k = 1.0 + sin(_t * frequency * 6.28318) * amount
    scale = Vector2(_base.x * k, _base.y * k)
