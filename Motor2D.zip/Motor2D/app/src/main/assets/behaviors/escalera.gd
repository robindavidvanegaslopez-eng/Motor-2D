# @nombre: Escalera / enredadera
# @categoria: Mundo y física
# @descripcion: Permite subir y bajar con el joystick mientras el jugador está dentro de la zona.
# @requiere: BoxCollider2D
# @trigger: si
extends Node2D
@export var who = "Jugador"
@export var climb_speed = 200.0
var _p = null

func _on_trigger_enter(other):
    if other.name == who or other.tag == who:
        _p = other

func _on_trigger_exit(other):
    if other == _p:
        _p.rigidbody.gravity_scale = 1.0
        _p = null

func _physics_process(delta):
    if _p != null and is_instance_valid(_p):
        var rb = _p.rigidbody
        rb.gravity_scale = 0.0
        rb.velocity = Vector2(rb.velocity.x, Input.joystick.y * climb_speed)
