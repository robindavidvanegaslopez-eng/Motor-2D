# @nombre: Enemigo vigilante (patrulla y persigue)
# @categoria: Mundo y física
# @descripcion: Camina de un lado a otro; si el objetivo se acerca a 'sight' lo persigue; si lo pierde vuelve a patrullar. Para plataformas (necesita gravedad).
# @requiere: Rigidbody2D, BoxCollider2D
# @bloquear_rotacion: si
# @tag: enemigo
extends Node2D
@export var target_name = "Jugador"
@export var patrol_speed = 70.0
@export var chase_speed = 150.0
@export var sight = 350.0
var _dir = 1.0
var _cool = 0.0
var _target = null

func _physics_process(delta):
    _cool -= delta
    if _target == null or not is_instance_valid(_target):
        _target = get_object(target_name)
    var rb = rigidbody
    var vx = _dir * patrol_speed
    if _target != null:
        var d = _target.global_position - global_position
        if d.length() < sight:
            vx = sign(d.x) * chase_speed
        elif rb.is_on_wall() and _cool <= 0.0:
            _dir = -_dir
            _cool = 0.3
            vx = _dir * patrol_speed
    rb.velocity = Vector2(vx, rb.velocity.y)
