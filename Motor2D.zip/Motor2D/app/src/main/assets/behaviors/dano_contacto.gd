# @nombre: Dañar al tocar
# @categoria: Combate y vida
# @descripcion: Hace daño al objeto que lo toque si ese objeto tiene el script Salud. Pinchos, lava, enemigos. Funciona con collider normal o disparador.
# @requiere: BoxCollider2D
# @tag: peligro
extends Node2D
@export var who = "Jugador"
@export var damage = 1
@export var cooldown = 0.5
@export var push = 350.0
var _cd = 0.0

func _process(delta):
    _cd -= delta

func _hit(other):
    if _cd > 0.0:
        return
    if other.name == who or other.tag == who:
        if other.has_method("hurt"):
            other.hurt(damage)
            _cd = cooldown
            if other.rigidbody != null and push > 0.0:
                var d = other.global_position - global_position
                other.rigidbody.velocity = Vector2(sign(d.x) * push, -push * 0.6)

func _on_collision_enter(other):
    _hit(other)

func _on_trigger_enter(other):
    _hit(other)
