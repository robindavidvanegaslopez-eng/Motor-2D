# @nombre: Zona de muerte
# @categoria: Objetos y coleccionables
# @descripcion: Si el jugador entra, reaparece (si tiene el script Reaparecer) o se reinicia la escena. Abismos, agua mortal.
# @requiere: BoxCollider2D
# @trigger: si
extends Node2D
@export var who = "Jugador"

func _on_trigger_enter(other):
    if other.name == who or other.tag == who:
        if other.has_method("respawn"):
            other.respawn()
        else:
            reload_scene()
