# @nombre: Parpadear
# @categoria: Efectos visuales
# @descripcion: El objeto se oculta y se muestra alternadamente. Alarmas, texto 'Toca para empezar', invulnerabilidad.
# @requiere: SpriteRenderer
extends Node2D
@export var on_time = 0.5
@export var off_time = 0.3
var _t = 0.0
var _show = true

func _process(delta):
    _t += delta
    if _show and _t >= on_time:
        _show = false
        _t = 0.0
        visible = false
    elif (not _show) and _t >= off_time:
        _show = true
        _t = 0.0
        visible = true
