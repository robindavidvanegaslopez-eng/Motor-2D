# @nombre: Arrastrar con el dedo
# @categoria: Movimiento
# @descripcion: Toca el objeto y arrástralo por la pantalla. Al soltarlo cae si tiene física.
# @requiere: BoxCollider2D
extends Node2D
var _dragging = false
var _offset = Vector2(0, 0)

func _process(delta):
    if Input.just_touched() and contains_point(Input.touch_world_position()):
        _dragging = true
        _offset = global_position - Input.touch_world_position()
    if _dragging:
        if Input.is_touching():
            global_position = Input.touch_world_position() + _offset
            if rigidbody != null:
                rigidbody.velocity = Vector2(0, 0)
        else:
            _dragging = false
