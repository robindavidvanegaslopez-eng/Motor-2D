# @nombre: Trampolín
# @categoria: Mundo y física
# @descripcion: Lanza hacia arriba a lo que caiga encima con 'force'.
# @requiere: BoxCollider2D
# @cuerpo: static
extends Node2D
@export var force = 900.0
@export var who = ""

func _on_collision_enter(other):
    if other.rigidbody == null:
        return
    if who != "" and other.name != who and other.tag != who:
        return
    other.rigidbody.velocity = Vector2(other.rigidbody.velocity.x, -force)
