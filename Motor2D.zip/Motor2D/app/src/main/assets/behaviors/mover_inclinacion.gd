# @nombre: Mover inclinando el celular
# @categoria: Movimiento
# @descripcion: El objeto se mueve según la inclinación del celular (acelerómetro).
# @requiere: Rigidbody2D
# @gravedad: 0
extends Node2D
@export var speed = 400.0

func _process(delta):
    var d = Input.tilt.limit_length(1.0) * speed
    if rigidbody != null:
        rigidbody.velocity = d
    else:
        translate(d * delta)
