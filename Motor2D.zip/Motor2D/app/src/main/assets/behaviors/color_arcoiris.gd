# @nombre: Cambiar de color sin parar
# @categoria: Efectos visuales
# @descripcion: El color del dibujo recorre todos los tonos del arcoíris.
# @requiere: SpriteRenderer
extends Node2D
@export var speed = 0.4
var _h = 0.0

func _process(delta):
    _h = fposmod(_h + speed * delta, 1.0)
    var r = clamp(abs(_h * 6.0 - 3.0) - 1.0, 0.0, 1.0)
    var g = clamp(2.0 - abs(_h * 6.0 - 2.0), 0.0, 1.0)
    var b = clamp(2.0 - abs(_h * 6.0 - 4.0), 0.0, 1.0)
    set_color(Color(r, g, b))
