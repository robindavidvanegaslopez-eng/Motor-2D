# @nombre: Proyectil (bala)
# @categoria: Combate y vida
# @descripcion: Avanza hacia donde apunta (su rotación), daña lo que tenga Salud y desaparece. Ponlo en un objeto 'Bala' DESACTIVADO como plantilla para instantiate.
# @requiere: Rigidbody2D, CircleCollider2D
# @trigger: si
# @gravedad: 0
# @tag: bala
extends Node2D
@export var speed = 600.0
@export var damage = 1
@export var life = 2.0
@export var ignore = "Jugador"
var _t = 0.0

func _ready():
    var a = deg_to_rad(rotation)
    if rigidbody != null:
        rigidbody.velocity = Vector2(cos(a), sin(a)) * speed

func _process(delta):
    _t += delta
    if _t >= life:
        destroy(self)

func _on_trigger_enter(other):
    if other.name == ignore or other.tag == ignore or other.tag == "bala":
        return
    if other.collider != null and other.collider.is_trigger:
        return
    if other.has_method("hurt"):
        other.hurt(damage)
    destroy(self)
