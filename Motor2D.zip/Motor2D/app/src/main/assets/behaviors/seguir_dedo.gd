# @nombre: Seguir el dedo
# @categoria: Movimiento
# @descripcion: El objeto va hacia el punto de la pantalla que tocas y se detiene al llegar.
# @requiere: Rigidbody2D
# @gravedad: 0
extends Node2D
@export var speed = 400.0
@export var stop_distance = 8.0

func _process(delta):
    var v = Vector2(0, 0)
    if Input.is_touching():
        var d = Input.touch_world_position() - global_position
        if d.length() > stop_distance:
            v = d.normalized() * speed
    if rigidbody != null:
        rigidbody.velocity = v
    else:
        translate(v * delta)
