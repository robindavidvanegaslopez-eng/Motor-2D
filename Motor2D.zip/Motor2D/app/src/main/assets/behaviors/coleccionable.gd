# @nombre: Moneda / coleccionable
# @categoria: Objetos y coleccionables
# @descripcion: Al tocarla el jugador suma 'points' al objeto marcador y desaparece. Usa un collider tipo disparador.
# @requiere: CircleCollider2D
# @trigger: si
# @tag: coleccionable
extends Node2D
@export var who = "Jugador"
@export var points = 1
@export var score_object = "Puntos"

func _on_trigger_enter(other):
    if other.name == who or other.tag == who:
        var s = get_object(score_object)
        if s != null and s.has_method("add"):
            s.add(points)
        destroy(self)
