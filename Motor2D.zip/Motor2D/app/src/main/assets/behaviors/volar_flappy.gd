# @nombre: Aleteo (toca para subir)
# @categoria: Movimiento
# @descripcion: Cada toque a la pantalla o botón A da un impulso hacia arriba. Estilo Flappy Bird (necesita gravedad).
# @requiere: Rigidbody2D, CircleCollider2D
# @bloquear_rotacion: si
# @tag: jugador
extends Node2D
@export var flap_force = 520.0
@export var max_fall_speed = 900.0

func _process(delta):
    var rb = rigidbody
    if Input.just_touched() or Input.is_button_just_pressed("A"):
        rb.velocity = Vector2(0, -flap_force)
    if rb.velocity.y > max_fall_speed:
        rb.velocity = Vector2(0, max_fall_speed)
