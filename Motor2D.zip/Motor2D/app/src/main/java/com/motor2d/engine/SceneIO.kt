package com.motor2d.engine

import com.motor2d.core.Json
import com.motor2d.core.Vec2

/** Guardado y carga de escenas (JSON) y clonado de objetos. */
object SceneIO {
    class SceneData(val objects: List<Map<String, Any?>>, val settings: Map<String, Any?>)

    fun parseScene(text: String): SceneData {
        val root = Json.parseObject(text)
        @Suppress("UNCHECKED_CAST")
        val objs = (root["objects"] as? List<Any?>)?.mapNotNull { it as? Map<String, Any?> } ?: emptyList()
        @Suppress("UNCHECKED_CAST")
        val settings = (root["settings"] as? Map<String, Any?>) ?: emptyMap()
        return SceneData(objs, settings)
    }

    fun objectToJson(o: GameObject): Map<String, Any?> {
        val m = LinkedHashMap<String, Any?>()
        m["id"] = o.id.toLong()
        m["name"] = o.name
        if (o.tag.isNotEmpty()) m["tag"] = o.tag
        if (!o.active) m["active"] = false
        m["position"] = listOf(o.position.x, o.position.y)
        if (o.rotation != 0.0) m["rotation"] = o.rotation
        if (o.scale != Vec2.ONE) m["scale"] = listOf(o.scale.x, o.scale.y)
        o.parent?.let { m["parent"] = it.id.toLong() }
        m["components"] = o.components.map { it.toJson() }
        return m
    }

    fun sceneToJson(w: World): String {
        val root = LinkedHashMap<String, Any?>()
        root["format"] = 1L
        root["settings"] = mapOf(
            "gravity" to listOf(w.physics.gravity.x, w.physics.gravity.y),
            "view_width" to w.viewW, "view_height" to w.viewH
        )
        root["objects"] = w.objects.filter { !it.destroyed }.map { objectToJson(it) }
        return Json.stringify(root)
    }

    private fun vec(j: Any?, def: Vec2): Vec2 {
        val l = j as? List<*> ?: return def
        if (l.size != 2) return def
        return Vec2((l[0] as? Number)?.toDouble() ?: def.x, (l[1] as? Number)?.toDouble() ?: def.y)
    }

    /** Rellena `w` con los objetos de la escena. Devuelve los objetos creados. */
    fun loadInto(w: World, data: SceneData, applySettings: Boolean): List<GameObject> {
        if (applySettings) {
            w.physics.gravity = vec(data.settings["gravity"], Vec2(0.0, 980.0))
            (data.settings["view_width"] as? Number)?.let { w.viewW = it.toDouble() }
            (data.settings["view_height"] as? Number)?.let { w.viewH = it.toDouble() }
        }
        val created = ArrayList<GameObject>()
        val byOldId = HashMap<Long, GameObject>()
        val parents = HashMap<GameObject, Long>()
        for (j in data.objects) {
            val o = GameObject((j["name"] as? String) ?: "Objeto")
            o.id = ((j["id"] as? Number)?.toInt()) ?: 0
            o.tag = (j["tag"] as? String) ?: ""
            o.active = (j["active"] as? Boolean) ?: true
            o.position = vec(j["position"], Vec2.ZERO)
            o.rotation = (j["rotation"] as? Number)?.toDouble() ?: 0.0
            o.scale = vec(j["scale"], Vec2.ONE)
            (j["parent"] as? Number)?.let { parents[o] = it.toLong() }
            @Suppress("UNCHECKED_CAST")
            for (cj in (j["components"] as? List<Any?>) ?: emptyList()) {
                val cm = cj as? Map<String, Any?> ?: continue
                val comp = ComponentTypes.create(cm["type"]?.toString() ?: "") ?: continue
                comp.loadJson(cm)
                o.addComponent(comp)
            }
            w.addObject(o)
            byOldId[o.id.toLong()] = o
            created.add(o)
        }
        for ((o, pid) in parents) {
            val p = byOldId[pid] ?: continue
            o.parent = p
            p.children.add(o)
        }
        return created
    }

    /** Duplica un objeto y todos sus hijos; los ids se renuevan. */
    fun cloneSubtree(w: World, src: GameObject): GameObject {
        val map = HashMap<GameObject, GameObject>()
        fun dup(s: GameObject): GameObject {
            val c = GameObject(s.name)
            c.tag = s.tag; c.active = s.active
            c.position = s.position; c.rotation = s.rotation; c.scale = s.scale
            for (comp in s.components) {
                val nc = ComponentTypes.create(comp.type) ?: continue
                comp.copyTo(nc)
                c.addComponent(nc)
            }
            w.addObject(c)
            map[s] = c
            for (ch in s.children) {
                val cc = dup(ch)
                cc.parent = c
                c.children.add(cc)
            }
            return c
        }
        return dup(src)
    }

    /** Copia profunda de la escena: sirve para restaurar el estado después de pulsar "Detener". */
    fun snapshot(w: World): String = sceneToJson(w)

    fun nameFor(w: World, base: String): String {
        if (w.findByName(base) == null) return base
        var i = 2
        while (w.findByName("$base $i") != null) i++
        return "$base $i"
    }
}
