package com.motor2d.core

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** Vector 2D inmutable (coordenadas en píxeles virtuales, eje Y hacia abajo como en Godot). */
data class Vec2(val x: Double, val y: Double) {
    operator fun plus(o: Vec2) = Vec2(x + o.x, y + o.y)
    operator fun minus(o: Vec2) = Vec2(x - o.x, y - o.y)
    operator fun times(k: Double) = Vec2(x * k, y * k)
    operator fun times(o: Vec2) = Vec2(x * o.x, y * o.y)
    operator fun div(k: Double) = Vec2(x / k, y / k)
    operator fun div(o: Vec2) = Vec2(x / o.x, y / o.y)
    operator fun unaryMinus() = Vec2(-x, -y)

    fun dot(o: Vec2) = x * o.x + y * o.y
    fun cross(o: Vec2) = x * o.y - y * o.x
    fun lengthSquared() = x * x + y * y
    fun length() = sqrt(x * x + y * y)
    fun normalized(): Vec2 {
        val l = length()
        return if (l < 1e-12) ZERO else Vec2(x / l, y / l)
    }
    fun distanceTo(o: Vec2) = (this - o).length()
    fun directionTo(o: Vec2) = (o - this).normalized()
    fun perp() = Vec2(-y, x)
    fun angle() = atan2(y, x)
    fun abs() = Vec2(abs(x), abs(y))
    fun lerp(o: Vec2, t: Double) = Vec2(x + (o.x - x) * t, y + (o.y - y) * t)
    fun rotated(rad: Double): Vec2 {
        val c = cos(rad)
        val s = sin(rad)
        return Vec2(x * c - y * s, x * s + y * c)
    }
    fun moveToward(to: Vec2, delta: Double): Vec2 {
        val d = to - this
        val l = d.length()
        return if (l <= delta || l < 1e-12) to else this + d / l * delta
    }
    fun limitLength(max: Double): Vec2 {
        val l = length()
        return if (l > max && l > 0) this * (max / l) else this
    }
    fun clampLen(min: Double, max: Double): Vec2 {
        val l = length()
        if (l < 1e-12) return this
        val t = l.coerceIn(min, max)
        return this * (t / l)
    }

    override fun toString(): String = "(${fmt(x)}, ${fmt(y)})"

    companion object {
        val ZERO = Vec2(0.0, 0.0)
        val ONE = Vec2(1.0, 1.0)
        val UP = Vec2(0.0, -1.0)
        val DOWN = Vec2(0.0, 1.0)
        val LEFT = Vec2(-1.0, 0.0)
        val RIGHT = Vec2(1.0, 0.0)
        fun fromAngle(rad: Double) = Vec2(cos(rad), sin(rad))
        fun fmt(d: Double): String {
            if (d == Math.rint(d) && abs(d) < 1e15) return d.toLong().toString() + ".0"
            val s = String.format(java.util.Locale.US, "%.4f", d).trimEnd('0')
            return if (s.endsWith(".")) s + "0" else s
        }
    }
}

/** Color RGBA con componentes 0..1 (lo que ve el script). */
data class GdColor(val r: Double, val g: Double, val b: Double, val a: Double = 1.0) {
    fun toArgb(): Int {
        fun c(v: Double) = (v.coerceIn(0.0, 1.0) * 255.0 + 0.5).toInt()
        return (c(a) shl 24) or (c(r) shl 16) or (c(g) shl 8) or c(b)
    }
    override fun toString() = "Color(${Vec2.fmt(r)}, ${Vec2.fmt(g)}, ${Vec2.fmt(b)}, ${Vec2.fmt(a)})"

    companion object {
        fun fromArgb(v: Int) = GdColor(
            ((v shr 16) and 0xFF) / 255.0, ((v shr 8) and 0xFF) / 255.0,
            (v and 0xFF) / 255.0, ((v ushr 24) and 0xFF) / 255.0
        )
    }
}

object Colors {
    private val named = mapOf(
        "white" to 0xFFFFFFFF.toInt(), "black" to 0xFF000000.toInt(), "red" to 0xFFE53935.toInt(),
        "green" to 0xFF43A047.toInt(), "blue" to 0xFF1E88E5.toInt(), "yellow" to 0xFFFDD835.toInt(),
        "orange" to 0xFFFB8C00.toInt(), "purple" to 0xFF8E24AA.toInt(), "pink" to 0xFFEC407A.toInt(),
        "cyan" to 0xFF00ACC1.toInt(), "gray" to 0xFF9E9E9E.toInt(), "grey" to 0xFF9E9E9E.toInt(),
        "brown" to 0xFF6D4C41.toInt(), "transparent" to 0x00000000
    )

    /** Acepta "#rrggbb", "#rrggbbaa", nombres básicos o null si no es válido. */
    fun parse(s: String): Int? {
        val t = s.trim().lowercase()
        named[t]?.let { return it }
        if (!t.startsWith("#")) return null
        val h = t.substring(1)
        return try {
            when (h.length) {
                6 -> (0xFF000000.toInt()) or h.toInt(16)
                8 -> {
                    val rgb = h.substring(0, 6).toInt(16)
                    val a = h.substring(6, 8).toInt(16)
                    (a shl 24) or rgb
                }
                3 -> {
                    val r = h.substring(0, 1).repeat(2); val g = h.substring(1, 2).repeat(2); val b = h.substring(2, 3).repeat(2)
                    (0xFF000000.toInt()) or (r + g + b).toInt(16)
                }
                else -> null
            }
        } catch (e: NumberFormatException) {
            null
        }
    }

    fun toHex(argb: Int): String {
        val a = (argb ushr 24) and 0xFF
        val rgb = argb and 0xFFFFFF
        return if (a == 255) String.format("#%06x", rgb) else String.format("#%06x%02x", rgb, a)
    }
}
