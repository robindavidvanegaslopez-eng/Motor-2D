package com.motor2d.script

enum class T { INT, FLOAT, STR, IDENT, KW, OP, NEWLINE, INDENT, DEDENT, EOF }

class Token(val type: T, val text: String, val line: Int, val value: Any? = null) {
    override fun toString() = "$type($text)@$line"
}

class Lexer(private val src: String, private val scriptName: String) {
    private val tokens = ArrayList<Token>()
    private var i = 0
    private var line = 1
    private var depth = 0
    private val indents = ArrayList<Int>().apply { add(0) }

    companion object {
        val KEYWORDS = setOf(
            "if", "elif", "else", "while", "for", "in", "func", "var", "const", "return", "pass",
            "break", "continue", "and", "or", "not", "true", "false", "null", "extends", "class_name",
            "match", "signal", "static", "self", "enum", "is", "as", "class", "await", "yield"
        )
        private val OPS3 = listOf("**=")
        private val OPS2 = listOf("**", "==", "!=", "<=", ">=", "+=", "-=", "*=", "/=", "%=", "->", ":=", "&&", "||", "<<", ">>")
    }

    private fun fail(msg: String): Nothing = throw ScriptError(msg, line, scriptName)

    private fun add(t: T, text: String, v: Any? = null) {
        tokens.add(Token(t, text, line, v))
    }

    fun tokenize(): List<Token> {
        var atLineStart = true
        val n = src.length
        while (i < n) {
            if (atLineStart && depth == 0) {
                var col = 0
                var j = i
                while (j < n && (src[j] == ' ' || src[j] == '\t')) {
                    col += if (src[j] == '\t') 4 else 1
                    j++
                }
                // Línea vacía o solo comentario: no cuenta para la indentación
                if (j >= n) { i = j; break }
                if (src[j] == '\n' || src[j] == '\r' || src[j] == '#') {
                    while (j < n && src[j] != '\n') j++
                    if (j < n) { j++; line++ }
                    i = j
                    continue
                }
                i = j
                val top = indents.last()
                if (col > top) {
                    indents.add(col); add(T.INDENT, "")
                } else if (col < top) {
                    while (indents.last() > col) {
                        indents.removeAt(indents.size - 1); add(T.DEDENT, "")
                    }
                    if (indents.last() != col) fail("Indentación inconsistente")
                }
                atLineStart = false
            }
            val c = src[i]
            when {
                c == ' ' || c == '\t' || c == '\r' -> i++
                c == '\n' -> {
                    i++
                    if (depth == 0) {
                        if (tokens.isNotEmpty() && tokens.last().type != T.NEWLINE) add(T.NEWLINE, "")
                        line++
                        atLineStart = true
                    } else line++
                }
                c == '#' -> { while (i < n && src[i] != '\n') i++ }
                c == '\\' && i + 1 < n && (src[i + 1] == '\n' || src[i + 1] == '\r') -> {
                    i++
                    if (src[i] == '\r') i++
                    if (i < n && src[i] == '\n') i++
                    line++
                }
                c == '"' || c == '\'' -> readString(c)
                c.isDigit() || (c == '.' && i + 1 < n && src[i + 1].isDigit()) -> readNumber()
                c.isLetter() || c == '_' -> {
                    val st = i
                    while (i < n && (src[i].isLetterOrDigit() || src[i] == '_')) i++
                    val w = src.substring(st, i)
                    if (w in KEYWORDS) add(T.KW, w) else add(T.IDENT, w)
                }
                else -> readOp()
            }
        }
        if (tokens.isNotEmpty() && tokens.last().type != T.NEWLINE) add(T.NEWLINE, "")
        while (indents.size > 1) { indents.removeAt(indents.size - 1); add(T.DEDENT, "") }
        add(T.EOF, "")
        return tokens
    }

    private fun readString(q: Char) {
        val n = src.length
        val triple = src.startsWith("$q$q$q", i)
        i += if (triple) 3 else 1
        val sb = StringBuilder()
        val startLine = line
        while (true) {
            if (i >= n) { line = startLine; fail("Cadena de texto sin cerrar") }
            val c = src[i]
            if (triple) {
                if (src.startsWith("$q$q$q", i)) { i += 3; break }
            } else if (c == q) { i++; break }
            else if (c == '\n') fail("Cadena de texto sin cerrar")
            if (c == '\\' && i + 1 < n) {
                i++
                when (val e = src[i]) {
                    'n' -> sb.append('\n'); 't' -> sb.append('\t'); 'r' -> sb.append('\r')
                    '\\' -> sb.append('\\'); '"' -> sb.append('"'); '\'' -> sb.append('\'')
                    else -> { sb.append('\\'); sb.append(e) }
                }
                i++
                continue
            }
            if (c == '\n') line++
            sb.append(c)
            i++
        }
        tokens.add(Token(T.STR, sb.toString(), startLine, sb.toString()))
    }

    private fun readNumber() {
        val n = src.length
        val st = i
        if (src[i] == '0' && i + 1 < n && (src[i + 1] == 'x' || src[i + 1] == 'X')) {
            i += 2
            val hs = i
            while (i < n && (src[i].isDigit() || src[i].lowercaseChar() in 'a'..'f' || src[i] == '_')) i++
            val v = src.substring(hs, i).replace("_", "").toLongOrNull(16) ?: fail("Número hexadecimal inválido")
            add(T.INT, src.substring(st, i), v)
            return
        }
        var isFloat = false
        while (i < n && (src[i].isDigit() || src[i] == '_')) i++
        if (i < n && src[i] == '.' && !(i + 1 < n && src[i + 1] == '.')) {
            isFloat = true
            i++
            while (i < n && (src[i].isDigit() || src[i] == '_')) i++
        }
        if (i < n && (src[i] == 'e' || src[i] == 'E')) {
            var j = i + 1
            if (j < n && (src[j] == '+' || src[j] == '-')) j++
            if (j < n && src[j].isDigit()) {
                isFloat = true
                i = j
                while (i < n && src[i].isDigit()) i++
            }
        }
        val text = src.substring(st, i).replace("_", "")
        if (isFloat) add(T.FLOAT, text, text.toDouble())
        else add(T.INT, text, text.toLongOrNull() ?: fail("Número entero demasiado grande"))
    }

    private fun readOp() {
        for (o in OPS3) if (src.startsWith(o, i)) { add(T.OP, o); i += o.length; return }
        for (o in OPS2) if (src.startsWith(o, i)) { add(T.OP, o); i += o.length; return }
        val c = src[i]
        when (c) {
            '(', '[', '{' -> depth++
            ')', ']', '}' -> if (depth > 0) depth--
        }
        if ("+-*/%<>=()[]{},:.!&|^~@;".indexOf(c) < 0) fail("Carácter no válido '$c'")
        add(T.OP, c.toString())
        i++
    }
}
