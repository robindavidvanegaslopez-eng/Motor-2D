package com.motor2d.app

import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import com.motor2d.core.Colors
import com.motor2d.core.Vec2
import com.motor2d.editor.Behaviors
import com.motor2d.editor.EditorModel
import com.motor2d.editor.ExportInfo
import com.motor2d.engine.Component
import com.motor2d.engine.ComponentTypes
import com.motor2d.engine.GameObject
import com.motor2d.engine.PT
import com.motor2d.engine.Prop
import com.motor2d.engine.ScriptComponent
import com.motor2d.script.Fmt

/** Muestra y edita el objeto seleccionado: nombre, transformación y componentes. */
class InspectorPanel(private val host: EditorHost, private val model: EditorModel) {
    private val ctx = host.activity
    private val content = LinearLayout(ctx)
    val view: View

    // Campos de la transformación, para actualizarlos mientras se arrastra en la escena
    private var posX: EditText? = null
    private var posY: EditText? = null
    private var rotF: EditText? = null
    private var scX: EditText? = null
    private var scY: EditText? = null

    init {
        content.orientation = LinearLayout.VERTICAL
        content.isFocusableInTouchMode = true   // así, al terminar de escribir, el foco no salta a otro campo
        content.setPadding(ctx.dp(10), ctx.dp(8), ctx.dp(10), ctx.dp(24))
        val scroll = ScrollView(ctx)
        scroll.isFillViewport = true
        scroll.addView(content, lp(Ui.MATCH, Ui.WRAP))
        view = scroll
    }

    // ---------- Construcción ----------
    fun refresh() {
        val focused = content.findFocus()
        if (focused != null && focused !== content) focused.clearFocus()
        content.removeAllViews()
        posX = null; posY = null; rotF = null; scX = null; scY = null
        val o = model.selected
        if (o == null) {
            val t = ctx.label("Toca un objeto en la escena o en la lista para editarlo.", 14f, Ui.MUTED)
            t.setPadding(ctx.dp(4), ctx.dp(12), ctx.dp(4), 0)
            content.addView(t)
            return
        }
        content.addView(basics(o))
        content.addView(transform(o))
        for (c in ArrayList(o.components)) content.addView(componentCard(o, c))
        val add = ctx.button("+ Añadir componente", Ui.ACCENT_DARK) { addComponentMenu(o) }
        val p = lp(Ui.MATCH, Ui.WRAP)
        p.topMargin = ctx.dp(12)
        content.addView(add, p)
    }

    /** Actualiza solo los números de posición/escala sin reconstruir (mientras se arrastra). */
    fun syncTransform() {
        val o = model.selected ?: return
        setIfIdle(posX, Fmt.num(o.position.x))
        setIfIdle(posY, Fmt.num(o.position.y))
        setIfIdle(rotF, Fmt.num(o.rotation))
        setIfIdle(scX, Fmt.num(o.scale.x))
        setIfIdle(scY, Fmt.num(o.scale.y))
    }

    /** Tamaños que cambian al estirar el objeto: se reconstruye si no se está escribiendo. */
    fun syncAll() {
        val f = content.findFocus()
        if (f == null || f === content) refresh() else syncTransform()
    }

    private fun setIfIdle(e: EditText?, text: String) {
        if (e != null && !e.hasFocus() && e.text.toString() != text) e.setText(text)
    }

    private fun card(title: String?, onRemove: (() -> Unit)? = null): LinearLayout {
        val c = LinearLayout(ctx)
        c.orientation = LinearLayout.VERTICAL
        c.background = roundBg(Ui.PANEL, ctx.dpf(12f))
        c.setPadding(ctx.dp(12), ctx.dp(8), ctx.dp(12), ctx.dp(10))
        if (title != null) {
            val h = LinearLayout(ctx)
            h.gravity = Gravity.CENTER_VERTICAL
            h.addView(ctx.label(title, 15f, Ui.ACCENT, true), lp(0, Ui.WRAP, 1f))
            if (onRemove != null) h.addView(ctx.button("Quitar", Color.TRANSPARENT, Ui.DANGER) { onRemove() }, lp(Ui.WRAP, ctx.dp(40)))
            c.addView(h, lp(Ui.MATCH, Ui.WRAP))
        }
        return c
    }

    private fun withMargin(v: View): View {
        v.layoutParams = lp(Ui.MATCH, Ui.WRAP).also { it.topMargin = ctx.dp(10) }
        return v
    }

    private fun fieldRow(label: String, vararg fields: View): LinearLayout {
        val r = LinearLayout(ctx)
        r.gravity = Gravity.CENTER_VERTICAL
        r.addView(ctx.label(label, 13f, Ui.MUTED), lp(0, Ui.WRAP, 0.9f))
        val box = LinearLayout(ctx)
        for ((i, f) in fields.withIndex()) {
            val p = lp(0, Ui.WRAP, 1f)
            if (i > 0) p.leftMargin = ctx.dp(6)
            box.addView(f, p)
        }
        r.addView(box, lp(0, Ui.WRAP, 2f))
        r.layoutParams = lp(Ui.MATCH, Ui.WRAP).also { it.topMargin = ctx.dp(6) }
        return r
    }

    private fun basics(o: GameObject): View {
        val c = card(null)
        val name = ctx.input(o.name, "Nombre")
        name.commitOn { model.rename(o, it); host.sceneChanged() }
        c.addView(fieldRow("Nombre", name))
        val tag = ctx.input(o.tag, "etiqueta")
        tag.commitOn { model.setTag(o, it); host.valueChanged() }
        c.addView(fieldRow("Etiqueta", tag))
        val active = CheckBox(ctx)
        active.text = "Activo"
        active.setTextColor(Ui.TEXT)
        active.isChecked = o.active
        active.setOnCheckedChangeListener { _, v -> if (v != o.active) { model.setActive(o, v); host.sceneChanged() } }
        c.addView(active, lp(Ui.WRAP, Ui.WRAP).also { it.topMargin = ctx.dp(4) })
        return withMargin(c)
    }

    private fun num(v: Double): EditText = ctx.input(Fmt.num(v), "", true)

    private fun parseNum(s: String): Double? = s.trim().replace(',', '.').toDoubleOrNull()

    private fun transform(o: GameObject): View {
        val c = card("Transformación")
        val px = num(o.position.x); val py = num(o.position.y)
        val rt = num(o.rotation)
        val sx = num(o.scale.x); val sy = num(o.scale.y)
        posX = px; posY = py; rotF = rt; scX = sx; scY = sy

        fun commitPos() {
            val x = parseNum(px.text.toString()); val y = parseNum(py.text.toString())
            if (x != null && y != null) { model.beginEdit(); model.setPosition(o, Vec2(x, y)); host.valueChanged() }
        }
        px.commitOn { commitPos() }
        py.commitOn { commitPos() }
        rt.commitOn { s -> parseNum(s)?.let { model.beginEdit(); model.setRotation(o, it); host.valueChanged() } }
        fun commitScale() {
            val x = parseNum(sx.text.toString()); val y = parseNum(sy.text.toString())
            if (x != null && y != null) { model.beginEdit(); model.setScale(o, Vec2(x, y)); host.valueChanged() }
        }
        sx.commitOn { commitScale() }
        sy.commitOn { commitScale() }

        c.addView(fieldRow("Posición X / Y", px, py))
        c.addView(fieldRow("Rotación (°)", rt))
        c.addView(fieldRow("Escala X / Y", sx, sy))
        return withMargin(c)
    }

    private fun addComponentMenu(o: GameObject) {
        val types = ComponentTypes.all
        val items = ArrayList<String>()
        items.add("★ Comportamiento prefabricado...")
        items.addAll(types.map { ComponentTypes.displayName(it) })
        ctx.pick("Añadir componente", items) { i ->
            if (i == 0) {
                behaviorMenu(o)
            } else {
                val err = model.addComponent(o, types[i - 1])
                if (err != null) ctx.toast(err) else host.sceneChanged()
            }
        }
    }

    /** Biblioteca de comportamientos: primero la categoría, luego el comportamiento. */
    private fun behaviorMenu(o: GameObject) {
        val all = BehaviorCatalog.load(ctx)
        if (all.isEmpty()) { ctx.toast("No se encontró la biblioteca de comportamientos"); return }
        val cats = Behaviors.categories(all)
        ctx.pick("Biblioteca (" + all.size + " comportamientos)", cats.map { c -> c + "  (" + all.count { it.category == c } + ")" }) { ci ->
            val list = all.filter { it.category == cats[ci] }
            ctx.pick(cats[ci], list.map { it.name + "\n" + it.summary }) { bi ->
                val b = list[bi]
                val extra = "\n\nSe añade un script con variables que puedes cambiar en «Variables del script». Si necesita física o un collider, se añaden solos."
                ctx.confirmDialog(b.name, b.description + extra, "Añadir") {
                    ctx.toast(model.addBehavior(o, b))
                    host.sceneChanged()
                }
            }
        }
    }

    private fun componentCard(o: GameObject, comp: Component): View {
        val c = card(ComponentTypes.displayName(comp.type)) {
            model.removeComponent(o, comp)
            host.sceneChanged()
        }
        for (p in comp.schema) {
            if (comp is ScriptComponent) c.addView(scriptRow(comp, p)) else c.addView(propRow(comp, p))
        }
        if (comp is ScriptComponent) addExports(c, comp)
        return withMargin(c)
    }

    // ---------- Propiedades ----------
    private fun propRow(comp: Component, p: Prop): View {
        val cur = comp.values[p.name]
        // Cambios que alteran lo que hay que mostrar reconstruyen el panel
        val structural = p.name == "shape" || p.name == "body_type"

        fun apply(text: String, rebuild: Boolean = structural) {
            val err = model.setValue(comp, p, text)
            if (err != null) { ctx.toast(err); refresh() } else if (rebuild) host.sceneChanged() else host.valueChanged()
        }

        return when (p.type) {
            PT.BOOL -> {
                val cb = CheckBox(ctx)
                cb.text = p.label
                cb.setTextColor(Ui.TEXT)
                cb.isChecked = cur as Boolean
                cb.setOnCheckedChangeListener { _, v -> model.setBool(comp, p, v); host.valueChanged() }
                cb.layoutParams = lp(Ui.MATCH, Ui.WRAP).also { it.topMargin = ctx.dp(6) }
                cb
            }
            PT.ENUM -> {
                val b = ctx.button(cur.toString()) {
                    ctx.pick(p.label, p.options) { i -> apply(p.options[i], true) }
                }
                fieldRow(p.label, b)
            }
            PT.COLOR -> {
                val sw = View(ctx)
                sw.background = roundBg(cur as Int, ctx.dpf(8f), Ui.MUTED, ctx.dp(1))
                sw.setOnClickListener {
                    ctx.pickColor(p.label) { col -> apply(Colors.toHex(col), true) }
                }
                val hex = ctx.input(Colors.toHex(cur), "#rrggbb")
                hex.commitOn { apply(it, true) }
                val r = fieldRow(p.label, hex)
                val box = r.getChildAt(1) as LinearLayout
                val sp = lp(ctx.dp(44), ctx.dp(44))
                sp.leftMargin = ctx.dp(6)
                box.addView(sw, sp)
                r
            }
            PT.VEC2 -> {
                val v = cur as Vec2
                val x = num(v.x); val y = num(v.y)
                fun commit() { apply(x.text.toString().trim() + ";" + y.text.toString().trim()) }
                x.commitOn { commit() }
                y.commitOn { commit() }
                fieldRow(p.label, x, y)
            }
            PT.IMAGE -> {
                val b = ctx.button(if ((cur as String).isEmpty()) "(elegir imagen)" else cur.removePrefix("assets/")) { imageMenu(comp, p) }
                fieldRow(p.label, b)
            }
            PT.TEXT -> {
                val e = ctx.input(cur as String)
                e.commitOn { apply(it, false) }
                fieldRow(p.label, e)
            }
            PT.FLOAT, PT.INT -> {
                val e = ctx.input(model.valueToText(p, cur), "", true)
                e.commitOn { apply(it, false) }
                fieldRow(p.label, e)
            }
            else -> {
                val e = ctx.input(cur?.toString() ?: "")
                e.commitOn { apply(it, false) }
                fieldRow(p.label, e)
            }
        }
    }

    private fun imageMenu(comp: Component, p: Prop) {
        val images = model.imagePaths()
        val items = ArrayList<String>()
        items.add("Importar imagen de la galería...")
        items.addAll(images.map { it.removePrefix("assets/") })
        items.add("Quitar imagen")
        ctx.pick("Imagen", items) { i ->
            when {
                i == 0 -> host.importImage { path ->
                    model.setValue(comp, p, path)
                    // Usar una imagen implica dibujarla como imagen
                    comp.prop("shape")?.let { model.setValue(comp, it, "image") }
                    host.sceneChanged()
                }
                i == items.size - 1 -> { model.setValue(comp, p, ""); host.sceneChanged() }
                else -> {
                    model.setValue(comp, p, images[i - 1])
                    comp.prop("shape")?.let { model.setValue(comp, it, "image") }
                    host.sceneChanged()
                }
            }
        }
    }

    // ---------- Scripts ----------
    private fun scriptRow(sc: ScriptComponent, p: Prop): View {
        val r = LinearLayout(ctx)
        r.gravity = Gravity.CENTER_VERTICAL
        val label = if (sc.path.isEmpty()) "(elegir script)" else sc.path.removePrefix("scripts/")
        r.addView(ctx.button(label) { scriptMenu(sc, p) }, lp(0, Ui.WRAP, 1f))
        if (sc.path.isNotEmpty()) {
            val b = ctx.button("Editar", Ui.ACCENT_DARK) { host.openScript(sc.path) }
            r.addView(b, lp(Ui.WRAP, Ui.WRAP).also { it.leftMargin = ctx.dp(6) })
        }
        r.layoutParams = lp(Ui.MATCH, Ui.WRAP).also { it.topMargin = ctx.dp(6) }
        return r
    }

    private fun scriptMenu(sc: ScriptComponent, p: Prop) {
        val paths = model.scriptPaths()
        val items = ArrayList<String>()
        items.add("Crear script nuevo...")
        items.addAll(paths.map { it.removePrefix("scripts/") })
        ctx.pick("Script", items) { i ->
            if (i == 0) {
                ctx.askText("Nombre del script", "") { n ->
                    val path = model.createScript(n)
                    model.setValue(sc, p, path)
                    host.sceneChanged()
                    host.openScript(path)
                }
            } else {
                model.setValue(sc, p, paths[i - 1])
                sc.exports.clear()
                host.sceneChanged()
            }
        }
    }

    private fun addExports(card: LinearLayout, sc: ScriptComponent) {
        val list: List<ExportInfo> = model.exportsFor(sc)
        if (list.isEmpty()) return
        val h = ctx.label("Variables del script (@export)", 12f, Ui.MUTED)
        card.addView(h, lp(Ui.WRAP, Ui.WRAP).also { it.topMargin = ctx.dp(10) })
        for (info in list) {
            val e = ctx.input(model.exportToText(info.value))
            e.commitOn { text ->
                val err = model.setExport(sc, info, text)
                if (err != null) { ctx.toast(err); refresh() } else host.valueChanged()
            }
            val row = fieldRow(info.name + if (info.overridden) " *" else "", e)
            if (info.overridden) {
                val reset = ctx.button("↺", Color.TRANSPARENT) {
                    model.resetExport(sc, info.name); host.sceneChanged()
                }
                (row.getChildAt(1) as LinearLayout).addView(reset, lp(ctx.dp(44), ctx.dp(44)))
            }
            card.addView(row)
        }
    }
}
