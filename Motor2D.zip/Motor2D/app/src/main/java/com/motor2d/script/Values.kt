package com.motor2d.script

import com.motor2d.core.GdColor
import com.motor2d.core.Vec2
import java.util.Locale

/** Error de script con línea y nombre de archivo, para mostrar en la consola del editor. */
class ScriptError(message: String, val line: Int = 0, val script: String = "") : Exception(message) {
    fun describe(): String {
        val where = buildString {
            if (script.isNotEmpty()) append(script)
            if (line > 0) { if (isNotEmpty()) append(":"); append(line) }
        }
        return if (where.isEmpty()) message ?: "error" else "[$where] $message"
    }
}

/** Valor centinela: "este objeto no tiene ese miembro". */
object NoSuch

/** Objeto del motor visible desde los scripts (GameObject, componentes, Input...). */
interface HostObject {
    val typeName: String
    /** Devuelve el valor o NoSuch si no existe. */
    fun getProp(name: String): Any?
    /** true si la propiedad existe y se pudo asignar. */
    fun setProp(name: String, value: Any?): Boolean
    /** Devuelve el resultado o NoSuch si el método no existe. */
    fun callMethod(name: String, args: List<Any?>): Any?
}

/** Funciones y variables globales aportadas por el mundo (get_object, Input, instantiate...). */
interface GlobalHost {
    fun getGlobal(name: String): Any?   // NoSuch si no existe
    fun callGlobal(name: String, args: List<Any?>): Any?   // NoSuch si no existe
}

object Fmt {
    /** Número como lo imprime GDScript: 5.0 -> "5", 1.5 -> "1.5". */
    fun num(d: Double): String {
        if (d.isNaN()) return "nan"
        if (d.isInfinite()) return if (d > 0) "inf" else "-inf"
        if (d == Math.rint(d) && Math.abs(d) < 1e15) return d.toLong().toString()
        val s = String.format(Locale.US, "%.5f", d).trimEnd('0').trimEnd('.')
        return if (s == "-0" || s.isEmpty()) "0" else s
    }

    fun str(v: Any?, quoteStrings: Boolean = false): String = when (v) {
        null -> "<null>"
        is Boolean -> v.toString()
        is Long -> v.toString()
        is Int -> v.toString()
        is Double -> num(v)
        is String -> if (quoteStrings) "\"" + v + "\"" else v
        is Vec2 -> "(" + num(v.x) + ", " + num(v.y) + ")"
        is GdColor -> "(" + num(v.r) + ", " + num(v.g) + ", " + num(v.b) + ", " + num(v.a) + ")"
        is List<*> -> v.joinToString(", ", "[", "]") { str(it, true) }
        is Map<*, *> -> v.entries.joinToString(", ", "{", "}") { str(it.key, true) + ": " + str(it.value, true) }
        is HostObject -> "<" + v.typeName + ">"
        else -> v.toString()
    }
}
