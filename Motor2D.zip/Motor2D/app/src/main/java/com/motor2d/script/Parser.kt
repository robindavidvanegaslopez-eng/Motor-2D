package com.motor2d.script

// ---------- AST ----------
sealed class Expr { var line = 0 }
class Lit(val value: Any?) : Expr()
class NameE(val id: String) : Expr()
class SelfE : Expr()
class ArrayE(val items: List<Expr>) : Expr()
class DictE(val pairs: List<Pair<Expr, Expr>>) : Expr()
class UnaryE(val op: String, val e: Expr) : Expr()
class BinaryE(val op: String, val l: Expr, val r: Expr) : Expr()
class LogicE(val isAnd: Boolean, val l: Expr, val r: Expr) : Expr()
class TernaryE(val cond: Expr, val a: Expr, val b: Expr) : Expr()
class CallE(val callee: Expr, val args: List<Expr>) : Expr()
class MemberE(val obj: Expr, val name: String) : Expr()
class IndexE(val obj: Expr, val index: Expr) : Expr()

sealed class Stmt { var line = 0 }
class ExprS(val e: Expr) : Stmt()
class VarS(val name: String, val init: Expr?) : Stmt()
class AssignS(val target: Expr, val op: String, val value: Expr) : Stmt()
class IfS(val conds: List<Expr>, val blocks: List<List<Stmt>>, val elseBlock: List<Stmt>?) : Stmt()
class WhileS(val cond: Expr, val body: List<Stmt>) : Stmt()
class ForS(val v: String, val iter: Expr, val body: List<Stmt>) : Stmt()
class ReturnS(val e: Expr?) : Stmt()
class BreakS : Stmt()
class ContinueS : Stmt()
class PassS : Stmt()
class MatchS(val subject: Expr, val cases: List<Pair<List<Expr>, List<Stmt>>>) : Stmt()

class Param(val name: String, val default: Expr?)
class FuncDecl(val name: String, val params: List<Param>, val body: List<Stmt>, val line: Int)
class MemberVar(
    val name: String, val init: Expr?, val isConst: Boolean,
    val isExport: Boolean, val isOnReady: Boolean, val line: Int
)

class ScriptClass(val name: String) {
    val members = ArrayList<MemberVar>()
    val funcs = HashMap<String, FuncDecl>()
    val signals = ArrayList<String>()

    /** Variables @export en el orden en que se declararon. */
    val exports: List<MemberVar> get() = members.filter { it.isExport }
}

// ---------- Parser ----------
class Parser(private val toks: List<Token>, private val scriptName: String) {
    private var p = 0

    private fun peek() = toks[p]
    private fun next() = toks[p++]
    private fun fail(msg: String, t: Token = peek()): Nothing = throw ScriptError(msg, t.line, scriptName)

    private fun isOp(s: String) = peek().type == T.OP && peek().text == s
    private fun isKw(s: String) = peek().type == T.KW && peek().text == s
    private fun acceptOp(s: String): Boolean { if (isOp(s)) { p++; return true }; return false }
    private fun acceptKw(s: String): Boolean { if (isKw(s)) { p++; return true }; return false }
    private fun expectOp(s: String) { if (!acceptOp(s)) fail("Se esperaba '$s' pero hay '${describe(peek())}'") }
    private fun expectKw(s: String) { if (!acceptKw(s)) fail("Se esperaba '$s' pero hay '${describe(peek())}'") }
    private fun describe(t: Token) = when (t.type) {
        T.NEWLINE -> "fin de línea"; T.INDENT -> "sangría"; T.DEDENT -> "fin de bloque"; T.EOF -> "fin del archivo"
        else -> t.text
    }
    private fun expectIdent(): String {
        val t = peek()
        // Algunas palabras clave se pueden usar como nombre de miembro (p. ej. obj.class), aquí solo IDENT
        if (t.type != T.IDENT) fail("Se esperaba un nombre pero hay '${describe(t)}'")
        p++
        return t.text
    }
    private fun skipNewlines() { while (peek().type == T.NEWLINE) p++ }
    private fun endStatement() {
        if (peek().type == T.NEWLINE) { p++; return }
        if (peek().type == T.EOF || peek().type == T.DEDENT) return
        if (acceptOp(";")) return
        fail("Texto inesperado '${describe(peek())}' al final de la instrucción")
    }

    fun parseScript(): ScriptClass {
        val cls = ScriptClass(scriptName)
        skipNewlines()
        while (peek().type != T.EOF) {
            parseTopLevel(cls)
            skipNewlines()
        }
        return cls
    }

    private fun skipBalancedParens() {
        if (!acceptOp("(")) return
        var d = 1
        while (d > 0) {
            val t = next()
            if (t.type == T.EOF) fail("Paréntesis sin cerrar")
            if (t.type == T.OP && t.text == "(") d++
            if (t.type == T.OP && t.text == ")") d--
        }
    }

    private fun parseTopLevel(cls: ScriptClass) {
        var isExport = false
        var isOnReady = false
        while (isOp("@")) {
            p++
            val name = next().text
            if (name.startsWith("export")) isExport = true
            if (name == "onready") isOnReady = true
            skipBalancedParens()
            while (peek().type == T.NEWLINE) p++
        }
        val t = peek()
        when {
            t.type == T.KW && (t.text == "extends" || t.text == "class_name") -> {
                p++
                while (peek().type != T.NEWLINE && peek().type != T.EOF) p++
                endStatement()
            }
            t.type == T.KW && t.text == "signal" -> {
                p++
                cls.signals.add(expectIdent())
                skipBalancedParens()
                endStatement()
            }
            t.type == T.KW && t.text == "enum" -> parseEnum(cls)
            t.type == T.KW && (t.text == "var" || t.text == "const") -> {
                p++
                val isConst = t.text == "const"
                val name = expectIdent()
                skipTypeHint()
                var init: Expr? = null
                if (acceptOp("=") || acceptOp(":=")) init = parseExpr()
                endStatement()
                cls.members.add(MemberVar(name, init, isConst, isExport, isOnReady, t.line))
            }
            t.type == T.KW && t.text == "static" -> {
                p++ // 'static' se ignora
                parseTopLevel(cls)
            }
            t.type == T.KW && t.text == "func" -> {
                val f = parseFunc()
                cls.funcs[f.name] = f
            }
            t.type == T.KW && t.text == "class" -> fail("Las clases internas (class) no están soportadas")
            t.type == T.KW && t.text == "pass" -> { p++; endStatement() }
            else -> fail("Aquí solo se permiten var, const, func, extends o signal, no '${describe(t)}'")
        }
    }

    private fun parseEnum(cls: ScriptClass) {
        p++ // enum
        if (peek().type == T.IDENT) p++
        expectOp("{")
        var v = 0L
        while (!isOp("}")) {
            while (peek().type == T.NEWLINE) p++
            if (isOp("}")) break
            val n = expectIdent()
            if (acceptOp("=")) {
                val e = parseExpr()
                v = (e as? Lit)?.value as? Long ?: fail("En enum solo se admiten números enteros")
            }
            cls.members.add(MemberVar(n, Lit(v).also { it.line = peek().line }, true, false, false, peek().line))
            v++
            if (!acceptOp(",")) break
        }
        while (peek().type == T.NEWLINE) p++
        expectOp("}")
        endStatement()
    }

    /** Ignora ": Tipo" (incluye Array[int], Vector2, etc.). */
    private fun skipTypeHint() {
        if (isOp(":")) {
            // ':' seguido de '=' lo tokeniza el lexer como ':=' así que aquí siempre hay tipo
            p++
            skipTypeName()
        }
    }

    private fun skipTypeName() {
        if (peek().type == T.IDENT || peek().type == T.KW) p++ else fail("Se esperaba un tipo")
        while (acceptOp(".")) p++
        if (isOp("[")) {
            var d = 0
            do {
                val t = next()
                if (t.type == T.OP && t.text == "[") d++
                if (t.type == T.OP && t.text == "]") d--
                if (t.type == T.EOF) fail("Corchete sin cerrar")
            } while (d > 0)
        }
    }

    private fun parseFunc(): FuncDecl {
        val line = peek().line
        expectKw("func")
        val name = expectIdent()
        expectOp("(")
        val params = ArrayList<Param>()
        while (!isOp(")")) {
            val pn = expectIdent()
            skipTypeHint()
            var def: Expr? = null
            if (acceptOp("=") || acceptOp(":=")) def = parseExpr()
            params.add(Param(pn, def))
            if (!acceptOp(",")) break
        }
        expectOp(")")
        if (acceptOp("->")) skipTypeName()
        expectOp(":")
        val body = parseBlock()
        return FuncDecl(name, params, body, line)
    }

    private fun parseBlock(): List<Stmt> {
        if (peek().type == T.NEWLINE) {
            p++
            skipNewlines()
            if (peek().type != T.INDENT) fail("Se esperaba un bloque con sangría")
            p++
            val out = ArrayList<Stmt>()
            while (peek().type != T.DEDENT && peek().type != T.EOF) {
                skipNewlines()
                if (peek().type == T.DEDENT || peek().type == T.EOF) break
                out.add(parseStatement())
            }
            if (peek().type == T.DEDENT) p++
            if (out.isEmpty()) fail("El bloque está vacío (usa 'pass')")
            return out
        }
        // Bloque en una sola línea: if x: return
        return listOf(parseStatement())
    }

    private fun parseStatement(): Stmt {
        val t = peek()
        val s: Stmt = when {
            t.type == T.KW -> when (t.text) {
                "var", "const" -> {
                    p++
                    val name = expectIdent()
                    skipTypeHint()
                    var init: Expr? = null
                    if (acceptOp("=") || acceptOp(":=")) init = parseExpr()
                    endStatement()
                    VarS(name, init)
                }
                "if" -> return parseIf()
                "while" -> {
                    p++
                    val c = parseExpr()
                    expectOp(":")
                    WhileS(c, parseBlock())
                }
                "for" -> {
                    p++
                    val v = expectIdent()
                    if (isOp(":")) { p++; skipTypeName() }
                    expectKw("in")
                    val it = parseExpr()
                    expectOp(":")
                    ForS(v, it, parseBlock())
                }
                "match" -> return parseMatch()
                "return" -> {
                    p++
                    val e = if (peek().type == T.NEWLINE || peek().type == T.EOF || peek().type == T.DEDENT || isOp(";")) null else parseExpr()
                    endStatement()
                    ReturnS(e)
                }
                "pass" -> { p++; endStatement(); PassS() }
                "break" -> { p++; endStatement(); BreakS() }
                "continue" -> { p++; endStatement(); ContinueS() }
                "await", "yield" -> fail("'${t.text}' no está soportado")
                else -> parseSimple()
            }
            else -> parseSimple()
        }
        s.line = t.line
        return s
    }

    private fun parseSimple(): Stmt {
        val e = parseExpr()
        val t = peek()
        if (t.type == T.OP && (t.text == "=" || t.text == "+=" || t.text == "-=" || t.text == "*=" || t.text == "/=" || t.text == "%=" || t.text == "**=")) {
            if (e !is NameE && e !is MemberE && e !is IndexE) fail("No se puede asignar a esta expresión", t)
            p++
            val v = parseExpr()
            endStatement()
            return AssignS(e, t.text, v)
        }
        endStatement()
        return ExprS(e)
    }

    private fun parseIf(): Stmt {
        val line = peek().line
        p++ // if
        val conds = ArrayList<Expr>()
        val blocks = ArrayList<List<Stmt>>()
        conds.add(parseExpr()); expectOp(":"); blocks.add(parseBlock())
        var elseB: List<Stmt>? = null
        while (true) {
            skipNewlinesBeforeElse()
            if (isKw("elif")) {
                p++
                conds.add(parseExpr()); expectOp(":"); blocks.add(parseBlock())
            } else if (isKw("else")) {
                p++
                expectOp(":")
                elseB = parseBlock()
                break
            } else break
        }
        return IfS(conds, blocks, elseB).also { it.line = line }
    }

    private fun skipNewlinesBeforeElse() {
        var q = p
        while (toks[q].type == T.NEWLINE) q++
        if (toks[q].type == T.KW && (toks[q].text == "elif" || toks[q].text == "else")) p = q
    }

    private fun parseMatch(): Stmt {
        val line = peek().line
        p++
        val subj = parseExpr()
        expectOp(":")
        if (peek().type != T.NEWLINE) fail("Después de 'match' va un bloque con casos")
        p++
        skipNewlines()
        if (peek().type != T.INDENT) fail("Se esperaba un bloque con casos")
        p++
        val cases = ArrayList<Pair<List<Expr>, List<Stmt>>>()
        while (peek().type != T.DEDENT && peek().type != T.EOF) {
            skipNewlines()
            if (peek().type == T.DEDENT) break
            val pats = ArrayList<Expr>()
            pats.add(parseExpr())
            while (acceptOp(",")) pats.add(parseExpr())
            expectOp(":")
            cases.add(Pair(pats, parseBlock()))
        }
        if (peek().type == T.DEDENT) p++
        return MatchS(subj, cases).also { it.line = line }
    }

    // ---------- Expresiones ----------
    fun parseExpr(): Expr = parseTernary()

    private fun <E : Expr> E.at(line: Int): E { this.line = line; return this }

    private fun parseTernary(): Expr {
        val e = parseOr()
        if (isKw("if")) {
            val ln = peek().line
            p++
            val c = parseOr()
            expectKw("else")
            val b = parseTernary()
            return TernaryE(c, e, b).at(ln)
        }
        return e
    }

    private fun parseOr(): Expr {
        var l = parseAnd()
        while (isKw("or") || isOp("||")) {
            val ln = peek().line; p++
            l = LogicE(false, l, parseAnd()).at(ln)
        }
        return l
    }

    private fun parseAnd(): Expr {
        var l = parseNot()
        while (isKw("and") || isOp("&&")) {
            val ln = peek().line; p++
            l = LogicE(true, l, parseNot()).at(ln)
        }
        return l
    }

    private fun parseNot(): Expr {
        if (isKw("not") || isOp("!")) {
            val ln = peek().line; p++
            return UnaryE("not", parseNot()).at(ln)
        }
        return parseCompare()
    }

    private fun parseCompare(): Expr {
        var l = parseBitOr()
        while (true) {
            val t = peek()
            val op = when {
                t.type == T.OP && (t.text == "==" || t.text == "!=" || t.text == "<" || t.text == ">" || t.text == "<=" || t.text == ">=") -> t.text
                t.type == T.KW && t.text == "in" -> "in"
                t.type == T.KW && t.text == "not" && toks[p + 1].type == T.KW && toks[p + 1].text == "in" -> "not in"
                else -> return l
            }
            p += if (op == "not in") 2 else 1
            l = BinaryE(op, l, parseBitOr()).at(t.line)
        }
    }

    private fun parseBitOr(): Expr {
        var l = parseBitXor()
        while (isOp("|")) { val ln = peek().line; p++; l = BinaryE("|", l, parseBitXor()).at(ln) }
        return l
    }

    private fun parseBitXor(): Expr {
        var l = parseBitAnd()
        while (isOp("^")) { val ln = peek().line; p++; l = BinaryE("^", l, parseBitAnd()).at(ln) }
        return l
    }

    private fun parseBitAnd(): Expr {
        var l = parseShift()
        while (isOp("&")) { val ln = peek().line; p++; l = BinaryE("&", l, parseShift()).at(ln) }
        return l
    }

    private fun parseShift(): Expr {
        var l = parseAdd()
        while (isOp("<<") || isOp(">>")) { val t = next(); l = BinaryE(t.text, l, parseAdd()).at(t.line) }
        return l
    }

    private fun parseAdd(): Expr {
        var l = parseMul()
        while (isOp("+") || isOp("-")) { val t = next(); l = BinaryE(t.text, l, parseMul()).at(t.line) }
        return l
    }

    private fun parseMul(): Expr {
        var l = parseUnary()
        while (isOp("*") || isOp("/") || isOp("%")) { val t = next(); l = BinaryE(t.text, l, parseUnary()).at(t.line) }
        return l
    }

    private fun parseUnary(): Expr {
        if (isOp("-") || isOp("+") || isOp("~")) {
            val t = next()
            return UnaryE(t.text, parseUnary()).at(t.line)
        }
        return parsePower()
    }

    private fun parsePower(): Expr {
        val base = parsePostfix()
        if (isOp("**")) {
            val t = next()
            return BinaryE("**", base, parseUnary()).at(t.line)
        }
        return base
    }

    private fun parsePostfix(): Expr {
        var e = parsePrimary()
        while (true) {
            val t = peek()
            if (t.type != T.OP) break
            when (t.text) {
                "(" -> {
                    p++
                    val args = ArrayList<Expr>()
                    while (!isOp(")")) {
                        args.add(parseExpr())
                        if (!acceptOp(",")) break
                    }
                    expectOp(")")
                    e = CallE(e, args).at(t.line)
                }
                "." -> {
                    p++
                    val nt = next()
                    if (nt.type != T.IDENT && nt.type != T.KW) fail("Se esperaba un nombre después del punto", nt)
                    e = MemberE(e, nt.text).at(t.line)
                }
                "[" -> {
                    p++
                    val idx = parseExpr()
                    expectOp("]")
                    e = IndexE(e, idx).at(t.line)
                }
                else -> break
            }
        }
        return e
    }

    private fun parsePrimary(): Expr {
        val t = next()
        return when (t.type) {
            T.INT, T.FLOAT -> Lit(t.value).at(t.line)
            T.STR -> Lit(t.value).at(t.line)
            T.IDENT -> NameE(t.text).at(t.line)
            T.KW -> when (t.text) {
                "true" -> Lit(true).at(t.line)
                "false" -> Lit(false).at(t.line)
                "null" -> Lit(null).at(t.line)
                "self" -> SelfE().at(t.line)
                else -> fail("No se esperaba '${t.text}' aquí", t)
            }
            T.OP -> when (t.text) {
                "(" -> {
                    val e = parseExpr()
                    expectOp(")")
                    e
                }
                "[" -> {
                    val items = ArrayList<Expr>()
                    while (!isOp("]")) {
                        items.add(parseExpr())
                        if (!acceptOp(",")) break
                    }
                    expectOp("]")
                    ArrayE(items).at(t.line)
                }
                "{" -> {
                    val pairs = ArrayList<Pair<Expr, Expr>>()
                    while (!isOp("}")) {
                        val k = parseExpr()
                        if (!acceptOp(":") && !acceptOp("=")) fail("Se esperaba ':' en el diccionario")
                        val v = parseExpr()
                        pairs.add(Pair(k, v))
                        if (!acceptOp(",")) break
                    }
                    expectOp("}")
                    DictE(pairs).at(t.line)
                }
                else -> fail("No se esperaba '${t.text}' aquí", t)
            }
            else -> fail("Expresión incompleta: aparece '${describe(t)}'", t)
        }
    }
}
