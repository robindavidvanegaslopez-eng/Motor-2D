package com.motor2d.app

import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import com.motor2d.editor.ProjectStore
import com.motor2d.editor.Templates

/** Pantalla de inicio: lista de proyectos y botón para crear uno nuevo. */
class ProjectListScreen(
    private val act: MainActivity,
    private val store: ProjectStore,
    private val onOpen: (String) -> Unit
) : Screen {

    private val root = FrameLayout(act)
    private val list = LinearLayout(act)

    override val view: View get() = root

    init {
        root.setBackgroundColor(Ui.BG)
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(act.dp(16), act.dp(24), act.dp(16), act.dp(16))

        col.addView(act.label("Motor 2D", 28f, Ui.ACCENT, true), lp(Ui.MATCH, Ui.WRAP))
        col.addView(
            act.label("Crea juegos 2D con objetos, físicas y scripts GDScript.", 14f, Ui.MUTED),
            lp(Ui.MATCH, Ui.WRAP).also { it.bottomMargin = act.dp(16) }
        )

        val actions = LinearLayout(act)
        actions.addView(
            act.button("+ Nuevo proyecto", Ui.ACCENT, 0xFF04202D.toInt()) { newProject() },
            lp(0, Ui.WRAP, 1f)
        )
        actions.addView(
            act.button("Ayuda") { act.showHelp() },
            lp(Ui.WRAP, Ui.WRAP).also { it.leftMargin = act.dp(8) }
        )
        col.addView(actions, lp(Ui.MATCH, Ui.WRAP).also { it.bottomMargin = act.dp(16) })

        list.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(act)
        sv.addView(list, FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        col.addView(sv, lp(Ui.MATCH, 0, 1f))

        root.addView(col, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        refresh()
    }

    fun refresh() {
        list.removeAllViews()
        val names = store.names()
        if (names.isEmpty()) {
            list.addView(
                act.label("Todavía no tienes proyectos. Toca «Nuevo proyecto» para empezar; la plantilla de demostración trae un jugador, monedas y plataformas.", 14f, Ui.MUTED),
                lp(Ui.MATCH, Ui.WRAP)
            )
            return
        }
        for (n in names) {
            val row = LinearLayout(act)
            row.gravity = Gravity.CENTER_VERTICAL
            row.background = roundBg(Ui.PANEL, act.dpf(12f))
            row.setPadding(act.dp(14), act.dp(8), act.dp(8), act.dp(8))
            row.isClickable = true
            row.setOnClickListener { onOpen(n) }
            row.addView(act.label(n, 17f), lp(0, Ui.WRAP, 1f))
            row.addView(act.button("⋮") { projectMenu(n) }, lp(Ui.WRAP, Ui.WRAP))
            list.addView(row, lp(Ui.MATCH, Ui.WRAP).also { it.bottomMargin = act.dp(8) })
        }
    }

    private fun newProject() {
        act.askText("Nombre del proyecto", "Mi juego") { raw ->
            act.pick("Plantilla", listOf("Demo de plataformas (recomendada)", "Proyecto vacío")) { i ->
                val p = store.create(raw, if (i == 0) Templates.DEMO else Templates.EMPTY)
                onOpen(p.name)
            }
        }
    }

    private fun projectMenu(name: String) {
        act.pick(name, listOf("Abrir", "Eliminar")) { i ->
            when (i) {
                0 -> onOpen(name)
                1 -> act.confirmDialog("Eliminar proyecto", "Se borrará «$name» con todas sus escenas y scripts. No se puede deshacer.", "Eliminar") {
                    store.delete(name)
                    refresh()
                }
            }
        }
    }
}
