package com.motor2d.engine

import com.motor2d.core.Vec2
import com.motor2d.script.HostObject
import com.motor2d.script.NoSuch
import com.motor2d.script.ScriptError

class GameObject(var name: String) : HostObject {
    var id = 0
    var tag = ""
    var active = true
    var position = Vec2.ZERO        // local (relativa al padre si lo hay)
    var rotation = 0.0              // grados, local
    var scale = Vec2.ONE            // local
    var parent: GameObject? = null
    val children = ArrayList<GameObject>()
    val components = ArrayList<Component>()
    var world: World? = null
    var destroyed = false
    var started = false

    override val typeName: String get() = "GameObject"

    // ---------- Transformación ----------
    fun worldRotation(): Double = (parent?.worldRotation() ?: 0.0) + rotation
    fun worldScale(): Vec2 = parent?.worldScale()?.let { it * scale } ?: scale
    fun worldPosition(): Vec2 {
        val p = parent ?: return position
        return p.worldPosition() + (position * p.worldScale()).rotated(Math.toRadians(p.worldRotation()))
    }

    fun setWorldPosition(w: Vec2) {
        val p = parent
        if (p == null) { position = w; return }
        val ps = p.worldScale()
        val local = (w - p.worldPosition()).rotated(-Math.toRadians(p.worldRotation()))
        position = Vec2(if (ps.x == 0.0) 0.0 else local.x / ps.x, if (ps.y == 0.0) 0.0 else local.y / ps.y)
    }

    fun setWorldRotation(deg: Double) {
        rotation = deg - (parent?.worldRotation() ?: 0.0)
    }

    fun isActiveInHierarchy(): Boolean {
        var o: GameObject? = this
        while (o != null) {
            if (!o.active || o.destroyed) return false
            o = o.parent
        }
        return true
    }

    fun reparent(p: GameObject?) {
        if (p === this) return
        var a = p
        while (a != null) { if (a === this) return; a = a.parent } // evitar ciclos
        val wp = worldPosition()
        val wr = worldRotation()
        parent?.children?.remove(this)
        parent = p
        p?.children?.add(this)
        setWorldPosition(wp)
        setWorldRotation(wr)
    }

    // ---------- Componentes ----------
    fun addComponent(c: Component): Component {
        c.owner = this
        components.add(c)
        return c
    }

    fun removeComponent(c: Component) {
        components.remove(c)
    }

    inline fun <reified T : Component> get(): T? {
        for (c in components) if (c is T) return c
        return null
    }

    fun findComponent(type: String): Component? = components.firstOrNull { it.type == type }

    val rigidbody: Rigidbody2D? get() = get<Rigidbody2D>()
    val sprite: SpriteRenderer? get() = get<SpriteRenderer>()
    val label: Label? get() = get<Label>()
    val camera: Camera2D? get() = get<Camera2D>()
    val colliders: List<Collider> get() = components.filterIsInstance<Collider>()
    val scripts: List<ScriptComponent> get() = components.filterIsInstance<ScriptComponent>()

    /** ¿El punto (en coordenadas del mundo) cae dentro de este objeto? Usa collider o sprite. */
    fun containsPoint(pt: Vec2): Boolean {
        val wp = worldPosition()
        val ws = worldScale()
        val rot = Math.toRadians(worldRotation())
        val local = (pt - wp).rotated(-rot)
        for (c in components) {
            when (c) {
                is BoxCollider2D -> {
                    val sz = c.v("size"); val off = c.v("offset")
                    val hx = Math.abs(sz.x * ws.x) / 2; val hy = Math.abs(sz.y * ws.y) / 2
                    val d = local - Vec2(off.x * ws.x, off.y * ws.y)
                    if (Math.abs(d.x) <= hx && Math.abs(d.y) <= hy) return true
                }
                is CircleCollider2D -> {
                    val off = c.v("offset")
                    val r = c.f("radius") * maxOf(Math.abs(ws.x), Math.abs(ws.y))
                    if ((local - Vec2(off.x * ws.x, off.y * ws.y)).length() <= r) return true
                }
                is SpriteRenderer -> {
                    val sz = c.v("size")
                    val hx = Math.abs(sz.x * ws.x) / 2; val hy = Math.abs(sz.y * ws.y) / 2
                    if (c.s("shape") == "circle") {
                        if (Math.hypot(local.x / hx, local.y / hy) <= 1.0) return true
                    } else if (Math.abs(local.x) <= hx && Math.abs(local.y) <= hy) return true
                }
                else -> {}
            }
        }
        return false
    }

    // ---------- Acceso desde scripts ----------
    private fun scriptVar(name: String): Any? {
        for (sc in scripts) {
            val inst = sc.instance ?: continue
            if (inst.vars.containsKey(name)) return inst.vars[name]
        }
        return NoSuch
    }

    private fun setScriptVar(name: String, value: Any?): Boolean {
        for (sc in scripts) {
            val inst = sc.instance ?: continue
            if (inst.vars.containsKey(name)) { inst.vars[name] = value; return true }
        }
        return false
    }

    override fun getProp(name: String): Any? {
        when (name) {
            "name" -> return this.name
            "tag" -> return tag
            "active" -> return active
            "position" -> return position
            "global_position" -> return worldPosition()
            "rotation" -> return rotation
            "global_rotation" -> return worldRotation()
            "scale" -> return scale
            "parent" -> return parent
            "rigidbody" -> return rigidbody
            "sprite" -> return sprite
            "label" -> return label
            "camera" -> return camera
            "collider" -> return colliders.firstOrNull()
            "velocity" -> return rigidbody?.velocity ?: NoSuch
            "visible" -> return sprite?.b("visible") ?: label?.b("visible") ?: NoSuch
        }
        val sv = scriptVar(name)
        if (sv !== NoSuch) return sv
        return NoSuch
    }

    override fun setProp(name: String, value: Any?): Boolean {
        when (name) {
            "name" -> { this.name = com.motor2d.script.Fmt.str(value); return true }
            "tag" -> { tag = com.motor2d.script.Fmt.str(value); return true }
            "active" -> { active = com.motor2d.script.Interpreter.truthy(value); return true }
            "position" -> { position = Coerce.toVec(value, name); return true }
            "global_position" -> { setWorldPosition(Coerce.toVec(value, name)); return true }
            "rotation" -> { rotation = Coerce.toDouble(value, name); return true }
            "global_rotation" -> { setWorldRotation(Coerce.toDouble(value, name)); return true }
            "scale" -> { scale = Coerce.toVec(value, name); return true }
            "velocity" -> { val rb = rigidbody ?: return false; rb.velocity = Coerce.toVec(value, name); return true }
            "visible" -> {
                val b = com.motor2d.script.Interpreter.truthy(value)
                var any = false
                sprite?.let { it.values["visible"] = b; any = true }
                label?.let { it.values["visible"] = b; any = true }
                return any
            }
        }
        return setScriptVar(name, value)
    }

    private fun targetPos(a: Any?): Vec2 = when (a) {
        is GameObject -> a.worldPosition()
        is Vec2 -> a
        else -> throw ScriptError("Se esperaba un objeto o un Vector2")
    }

    override fun callMethod(name: String, args: List<Any?>): Any? {
        when (name) {
            "destroy" -> { world?.destroy((args.getOrNull(0) as? GameObject) ?: this); return null }
            "translate" -> { position += Coerce.toVec(args.getOrNull(0), "translate"); return null }
            "rotate" -> { rotation += Coerce.toDouble(args.getOrNull(0), "rotate"); return null }
            "distance_to" -> return worldPosition().distanceTo(targetPos(args.getOrNull(0)))
            "direction_to" -> return worldPosition().directionTo(targetPos(args.getOrNull(0)))
            "look_at" -> {
                val d = targetPos(args.getOrNull(0)) - worldPosition()
                setWorldRotation(Math.toDegrees(Math.atan2(d.y, d.x)))
                return null
            }
            "contains_point" -> return containsPoint(Coerce.toVec(args.getOrNull(0), "contains_point"))
            "is_touched" -> {
                val w = world ?: return false
                return w.input.justPressed && containsPoint(w.screenToWorld(w.input.touchPos))
            }
            "is_held" -> {
                val w = world ?: return false
                return w.input.touching && containsPoint(w.screenToWorld(w.input.touchPos))
            }
            "get_component" -> {
                val t = ComponentTypes.canonical(args.getOrNull(0)?.toString() ?: "") ?: return null
                return findComponent(t)
            }
            "has_component" -> {
                val t = ComponentTypes.canonical(args.getOrNull(0)?.toString() ?: "") ?: return false
                return findComponent(t) != null
            }
            "get_children" -> return ArrayList<Any?>(children)
            "get_parent" -> return parent
            "set_parent" -> { reparent(args.getOrNull(0) as? GameObject); return null }
            "get_object" -> return world?.findByName(args.getOrNull(0)?.toString() ?: "")
            "is_valid" -> return !destroyed
            "after" -> {
                val w = world ?: return null
                return w.timers.after(this, Coerce.toDouble(args.getOrNull(0), "after"), args.getOrNull(1)?.toString() ?: "")
            }
            "every" -> {
                val w = world ?: return null
                return w.timers.every(this, Coerce.toDouble(args.getOrNull(0), "every"), args.getOrNull(1)?.toString() ?: "")
            }
            "cancel_timer" -> { world?.timers?.cancel((args.getOrNull(0) as? Long) ?: -1L); return null }
            "tween_to" -> {
                world?.timers?.tween(this, args.getOrNull(0)?.toString() ?: "", args.getOrNull(1),
                    Coerce.toDouble(args.getOrNull(2) ?: 1.0, "tween_to"), args.getOrNull(3)?.toString() ?: "linear")
                return null
            }
            "play_animation" -> { sprite?.play(args.getOrNull(0)?.toString()); return null }
            "stop_animation" -> { sprite?.stopAnimation(); return null }
            "has_method" -> {
                val fn = args.getOrNull(0)?.toString() ?: return false
                return scripts.any { it.instance?.hasFunc(fn) == true }
            }
            "set_color" -> {
                sprite?.setProp("color", args.getOrNull(0)) ?: label?.setProp("color", args.getOrNull(0))
                return null
            }
            "set_text" -> {
                label?.setProp("text", args.getOrNull(0))
                return null
            }
        }
        // Funciones definidas en los scripts de este objeto (other.hurt(5))
        for (sc in scripts) {
            val inst = sc.instance ?: continue
            if (inst.hasFunc(name)) return inst.call(name, args)
        }
        return NoSuch
    }

    override fun toString() = "GameObject($name)"
}
