package com.motor2d.editor

/** El GDScript generado y, para cada línea, el bloque que la produjo (null si es estructura). */
class Compiled(val text: String, val owners: List<Block?>) {
    /** Bloque responsable de la línea `line` (empezando en 1), por ejemplo para marcar el bloque con el error. */
    fun ownerOfLine(line: Int): Block? = owners.getOrNull(line - 1)
}

/**
 * Convierte un script de bloques en GDScript legible. Los eventos del mismo tipo se juntan en una sola función
 * (dos «Al empezar» pasan a ser un único `_ready`), y cada bloque deja un comentario con lo que hace.
 */
object BlockCompiler {

    private class Line(val text: String, val owner: Block?)

    private class Fn(val name: String, val params: String) {
        val lines = ArrayList<Line>()
    }

    private class Ctx {
        val fns = LinkedHashMap<String, Fn>()
        val helpers = ArrayList<Fn>()
        val vars = LinkedHashMap<String, String>()
        var counter = 0

        fun fn(name: String, params: String): Fn = fns.getOrPut(name) { Fn(name, params) }
    }

    // ---------- Valores de los huecos ----------
    private fun oneLine(s: String) = s.replace('\r', ' ').replace('\n', ' ')

    fun quote(raw: String): String =
        "\"" + oneLine(raw).replace("\\", "\\\\").replace("\"", "\\\"") + "\""

    /** Nombre válido de variable o función: solo letras, números y guion bajo. */
    fun ident(raw: String, fallback: String = "x"): String {
        val sb = StringBuilder()
        for (c in raw.trim()) sb.append(if (c.isLetterOrDigit() || c == '_') c else '_')
        var s = sb.toString()
        if (s.isEmpty()) s = fallback
        if (s[0].isDigit()) s = "_$s"
        return s
    }

    private fun render(p: BParam, raw: String): String {
        val v = oneLine(raw).trim()
        return when (p.kind) {
            PKind.NUM -> v.ifEmpty { "0" }
            PKind.COND -> v.ifEmpty { "true" }
            PKind.TEXT, PKind.NAME -> quote(raw)
            PKind.CHOICE -> v
            PKind.COLOR -> quote(v.ifEmpty { "white" })
            PKind.IDENT -> ident(v)
        }
    }

    private val PLACEHOLDER = Regex("\\{(\\w+)\\}")

    private fun fill(def: BlockDef, b: Block, template: String, loopVar: String): String =
        PLACEHOLDER.replace(template) { m ->
            val name = m.groupValues[1]
            if (name == "iv") loopVar
            else {
                val p = def.param(name)
                if (p == null) m.value else render(p, b.args[name] ?: p.def)
            }
        }

    private fun pad(indent: Int) = "    ".repeat(indent)

    // ---------- Variables que se usan sin declarar ----------
    private val RESERVED = setOf(
        "and", "or", "not", "in", "if", "else", "true", "false", "null", "self", "position", "global_position",
        "rotation", "global_rotation", "scale", "name", "tag", "velocity", "delta", "other", "visible", "active",
        "parent", "rigidbody", "sprite", "label", "camera", "collider", "screen_size", "screen_width", "screen_height",
        "Input", "Physics", "Time", "Vector2", "Color", "PI", "TAU", "INF"
    )
    private val TOKEN = Regex("\"(?:[^\"\\\\]|\\\\.)*\"|(?<![\\w.])([A-Za-z_]\\w*)(?!\\w)")
    private val LOOP_VAR = Regex("^i\\d+$")

    /** Si una expresión usa un nombre suelto que nadie declaró (p. ej. `puntos > 3`), lo declara con valor 0. */
    private fun declareFree(expr: String, ctx: Ctx) {
        for (m in TOKEN.findAll(expr)) {
            val id = m.groups[1]?.value ?: continue
            if (id in RESERVED || LOOP_VAR.matches(id) || ctx.vars.containsKey(id)) continue
            val after = expr.substring(m.range.last + 1).trimStart()
            if (after.startsWith("(")) continue
            ctx.vars[id] = "0"
        }
    }

    // ---------- Instrucciones ----------
    private fun emit(blocks: List<Block>, out: Fn, indent: Int, depth: Int, ctx: Ctx) {
        for (b in blocks) {
            val def = BlockCatalog.def(b.type) ?: continue
            if (def.kind == BKind.HAT) continue   // los eventos solo van en la raíz
            out.lines.add(Line(pad(indent) + "# " + oneLine(BlockCatalog.describe(b)), b))

            // variables que se usan sin haberse declarado
            if (b.type == "va_set" || b.type == "va_change" || b.type == "va_random") {
                val name = ident(b.args["var"] ?: "x")
                if (!ctx.vars.containsKey(name)) ctx.vars[name] = "0"
            }
            for (p in def.params) {
                if (p.kind == PKind.NUM || p.kind == PKind.COND) declareFree(b.args[p.name] ?: p.def, ctx)
            }

            when (def.kind) {
                BKind.STATEMENT -> for (l in def.code) out.lines.add(Line(pad(indent) + fill(def, b, l, ""), b))
                BKind.CONTAINER -> emitContainer(def, b, out, indent, depth, ctx)
                BKind.HAT -> {}
            }
        }
    }

    private fun emitBody(blocks: List<Block>, out: Fn, indent: Int, depth: Int, ctx: Ctx, owner: Block?) {
        val before = out.lines.size
        emit(blocks, out, indent, depth, ctx)
        if (out.lines.size == before) out.lines.add(Line(pad(indent) + "pass", owner))
    }

    private fun emitContainer(def: BlockDef, b: Block, out: Fn, indent: Int, depth: Int, ctx: Ctx) {
        if (b.type == "ct_after") {
            // Esperar N segundos y luego...: el contenido pasa a una función auxiliar que se llama con after()
            val name = "_espera_" + (++ctx.counter)
            val helper = Fn(name, "")
            ctx.helpers.add(helper)
            emitBody(b.children, helper, 1, depth, ctx, b)
            val n = render(def.param("n")!!, b.args["n"] ?: "1")
            out.lines.add(Line(pad(indent) + "after($n, \"$name\")", b))
            return
        }
        val loopVar = "i$depth"
        out.lines.add(Line(pad(indent) + fill(def, b, def.code[0], loopVar), b))
        emitBody(b.children, out, indent + 1, depth + 1, ctx, b)
        if (def.hasElse) {
            out.lines.add(Line(pad(indent) + "else:", b))
            emitBody(b.elseChildren, out, indent + 1, depth + 1, ctx, b)
        }
    }

    // ---------- Eventos ----------
    private fun filtered(who: String, body: (Int) -> Unit, out: Fn, owner: Block) {
        val w = who.trim()
        if (w.isEmpty()) { body(1); return }
        val q = quote(w)
        out.lines.add(Line("    if other.name == $q or other.tag == $q:", owner))
        body(2)
    }

    private fun addEvent(b: Block, ctx: Ctx) {
        val def = BlockCatalog.def(b.type) ?: return
        run {
            fun arg(n: String) = b.args[n] ?: def.param(n)?.def ?: ""
            fun simple(fnName: String, params: String) {
                val f = ctx.fn(fnName, params)
                f.lines.add(Line("    # " + oneLine(BlockCatalog.describe(b)), b))
                emitBody(b.children, f, 1, 0, ctx, b)
            }
            fun withFilter(fnName: String) {
                val f = ctx.fn(fnName, "other")
                f.lines.add(Line("    # " + oneLine(BlockCatalog.describe(b)), b))
                filtered(arg("who"), { ind -> emitBody(b.children, f, ind, 0, ctx, b) }, f, b)
            }
            fun inProcess(condition: String) {
                val f = ctx.fn("_process", "delta")
                f.lines.add(Line("    # " + oneLine(BlockCatalog.describe(b)), b))
                f.lines.add(Line("    if $condition:", b))
                emitBody(b.children, f, 2, 0, ctx, b)
            }
            when (b.type) {
                "ev_start" -> simple("_ready", "")
                "ev_frame" -> simple("_process", "delta")
                "ev_physics" -> simple("_physics_process", "delta")
                "ev_touch" -> simple("_on_touched", "")
                "ev_collide" -> withFilter("_on_collision_enter")
                "ev_collide_exit" -> withFilter("_on_collision_exit")
                "ev_trigger" -> withFilter("_on_trigger_enter")
                "ev_trigger_exit" -> withFilter("_on_trigger_exit")
                "ev_key" -> inProcess("Input.is_key_just_pressed(" + quote(arg("key")) + ")")
                "ev_key_held" -> inProcess("Input.is_key_pressed(" + quote(arg("key")) + ")")
                "ev_button" -> inProcess("Input.is_button_just_pressed(" + quote(arg("button")) + ")")
                "ev_click" -> inProcess("Input.just_clicked(" + quote(arg("button")) + ")")
                "ev_after", "ev_every" -> {
                    val name = "_" + b.type.removePrefix("ev_") + "_" + (++ctx.counter)
                    val helper = Fn(name, "")
                    ctx.helpers.add(helper)
                    emitBody(b.children, helper, 1, 0, ctx, b)
                    val n = render(def.param("n")!!, arg("n"))
                    val ready = ctx.fn("_ready", "")
                    ready.lines.add(Line("    # " + oneLine(BlockCatalog.describe(b)), b))
                    val call = if (b.type == "ev_after") "after" else "every"
                    ready.lines.add(Line("    $call($n, \"$name\")", b))
                }
                "ev_func" -> {
                    val name = ident(arg("name"), "mi_funcion")
                    val f = ctx.fn(name, "")
                    f.lines.add(Line("    # " + oneLine(BlockCatalog.describe(b)), b))
                    emitBody(b.children, f, 1, 0, ctx, b)
                }
            }
        }
    }

    // ---------- Resultado ----------
    private val LITERAL = Regex("^-?\\d+(\\.\\d+)?$|^true$|^false$|^\"[^\"\\\\]*\"$|^Vector2\\(\\s*-?\\d+(\\.\\d+)?\\s*,\\s*-?\\d+(\\.\\d+)?\\s*\\)$")

    fun compile(s: BlockScript): Compiled {
        val ctx = Ctx()
        for ((k, v) in s.vars) ctx.vars[ident(k)] = oneLine(v).ifBlank { "0" }
        for (e in s.events) addEvent(e, ctx)

        val lines = ArrayList<Line>()
        fun add(t: String, owner: Block? = null) { lines.add(Line(t, owner)) }
        add("extends Node2D")
        add("# Generado por los bloques: se reescribe cada vez que guardas. Para programar a mano, copia este archivo.")
        for ((name, value) in ctx.vars) {
            // las variables con un valor simple se pueden cambiar desde el Inspector
            add((if (LITERAL.matches(value.trim())) "@export var " else "var ") + name + " = " + value)
        }
        val all = ArrayList<Fn>(ctx.fns.values)
        all.addAll(ctx.helpers)
        for (f in all) {
            add("")
            add("func ${f.name}(${f.params}):")
            val body = ArrayList(f.lines)
            val usesDelta = body.any { Regex("\\bdelta\\b").containsMatchIn(it.text) }
            if (usesDelta && !f.params.contains("delta")) body.add(0, Line("    var delta = 1.0 / 60.0", null))
            if (body.isEmpty()) body.add(Line("    pass", null))
            lines.addAll(body)
        }
        return Compiled(lines.joinToString("\n") { it.text } + "\n", lines.map { it.owner })
    }
}
