package com.motor2d.editor

import com.motor2d.core.Vec2
import com.motor2d.engine.BoxCollider2D
import com.motor2d.engine.Camera2D
import com.motor2d.engine.CircleCollider2D
import com.motor2d.engine.GameObject
import com.motor2d.engine.Label
import com.motor2d.engine.Rigidbody2D
import com.motor2d.engine.ScriptComponent
import com.motor2d.engine.SpriteRenderer

/**
 * Un comportamiento prefabricado: un script GDScript listo para usar, con variables @export
 * que se cambian en el Inspector, y la lista de componentes que necesita para funcionar.
 */
data class Behavior(
    val id: String,
    val name: String,
    val category: String,
    val description: String,
    val requires: List<String>,
    val trigger: Boolean,
    val bodyType: String?,
    val gravity: Double?,
    val freezeRotation: Boolean,
    val tag: String?,
    val source: String
) {
    /** Dónde se guarda dentro del proyecto. */
    val path: String get() = "$FOLDER/$id.gd"

    /** Primera frase de la descripción, para mostrarla en listas. */
    val summary: String
        get() {
            val end = description.indexOf(". ")
            val s = if (end in 10..140) description.substring(0, end + 1) else description
            return if (s.length > 140) s.take(137) + "..." else s
        }

    companion object { const val FOLDER = "scripts/comportamientos" }
}

object Behaviors {

    /** Lee un .gd de la biblioteca: las líneas «# @clave: valor» del principio son los datos. */
    fun parse(id: String, text: String): Behavior {
        val meta = HashMap<String, String>()
        val body = StringBuilder()
        var inHeader = true
        for (line in text.lines()) {
            if (inHeader && line.startsWith("# @")) {
                val k = line.substring(3).substringBefore(':').trim()
                val v = line.substringAfter(':', "").trim()
                meta[k] = v
            } else {
                inHeader = false
                body.append(line).append('\n')
            }
        }
        fun yes(k: String) = meta[k]?.lowercase() in listOf("si", "sí", "true", "yes")
        return Behavior(
            id = id,
            name = meta["nombre"] ?: id,
            category = meta["categoria"] ?: "Otros",
            description = meta["descripcion"] ?: "",
            requires = (meta["requiere"] ?: "").split(',').map { it.trim() }.filter { it.isNotEmpty() },
            trigger = yes("trigger"),
            bodyType = meta["cuerpo"],
            gravity = meta["gravedad"]?.toDoubleOrNull(),
            freezeRotation = yes("bloquear_rotacion"),
            tag = meta["tag"],
            source = body.toString().trimEnd() + "\n"
        )
    }

    /** Ordena por categoría (en el orden en que conviene mostrarlas) y luego por nombre. */
    private val CATEGORY_ORDER = listOf(
        "Movimiento", "Combate y vida", "Objetos y coleccionables", "Mundo y física",
        "Reglas y marcadores", "Cámara", "Efectos visuales", "Interfaz"
    )

    fun sorted(list: List<Behavior>): List<Behavior> =
        list.sortedWith(compareBy({ CATEGORY_ORDER.indexOf(it.category).let { i -> if (i < 0) 99 else i } }, { it.name.lowercase() }))

    fun categories(list: List<Behavior>): List<String> = sorted(list).map { it.category }.distinct()

    /**
     * Prepara el objeto para el comportamiento: añade los componentes que falten (física, collider,
     * texto...) y el componente Script con la ruta del comportamiento. No escribe el archivo del
     * script (eso lo hace quien tenga el proyecto). Devuelve un resumen de lo que se añadió.
     */
    fun applyTo(o: GameObject, b: Behavior): String {
        val added = ArrayList<String>()

        fun needsBody() = "Rigidbody2D" in b.requires
        val wantsCollider = b.requires.any { it == "BoxCollider2D" || it == "CircleCollider2D" }

        // Un dibujo para que se vea (solo en cosas físicas, no en textos ni cámaras)
        if ((needsBody() || wantsCollider) && o.sprite == null && o.label == null && o.camera == null) {
            o.addComponent(SpriteRenderer())
            added.add("Dibujo")
        }

        for (r in b.requires) {
            when (r) {
                "Rigidbody2D" -> if (o.rigidbody == null) {
                    o.addComponent(Rigidbody2D().also {
                        if (b.bodyType != null) it.values["body_type"] = b.bodyType
                        if (b.gravity != null) it.values["gravity_scale"] = b.gravity
                        if (b.freezeRotation) it.values["freeze_rotation"] = true
                    })
                    added.add("Rigidbody (" + (b.bodyType ?: "dynamic") + ")")
                }
                "BoxCollider2D", "CircleCollider2D" -> if (o.colliders.isEmpty()) {
                    val sz = o.sprite?.v("size")
                    if (r == "BoxCollider2D") {
                        o.addComponent(BoxCollider2D().also { c -> if (sz != null) c.values["size"] = sz })
                    } else {
                        o.addComponent(CircleCollider2D().also { c ->
                            c.values["radius"] = if (sz != null) Math.min(sz.x, sz.y) / 2 else 32.0
                        })
                    }
                    added.add("Collider")
                }
                "Label" -> if (o.label == null) { o.addComponent(Label()); added.add("Texto") }
                "Camera2D" -> if (o.camera == null) { o.addComponent(Camera2D()); added.add("Cámara") }
                "SpriteRenderer" -> if (o.sprite == null) { o.addComponent(SpriteRenderer()); added.add("Dibujo") }
            }
        }

        if (b.trigger) {
            val c = o.colliders.firstOrNull()
            if (c != null && c.values["is_trigger"] != true) { c.values["is_trigger"] = true; added.add("Collider como disparador") }
        }
        if (b.tag != null && o.tag.isEmpty()) { o.tag = b.tag; added.add("etiqueta «${b.tag}»") }

        o.addComponent(ScriptComponent().also { it.values["path"] = b.path })
        val extra = if (added.isEmpty()) "" else " (también: " + added.joinToString(", ") + ")"
        return "Añadido: ${b.name}$extra"
    }
}
