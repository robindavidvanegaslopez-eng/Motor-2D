package com.motor2d.engine

import com.motor2d.core.Vec2
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

class PhysicsEvents {
    val collisionEnter = ArrayList<Pair<GameObject, GameObject>>()
    val collisionExit = ArrayList<Pair<GameObject, GameObject>>()
    val triggerEnter = ArrayList<Pair<GameObject, GameObject>>()
    val triggerExit = ArrayList<Pair<GameObject, GameObject>>()
    fun isEmpty() = collisionEnter.isEmpty() && collisionExit.isEmpty() && triggerEnter.isEmpty() && triggerExit.isEmpty()
}

/** Física 2D de impulsos secuenciales: círculos y cajas orientadas, fricción, rebote, triggers. */
class Physics {
    var gravity = Vec2(0.0, 980.0)
    var substeps = 2
    var iterations = 8

    private class Constraint(
        val m: Manifold, val c: Contact, val a: Body?, val b: Body?,
        val rax: Double, val ray: Double, val rbx: Double, val rby: Double,
        val nMass: Double, val tMass: Double, val bounceVel: Double, val mu: Double
    ) {
        var accN = 0.0
        var accT = 0.0
    }

    private var prevSolid = HashMap<Long, Pair<GameObject, GameObject>>()
    private var prevTrigger = HashMap<Long, Pair<GameObject, GameObject>>()

    fun reset() { prevSolid = HashMap(); prevTrigger = HashMap() }

    private fun key(a: GameObject, b: GameObject): Long {
        val lo = minOf(a.id, b.id).toLong(); val hi = maxOf(a.id, b.id).toLong()
        return (lo shl 32) or hi
    }

    fun step(objects: List<GameObject>, dt: Double): PhysicsEvents {
        val ev = PhysicsEvents()
        // ---- 1. Recoger cuerpos y formas ----
        val bodyOf = HashMap<GameObject, Body>()
        val bodies = ArrayList<Body>()
        for (o in objects) {
            if (!o.isActiveInHierarchy()) continue
            val rb = o.rigidbody ?: continue
            if (rb.s("body_type") == "static") continue
            val b = Body(o, rb)
            val wp = o.worldPosition()
            b.x = wp.x; b.y = wp.y
            b.angle = Math.toRadians(o.worldRotation())
            b.vx = rb.velocity.x; b.vy = rb.velocity.y
            b.w = Math.toRadians(rb.angularVelocity)
            b.kinematic = rb.isKinematic
            val mass = rb.f("mass").coerceAtLeast(1e-4)
            b.invMass = if (b.kinematic) 0.0 else 1.0 / mass
            b.gravityScale = rb.f("gravity_scale")
            b.drag = rb.f("drag").coerceAtLeast(0.0)
            bodyOf[o] = b
            bodies.add(b)
        }

        val shapes = ArrayList<Shape>()
        for (o in objects) {
            if (!o.isActiveInHierarchy()) continue
            val cols = o.colliders
            if (cols.isEmpty()) continue
            val body = bodyOf[o]
            for (c in cols) shapes.add(Shape(o, c, body))
        }
        // Inercia: según la primera forma del cuerpo
        for (b in bodies) {
            if (b.kinematic || b.rb.b("freeze_rotation")) { b.invI = 0.0; b.w = if (b.kinematic) b.w else 0.0; continue }
            val sh = shapes.firstOrNull { it.body === b }
            if (sh == null) { b.invI = 0.0; continue }
            val ws = b.obj.worldScale()
            sh.update(b.x, b.y, b.angle, ws.x, ws.y)
            val m = 1.0 / b.invMass
            val inertia = if (sh.isBox) m * ((2 * sh.hx) * (2 * sh.hx) + (2 * sh.hy) * (2 * sh.hy)) / 12.0
            else 0.5 * m * sh.r * sh.r
            b.invI = if (inertia > 1e-9) 1.0 / inertia else 0.0
        }

        val solidNow = HashMap<Long, Pair<GameObject, GameObject>>()
        val triggerNow = HashMap<Long, Pair<GameObject, GameObject>>()
        for (b in bodies) { b.rb.onFloor = false; b.rb.onWall = false; b.rb.onCeiling = false }

        val n = substeps.coerceAtLeast(1)
        val h = dt / n
        for (sub in 0 until n) {
            // ---- 2. Fuerzas ----
            for (b in bodies) {
                if (b.kinematic) continue
                val f = b.rb.force
                b.vx += (gravity.x * b.gravityScale + f.x * b.invMass) * h
                b.vy += (gravity.y * b.gravityScale + f.y * b.invMass) * h
                if (b.drag > 0) { val k = 1.0 / (1.0 + h * b.drag); b.vx *= k; b.vy *= k }
                b.w *= 1.0 / (1.0 + h * 0.05)
                val sp = sqrt(b.vx * b.vx + b.vy * b.vy)
                if (sp > 6000.0) { val k = 6000.0 / sp; b.vx *= k; b.vy *= k }
            }

            // ---- 3. Actualizar formas ----
            for (s in shapes) {
                val bd = s.body
                if (bd != null) {
                    val ws = bd.obj.worldScale()
                    s.update(bd.x, bd.y, bd.angle, ws.x, ws.y)
                } else {
                    val o = s.obj
                    val p = o.worldPosition(); val ws = o.worldScale()
                    s.update(p.x, p.y, Math.toRadians(o.worldRotation()), ws.x, ws.y)
                }
            }

            // ---- 4. Detección ----
            val constraints = ArrayList<Constraint>()
            val manifolds = ArrayList<Manifold>()
            val ns = shapes.size
            for (i in 0 until ns) {
                val a = shapes[i]
                for (j in i + 1 until ns) {
                    val b = shapes[j]
                    if (a.obj === b.obj) continue
                    if (a.body == null && b.body == null) continue
                    val aDyn = a.body != null && !a.body.kinematic
                    val bDyn = b.body != null && !b.body.kinematic
                    val trig = a.trigger || b.trigger
                    if (!trig && !aDyn && !bDyn) continue   // cinemático contra estático: sin choque
                    val m = Collision.collide(a, b) ?: continue
                    val k = key(a.obj, b.obj)
                    if (trig) {
                        triggerNow[k] = Pair(a.obj, b.obj)
                        continue
                    }
                    solidNow[k] = Pair(a.obj, b.obj)
                    manifolds.add(m)
                    for (c in m.contacts) buildConstraint(m, c, a.body, b.body)?.let { constraints.add(it) }
                }
            }

            // ---- 5. Resolver velocidades ----
            for (it in 0 until iterations) {
                for (c in constraints) solve(c)
            }

            // ---- 6. Integrar posiciones ----
            for (b in bodies) {
                b.x += b.vx * h
                b.y += b.vy * h
                b.angle += b.w * h
            }

            // ---- 7. Corrección de posición + banderas de suelo ----
            for (m in manifolds) {
                val a = m.a.body; val b = m.b.body
                var pen = 0.0
                for (c in m.contacts) pen = max(pen, c.penetration)
                val ima = a?.invMass ?: 0.0
                val imb = b?.invMass ?: 0.0
                val tot = ima + imb
                if (tot > 0) {
                    val corr = max(pen - 0.5, 0.0) * 0.4 / tot
                    if (a != null) { a.x -= m.nx * corr * ima; a.y -= m.ny * corr * ima }
                    if (b != null) { b.x += m.nx * corr * imb; b.y += m.ny * corr * imb }
                }
                if (a != null) flags(a, m.nx, m.ny)
                if (b != null) flags(b, -m.nx, -m.ny)
            }
        }

        // ---- 8. Escribir resultados ----
        for (b in bodies) {
            b.obj.setWorldPosition(Vec2(b.x, b.y))
            if (!b.rb.b("freeze_rotation") || b.kinematic) b.obj.setWorldRotation(Math.toDegrees(b.angle))
            b.rb.velocity = Vec2(b.vx, b.vy)
            b.rb.angularVelocity = Math.toDegrees(b.w)
            b.rb.force = Vec2.ZERO
        }

        // ---- 9. Eventos ----
        for ((k, p) in solidNow) if (!prevSolid.containsKey(k)) ev.collisionEnter.add(p)
        for ((k, p) in prevSolid) if (!solidNow.containsKey(k)) ev.collisionExit.add(p)
        for ((k, p) in triggerNow) if (!prevTrigger.containsKey(k)) ev.triggerEnter.add(p)
        for ((k, p) in prevTrigger) if (!triggerNow.containsKey(k)) ev.triggerExit.add(p)
        prevSolid = solidNow
        prevTrigger = triggerNow
        return ev
    }

    private fun flags(b: Body, nx: Double, ny: Double) {
        // (nx, ny) apunta del cuerpo hacia el otro objeto
        if (ny > 0.6) b.rb.onFloor = true
        else if (ny < -0.6) b.rb.onCeiling = true
        if (abs(nx) > 0.7) b.rb.onWall = true
    }

    private fun buildConstraint(m: Manifold, c: Contact, a: Body?, b: Body?): Constraint? {
        val ima = a?.invMass ?: 0.0; val imb = b?.invMass ?: 0.0
        val iia = a?.invI ?: 0.0; val iib = b?.invI ?: 0.0
        if (ima + imb == 0.0) return null
        val rax = if (a != null) c.x - a.x else 0.0
        val ray = if (a != null) c.y - a.y else 0.0
        val rbx = if (b != null) c.x - b.x else 0.0
        val rby = if (b != null) c.y - b.y else 0.0
        val nx = m.nx; val ny = m.ny
        val racn = rax * ny - ray * nx
        val rbcn = rbx * ny - rby * nx
        val kn = ima + imb + racn * racn * iia + rbcn * rbcn * iib
        val tx = -ny; val ty = nx
        val ract = rax * ty - ray * tx
        val rbct = rbx * ty - rby * tx
        val kt = ima + imb + ract * ract * iia + rbct * rbct * iib
        // velocidad relativa normal antes de resolver (para el rebote)
        val avx = a?.vx ?: 0.0; val avy = a?.vy ?: 0.0; val aw = a?.w ?: 0.0
        val bvx = b?.vx ?: 0.0; val bvy = b?.vy ?: 0.0; val bw = b?.w ?: 0.0
        val rvx = (bvx - bw * rby) - (avx - aw * ray)
        val rvy = (bvy + bw * rbx) - (avy + aw * rax)
        val vn = rvx * nx + rvy * ny
        val e = max(m.a.bounce, m.b.bounce)
        val bounce = if (vn < -60.0 && e > 0.0) -e * vn else 0.0
        val mu = sqrt(m.a.friction * m.b.friction)
        return Constraint(m, c, a, b, rax, ray, rbx, rby, 1.0 / kn, if (kt > 0) 1.0 / kt else 0.0, bounce, mu)
    }

    private fun solve(k: Constraint) {
        val a = k.a; val b = k.b
        val ima = a?.invMass ?: 0.0; val imb = b?.invMass ?: 0.0
        val iia = a?.invI ?: 0.0; val iib = b?.invI ?: 0.0
        val nx = k.m.nx; val ny = k.m.ny

        // --- normal ---
        var avx = a?.vx ?: 0.0; var avy = a?.vy ?: 0.0; var aw = a?.w ?: 0.0
        var bvx = b?.vx ?: 0.0; var bvy = b?.vy ?: 0.0; var bw = b?.w ?: 0.0
        var rvx = (bvx - bw * k.rby) - (avx - aw * k.ray)
        var rvy = (bvy + bw * k.rbx) - (avy + aw * k.rax)
        val vn = rvx * nx + rvy * ny
        var j = (k.bounceVel - vn) * k.nMass
        val newN = max(k.accN + j, 0.0)
        j = newN - k.accN
        k.accN = newN
        applyImpulse(a, b, ima, imb, iia, iib, k, nx * j, ny * j)

        // --- fricción ---
        avx = a?.vx ?: 0.0; avy = a?.vy ?: 0.0; aw = a?.w ?: 0.0
        bvx = b?.vx ?: 0.0; bvy = b?.vy ?: 0.0; bw = b?.w ?: 0.0
        rvx = (bvx - bw * k.rby) - (avx - aw * k.ray)
        rvy = (bvy + bw * k.rbx) - (avy + aw * k.rax)
        val tx = -ny; val ty = nx
        val vt = rvx * tx + rvy * ty
        var jt = -vt * k.tMass
        val maxF = k.mu * k.accN
        val newT = (k.accT + jt).coerceIn(-maxF, maxF)
        jt = newT - k.accT
        k.accT = newT
        applyImpulse(a, b, ima, imb, iia, iib, k, tx * jt, ty * jt)
    }

    private fun applyImpulse(a: Body?, b: Body?, ima: Double, imb: Double, iia: Double, iib: Double, k: Constraint, px: Double, py: Double) {
        if (a != null) {
            a.vx -= px * ima; a.vy -= py * ima
            a.w -= iia * (k.rax * py - k.ray * px)
        }
        if (b != null) {
            b.vx += px * imb; b.vy += py * imb
            b.w += iib * (k.rbx * py - k.rby * px)
        }
    }
}
