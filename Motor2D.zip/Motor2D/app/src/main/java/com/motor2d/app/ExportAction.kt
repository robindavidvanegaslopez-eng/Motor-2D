package com.motor2d.app

import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.LinearLayout
import com.motor2d.editor.Project
import com.motor2d.editor.SpriteDoc
import com.motor2d.export.ApkExporter
import com.motor2d.export.ExportConfig
import com.motor2d.export.ExportKeys
import com.motor2d.export.isValidPackageName
import com.motor2d.export.suggestPackageName
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

/**
 * «Exportar APK»: convierte el proyecto en una app independiente copiando el APK de este mismo motor,
 * cambiándole nombre y paquete, metiendo el juego dentro y firmándolo. Todo ocurre en el teléfono, sin internet.
 */
object ExportAction {

    fun start(act: MainActivity, project: Project, saveFirst: () -> Unit) {
        saveFirst()
        val nameField = act.input(project.name, "Nombre del juego")
        val pkgField = act.input(suggestPackageName(project.name), "com.tuestudio.juego")
        val verField = act.input("1.0", "Versión")
        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(act.dp(20), act.dp(8), act.dp(20), 0)
        box.addView(act.label("Nombre que verá el jugador", 12f, Ui.MUTED))
        box.addView(nameField, lp(Ui.MATCH, Ui.WRAP))
        box.addView(act.label("Identificador único (paquete)", 12f, Ui.MUTED).also { it.setPadding(0, act.dp(10), 0, 0) })
        box.addView(pkgField, lp(Ui.MATCH, Ui.WRAP))
        box.addView(act.label("Versión", 12f, Ui.MUTED).also { it.setPadding(0, act.dp(10), 0, 0) })
        box.addView(verField, lp(Ui.MATCH, Ui.WRAP))
        // al cambiar el nombre se propone un paquete nuevo mientras el usuario no haya tocado el paquete
        var pkgEdited = false
        pkgField.setOnFocusChangeListener { _, has -> if (has) pkgEdited = true }
        nameField.setOnFocusChangeListener { _, has ->
            if (!has && !pkgEdited) pkgField.setText(suggestPackageName(nameField.text.toString()))
        }
        AlertDialog.Builder(act)
            .setTitle("Exportar APK")
            .setView(box)
            .setPositiveButton("Crear APK") { _, _ ->
                val appName = nameField.text.toString().trim()
                val pkg = pkgField.text.toString().trim()
                val ver = verField.text.toString().trim().ifEmpty { "1.0" }
                if (appName.isEmpty() || appName.any { it < ' ' }) { act.toast("Escribe un nombre para el juego"); return@setPositiveButton }
                if (!pkg.isValidPackageName()) {
                    act.toast("El paquete debe ser como com.miestudio.juego (minúsculas, números y _)")
                    return@setPositiveButton
                }
                if (pkg == act.packageName) { act.toast("Ese paquete es el del propio motor; usa otro"); return@setPositiveButton }
                build(act, project, ExportConfig(pkg, appName, ver, act.packageName, "Motor 2D"))
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun build(act: MainActivity, project: Project, cfg: ExportConfig) {
        val progress = AlertDialog.Builder(act)
            .setTitle("Creando APK…")
            .setMessage("Empaquetando y firmando el juego. Puede tardar unos segundos.")
            .setCancelable(false)
            .show()
        Thread {
            var result: Uri? = null
            var where = ""
            var error: String? = null
            try {
                val files = HashMap<String, ByteArray>()
                for (e in project.allFiles().entries) files["assets/game/" + e.key] = e.value
                val keys = ExportKeys.load(
                    act.assets.open("export/key.pk8").use { it.readBytes() },
                    act.assets.open("export/cert.der").use { it.readBytes() }
                )
                val template = File(act.applicationInfo.sourceDir)
                val buf = ByteArrayOutputStream(template.length().toInt() + 1_000_000)
                ApkExporter.export(template, buf, files, cfg, keys.first, keys.second)
                val fileName = SpriteDoc.cleanName(cfg.appName) + ".apk"
                if (Build.VERSION.SDK_INT >= 29) {
                    val cv = ContentValues()
                    cv.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/vnd.android.package-archive")
                    cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    val uri = act.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                        ?: throw IllegalStateException("No se pudo crear el archivo en Descargas")
                    act.contentResolver.openOutputStream(uri)?.use { it.write(buf.toByteArray()) }
                        ?: throw IllegalStateException("No se pudo escribir en Descargas")
                    result = uri
                    where = "Descargas/$fileName"
                } else {
                    val dir = act.getExternalFilesDir(null) ?: act.filesDir
                    val f = File(dir, fileName)
                    FileOutputStream(f).use { it.write(buf.toByteArray()) }
                    where = f.absolutePath
                }
            } catch (e: Throwable) {
                error = e.message ?: e.javaClass.simpleName
            }
            val uriOut = result
            val whereOut = where
            val errOut = error
            act.runOnUiThread {
                progress.dismiss()
                if (errOut != null) {
                    AlertDialog.Builder(act).setTitle("No se pudo crear el APK").setMessage(errOut).setPositiveButton("Cerrar", null).show()
                } else {
                    val b = AlertDialog.Builder(act)
                        .setTitle("APK listo")
                        .setMessage("Guardado en $whereOut.\n\nAl instalarlo, Android puede pedirte permiso para «instalar apps desconocidas» de este motor.")
                        .setNegativeButton("Cerrar", null)
                    if (uriOut != null) b.setPositiveButton("Instalar ahora") { _, _ -> install(act, uriOut) }
                    b.show()
                }
            }
        }.start()
    }

    private fun install(act: MainActivity, uri: Uri) {
        try {
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(uri, "application/vnd.android.package-archive")
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            act.startActivity(i)
        } catch (e: Exception) {
            act.toast("Abre el archivo desde la app Archivos > Descargas")
        }
    }
}
