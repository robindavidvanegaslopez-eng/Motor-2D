package com.motor2d.app

import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.LinearLayout
import com.motor2d.editor.Project
import com.motor2d.export.ApkExporter
import com.motor2d.export.ExportConfig
import com.motor2d.export.ExportKeys
import com.motor2d.export.isValidPackageName
import com.motor2d.export.suggestPackageName
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * «Exportar APK»: convierte el proyecto en una app instalable sin salir de Motor 2D.
 * Usa la propia app como plantilla, le mete el juego (assets/game/), cambia nombre y paquete y la firma.
 */
object ApkExportAction {
    const val GAME_DIR = "assets/game/"
    const val START_FILE = "assets/game/start.txt"

    private class Result(val fileName: String, val uri: Uri?, val path: String, val sizeBytes: Int)

    fun start(act: MainActivity, project: Project, startScene: String) {
        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(act.dp(20), act.dp(8), act.dp(20), 0)
        val nameF = act.input(project.name, "Nombre del juego")
        val pkgF = act.input(suggestPackageName(project.name), "com.tuestudio.mijuego")
        val verF = act.input("1.0", "Versión")
        box.addView(act.label("Nombre que verá el jugador", 12f, Ui.MUTED))
        box.addView(nameF, lp(Ui.MATCH, Ui.WRAP))
        box.addView(act.label("Identificador único de la app (solo minúsculas, números y _ separados por puntos)", 12f, Ui.MUTED),
            lp(Ui.WRAP, Ui.WRAP).also { it.topMargin = act.dp(10) })
        box.addView(pkgF, lp(Ui.MATCH, Ui.WRAP))
        box.addView(act.label("Versión", 12f, Ui.MUTED), lp(Ui.WRAP, Ui.WRAP).also { it.topMargin = act.dp(10) })
        box.addView(verF, lp(Ui.MATCH, Ui.WRAP))

        AlertDialog.Builder(act)
            .setTitle("Exportar a APK")
            .setView(box)
            .setPositiveButton("Crear APK") { _, _ ->
                val appName = nameF.text.toString().trim()
                val pkg = pkgF.text.toString().trim()
                val ver = verF.text.toString().trim().ifEmpty { "1.0" }
                when {
                    appName.isEmpty() -> act.toast("Escribe un nombre para el juego")
                    !pkg.isValidPackageName() -> act.toast("Identificador no válido. Ejemplo: com.miestudio.mijuego")
                    else -> run(act, project, startScene, appName, pkg, ver)
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun run(act: MainActivity, project: Project, startScene: String, appName: String, pkg: String, version: String) {
        val progress = AlertDialog.Builder(act)
            .setTitle("Creando APK…")
            .setMessage("Empaquetando y firmando. Puede tardar unos segundos.")
            .setCancelable(false)
            .show()
        Thread {
            var result: Result? = null
            var error: String? = null
            try {
                result = build(act, project, startScene, appName, pkg, version)
            } catch (e: Throwable) {
                error = (e.message ?: e.javaClass.simpleName)
            }
            val r = result
            val err = error
            act.runOnUiThread {
                progress.dismiss()
                if (r != null) done(act, r) else showError(act, err ?: "error desconocido")
            }
        }.start()
    }

    private fun build(act: MainActivity, project: Project, startScene: String, appName: String, pkg: String, version: String): Result {
        val extra = LinkedHashMap<String, ByteArray>()
        for (e in project.allFiles().entries) extra[GAME_DIR + e.key] = e.value
        extra[START_FILE] = startScene.toByteArray(Charsets.UTF_8)

        val pk8 = act.assets.open("export/key.pk8").use { it.readBytes() }
        val cert = act.assets.open("export/cert.der").use { it.readBytes() }
        val keys = ExportKeys.load(pk8, cert)
        val template = File(act.applicationInfo.sourceDir)
        val cfg = ExportConfig(pkg, appName, version, act.packageName, "Motor 2D")

        val buf = ByteArrayOutputStream(template.length().toInt() + 1024 * 1024)
        ApkExporter.export(template, buf, extra, cfg, keys.first, keys.second)
        val bytes = buf.toByteArray()

        val fileName = project.name.filter { it.isLetterOrDigit() || it == '_' || it == '-' }.ifEmpty { "juego" } + "-" + version.filter { it.isLetterOrDigit() || it == '.' } + ".apk"
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues()
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            values.put(MediaStore.MediaColumns.MIME_TYPE, "application/vnd.android.package-archive")
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            val uri = act.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("No se pudo crear el archivo en Descargas")
            val os = act.contentResolver.openOutputStream(uri) ?: throw IllegalStateException("No se pudo escribir en Descargas")
            os.use { it.write(bytes) }
            return Result(fileName, uri, "Descargas/$fileName", bytes.size)
        }
        @Suppress("DEPRECATION")
        val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        dir.mkdirs()
        val f = File(dir, fileName)
        f.writeBytes(bytes)
        return Result(fileName, Uri.fromFile(f), "Descargas/$fileName", bytes.size)
    }

    private fun done(act: MainActivity, r: Result) {
        val mb = String.format(java.util.Locale.US, "%.1f", r.sizeBytes / 1048576.0)
        AlertDialog.Builder(act)
            .setTitle("APK creado")
            .setMessage("Se guardó en " + r.path + " (" + mb + " MB).\n\nPara instalarlo pulsa «Instalar». Si Android lo pide, permite instalar apps desde Motor 2D.")
            .setPositiveButton("Instalar") { _, _ -> install(act, r) }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun install(act: MainActivity, r: Result) {
        val uri = r.uri
        if (uri == null) { act.toast("Búscalo en Descargas: " + r.fileName); return }
        try {
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(uri, "application/vnd.android.package-archive")
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            act.startActivity(i)
        } catch (e: Exception) {
            act.toast("No se pudo abrir el instalador. Abre el archivo desde Descargas.")
        }
    }

    private fun showError(act: MainActivity, msg: String) {
        AlertDialog.Builder(act)
            .setTitle("No se pudo crear el APK")
            .setMessage(msg)
            .setPositiveButton("Cerrar", null)
            .show()
    }
}
