package com.motor2d.engine

import com.motor2d.core.GdColor
import com.motor2d.core.Vec2
import com.motor2d.script.GlobalHost
import com.motor2d.script.HostObject
import com.motor2d.script.Interpreter
import com.motor2d.script.Lexer
import com.motor2d.script.NoSuch
import com.motor2d.script.Parser
import com.motor2d.script.ScriptClass
import com.motor2d.script.ScriptError
import com.motor2d.script.ScriptInstance

/** Acceso a los archivos del proyecto (scripts, escenas). */
interface ProjectFiles {
    fun readText(path: String): String?
}

interface LogSink {
    fun log(text: String, isError: Boolean)
}

class CameraView(val center: Vec2, val zoom: Double, val background: Int)

class World(val files: ProjectFiles?, val sink: LogSink?) : GlobalHost {
    val objects = ArrayList<GameObject>()
    val input = InputState()
    val interp = Interpreter(this)
    val physics = Physics()
    val timers = TimerSystem(this)

    var viewW = 720.0
    var viewH = 1280.0
    var playing = false
    var error: ScriptError? = null
    var sceneName = "main"
    var pendingScene: String? = null
    var stopRequested = false
    var time = 0.0
    var nextId = 1

    /** Funciones extra aportadas por la plataforma (vibrate, play_sound...). */
    val hostFunctions = HashMap<String, (List<Any?>) -> Any?>()

    private val inputHost = InputHost(this)
    private val timeHost = TimeHost(this)
    private val physicsHost = PhysicsHost(this)
    private val scriptCache = HashMap<String, ScriptClass>()
    private val pendingStart = ArrayList<GameObject>()
    private val toDestroy = ArrayList<GameObject>()
    private var acc = 0.0

    init {
        interp.out = { text -> sink?.log(text, text.startsWith("[error]")) }
    }

    // ---------- Objetos ----------
    fun addObject(o: GameObject): GameObject {
        if (o.id == 0) o.id = nextId++ else if (o.id >= nextId) nextId = o.id + 1
        o.world = this
        objects.add(o)
        if (playing) pendingStart.add(o)
        return o
    }

    fun findByName(name: String): GameObject? = objects.firstOrNull { it.name == name && !it.destroyed }
    fun findById(id: Int): GameObject? = objects.firstOrNull { it.id == id }
    fun findByTag(tag: String): List<GameObject> = objects.filter { it.tag == tag && !it.destroyed && it.isActiveInHierarchy() }

    fun destroy(o: GameObject) {
        if (o.destroyed) return
        o.destroyed = true
        toDestroy.add(o)
        for (c in ArrayList(o.children)) destroy(c)
    }

    private fun flushDestroyed() {
        if (toDestroy.isEmpty()) return
        for (o in toDestroy) {
            objects.remove(o)
            o.parent?.children?.remove(o)
            pendingStart.remove(o)
        }
        toDestroy.clear()
    }

    fun instantiate(src: GameObject, pos: Vec2?): GameObject {
        val clone = SceneIO.cloneSubtree(this, src)
        clone.active = true
        if (pos != null) clone.setWorldPosition(pos)
        return clone
    }

    // ---------- Cámara ----------
    fun camera(): CameraView {
        for (o in objects) {
            val cam = o.camera ?: continue
            if (!o.isActiveInHierarchy()) continue
            return CameraView(o.worldPosition(), cam.f("zoom").coerceAtLeast(0.05), cam.c("background"))
        }
        return CameraView(Vec2(viewW / 2, viewH / 2), 1.0, 0xFF1B1F2A.toInt())
    }

    fun screenToWorld(p: Vec2): Vec2 {
        val c = camera()
        return c.center + (p - Vec2(viewW / 2, viewH / 2)) / c.zoom
    }

    fun worldToScreen(p: Vec2): Vec2 {
        val c = camera()
        return (p - c.center) * c.zoom + Vec2(viewW / 2, viewH / 2)
    }

    // ---------- Scripts ----------
    fun getScriptClass(path: String): ScriptClass {
        scriptCache[path]?.let { return it }
        val text = files?.readText(path) ?: throw ScriptError("No se encontró el script '$path'", 0, path)
        val cls = Parser(Lexer(text, path).tokenize(), path).parseScript()
        scriptCache[path] = cls
        return cls
    }

    fun clearScriptCache() { scriptCache.clear() }

    private fun fail(e: ScriptError) {
        if (error == null) {
            error = e
            sink?.log(e.describe(), true)
        }
    }

    private fun failAny(e: Throwable, script: String) {
        val msg = when (e) {
            is ScriptError -> { fail(e); return }
            is StackOverflowError -> "Recursión demasiado profunda"
            else -> "Error interno: " + (e.message ?: e.javaClass.simpleName)
        }
        fail(ScriptError(msg, 0, script))
    }

    /** Llama a una función de los scripts de un objeto (la usan los temporizadores). */
    fun callFunction(o: GameObject, fn: String, args: List<Any?> = emptyList()) = callOn(o, fn, args)

    private fun callOn(o: GameObject, fn: String, args: List<Any?>) {
        for (sc in o.scripts) {
            val inst = sc.instance ?: continue
            if (sc.failed || !inst.hasFunc(fn)) continue
            try {
                inst.call(fn, args)
            } catch (e: Throwable) {
                sc.failed = true
                failAny(e, sc.path)
            }
            if (error != null) return
        }
    }

    private fun startObjects(list: List<GameObject>) {
        // 1) crear instancias y evaluar variables
        for (o in list) {
            if (o.destroyed) continue
            o.sprite?.resetAnimation()
            for (sc in o.scripts) {
                if (sc.instance != null || sc.path.isEmpty()) continue
                try {
                    val cls = getScriptClass(sc.path)
                    val inst = ScriptInstance(cls, interp, o)
                    inst.init(sc.exports)
                    sc.instance = inst
                } catch (e: Throwable) {
                    sc.failed = true
                    failAny(e, sc.path)
                    return
                }
            }
        }
        // 2) @onready
        for (o in list) {
            if (o.destroyed) continue
            for (sc in o.scripts) {
                val inst = sc.instance ?: continue
                try { inst.initOnReady() } catch (e: Throwable) { sc.failed = true; failAny(e, sc.path); return }
            }
        }
        // 3) _ready
        for (o in list) {
            if (o.destroyed) continue
            o.started = true
            callOn(o, "_ready", emptyList())
            if (error != null) return
        }
    }

    /** Pasa de modo edición a modo juego: crea los scripts y llama a _ready. */
    fun start() {
        playing = true
        error = null
        stopRequested = false
        acc = 0.0
        time = 0.0
        physics.reset()
        input.reset()
        timers.clear()
        interp.budget = 5_000_000
        pendingStart.clear()
        startObjects(ArrayList(objects))
    }

    fun update(dt: Double) {
        if (!playing || error != null) return
        interp.budget = 5_000_000
        if (pendingStart.isNotEmpty()) {
            val l = ArrayList(pendingStart); pendingStart.clear(); startObjects(l)
            if (error != null) return
        }
        acc += minOf(dt, 0.1)
        val fixed = 1.0 / 60.0
        var steps = 0
        while (acc >= fixed && steps < 5 && error == null) {
            fixedStep(fixed)
            acc -= fixed
            steps++
        }
        if (acc > fixed * 5) acc = 0.0
        if (error != null) return

        if (input.justPressed) dispatchTouched()
        val snapshot = ArrayList(objects)
        for (o in snapshot) {
            if (!o.isActiveInHierarchy()) continue
            callOn(o, "_process", listOf(dt))
            if (error != null) return
        }
        timers.update(dt)
        if (error != null) return
        for (o in snapshot) o.sprite?.advance(dt)
        flushDestroyed()
        input.endFrame()
        time += dt
        val ps = pendingScene
        if (ps != null) {
            pendingScene = null
            loadSceneNow(ps)
        }
    }

    private fun dispatchTouched() {
        val wp = screenToWorld(input.touchPos)
        val snapshot = ArrayList(objects)
        for (o in snapshot) {
            if (!o.isActiveInHierarchy()) continue
            if (o.scripts.none { it.instance?.hasFunc("_on_touched") == true }) continue
            if (o.containsPoint(wp)) callOn(o, "_on_touched", emptyList())
            if (error != null) return
        }
    }

    private fun fixedStep(dt: Double) {
        val snapshot = ArrayList(objects)
        for (o in snapshot) {
            if (!o.isActiveInHierarchy()) continue
            callOn(o, "_physics_process", listOf(dt))
            if (error != null) return
        }
        val ev = physics.step(objects, dt)
        if (ev.isEmpty()) return
        fun both(list: List<Pair<GameObject, GameObject>>, fn: String) {
            for ((a, b) in list) {
                if (a.destroyed || b.destroyed) continue
                callOn(a, fn, listOf(b))
                if (error != null) return
                callOn(b, fn, listOf(a))
                if (error != null) return
            }
        }
        both(ev.collisionEnter, "_on_collision_enter")
        both(ev.triggerEnter, "_on_trigger_enter")
        both(ev.collisionExit, "_on_collision_exit")
        both(ev.triggerExit, "_on_trigger_exit")
    }

    private fun loadSceneNow(name: String) {
        val text = files?.readText("scenes/$name.json")
        if (text == null) {
            fail(ScriptError("No existe la escena '$name'"))
            return
        }
        objects.clear(); pendingStart.clear(); toDestroy.clear()
        sceneName = name
        nextId = 1
        SceneIO.loadInto(this, SceneIO.parseScene(text), true)
        physics.reset()
        start()
    }

    // ---------- GlobalHost ----------
    override fun getGlobal(name: String): Any? = when (name) {
        "Input" -> inputHost
        "Time" -> timeHost
        "Physics" -> physicsHost
        "screen_size" -> Vec2(viewW, viewH)
        "screen_width" -> viewW
        "screen_height" -> viewH
        else -> NoSuch
    }

    override fun callGlobal(name: String, args: List<Any?>): Any? {
        when (name) {
            "get_object" -> return findByName(args.getOrNull(0)?.toString() ?: "")
            "find_objects_with_tag" -> return ArrayList<Any?>(findByTag(args.getOrNull(0)?.toString() ?: ""))
            "instantiate" -> {
                val a0 = args.getOrNull(0)
                val src = when (a0) {
                    is GameObject -> a0
                    else -> objects.firstOrNull { it.name == a0.toString() } ?: throw ScriptError("instantiate: no existe un objeto llamado '$a0'")
                }
                val pos = args.getOrNull(1)?.let { Coerce.toVec(it, "instantiate") }
                return instantiate(src, pos)
            }
            "destroy" -> { (args.getOrNull(0) as? GameObject)?.let { destroy(it) }; return null }
            "tween" -> {
                val t = args.getOrNull(0) as? GameObject ?: throw ScriptError("tween: el primer valor debe ser un objeto")
                timers.tween(t, args.getOrNull(1)?.toString() ?: "", args.getOrNull(2),
                    Coerce.toDouble(args.getOrNull(3) ?: 1.0, "tween"), args.getOrNull(4)?.toString() ?: "linear")
                return null
            }
            "cancel_timer" -> { timers.cancel((args.getOrNull(0) as? Long) ?: -1L); return null }
            "is_instance_valid" -> return (args.getOrNull(0) as? GameObject)?.let { !it.destroyed } ?: false
            "load_scene" -> { pendingScene = args.getOrNull(0)?.toString() ?: sceneName; return null }
            "reload_scene" -> { pendingScene = sceneName; return null }
            "quit", "stop_game" -> { stopRequested = true; return null }
            "screen_to_world" -> return screenToWorld(Coerce.toVec(args.getOrNull(0), name))
            "world_to_screen" -> return worldToScreen(Coerce.toVec(args.getOrNull(0), name))
        }
        val hf = hostFunctions[name]
        if (hf != null) return hf(args)
        return NoSuch
    }

    fun log(text: String, isError: Boolean = false) { sink?.log(text, isError) }
}

class TimeHost(private val w: World) : HostObject {
    override val typeName = "Time"
    override fun getProp(name: String): Any? = when (name) {
        "time" -> w.time
        else -> NoSuch
    }
    override fun setProp(name: String, value: Any?) = false
    override fun callMethod(name: String, args: List<Any?>): Any? = when (name) {
        "get_ticks_msec" -> (w.time * 1000.0).toLong()
        "get_time" -> w.time
        else -> NoSuch
    }
}

class PhysicsHost(private val w: World) : HostObject {
    override val typeName = "Physics"
    override fun getProp(name: String): Any? = when (name) {
        "gravity" -> w.physics.gravity
        else -> NoSuch
    }
    override fun setProp(name: String, value: Any?): Boolean {
        if (name == "gravity") { w.physics.gravity = Coerce.toVec(value, name); return true }
        return false
    }
    override fun callMethod(name: String, args: List<Any?>): Any? = NoSuch
}
