package com.motor2d.export

import java.io.ByteArrayInputStream
import java.security.KeyFactory
import java.security.PrivateKey
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.interfaces.RSAPrivateKey
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec

object ExportKeys {
    /** Carga la clave privada RSA (PKCS#8 DER) y el certificado X.509 (DER); comprueba que se corresponden. */
    fun load(pk8: ByteArray, certDer: ByteArray): Pair<PrivateKey, X509Certificate> {
        val key = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(pk8))
        val cert = CertificateFactory.getInstance("X.509").generateCertificate(ByteArrayInputStream(certDer)) as X509Certificate
        val pub = cert.publicKey
        if (key is RSAPrivateKey && pub is RSAPublicKey && key.modulus != pub.modulus)
            throw IllegalArgumentException("La clave privada no corresponde al certificado")
        return Pair(key, cert)
    }
}
