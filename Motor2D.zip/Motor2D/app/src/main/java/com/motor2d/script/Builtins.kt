package com.motor2d.script

import com.motor2d.core.Colors
import com.motor2d.core.GdColor
import com.motor2d.core.Vec2
import java.util.Locale
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

// ---------- Operadores ----------
object Ops {
    fun toDouble(ip: Interpreter, v: Any?): Double = when (v) {
        is Double -> v
        is Long -> v.toDouble()
        is Boolean -> if (v) 1.0 else 0.0
        else -> ip.fail("Se esperaba un número pero llegó ${Interpreter.typeName(v)}")
    }

    fun toLong(ip: Interpreter, v: Any?): Long = when (v) {
        is Long -> v
        is Double -> v.toLong()
        is Boolean -> if (v) 1L else 0L
        else -> ip.fail("Se esperaba un entero pero llegó ${Interpreter.typeName(v)}")
    }

    fun key(v: Any?): Any? = v

    fun equals(a: Any?, b: Any?): Boolean {
        if (a == null || b == null) return a == null && b == null
        if (a is Long && b is Double) return a.toDouble() == b
        if (a is Double && b is Long) return a == b.toDouble()
        if (a is List<*> && b is List<*>) {
            if (a.size != b.size) return false
            for (i in a.indices) if (!equals(a[i], b[i])) return false
            return true
        }
        if (a is HostObject || b is HostObject) return a === b
        return a == b
    }

    private fun isNum(v: Any?) = v is Long || v is Double

    fun binary(ip: Interpreter, op: String, l: Any?, r: Any?): Any? {
        when (op) {
            "==" -> return equals(l, r)
            "!=" -> return !equals(l, r)
            "in" -> return contains(ip, r, l)
            "not in" -> return !contains(ip, r, l)
            "+" -> {
                if (l is Long && r is Long) return l + r
                if (isNum(l) && isNum(r)) return toDouble(ip, l) + toDouble(ip, r)
                if (l is String && r is String) return l + r
                if (l is Vec2 && r is Vec2) return l + r
                if (l is List<*> && r is List<*>) return ArrayList<Any?>(l).also { it.addAll(r) }
                if (l is String || r is String) ip.fail("No se puede sumar texto con ${Interpreter.typeName(if (l is String) r else l)}: usa str(valor)")
                ip.fail("No se puede sumar ${Interpreter.typeName(l)} + ${Interpreter.typeName(r)}")
            }
            "-" -> {
                if (l is Long && r is Long) return l - r
                if (isNum(l) && isNum(r)) return toDouble(ip, l) - toDouble(ip, r)
                if (l is Vec2 && r is Vec2) return l - r
                ip.fail("No se puede restar ${Interpreter.typeName(l)} - ${Interpreter.typeName(r)}")
            }
            "*" -> {
                if (l is Long && r is Long) return l * r
                if (isNum(l) && isNum(r)) return toDouble(ip, l) * toDouble(ip, r)
                if (l is Vec2 && isNum(r)) return l * toDouble(ip, r)
                if (isNum(l) && r is Vec2) return r * toDouble(ip, l)
                if (l is Vec2 && r is Vec2) return l * r
                ip.fail("No se puede multiplicar ${Interpreter.typeName(l)} * ${Interpreter.typeName(r)}")
            }
            "/" -> {
                if (l is Long && r is Long) {
                    if (r == 0L) ip.fail("División entre cero")
                    return l / r
                }
                if (isNum(l) && isNum(r)) return toDouble(ip, l) / toDouble(ip, r)
                if (l is Vec2 && isNum(r)) return l / toDouble(ip, r)
                if (l is Vec2 && r is Vec2) return l / r
                ip.fail("No se puede dividir ${Interpreter.typeName(l)} / ${Interpreter.typeName(r)}")
            }
            "%" -> {
                if (l is String) return percentFormat(ip, l, r)
                if (l is Long && r is Long) {
                    if (r == 0L) ip.fail("División entre cero")
                    return l % r
                }
                if (isNum(l) && isNum(r)) return toDouble(ip, l) % toDouble(ip, r)
                ip.fail("No se puede calcular ${Interpreter.typeName(l)} % ${Interpreter.typeName(r)}")
            }
            "**" -> {
                if (l is Long && r is Long && r >= 0) {
                    var res = 1L
                    repeat(r.toInt().coerceAtMost(64)) { res *= l }
                    return res
                }
                return toDouble(ip, l).pow(toDouble(ip, r))
            }
            "<", ">", "<=", ">=" -> {
                val c: Int = if (isNum(l) && isNum(r)) {
                    if (l is Long && r is Long) l.compareTo(r) else toDouble(ip, l).compareTo(toDouble(ip, r))
                } else if (l is String && r is String) l.compareTo(r)
                else ip.fail("No se puede comparar ${Interpreter.typeName(l)} $op ${Interpreter.typeName(r)}")
                return when (op) { "<" -> c < 0; ">" -> c > 0; "<=" -> c <= 0; else -> c >= 0 }
            }
            "&" -> return toLong(ip, l) and toLong(ip, r)
            "|" -> return toLong(ip, l) or toLong(ip, r)
            "^" -> return toLong(ip, l) xor toLong(ip, r)
            "<<" -> return toLong(ip, l) shl toLong(ip, r).toInt()
            ">>" -> return toLong(ip, l) shr toLong(ip, r).toInt()
        }
        ip.fail("Operador desconocido '$op'")
    }

    private fun contains(ip: Interpreter, container: Any?, x: Any?): Boolean = when (container) {
        is List<*> -> container.any { equals(it, x) }
        is Map<*, *> -> container.containsKey(x)
        is String -> if (x is String) container.contains(x) else ip.fail("'in' con texto necesita otro texto")
        else -> ip.fail("'in' no funciona con ${Interpreter.typeName(container)}")
    }

    fun index(ip: Interpreter, base: Any?, idx: Any?): Any? {
        when (base) {
            is List<*> -> {
                var i = toLong(ip, idx).toInt()
                if (i < 0) i += base.size
                if (i < 0 || i >= base.size) ip.fail("Índice $i fuera de rango (tamaño ${base.size})")
                return base[i]
            }
            is Map<*, *> -> return base[idx]
            is String -> {
                var i = toLong(ip, idx).toInt()
                if (i < 0) i += base.length
                if (i < 0 || i >= base.length) ip.fail("Índice $i fuera de rango (tamaño ${base.length})")
                return base[i].toString()
            }
            is Vec2 -> return when (toLong(ip, idx).toInt()) {
                0 -> base.x; 1 -> base.y
                else -> ip.fail("Índice de Vector2 fuera de rango")
            }
            null -> ip.fail("Se intentó usar [] sobre un valor nulo (null)")
            else -> ip.fail("No se puede usar [] sobre ${Interpreter.typeName(base)}")
        }
    }

    /** "texto %d %s" % valor  (formato de GDScript). */
    fun percentFormat(ip: Interpreter, fmt: String, arg: Any?): String {
        val args: List<Any?> = if (arg is List<*>) arg else listOf(arg)
        val re = Regex("%([-+ 0]*)(\\d*)(?:\\.(\\d+))?([dsfxXic%])")
        var ai = 0
        return re.replace(fmt) { m ->
            val flags = m.groupValues[1]; val width = m.groupValues[2]; val prec = m.groupValues[3]; val conv = m.groupValues[4]
            if (conv == "%") return@replace "%"
            if (ai >= args.size) ip.fail("Faltan valores para el formato '%'")
            val v = args[ai++]
            when (conv) {
                "d", "i" -> String.format(Locale.US, "%" + flags + width + "d", toLong(ip, v))
                "f" -> String.format(Locale.US, "%" + flags + width + "." + (if (prec.isEmpty()) "6" else prec) + "f", toDouble(ip, v))
                "x" -> String.format(Locale.US, "%" + flags + width + "x", toLong(ip, v))
                "X" -> String.format(Locale.US, "%" + flags + width + "X", toLong(ip, v))
                "c" -> toLong(ip, v).toInt().toChar().toString()
                else -> String.format(Locale.US, "%" + flags.replace("0", "") + width + "s", Fmt.str(v))
            }
        }
    }
}

// ---------- Vector2.* y Color.* ----------
object VectorStatics : HostObject {
    override val typeName = "Vector2"
    override fun getProp(name: String): Any? = when (name) {
        "ZERO" -> Vec2.ZERO; "ONE" -> Vec2.ONE; "UP" -> Vec2.UP; "DOWN" -> Vec2.DOWN
        "LEFT" -> Vec2.LEFT; "RIGHT" -> Vec2.RIGHT
        else -> NoSuch
    }
    override fun setProp(name: String, value: Any?) = false
    override fun callMethod(name: String, args: List<Any?>): Any? = when (name) {
        "from_angle" -> Vec2.fromAngle((args[0] as Number).toDouble())
        else -> NoSuch
    }
}

object ColorStatics : HostObject {
    override val typeName = "Color"
    override fun getProp(name: String): Any? {
        val c = Colors.parse(name.lowercase())
        return if (c != null && name == name.uppercase()) GdColor.fromArgb(c) else NoSuch
    }
    override fun setProp(name: String, value: Any?) = false
    override fun callMethod(name: String, args: List<Any?>): Any? = when (name) {
        "html" -> Colors.parse(args[0].toString())?.let { GdColor.fromArgb(it) } ?: GdColor(1.0, 1.0, 1.0)
        else -> NoSuch
    }
}

// ---------- Funciones globales ----------
object Builtins {
    private fun num(ip: Interpreter, a: List<Any?>, i: Int): Double {
        if (i >= a.size) ip.fail("Faltan argumentos")
        return Ops.toDouble(ip, a[i])
    }

    private fun need(ip: Interpreter, name: String, a: List<Any?>, n: Int) {
        if (a.size < n) ip.fail("'$name' necesita al menos $n argumento(s)")
    }

    private fun allLong(a: List<Any?>) = a.all { it is Long }

    fun call(ip: Interpreter, name: String, a: List<Any?>): Any? {
        when (name) {
            "print" -> { ip.out(a.joinToString("") { Fmt.str(it) }); return null }
            "prints" -> { ip.out(a.joinToString(" ") { Fmt.str(it) }); return null }
            "push_error" -> { ip.out("[error] " + a.joinToString("") { Fmt.str(it) }); return null }
            "push_warning" -> { ip.out("[aviso] " + a.joinToString("") { Fmt.str(it) }); return null }
            "str" -> return a.joinToString("") { Fmt.str(it) }
            "assert" -> {
                need(ip, name, a, 1)
                if (!Interpreter.truthy(a[0])) ip.fail("assert falló" + if (a.size > 1) ": " + Fmt.str(a[1]) else "")
                return null
            }
            "int" -> {
                need(ip, name, a, 1)
                return when (val v = a[0]) {
                    is Long -> v
                    is Double -> v.toLong()
                    is Boolean -> if (v) 1L else 0L
                    is String -> v.trim().toLongOrNull() ?: v.trim().toDoubleOrNull()?.toLong() ?: 0L
                    else -> ip.fail("No se puede convertir ${Interpreter.typeName(v)} a int")
                }
            }
            "float" -> {
                need(ip, name, a, 1)
                return when (val v = a[0]) {
                    is Long -> v.toDouble()
                    is Double -> v
                    is Boolean -> if (v) 1.0 else 0.0
                    is String -> v.trim().toDoubleOrNull() ?: 0.0
                    else -> ip.fail("No se puede convertir ${Interpreter.typeName(v)} a float")
                }
            }
            "bool" -> { need(ip, name, a, 1); return Interpreter.truthy(a[0]) }
            "abs" -> {
                need(ip, name, a, 1)
                return when (val v = a[0]) {
                    is Long -> abs(v); is Double -> abs(v); is Vec2 -> v.abs()
                    else -> ip.fail("abs() necesita un número")
                }
            }
            "absf" -> return abs(num(ip, a, 0))
            "absi" -> return abs(Ops.toLong(ip, a.getOrNull(0)))
            "sign", "signf", "signi" -> {
                need(ip, name, a, 1)
                val v = a[0]
                return if (v is Long || name == "signi") Math.signum(Ops.toDouble(ip, v)).toLong() else Math.signum(num(ip, a, 0))
            }
            "min", "max" -> {
                val xs = if (a.size == 1 && a[0] is List<*>) (a[0] as List<*>) else a
                if (xs.isEmpty()) ip.fail("$name() necesita valores")
                var best = xs[0]
                for (x in xs.drop(1)) {
                    val d = Ops.toDouble(ip, x) - Ops.toDouble(ip, best)
                    if ((name == "min" && d < 0) || (name == "max" && d > 0)) best = x
                }
                return if (allLong(xs)) best else Ops.toDouble(ip, best)
            }
            "clamp" -> {
                need(ip, name, a, 3)
                val v = Ops.toDouble(ip, a[0]); val lo = Ops.toDouble(ip, a[1]); val hi = Ops.toDouble(ip, a[2])
                val r = if (v < lo) lo else if (v > hi) hi else v
                return if (allLong(a.take(3))) r.toLong() else r
            }
            "clampf" -> return num(ip, a, 0).coerceIn(num(ip, a, 1), num(ip, a, 2))
            "clampi" -> return Ops.toLong(ip, a[0]).coerceIn(Ops.toLong(ip, a[1]), Ops.toLong(ip, a[2]))
            "lerp" -> {
                need(ip, name, a, 3)
                val t = Ops.toDouble(ip, a[2])
                val x = a[0]; val y = a[1]
                if (x is Vec2 && y is Vec2) return x.lerp(y, t)
                if (x is GdColor && y is GdColor)
                    return GdColor(x.r + (y.r - x.r) * t, x.g + (y.g - x.g) * t, x.b + (y.b - x.b) * t, x.a + (y.a - x.a) * t)
                val p = Ops.toDouble(ip, x)
                return p + (Ops.toDouble(ip, y) - p) * t
            }
            "lerpf" -> return num(ip, a, 0) + (num(ip, a, 1) - num(ip, a, 0)) * num(ip, a, 2)
            "inverse_lerp" -> { val f = num(ip, a, 0); val t = num(ip, a, 1); return if (t == f) 0.0 else (num(ip, a, 2) - f) / (t - f) }
            "remap" -> {
                val v = num(ip, a, 0); val i0 = num(ip, a, 1); val i1 = num(ip, a, 2); val o0 = num(ip, a, 3); val o1 = num(ip, a, 4)
                return if (i1 == i0) o0 else o0 + (o1 - o0) * ((v - i0) / (i1 - i0))
            }
            "smoothstep" -> {
                val f = num(ip, a, 0); val t = num(ip, a, 1); val x = num(ip, a, 2)
                if (f == t) return 0.0
                val s = ((x - f) / (t - f)).coerceIn(0.0, 1.0)
                return s * s * (3 - 2 * s)
            }
            "move_toward" -> {
                if (a.size >= 3 && a[0] is Vec2) return (a[0] as Vec2).moveToward(a[1] as Vec2, num(ip, a, 2))
                val f = num(ip, a, 0); val t = num(ip, a, 1); val d = num(ip, a, 2)
                return if (abs(t - f) <= d) t else f + Math.signum(t - f) * d
            }
            "sqrt" -> return sqrt(num(ip, a, 0))
            "pow" -> return num(ip, a, 0).pow(num(ip, a, 1))
            "exp" -> return exp(num(ip, a, 0))
            "log" -> return ln(num(ip, a, 0))
            "sin" -> return sin(num(ip, a, 0))
            "cos" -> return cos(num(ip, a, 0))
            "tan" -> return tan(num(ip, a, 0))
            "asin" -> return asin(num(ip, a, 0))
            "acos" -> return acos(num(ip, a, 0))
            "atan" -> return atan(num(ip, a, 0))
            "atan2" -> return atan2(num(ip, a, 0), num(ip, a, 1))
            "floor" -> return floor(num(ip, a, 0))
            "ceil" -> return ceil(num(ip, a, 0))
            "round" -> return Math.floor(num(ip, a, 0) + 0.5)
            "floori" -> return floor(num(ip, a, 0)).toLong()
            "ceili" -> return ceil(num(ip, a, 0)).toLong()
            "roundi" -> return Math.floor(num(ip, a, 0) + 0.5).toLong()
            "fmod" -> return num(ip, a, 0) % num(ip, a, 1)
            "fposmod" -> { val b = num(ip, a, 1); val r = num(ip, a, 0) % b; return if (r < 0) r + b else r }
            "posmod" -> return Math.floorMod(Ops.toLong(ip, a[0]), Ops.toLong(ip, a[1]))
            "snapped" -> { val s = num(ip, a, 1); return if (s == 0.0) num(ip, a, 0) else Math.floor(num(ip, a, 0) / s + 0.5) * s }
            "wrapf" -> {
                val v = num(ip, a, 0); val lo = num(ip, a, 1); val hi = num(ip, a, 2); val r = hi - lo
                if (r == 0.0) return lo
                return v - r * floor((v - lo) / r)
            }
            "wrapi" -> {
                val v = Ops.toLong(ip, a[0]); val lo = Ops.toLong(ip, a[1]); val hi = Ops.toLong(ip, a[2]); val r = hi - lo
                if (r == 0L) return lo
                return lo + Math.floorMod(v - lo, r)
            }
            "deg_to_rad" -> return Math.toRadians(num(ip, a, 0))
            "rad_to_deg" -> return Math.toDegrees(num(ip, a, 0))
            "is_equal_approx" -> return abs(num(ip, a, 0) - num(ip, a, 1)) <= 1e-5 * maxOf(1.0, abs(num(ip, a, 0)))
            "is_zero_approx" -> return abs(num(ip, a, 0)) < 1e-5
            "randf" -> return ip.rng.nextDouble()
            "randi" -> return ip.rng.nextInt(Int.MAX_VALUE).toLong()
            "randf_range" -> { val lo = num(ip, a, 0); val hi = num(ip, a, 1); return lo + ip.rng.nextDouble() * (hi - lo) }
            "randi_range" -> {
                val lo = Ops.toLong(ip, a[0]); val hi = Ops.toLong(ip, a[1])
                if (hi < lo) return lo
                return lo + (ip.rng.nextDouble() * (hi - lo + 1)).toLong()
            }
            "randomize" -> { ip.rng = java.util.Random(); return null }
            "seed" -> { ip.rng = java.util.Random(Ops.toLong(ip, a[0])); return null }
            "range" -> {
                val out = ArrayList<Any?>()
                val start: Long; val end: Long; var step = 1L
                when (a.size) {
                    1 -> { start = 0; end = Ops.toLong(ip, a[0]) }
                    2 -> { start = Ops.toLong(ip, a[0]); end = Ops.toLong(ip, a[1]) }
                    3 -> { start = Ops.toLong(ip, a[0]); end = Ops.toLong(ip, a[1]); step = Ops.toLong(ip, a[2]) }
                    else -> ip.fail("range() recibe de 1 a 3 argumentos")
                }
                if (step == 0L) ip.fail("range(): el paso no puede ser 0")
                if ((end - start) / step > 1_000_000) ip.fail("range(): demasiados elementos")
                var x = start
                if (step > 0) while (x < end) { out.add(x); x += step } else while (x > end) { out.add(x); x += step }
                return out
            }
            "len" -> {
                need(ip, name, a, 1)
                return when (val v = a[0]) {
                    is String -> v.length.toLong(); is List<*> -> v.size.toLong(); is Map<*, *> -> v.size.toLong()
                    else -> ip.fail("len() no funciona con ${Interpreter.typeName(v)}")
                }
            }
            "Vector2" -> {
                if (a.isEmpty()) return Vec2.ZERO
                if (a.size == 1 && a[0] is Vec2) return a[0]
                if (a.size != 2) ip.fail("Vector2 necesita 2 números: Vector2(x, y)")
                return Vec2(num(ip, a, 0), num(ip, a, 1))
            }
            "Color" -> {
                if (a.isEmpty()) return GdColor(1.0, 1.0, 1.0)
                val f = a[0]
                if (f is String) {
                    val c = Colors.parse(f) ?: ip.fail("Color desconocido '$f' (usa un nombre como \"red\" o \"#ff8800\")")
                    val g = GdColor.fromArgb(c)
                    return if (a.size > 1) g.copy(a = num(ip, a, 1)) else g
                }
                if (f is GdColor) return if (a.size > 1) f.copy(a = num(ip, a, 1)) else f
                if (a.size < 3) ip.fail("Color necesita r, g, b (valores de 0 a 1)")
                return GdColor(num(ip, a, 0), num(ip, a, 1), num(ip, a, 2), if (a.size > 3) num(ip, a, 3) else 1.0)
            }
            "typeof_name" -> return Interpreter.typeName(a.getOrNull(0))
        }
        return NoSuch
    }
}

// ---------- Métodos de tipos básicos ----------
object Methods {
    private fun d(ip: Interpreter, a: List<Any?>, i: Int): Double {
        if (i >= a.size) ip.fail("Faltan argumentos")
        return Ops.toDouble(ip, a[i])
    }

    private fun v(ip: Interpreter, a: List<Any?>, i: Int): Vec2 =
        a.getOrNull(i) as? Vec2 ?: ip.fail("Se esperaba un Vector2")

    fun vec2(ip: Interpreter, s: Vec2, name: String, a: List<Any?>): Any? = when (name) {
        "length" -> s.length()
        "length_squared" -> s.lengthSquared()
        "normalized" -> s.normalized()
        "dot" -> s.dot(v(ip, a, 0))
        "cross" -> s.cross(v(ip, a, 0))
        "distance_to" -> s.distanceTo(v(ip, a, 0))
        "distance_squared_to" -> (s - v(ip, a, 0)).lengthSquared()
        "direction_to" -> s.directionTo(v(ip, a, 0))
        "angle" -> s.angle()
        "angle_to" -> atan2(s.cross(v(ip, a, 0)), s.dot(v(ip, a, 0)))
        "angle_to_point" -> (v(ip, a, 0) - s).angle()
        "rotated" -> s.rotated(d(ip, a, 0))
        "lerp" -> s.lerp(v(ip, a, 0), d(ip, a, 1))
        "move_toward" -> s.moveToward(v(ip, a, 0), d(ip, a, 1))
        "limit_length" -> s.limitLength(if (a.isEmpty()) 1.0 else d(ip, a, 0))
        "abs" -> s.abs()
        "orthogonal" -> s.perp()
        "is_zero_approx" -> s.length() < 1e-5
        "floor" -> Vec2(floor(s.x), floor(s.y))
        "round" -> Vec2(Math.floor(s.x + 0.5), Math.floor(s.y + 0.5))
        "project" -> { val b = v(ip, a, 0); val l = b.lengthSquared(); if (l == 0.0) Vec2.ZERO else b * (s.dot(b) / l) }
        "reflect" -> { val n = v(ip, a, 0).normalized(); n * (2.0 * n.dot(s)) - s }
        "bounce" -> { val n = v(ip, a, 0).normalized(); s - n * (2.0 * n.dot(s)) }
        "slide" -> { val n = v(ip, a, 0).normalized(); s - n * n.dot(s) }
        "snapped" -> { val st = v(ip, a, 0); Vec2(if (st.x == 0.0) s.x else Math.floor(s.x / st.x + 0.5) * st.x, if (st.y == 0.0) s.y else Math.floor(s.y / st.y + 0.5) * st.y) }
        else -> NoSuch
    }

    fun string(ip: Interpreter, s: String, name: String, a: List<Any?>): Any? = when (name) {
        "length" -> s.length.toLong()
        "to_upper" -> s.uppercase()
        "to_lower" -> s.lowercase()
        "capitalize" -> s.replaceFirstChar { it.uppercase() }
        "begins_with" -> s.startsWith(a[0].toString())
        "ends_with" -> s.endsWith(a[0].toString())
        "contains" -> s.contains(a[0].toString())
        "find" -> s.indexOf(a[0].toString()).toLong()
        "replace" -> s.replace(a[0].toString(), a[1].toString())
        "split" -> {
            val sep = if (a.isEmpty()) " " else a[0].toString()
            if (sep.isEmpty()) s.map { it.toString() }.toMutableList<Any?>() else s.split(sep).toMutableList<Any?>()
        }
        "substr" -> {
            val from = Ops.toLong(ip, a[0]).toInt().coerceIn(0, s.length)
            val len = if (a.size > 1) Ops.toLong(ip, a[1]).toInt() else s.length
            s.substring(from, (from + len).coerceIn(from, s.length))
        }
        "left" -> s.take(Ops.toLong(ip, a[0]).toInt().coerceAtLeast(0))
        "right" -> s.takeLast(Ops.toLong(ip, a[0]).toInt().coerceAtLeast(0))
        "strip_edges" -> s.trim()
        "is_empty" -> s.isEmpty()
        "to_int" -> s.trim().toLongOrNull() ?: 0L
        "to_float" -> s.trim().toDoubleOrNull() ?: 0.0
        "pad_zeros" -> s.padStart(Ops.toLong(ip, a[0]).toInt(), '0')
        "join" -> (a[0] as? List<*> ?: ip.fail("join() necesita un Array")).joinToString(s) { Fmt.str(it) }
        else -> NoSuch
    }

    fun list(ip: Interpreter, l: MutableList<Any?>, name: String, a: List<Any?>): Any? = when (name) {
        "append", "push_back" -> { l.add(a[0]); null }
        "push_front" -> { l.add(0, a[0]); null }
        "append_array" -> { l.addAll(a[0] as? List<*> ?: ip.fail("append_array necesita un Array")); null }
        "pop_back" -> if (l.isEmpty()) null else l.removeAt(l.size - 1)
        "pop_front" -> if (l.isEmpty()) null else l.removeAt(0)
        "pop_at" -> {
            var i = Ops.toLong(ip, a[0]).toInt(); if (i < 0) i += l.size
            if (i < 0 || i >= l.size) null else l.removeAt(i)
        }
        "remove_at" -> {
            var i = Ops.toLong(ip, a[0]).toInt(); if (i < 0) i += l.size
            if (i < 0 || i >= l.size) ip.fail("Índice fuera de rango")
            l.removeAt(i); null
        }
        "insert" -> { l.add(Ops.toLong(ip, a[0]).toInt().coerceIn(0, l.size), a[1]); null }
        "size" -> l.size.toLong()
        "clear" -> { l.clear(); null }
        "is_empty" -> l.isEmpty()
        "has" -> l.any { Ops.equals(it, a[0]) }
        "find" -> l.indexOfFirst { Ops.equals(it, a[0]) }.toLong()
        "count" -> l.count { Ops.equals(it, a[0]) }.toLong()
        "erase" -> { val i = l.indexOfFirst { Ops.equals(it, a[0]) }; if (i >= 0) l.removeAt(i); null }
        "reverse" -> { l.reverse(); null }
        "shuffle" -> { java.util.Collections.shuffle(l, ip.rng); null }
        "back" -> l.lastOrNull()
        "front" -> l.firstOrNull()
        "pick_random" -> if (l.isEmpty()) null else l[ip.rng.nextInt(l.size)]
        "duplicate" -> ArrayList(l)
        "slice" -> {
            val from = Ops.toLong(ip, a[0]).toInt().coerceIn(0, l.size)
            val to = (if (a.size > 1) Ops.toLong(ip, a[1]).toInt() else l.size).coerceIn(from, l.size)
            ArrayList(l.subList(from, to))
        }
        "min" -> l.minWithOrNull { x, y -> Ops.toDouble(ip, x).compareTo(Ops.toDouble(ip, y)) }
        "max" -> l.maxWithOrNull { x, y -> Ops.toDouble(ip, x).compareTo(Ops.toDouble(ip, y)) }
        "sort" -> {
            try {
                l.sortWith { x, y ->
                    if (x is String && y is String) x.compareTo(y) else Ops.toDouble(ip, x).compareTo(Ops.toDouble(ip, y))
                }
            } catch (e: ScriptError) { throw e }
            null
        }
        else -> NoSuch
    }

    fun map(ip: Interpreter, m: MutableMap<Any?, Any?>, name: String, a: List<Any?>): Any? = when (name) {
        "keys" -> ArrayList<Any?>(m.keys)
        "values" -> ArrayList<Any?>(m.values)
        "has" -> m.containsKey(a[0])
        "erase" -> m.remove(a[0]) != null
        "get" -> if (m.containsKey(a[0])) m[a[0]] else a.getOrNull(1)
        "size" -> m.size.toLong()
        "clear" -> { m.clear(); null }
        "is_empty" -> m.isEmpty()
        "duplicate" -> LinkedHashMap(m)
        "merge" -> {
            val o = a[0] as? Map<*, *> ?: ip.fail("merge() necesita un Dictionary")
            val over = a.size > 1 && Interpreter.truthy(a[1])
            for ((k, x) in o) if (over || !m.containsKey(k)) m[k] = x
            null
        }
        else -> NoSuch
    }
}
