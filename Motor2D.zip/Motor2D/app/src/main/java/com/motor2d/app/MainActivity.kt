package com.motor2d.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.KeyEvent
import android.widget.FrameLayout
import android.widget.ScrollView
import android.widget.TextView
import com.motor2d.editor.ProjectStore
import java.io.File

/** Única actividad de la app: cambia entre la lista de proyectos y el editor. */
class MainActivity : Activity() {

    private lateinit var store: ProjectStore
    private lateinit var holder: FrameLayout
    private var screen: Screen? = null
    private var imageCallback: ((String, ByteArray) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ProjectStore(File(filesDir, "projects"))
        holder = FrameLayout(this)
        holder.setBackgroundColor(Ui.BG)
        setContentView(holder)
        showProjects()
    }

    private fun show(s: Screen) {
        holder.removeAllViews()
        screen = s
        holder.addView(s.view, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
    }

    private fun showProjects() {
        show(ProjectListScreen(this, store) { name -> openProject(name) })
    }

    private fun openProject(name: String) {
        val p = store.open(name)
        if (p == null) {
            toast("No se encontró el proyecto")
            showProjects()
            return
        }
        show(EditorScreen(this, p) { showProjects() })
    }

    // ---------- Elegir imagen de la galería ----------
    fun pickImage(onDone: (String, ByteArray) -> Unit) {
        imageCallback = onDone
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = "image/*"
        i.addCategory(Intent.CATEGORY_OPENABLE)
        try {
            startActivityForResult(Intent.createChooser(i, "Elegir imagen"), REQ_IMAGE)
        } catch (e: Exception) {
            imageCallback = null
            toast("No se pudo abrir la galería")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_IMAGE) return
        val cb = imageCallback
        imageCallback = null
        val uri: Uri? = data?.data
        if (resultCode != RESULT_OK || uri == null || cb == null) return
        try {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
            if (bytes == null) { toast("No se pudo leer la imagen"); return }
            var name = "imagen.png"
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) c.getString(idx)?.let { name = it }
                }
            }
            cb(name, bytes)
        } catch (e: Exception) {
            toast("No se pudo importar la imagen")
        }
    }

    fun showHelp() {
        val t = TextView(this)
        t.text = HelpText.TEXT
        t.typeface = Typeface.MONOSPACE
        t.textSize = 12f
        t.setTextColor(Ui.TEXT)
        t.setPadding(dp(16), dp(8), dp(16), dp(8))
        val sv = ScrollView(this)
        sv.addView(t)
        AlertDialog.Builder(this).setTitle("Ayuda de scripts").setView(sv).setPositiveButton("Cerrar", null).show()
    }

    // ---------- Ciclo de vida y teclas ----------
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (screen?.onBack() == true) return
        @Suppress("DEPRECATION")
        super.onBackPressed()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (screen?.onKey(keyCode, true) == true) return true
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (screen?.onKey(keyCode, false) == true) return true
        return super.onKeyUp(keyCode, event)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        screen?.onConfigurationChanged()
    }

    override fun onPause() {
        screen?.onPause()
        super.onPause()
    }

    companion object {
        private const val REQ_IMAGE = 4021
    }
}
