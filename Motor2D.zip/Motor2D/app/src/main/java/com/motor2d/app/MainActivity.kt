package com.motor2d.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.KeyEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.ScrollView
import android.widget.TextView
import com.motor2d.editor.Project
import com.motor2d.editor.ProjectStore
import java.io.File

/** Única actividad de la app: cambia entre la lista de proyectos y el editor. */
class MainActivity : Activity() {

    private lateinit var store: ProjectStore
    private lateinit var holder: FrameLayout
    private var screen: Screen? = null
    private var isGame = false

    /** Carpeta del proyecto abierto en el editor y su escena actual, para el exportador. */
    fun exportProject(project: com.motor2d.editor.Project, scene: String) = ApkExportAction.start(this, project, scene)
    private var imageCallback: ((String, ByteArray) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ProjectStore(File(filesDir, "projects"))
        holder = FrameLayout(this)
        holder.setBackgroundColor(Ui.BG)
        setContentView(holder)
        if (!bootGame()) showProjects()
    }

    /** Si este APK lleva un juego dentro (assets/game), lo abre directamente en vez del editor. */
    private fun bootGame(): Boolean {
        val has = try { (assets.list("game") ?: emptyArray<String>()).isNotEmpty() } catch (e: Exception) { false }
        if (!has) return false
        return try {
            val dir = File(filesDir, "game_runtime")
            dir.deleteRecursively()
            copyAsset("game", dir)
            val start = try { assets.open("game/start.txt").use { String(it.readBytes(), Charsets.UTF_8).trim() } } catch (e: Exception) { "" }
            val project = com.motor2d.editor.Project(dir)
            window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
                android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
            isGame = true
            show(GameScreen(this, project, start))
            true
        } catch (e: Exception) {
            toast("No se pudo abrir el juego: " + (e.message ?: ""))
            false
        }
    }

    private fun copyAsset(path: String, target: File) {
        val children = assets.list(path) ?: emptyArray<String>()
        if (children.isEmpty()) {
            target.parentFile?.mkdirs()
            assets.open(path).use { input -> target.outputStream().use { out -> input.copyTo(out) } }
        } else {
            target.mkdirs()
            for (c in children) copyAsset("$path/$c", File(target, c))
        }
    }

    private fun show(s: Screen) {
        holder.removeAllViews()
        screen = s
        holder.addView(s.view, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
    }

    private fun showProjects() {
        show(ProjectListScreen(this, store) { name -> openProject(name) })
    }

    private fun openProject(name: String) {
        val p = store.open(name)
        if (p == null) {
            toast("No se encontró el proyecto")
            showProjects()
            return
        }
        show(EditorScreen(this, p) { showProjects() })
    }

    // ---------- Elegir imagen de la galería ----------
    fun pickImage(onDone: (String, ByteArray) -> Unit) {
        imageCallback = onDone
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = "image/*"
        i.addCategory(Intent.CATEGORY_OPENABLE)
        try {
            startActivityForResult(Intent.createChooser(i, "Elegir imagen"), REQ_IMAGE)
        } catch (e: Exception) {
            imageCallback = null
            toast("No se pudo abrir la galería")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_IMAGE) return
        val cb = imageCallback
        imageCallback = null
        val uri: Uri? = data?.data
        if (resultCode != RESULT_OK || uri == null || cb == null) return
        try {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
            if (bytes == null) { toast("No se pudo leer la imagen"); return }
            var name = "imagen.png"
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) c.getString(idx)?.let { name = it }
                }
            }
            cb(name, bytes)
        } catch (e: Exception) {
            toast("No se pudo importar la imagen")
        }
    }

    fun showHelp() {
        val t = TextView(this)
        t.text = HelpText.TEXT
        t.typeface = Typeface.MONOSPACE
        t.textSize = 12f
        t.setTextColor(Ui.TEXT)
        t.setPadding(dp(16), dp(8), dp(16), dp(8))
        val sv = ScrollView(this)
        sv.addView(t)
        AlertDialog.Builder(this).setTitle("Ayuda de scripts").setView(sv).setPositiveButton("Cerrar", null).show()
    }

    // ---------- Ciclo de vida y teclas ----------
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (screen?.onBack() == true) return
        @Suppress("DEPRECATION")
        super.onBackPressed()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val ctrl = event?.isCtrlPressed == true
        val shift = event?.isShiftPressed == true
        if (screen?.onKeyEvent(keyCode, true, ctrl, shift) == true) return true
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        val ctrl = event?.isCtrlPressed == true
        val shift = event?.isShiftPressed == true
        if (screen?.onKeyEvent(keyCode, false, ctrl, shift) == true) return true
        return super.onKeyUp(keyCode, event)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        screen?.onConfigurationChanged()
    }

    override fun onPause() {
        screen?.onPause()
        super.onPause()
    }

    companion object {
        private const val REQ_IMAGE = 4021
    }
}
