package com.motor2d.export

import java.io.ByteArrayOutputStream
import java.math.BigInteger
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.Signature
import java.security.cert.X509Certificate
import java.util.Base64

internal object Der {
    fun len(n: Int): ByteArray = when {
        n < 0x80 -> byteArrayOf(n.toByte())
        n < 0x100 -> byteArrayOf(0x81.toByte(), n.toByte())
        n < 0x10000 -> byteArrayOf(0x82.toByte(), (n shr 8).toByte(), n.toByte())
        else -> byteArrayOf(0x83.toByte(), (n shr 16).toByte(), (n shr 8).toByte(), n.toByte())
    }
    fun tlv(tag: Int, vararg parts: ByteArray): ByteArray {
        val bo = ByteArrayOutputStream()
        for (p in parts) bo.write(p)
        val body = bo.toByteArray()
        val out = ByteArrayOutputStream()
        out.write(tag); out.write(len(body.size)); out.write(body)
        return out.toByteArray()
    }
    fun seq(vararg p: ByteArray) = tlv(0x30, *p)
    fun set(vararg p: ByteArray) = tlv(0x31, *p)
    fun octets(b: ByteArray) = tlv(0x04, b)
    fun nul() = byteArrayOf(0x05, 0x00)
    fun int(v: BigInteger) = tlv(0x02, v.toByteArray())
    fun int(v: Int) = int(BigInteger.valueOf(v.toLong()))
    fun oid(s: String): ByteArray {
        val parts = s.split('.').map { it.toLong() }
        val bo = ByteArrayOutputStream()
        bo.write((parts[0] * 40 + parts[1]).toInt())
        for (i in 2 until parts.size) {
            var v = parts[i]
            val tmp = ArrayList<Int>()
            tmp.add((v and 0x7f).toInt()); v = v shr 7
            while (v > 0) { tmp.add(((v and 0x7f) or 0x80).toInt()); v = v shr 7 }
            for (k in tmp.indices.reversed()) bo.write(tmp[k])
        }
        return tlv(0x06, bo.toByteArray())
    }
}

/** Firma JAR (v1) con SHA-256withRSA: MANIFEST.MF, CERT.SF y CERT.RSA (PKCS#7 SignedData desacoplado, DER). */
internal object V1Signer {
    class Entry(val name: String, val sha256: ByteArray)

    private const val CRLF = "\r\n"
    private val b64 = Base64.getEncoder()

    /** Una cabecera "Nombre: valor" con líneas de máx. 72 bytes (sin CRLF) y continuación con espacio inicial. */
    private fun header(out: ByteArrayOutputStream, name: String, value: String) {
        val line = "$name: $value".toByteArray(Charsets.UTF_8)
        var pos = 0
        var first = true
        while (pos < line.size) {
            val max = if (first) 72 else 71
            var end = minOf(line.size, pos + max)
            if (end < line.size) while (end > pos + 1 && (line[end].toInt() and 0xC0) == 0x80) end-- // no partir UTF-8
            if (!first) out.write(' '.code)
            out.write(line, pos, end - pos)
            out.write(CRLF.toByteArray())
            pos = end
            first = false
        }
    }

    private fun sha256(b: ByteArray) = MessageDigest.getInstance("SHA-256").digest(b)

    /** Devuelve los contenidos de META-INF/MANIFEST.MF, META-INF/CERT.SF y META-INF/CERT.RSA. */
    fun sign(entries: List<Entry>, key: PrivateKey, cert: X509Certificate): Triple<ByteArray, ByteArray, ByteArray> {
        val mf = ByteArrayOutputStream()
        header(mf, "Manifest-Version", "1.0")
        header(mf, "Created-By", "1.0 (Motor2D Export)")
        mf.write(CRLF.toByteArray())
        val sections = ArrayList<ByteArray>(entries.size)
        for (e in entries) {
            val s = ByteArrayOutputStream()
            header(s, "Name", e.name)
            header(s, "SHA-256-Digest", b64.encodeToString(e.sha256))
            s.write(CRLF.toByteArray())
            val sb = s.toByteArray()
            sections.add(sb); mf.write(sb)
        }
        val mfBytes = mf.toByteArray()

        val sf = ByteArrayOutputStream()
        header(sf, "Signature-Version", "1.0")
        header(sf, "Created-By", "1.0 (Motor2D Export)")
        header(sf, "SHA-256-Digest-Manifest", b64.encodeToString(sha256(mfBytes)))
        header(sf, "X-Android-APK-Signed", "2")
        sf.write(CRLF.toByteArray())
        for ((i, e) in entries.withIndex()) {
            header(sf, "Name", e.name)
            header(sf, "SHA-256-Digest", b64.encodeToString(sha256(sections[i])))
            sf.write(CRLF.toByteArray())
        }
        val sfBytes = sf.toByteArray()

        val sig = Signature.getInstance("SHA256withRSA")
        sig.initSign(key); sig.update(sfBytes)
        val sigBytes = sig.sign()

        val sha256Alg = Der.seq(Der.oid("2.16.840.1.101.3.4.2.1"), Der.nul())
        val rsaAlg = Der.seq(Der.oid("1.2.840.113549.1.1.1"), Der.nul())
        val issuerAndSerial = Der.seq(cert.issuerX500Principal.encoded, Der.int(cert.serialNumber))
        val signerInfo = Der.seq(Der.int(1), issuerAndSerial, sha256Alg, rsaAlg, Der.octets(sigBytes))
        val signedData = Der.seq(
            Der.int(1),
            Der.set(sha256Alg),
            Der.seq(Der.oid("1.2.840.113549.1.7.1")),          // contenido desacoplado
            Der.tlv(0xA0, cert.encoded),                        // [0] IMPLICIT certificates
            Der.set(signerInfo)
        )
        val rsa = Der.seq(Der.oid("1.2.840.113549.1.7.2"), Der.tlv(0xA0, signedData))
        return Triple(mfBytes, sfBytes, rsa)
    }
}

/** APK Signature Scheme v2 (RSASSA-PKCS1-v1_5 con SHA2-256, id 0x0103). */
internal object V2Signer {
    const val BLOCK_ID = 0x7109871a
    const val ALG_RSA_PKCS1_SHA256 = 0x0103
    private const val CHUNK = 1 shl 20
    private val MAGIC = "APK Sig Block 42".toByteArray(Charsets.US_ASCII)

    private fun u32(v: Int): ByteArray = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(v).array()
    private fun u64(v: Long): ByteArray = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(v).array()
    private fun lp(b: ByteArray): ByteArray = u32(b.size) + b
    private fun lpAll(parts: List<ByteArray>): ByteArray {
        val bo = ByteArrayOutputStream()
        for (p in parts) bo.write(lp(p))
        return bo.toByteArray()
    }

    private fun chunkDigests(md: MessageDigest, data: ByteArray, off: Int, len: Int, out: ByteArrayOutputStream): Int {
        var n = 0
        var p = off
        val end = off + len
        while (p < end) {
            val l = minOf(CHUNK, end - p)
            md.update(0xa5.toByte()); md.update(u32(l)); md.update(data, p, l)
            out.write(md.digest())
            p += l; n++
        }
        return n
    }

    /**
     * [data]: array con las entradas locales en [0, cdOffset). [cd]: directorio central. [eocd]: EOCD sin firmar
     * (cuyo offset del directorio central es cdOffset = inicio del bloque de firma). Devuelve el APK Signing Block completo.
     */
    fun buildSigningBlock(data: ByteArray, cdOffset: Int, cd: ByteArray, eocd: ByteArray, key: PrivateKey, cert: X509Certificate): ByteArray {
        val md = MessageDigest.getInstance("SHA-256")
        val digs = ByteArrayOutputStream()
        var count = chunkDigests(md, data, 0, cdOffset, digs)
        count += chunkDigests(md, cd, 0, cd.size, digs)
        count += chunkDigests(md, eocd, 0, eocd.size, digs) // EOCD con offset del CD == offset del bloque (ya lo es)
        md.update(0x5a.toByte()); md.update(u32(count)); md.update(digs.toByteArray())
        val top = md.digest()

        val digestEntry = u32(ALG_RSA_PKCS1_SHA256) + lp(top)
        val signedData = lp(lpAll(listOf(digestEntry))) + lp(lpAll(listOf(cert.encoded))) + lp(ByteArray(0))
        val sig = Signature.getInstance("SHA256withRSA")
        sig.initSign(key); sig.update(signedData)
        val signature = sig.sign()
        val sigEntry = u32(ALG_RSA_PKCS1_SHA256) + lp(signature)
        val signer = lp(signedData) + lp(lpAll(listOf(sigEntry))) + lp(cert.publicKey.encoded)
        val value = lp(lpAll(listOf(signer)))

        // pares id-valor: [tamaño u64 = 4 + valor][id u32][valor]
        val pair = u64(4L + value.size) + u32(BLOCK_ID) + value
        var total = 8L + pair.size + 8L + 16L
        val bo = ByteArrayOutputStream()
        // relleno (id 0x42726577) para que el bloque ocupe un múltiplo de 4096 bytes, como hace apksig
        var padPair = ByteArray(0)
        val rem = (total % 4096).toInt()
        if (rem != 0) {
            var pad = 4096 - rem
            if (pad < 12) pad += 4096
            padPair = u64(pad - 8L) + u32(0x42726577) + ByteArray(pad - 12)
            total += pad
        }
        bo.write(u64(total - 8)); bo.write(pair); bo.write(padPair)
        bo.write(u64(total - 8)); bo.write(MAGIC)
        val block = bo.toByteArray()
        check(block.size.toLong() == total) { "tamaño de bloque incoherente" }
        return block
    }
}
