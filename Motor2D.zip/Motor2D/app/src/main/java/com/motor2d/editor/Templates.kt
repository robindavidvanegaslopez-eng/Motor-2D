package com.motor2d.editor

import com.motor2d.core.Vec2
import com.motor2d.engine.*

/** Proyectos de partida: uno vacío y uno de ejemplo (plataformas) para aprender. */
object Templates {
    const val EMPTY = "empty"
    const val DEMO = "demo"

    val PLAYER_GD = """
extends Node2D
# Jugador: joystick para moverse, botón A para saltar, botón B lanza una pelota.
@export var speed = 320.0
@export var jump_force = 760.0

func _process(delta):
    var rb = rigidbody
    var dir = Input.joystick
    rb.velocity = Vector2(dir.x * speed, rb.velocity.y)
    if Input.is_button_just_pressed("A") and rb.is_on_floor():
        rb.velocity = Vector2(rb.velocity.x, -jump_force)
    if Input.is_button_just_pressed("B"):
        var p = instantiate("Pelota", position + Vector2(0, -60))
        p.velocity = Vector2(400, -300)
    if position.y > 1500:
        position = Vector2(200, 540)
        rb.stop()
""".trimStart()

    val COIN_GD = """
extends Node2D
# Moneda: es un disparador (trigger). Cuando el jugador la toca suma un punto.
func _on_trigger_enter(other):
    if other.name == "Jugador":
        get_object("Puntos").add(1)
        destroy(self)
""".trimStart()

    val HUD_GD = """
extends Node2D
# Marcador: sigue a la cámara y muestra los puntos.
var score = 0

func add(n):
    score += n
    label.text = "Monedas: " + str(score)

func _ready():
    label.text = "Monedas: 0"

func _process(delta):
    var cam = get_object("Camara")
    position = cam.position + Vector2(0, -310)
""".trimStart()

    val CAMERA_GD = """
extends Node2D
# Cámara que sigue al objeto indicado en 'target' (solo en horizontal).
@export var target = "Jugador"

func _process(delta):
    var t = get_object(target)
    if t == null:
        return
    var x = lerp(position.x, t.position.x, min(1.0, delta * 6.0))
    position = Vector2(max(x, 640.0), position.y)
""".trimStart()

    fun newScript(): String = """
extends Node2D
# Se llama una vez cuando empieza el juego.
func _ready():
    print("Hola desde ", name)

# Se llama en cada fotograma. delta = segundos desde el anterior.
func _process(delta):
    pass
""".trimStart()

    fun apply(p: Project, template: String) {
        val w = World(null, null)
        if (template == DEMO) buildDemo(w, p) else buildEmpty(w)
        p.writeText("scenes/main.json", SceneIO.sceneToJson(w))
    }

    private fun obj(w: World, name: String, x: Double, y: Double): GameObject =
        w.addObject(GameObject(name).also { it.position = Vec2(x, y) })

    private fun sprite(o: GameObject, wd: Double, ht: Double, color: Int, circle: Boolean = false) {
        o.addComponent(SpriteRenderer().also {
            it.values["size"] = Vec2(wd, ht)
            it.values["color"] = color
            if (circle) it.values["shape"] = "circle"
        })
    }

    private fun box(o: GameObject, wd: Double, ht: Double) {
        o.addComponent(BoxCollider2D().also { it.values["size"] = Vec2(wd, ht) })
    }

    private fun body(o: GameObject, type: String, freeze: Boolean = false) {
        o.addComponent(Rigidbody2D().also {
            it.values["body_type"] = type
            it.values["freeze_rotation"] = freeze
        })
    }

    private fun script(o: GameObject, path: String) {
        o.addComponent(ScriptComponent().also { it.values["path"] = path })
    }

    private fun buildEmpty(w: World) {
        w.viewW = 720.0; w.viewH = 1280.0
        val cam = obj(w, "Camara", 360.0, 640.0)
        cam.addComponent(Camera2D())
    }

    private fun buildDemo(w: World, p: Project) {
        w.viewW = 1280.0; w.viewH = 720.0
        p.writeText("scripts/player.gd", PLAYER_GD)
        p.writeText("scripts/coin.gd", COIN_GD)
        p.writeText("scripts/hud.gd", HUD_GD)
        p.writeText("scripts/camera.gd", CAMERA_GD)

        val cam = obj(w, "Camara", 640.0, 360.0)
        cam.addComponent(Camera2D().also { it.values["background"] = 0xFF1E2A3A.toInt() })
        script(cam, "scripts/camera.gd")

        val ground = obj(w, "Suelo", 1000.0, 670.0)
        sprite(ground, 4000.0, 100.0, 0xFF4E8F4E.toInt()); box(ground, 4000.0, 100.0); body(ground, "static")

        for ((n, x) in listOf("Muro izquierdo" to -60.0, "Muro derecho" to 2100.0)) {
            val m = obj(w, n, x, 360.0)
            sprite(m, 40.0, 1000.0, 0xFF37474F.toInt()); box(m, 40.0, 1000.0); body(m, "static")
        }

        for ((i, pl) in listOf(Triple(500.0, 480.0, 200.0), Triple(800.0, 380.0, 200.0), Triple(1150.0, 480.0, 240.0)).withIndex()) {
            val o = obj(w, "Plataforma ${i + 1}", pl.first, pl.second)
            sprite(o, pl.third, 24.0, 0xFF8D6E63.toInt()); box(o, pl.third, 24.0); body(o, "static")
        }

        val player = obj(w, "Jugador", 200.0, 540.0)
        player.tag = "jugador"
        sprite(player, 56.0, 56.0, 0xFF4FC3F7.toInt()); box(player, 56.0, 56.0); body(player, "dynamic", freeze = true)
        script(player, "scripts/player.gd")

        for ((i, c) in listOf(Vec2(500.0, 430.0), Vec2(800.0, 330.0), Vec2(1150.0, 430.0), Vec2(1500.0, 580.0)).withIndex()) {
            val o = obj(w, "Moneda ${i + 1}", c.x, c.y)
            sprite(o, 32.0, 32.0, 0xFFFDD835.toInt(), circle = true)
            o.addComponent(CircleCollider2D().also { it.values["radius"] = 16.0; it.values["is_trigger"] = true })
            script(o, "scripts/coin.gd")
        }

        val ball = obj(w, "Pelota", 700.0, 100.0)
        ball.active = false
        sprite(ball, 36.0, 36.0, 0xFFEF5350.toInt(), circle = true)
        ball.addComponent(CircleCollider2D().also { it.values["radius"] = 18.0; it.values["bounciness"] = 0.6 })
        body(ball, "dynamic")

        val hud = obj(w, "Puntos", 640.0, 50.0)
        hud.addComponent(Label().also { it.values["text"] = "Monedas: 0"; it.values["font_size"] = 36.0 })
        script(hud, "scripts/hud.gd")
    }
}
