package com.motor2d.app

import android.app.Activity
import android.content.res.Configuration
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.motor2d.core.Vec2
import com.motor2d.editor.EditorModel
import com.motor2d.editor.Project
import com.motor2d.editor.SpriteDoc
import com.motor2d.engine.GameObject

/** La pantalla del editor: barra superior, escena y paneles. */
class EditorScreen(
    private val act: MainActivity,
    val project: Project,
    private val onExit: () -> Unit
) : Screen, EditorHost {

    override val activity: Activity get() = act

    private val model = EditorModel(project)
    private val renderer = Renderer(project)
    private val sceneView = SceneView(act, model, renderer)
    private val hierarchy = HierarchyPanel(this, model)
    private val inspector = InspectorPanel(this, model)
    private val scripts = ScriptsPanel(this, model)
    private val console = ConsolePanel(this, model)

    private val root = FrameLayout(act)
    private val body = LinearLayout(act)
    private val sceneFrame = FrameLayout(act)
    private val panel = LinearLayout(act)
    private val panelContent = FrameLayout(act)
    private val tabViews = ArrayList<TextView>()
    private val panelViews = listOf(hierarchy.view, inspector.view, scripts.view, console.view)
    private var tab = 0

    private val title = TextView(act)
    private lateinit var undoBtn: TextView
    private lateinit var redoBtn: TextView
    private lateinit var playBtn: TextView
    private lateinit var menuBtn: TextView
    private lateinit var consoleBtn: TextView
    private lateinit var snapBtn: TextView
    private lateinit var toolsBox: LinearLayout

    private var scriptEditor: ScriptEditor? = null
    private var blocksEditor: BlocksEditor? = null
    private var spriteEditor: SpriteEditor? = null
    private var consoleOpen = false
    private var lastSync = 0L
    private var consoleScheduled = false
    private val handler = Handler(Looper.getMainLooper())

    override val view: View get() = root

    init {
        root.setBackgroundColor(Ui.BG)
        val main = LinearLayout(act)
        main.orientation = LinearLayout.VERTICAL
        main.addView(buildTopBar(), lp(Ui.MATCH, Ui.WRAP))

        // Escena + herramientas flotantes
        sceneFrame.addView(sceneView, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        toolsBox = LinearLayout(act)
        toolsBox.orientation = LinearLayout.VERTICAL
        snapBtn = act.button("⊞", 0xAA000000.toInt()) {
            sceneView.snap = !sceneView.snap
            updateSnap()
            act.toast(if (sceneView.snap) "Imán de 8 activado" else "Imán desactivado")
        }
        toolsBox.addView(snapBtn, lp(act.dp(44), act.dp(44)).also { it.bottomMargin = act.dp(6) })
        toolsBox.addView(act.button("⤢", 0xAA000000.toInt()) { sceneView.frameGame(); sceneView.invalidate() },
            lp(act.dp(44), act.dp(44)).also { it.bottomMargin = act.dp(6) })
        toolsBox.addView(act.button("◎", 0xAA000000.toInt()) { sceneView.focusSelected() }, lp(act.dp(44), act.dp(44)))
        val tp = FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.TOP or Gravity.END)
        tp.setMargins(0, act.dp(8), act.dp(8), 0)
        sceneFrame.addView(toolsBox, tp)

        // Panel con pestañas
        panel.orientation = LinearLayout.VERTICAL
        panel.setBackgroundColor(Ui.BG)
        val tabs = LinearLayout(act)
        tabs.setBackgroundColor(Ui.PANEL)
        val names = listOf("Objetos", "Inspector", "Scripts", "Consola")
        for ((i, n) in names.withIndex()) {
            val t = TextView(act)
            t.text = n
            t.textSize = 14f
            t.gravity = Gravity.CENTER
            t.minHeight = act.dp(46)
            t.setOnClickListener { showTab(i) }
            tabViews.add(t)
            tabs.addView(t, lp(0, Ui.WRAP, 1f))
        }
        panel.addView(tabs, lp(Ui.MATCH, Ui.WRAP))
        for (v in panelViews) panelContent.addView(v, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        panel.addView(panelContent, lp(Ui.MATCH, 0, 1f))

        body.addView(sceneFrame)
        body.addView(panel)
        main.addView(body, lp(Ui.MATCH, 0, 1f))
        root.addView(main, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))

        sceneView.onSelectionChanged = {
            hierarchy.refresh(); inspector.refresh(); showTab(1)
        }
        sceneView.onTransformChanged = {
            val now = SystemClock.uptimeMillis()
            if (now - lastSync > 100) { lastSync = now; inspector.syncAll() }
            updateUndo()
        }
        sceneView.onEditEnd = { inspector.syncAll(); updateUndo() }
        sceneView.onStopRequested = { stop() }
        model.onConsole = { scheduleConsoleRefresh() }

        applyOrientation()
        refreshAll()
        showTab(0)
        updateMode()
        updateSnap()
    }

    // ---------- Barra superior ----------
    private fun buildTopBar(): View {
        val bar = LinearLayout(act)
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(Ui.PANEL)
        bar.setPadding(act.dp(6), act.dp(4), act.dp(6), act.dp(4))
        bar.addView(act.button("←", Ui.PANEL2) { onBack() }, lp(Ui.WRAP, Ui.WRAP))
        title.textSize = 15f
        title.setTextColor(Ui.TEXT)
        title.setSingleLine(true)
        title.setPadding(act.dp(10), 0, act.dp(4), 0)
        bar.addView(title, lp(0, Ui.WRAP, 1f))
        undoBtn = act.button("↩", Ui.PANEL2) { model.undo(); refreshAll() }
        redoBtn = act.button("↪", Ui.PANEL2) { model.redo(); refreshAll() }
        bar.addView(undoBtn, lp(Ui.WRAP, Ui.WRAP))
        bar.addView(redoBtn, lp(Ui.WRAP, Ui.WRAP).also { it.leftMargin = act.dp(4) })
        consoleBtn = act.button("Consola", Ui.PANEL2) { toggleConsole() }
        bar.addView(consoleBtn, lp(Ui.WRAP, Ui.WRAP).also { it.leftMargin = act.dp(4) })
        playBtn = act.button("▶ Ejecutar", Ui.ACCENT, 0xFF04202D.toInt()) { if (model.isPlaying) stop() else play() }
        bar.addView(playBtn, lp(Ui.WRAP, Ui.WRAP).also { it.leftMargin = act.dp(6) })
        menuBtn = act.button("⋮", Ui.PANEL2) { menu() }
        bar.addView(menuBtn, lp(Ui.WRAP, Ui.WRAP).also { it.leftMargin = act.dp(4) })
        return bar
    }

    private fun updateTitle() {
        title.text = if (model.isPlaying) "Ejecutando…" else project.name + " · " + model.sceneName + if (model.dirty) " •" else ""
    }

    private fun updateUndo() {
        undoBtn.alpha = if (model.canUndo) 1f else 0.35f
        redoBtn.alpha = if (model.canRedo) 1f else 0.35f
        updateTitle()
    }

    private fun updateSnap() {
        snapBtn.background = roundBg(if (sceneView.snap) Ui.ACCENT_DARK else 0xAA000000.toInt(), act.dpf(10f))
    }

    // ---------- Disposición ----------
    private fun applyOrientation() {
        val land = act.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        if (land) {
            body.orientation = LinearLayout.HORIZONTAL
            sceneFrame.layoutParams = lp(0, Ui.MATCH, 3f)
            panel.layoutParams = lp(0, Ui.MATCH, 2f)
        } else {
            body.orientation = LinearLayout.VERTICAL
            sceneFrame.layoutParams = lp(Ui.MATCH, 0, 5f)
            panel.layoutParams = lp(Ui.MATCH, 0, 4f)
        }
        body.requestLayout()
    }

    override fun onConfigurationChanged() {
        applyOrientation()
        spriteEditor?.onConfigurationChanged()
    }

    private fun updateMode() {
        val playing = model.isPlaying
        undoBtn.visibility = if (playing) View.GONE else View.VISIBLE
        redoBtn.visibility = if (playing) View.GONE else View.VISIBLE
        menuBtn.visibility = if (playing) View.GONE else View.VISIBLE
        consoleBtn.visibility = if (playing) View.VISIBLE else View.GONE
        toolsBox.visibility = if (playing) View.GONE else View.VISIBLE
        playBtn.text = if (playing) "■ Detener" else "▶ Ejecutar"
        playBtn.background = roundBg(if (playing) Ui.DANGER else Ui.ACCENT, act.dpf(10f))
        panel.visibility = if (!playing || consoleOpen) View.VISIBLE else View.GONE
        updateUndo()
    }

    private fun toggleConsole() {
        consoleOpen = !consoleOpen
        if (consoleOpen) showTab(3)
        updateMode()
    }

    override fun showTab(index: Int) {
        tab = index
        for ((i, v) in panelViews.withIndex()) v.visibility = if (i == index) View.VISIBLE else View.GONE
        for ((i, t) in tabViews.withIndex()) {
            t.setTextColor(if (i == index) Ui.ACCENT else Ui.MUTED)
            t.setBackgroundColor(if (i == index) Ui.PANEL2 else Color.TRANSPARENT)
        }
        if (index == 3) console.refresh()
    }

    private fun scheduleConsoleRefresh() {
        if (consoleScheduled) return
        consoleScheduled = true
        handler.postDelayed({
            consoleScheduled = false
            if (tab == 3 && panel.visibility == View.VISIBLE) console.refresh()
        }, 120)
    }

    // ---------- Ejecutar ----------
    private fun play() {
        scriptEditor?.save()
        blocksEditor?.saveNow()
        if (!model.startPlay()) { act.toast("No se pudo guardar la escena"); return }
        renderer.clearCache()
        sceneView.keepScreenOn = true
        updateMode()
        sceneView.startLoop()
        sceneView.invalidate()
    }

    private fun stop() {
        val hadError = model.play?.error != null
        model.stopPlay()
        sceneView.keepScreenOn = false
        consoleOpen = false
        updateMode()
        refreshAll()
        if (hadError) { showTab(3) }
    }

    // ---------- EditorHost ----------
    override fun viewCenter(): Vec2 = sceneView.camCenter

    private fun refreshAll() {
        hierarchy.refresh()
        inspector.refresh()
        scripts.refresh()
        sceneView.invalidate()
        updateUndo()
    }

    override fun selectionChanged() {
        hierarchy.refresh(); inspector.refresh(); sceneView.invalidate()
    }

    override fun sceneChanged() { refreshAll() }

    override fun valueChanged() { sceneView.invalidate(); updateUndo() }

    override fun importImage(onDone: (String) -> Unit) {
        act.pickImage { name, data ->
            val path = model.importImage(name, data)
            renderer.clearCache()
            onDone(path)
        }
    }

    override fun openScript(path: String) {
        // Los scripts que salen de bloques se editan con bloques: el código se regenera al guardar
        val blocks = model.blocksNameOf(path)
        if (blocks != null) { openBlocks(blocks); return }
        closeOverlays()
        scriptEditor?.let { it.save(); root.removeView(it.view) }
        val se = ScriptEditor(act, model, path, { closeScript() }, { closeScript(); play() })
        scriptEditor = se
        root.addView(se.view, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
    }

    private fun closeScript() {
        scriptEditor?.let { root.removeView(it.view) }
        scriptEditor = null
        refreshAll()
    }

    // ---------- Bloques visuales ----------
    override fun openBlocks(name: String) {
        closeOverlays()
        scriptEditor?.let { it.save(); root.removeView(it.view) }
        scriptEditor = null
        val be = BlocksEditor(act, model, name, { closeBlocks() }, { closeBlocks(); play() })
        blocksEditor = be
        root.addView(be.view, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
    }

    private fun closeBlocks() {
        blocksEditor?.let { root.removeView(it.view) }
        blocksEditor = null
        refreshAll()
    }

    // ---------- Sprites ----------
    override fun openSpriteEditor(o: GameObject) {
        closeOverlays()
        val existing = SpriteEditor.loadExisting(model, o)
        if (existing != null) { startSpriteEditor(o, existing); return }
        if (o.sprite?.s("image")?.isNotEmpty() == true) {
            act.toast("Esa imagen no se puede editar aquí (es muy grande o no se pudo leer). Se creará un sprite nuevo.")
        }
        val sizes = listOf(16, 32, 48, 64, 128)
        act.pick("Tamaño del sprite nuevo (píxeles)", sizes.map { it.toString() + " × " + it }) { i ->
            val side = sizes[i]
            act.askText("Nombre del sprite", SpriteDoc.cleanName(o.name).lowercase()) { raw ->
                val base = SpriteDoc.cleanName(raw)
                var n = base
                var k = 2
                while (project.exists("assets/$n.png") || project.exists("assets/" + n + "_1.png")) { n = base + k; k++ }
                startSpriteEditor(o, SpriteDoc(n, side, side))
            }
        }
    }

    private fun startSpriteEditor(o: GameObject, doc: SpriteDoc) {
        val se = SpriteEditor(act, model, o, doc) { applied -> closeSprite(applied) }
        spriteEditor = se
        root.addView(se.view, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
    }

    private fun closeSprite(applied: Boolean) {
        spriteEditor?.let { it.dispose(); root.removeView(it.view) }
        spriteEditor = null
        if (applied) renderer.clearCache()
        refreshAll()
    }

    /** Cierra los editores a pantalla completa que haya abiertos (guardando lo que tengan). */
    private fun closeOverlays() {
        blocksEditor?.let { it.saveNow(); root.removeView(it.view) }
        blocksEditor = null
        spriteEditor?.let { it.dispose(); root.removeView(it.view) }
        spriteEditor = null
    }

    // ---------- Menú ----------
    private fun menu() {
        val items = ArrayList<Pair<String, () -> Unit>>()
        items.add("Guardar" to { model.save(); updateTitle(); act.toast("Guardado") })
        items.add("Escenas..." to { scenesDialog() })
        items.add((if (model.isLandscape) "Pasar el juego a vertical" else "Pasar el juego a horizontal") to {
            model.setLandscape(!model.isLandscape); sceneView.frameGame(); refreshAll()
        })
        items.add("Gravedad..." to { gravityDialog() })
        items.add((if (sceneView.showControls) "Ocultar" else "Mostrar") + " joystick y botones al ejecutar" to {
            sceneView.showControls = !sceneView.showControls
        })
        items.add("Exportar APK (instalable)..." to { model.save(); act.exportProject(project, model.sceneName) })
        items.add("Exportar APK (juego instalable)..." to { ExportAction.start(act, project) { model.save() } })
        items.add("Ayuda de scripts" to { helpDialog() })
        items.add("Cerrar proyecto" to { onBack(); Unit })
        act.pick("Menú", items.map { it.first }) { i -> items[i].second() }
    }

    private fun gravityDialog() {
        val g = model.world.physics.gravity
        act.askText("Gravedad (x, y)", com.motor2d.script.Fmt.num(g.x) + ", " + com.motor2d.script.Fmt.num(g.y)) { t ->
            try { model.setGravity(model.parseVec(t)); refreshAll() } catch (e: IllegalArgumentException) { act.toast(e.message ?: "Valor no válido") }
        }
    }

    private fun scenesDialog() {
        val names = model.project.scenes()
        val items = ArrayList<String>()
        items.addAll(names.map { if (it == model.sceneName) "$it (actual)" else it })
        items.add("+ Nueva escena...")
        act.pick("Escenas", items) { i ->
            if (i == items.size - 1) {
                act.askText("Nombre de la escena", "nivel2") { n ->
                    model.newScene(n); sceneView.frameGame(); refreshAll()
                }
            } else if (names[i] != model.sceneName) {
                model.save()
                model.loadScene(names[i])
                sceneView.frameGame()
                refreshAll()
            }
        }
    }

    private fun helpDialog() {
        val t = TextView(act)
        t.text = HelpText.TEXT
        t.typeface = android.graphics.Typeface.MONOSPACE
        t.textSize = 12f
        t.setTextColor(Ui.TEXT)
        t.setPadding(act.dp(16), act.dp(8), act.dp(16), act.dp(8))
        val sv = ScrollView(act)
        sv.addView(t)
        android.app.AlertDialog.Builder(act).setTitle("Ayuda de scripts").setView(sv).setPositiveButton("Cerrar", null).show()
    }

    // ---------- Screen ----------
    override fun onBack(): Boolean {
        spriteEditor?.let { it.tryClose(); return true }
        blocksEditor?.let { it.close(); return true }
        if (scriptEditor != null) { scriptEditor?.let { it.save() }; closeScript(); return true }
        if (model.isPlaying) { stop(); return true }
        model.save()
        onExit()
        return true
    }

    override fun onPause() {
        scriptEditor?.save()
        blocksEditor?.saveNow()
        if (!model.isPlaying) model.save()
    }

    override fun onKeyEvent(keyCode: Int, down: Boolean, ctrl: Boolean, shift: Boolean): Boolean {
        // Jugando: todo el teclado va al juego (Esc detiene)
        val w = model.play
        if (w != null) {
            if (down && keyCode == KeyEvent.KEYCODE_ESCAPE) { stop(); return true }
            return GameKeys.handle(w.input, keyCode, down)
        }
        if (!down) return false
        // Editores a pantalla completa
        val se = spriteEditor
        if (se != null) return se.onKey(keyCode, ctrl, shift)
        if (blocksEditor != null || scriptEditor != null) {
            if (ctrl && keyCode == KeyEvent.KEYCODE_S) { scriptEditor?.save(); blocksEditor?.saveNow(); act.toast("Guardado"); return true }
            if (keyCode == KeyEvent.KEYCODE_F5) { play(); return true }
            return false
        }
        // Atajos del editor de escena
        if (keyCode == KeyEvent.KEYCODE_F5 || (ctrl && keyCode == KeyEvent.KEYCODE_R)) { play(); return true }
        if (ctrl) {
            when (keyCode) {
                KeyEvent.KEYCODE_S -> { model.save(); updateTitle(); act.toast("Guardado"); return true }
                KeyEvent.KEYCODE_Z -> { if (shift) model.redo() else model.undo(); refreshAll(); return true }
                KeyEvent.KEYCODE_Y -> { model.redo(); refreshAll(); return true }
                KeyEvent.KEYCODE_D -> {
                    val o = model.selected
                    if (o != null) { val c = model.duplicate(o); model.select(c); refreshAll() }
                    return true
                }
            }
            return false
        }
        if (keyCode == KeyEvent.KEYCODE_DEL || keyCode == KeyEvent.KEYCODE_FORWARD_DEL) {
            val o = model.selected
            if (o != null) { model.delete(o); model.select(null); refreshAll(); return true }
        }
        return false
    }
}
