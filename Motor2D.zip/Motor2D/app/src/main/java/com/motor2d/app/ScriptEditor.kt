package com.motor2d.app

import android.app.Activity
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import com.motor2d.editor.EditorModel
import com.motor2d.script.ScriptError

/** Editor de código a pantalla completa con colores, sangría automática y barra de símbolos. */
class ScriptEditor(
    private val activity: Activity,
    private val model: EditorModel,
    val path: String,
    private val onClose: () -> Unit,
    private val onRun: () -> Unit
) {
    val view: View
    private val edit = EditText(activity)
    private val status = TextView(activity)
    private val title = TextView(activity)
    private val handler = Handler(Looper.getMainLooper())
    private var lastError: ScriptError? = null
    private var dirty = false
    private var highlighting = false

    private val check = Runnable { runCheck() }

    companion object {
        private val KEYWORDS = setOf(
            "extends", "class_name", "var", "const", "func", "if", "elif", "else", "for", "while", "match",
            "break", "continue", "pass", "return", "in", "and", "or", "not", "true", "false", "null", "signal", "self"
        )
        private const val C_KEYWORD = 0xFFFF7B72.toInt()
        private const val C_STRING = 0xFFA5D6A7.toInt()
        private const val C_COMMENT = 0xFF7D8590.toInt()
        private const val C_NUMBER = 0xFF79C0FF.toInt()
        private const val C_FUNC = 0xFFD2A8FF.toInt()
        private const val C_ANNOT = 0xFFFFB74D.toInt()
    }

    init {
        val root = LinearLayout(activity)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)

        val bar = LinearLayout(activity)
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(Ui.PANEL)
        bar.setPadding(activity.dp(6), activity.dp(4), activity.dp(6), activity.dp(4))
        bar.addView(activity.button("←", Ui.PANEL2) { close() }, lp(Ui.WRAP, Ui.WRAP))
        title.textSize = 15f
        title.setTextColor(Ui.TEXT)
        title.setSingleLine(true)
        title.setPadding(activity.dp(10), 0, activity.dp(6), 0)
        bar.addView(title, lp(0, Ui.WRAP, 1f))
        bar.addView(activity.button("Ayuda", Ui.PANEL2) { showHelp() }, lp(Ui.WRAP, Ui.WRAP))
        bar.addView(activity.button("▶ Ejecutar", Ui.ACCENT, 0xFF04202D.toInt()) { run() },
            lp(Ui.WRAP, Ui.WRAP).also { it.leftMargin = activity.dp(6) })
        root.addView(bar, lp(Ui.MATCH, Ui.WRAP))

        status.textSize = 12f
        status.setPadding(activity.dp(12), activity.dp(6), activity.dp(12), activity.dp(6))
        status.setOnClickListener { jumpToError() }
        root.addView(status, lp(Ui.MATCH, Ui.WRAP))

        edit.typeface = Typeface.MONOSPACE
        edit.textSize = 14f
        edit.setTextColor(Ui.TEXT)
        edit.setBackgroundColor(Ui.FIELD)
        edit.gravity = Gravity.TOP or Gravity.START
        edit.setPadding(activity.dp(10), activity.dp(8), activity.dp(10), activity.dp(8))
        edit.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        edit.setHorizontallyScrolling(false)
        edit.filters = arrayOf<InputFilter>(autoIndent())
        edit.setText(model.project.readText(path) ?: "")
        highlight(edit.text)
        edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable) {
                if (highlighting) return
                dirty = true
                updateTitle()
                highlighting = true
                highlight(s)
                highlighting = false
                handler.removeCallbacks(check)
                handler.postDelayed(check, 500)
            }
        })
        root.addView(edit, lp(Ui.MATCH, 0, 1f))
        root.addView(symbolBar(), lp(Ui.MATCH, Ui.WRAP))
        view = root
        updateTitle()
        runCheck()
    }

    private fun updateTitle() {
        title.text = path.removePrefix("scripts/") + if (dirty) "  •" else ""
    }

    private fun runCheck() {
        val err = model.checkScript(path, edit.text.toString())
        lastError = err
        if (err == null) {
            status.text = "✓ Sin errores de sintaxis"
            status.setTextColor(Ui.OK)
            status.setBackgroundColor(0xFF14261A.toInt())
        } else {
            status.text = "✗ " + err.describe() + "  (toca para ir)"
            status.setTextColor(Ui.DANGER)
            status.setBackgroundColor(0xFF2C1517.toInt())
        }
    }

    private fun jumpToError() {
        val err = lastError ?: return
        if (err.line <= 0) return
        val text = edit.text.toString()
        var offset = 0
        var line = 1
        while (line < err.line) {
            val nl = text.indexOf('\n', offset)
            if (nl < 0) break
            offset = nl + 1
            line++
        }
        edit.requestFocus()
        edit.setSelection(offset.coerceIn(0, text.length))
    }

    fun save() {
        if (!dirty && model.project.exists(path)) return
        model.saveScript(path, edit.text.toString())
        dirty = false
        updateTitle()
    }

    private fun close() {
        handler.removeCallbacks(check)
        save()
        activity.hideKeyboard(edit)
        onClose()
    }

    private fun run() {
        handler.removeCallbacks(check)
        save()
        activity.hideKeyboard(edit)
        val err = model.checkScript(path, edit.text.toString())
        if (err != null) { runCheck(); activity.toast("Corrige el error antes de ejecutar"); return }
        onRun()
    }

    private fun showHelp() {
        val t = TextView(activity)
        t.text = HelpText.TEXT
        t.typeface = Typeface.MONOSPACE
        t.textSize = 12f
        t.setTextColor(Ui.TEXT)
        t.setPadding(activity.dp(16), activity.dp(8), activity.dp(16), activity.dp(8))
        val sv = android.widget.ScrollView(activity)
        sv.addView(t)
        android.app.AlertDialog.Builder(activity).setTitle("Ayuda de scripts").setView(sv).setPositiveButton("Cerrar", null).show()
    }

    // ---------- Sangría automática ----------
    private fun autoIndent(): InputFilter = InputFilter { source, start, end, dest, dstart, _ ->
        if (end - start == 1 && source[start] == '\n') {
            val d = dest.toString()
            val lineStart = d.lastIndexOf('\n', dstart - 1) + 1
            val before = d.substring(lineStart, dstart)
            var k = 0
            while (k < before.length && (before[k] == ' ' || before[k] == '\t')) k++
            var indent = before.substring(0, k)
            if (before.trimEnd().endsWith(":")) indent += "    "
            "\n" + indent
        } else null
    }

    // ---------- Colores ----------
    private fun highlight(e: Editable) {
        for (sp in e.getSpans(0, e.length, ForegroundColorSpan::class.java)) e.removeSpan(sp)
        val s = e.toString()
        val n = s.length
        var i = 0
        var prevWord = ""
        fun span(a: Int, b: Int, color: Int) {
            if (b > a) e.setSpan(ForegroundColorSpan(color), a, b, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        while (i < n) {
            val ch = s[i]
            if (ch == '#') {
                var j = s.indexOf('\n', i)
                if (j < 0) j = n
                span(i, j, C_COMMENT)
                i = j
            } else if (ch == '"' || ch == '\'') {
                var j = i + 1
                while (j < n && s[j] != ch && s[j] != '\n') { if (s[j] == '\\' && j + 1 < n) j++; j++ }
                j = minOf(n, j + 1)
                span(i, j, C_STRING)
                i = j
            } else if (ch.isDigit()) {
                var j = i
                while (j < n && (s[j].isDigit() || s[j] == '.')) j++
                span(i, j, C_NUMBER)
                i = j
            } else if (ch.isLetter() || ch == '_' || ch == '@') {
                var j = i + 1
                while (j < n && (s[j].isLetterOrDigit() || s[j] == '_')) j++
                val w = s.substring(i, j)
                when {
                    w.startsWith("@") -> span(i, j, C_ANNOT)
                    w in KEYWORDS -> span(i, j, C_KEYWORD)
                    prevWord == "func" -> span(i, j, C_FUNC)
                }
                prevWord = w
                i = j
            } else {
                i++
            }
        }
    }

    // ---------- Barra de símbolos ----------
    private fun symbolBar(): View {
        val sv = HorizontalScrollView(activity)
        sv.setBackgroundColor(Ui.PANEL)
        sv.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(activity)
        row.setPadding(activity.dp(4), activity.dp(4), activity.dp(4), activity.dp(4))
        val keys = listOf(
            "Tab" to "    ", ":" to ":", "(" to "(", ")" to ")", "[" to "[", "]" to "]", "{" to "{", "}" to "}",
            "\"" to "\"", "_" to "_", "=" to "=", "." to ".", "," to ",", "+" to "+", "-" to "-", "*" to "*",
            "/" to "/", "<" to "<", ">" to ">", "#" to "#", "!" to "!"
        )
        for ((label, ins) in keys) {
            val b = activity.button(label, Ui.PANEL2) { insert(ins) }
            b.minWidth = activity.dp(40)
            b.setPadding(activity.dp(10), activity.dp(4), activity.dp(10), activity.dp(4))
            row.addView(b, lp(Ui.WRAP, activity.dp(42)).also { it.rightMargin = activity.dp(4) })
        }
        sv.addView(row)
        return sv
    }

    private fun insert(text: String) {
        val a = edit.selectionStart.coerceAtLeast(0)
        val b = edit.selectionEnd.coerceAtLeast(0)
        edit.text.replace(minOf(a, b), maxOf(a, b), text)
    }
}
