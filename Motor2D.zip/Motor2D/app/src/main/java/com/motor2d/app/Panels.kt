package com.motor2d.app

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.motor2d.core.Vec2
import com.motor2d.editor.EditorModel
import com.motor2d.engine.GameObject

/** Lo que los paneles necesitan del editor que los contiene. */
interface EditorHost {
    val activity: Activity
    fun openScript(path: String)
    /** Abre el editor de bloques visuales del script de bloques con ese nombre. */
    fun openBlocks(name: String)
    /** Abre el editor de sprites para dibujar la imagen de ese objeto. */
    fun openSpriteEditor(o: GameObject)
    fun importImage(onDone: (String) -> Unit)
    fun viewCenter(): Vec2
    /** Cambió la selección (desde un panel). */
    fun selectionChanged()
    /** Cambió la estructura de la escena (crear, borrar, componentes...): refresca todo. */
    fun sceneChanged()
    /** Solo cambió un valor: basta con redibujar la escena. */
    fun valueChanged()
    fun showTab(index: Int)
}

private val KINDS = listOf(
    "Cuadrado" to "square",
    "Círculo" to "circle",
    "Texto" to "text",
    "Plataforma (estática)" to "platform",
    "Caja (con física)" to "box",
    "Pelota (con física)" to "ball",
    "Zona (disparador)" to "trigger",
    "Cámara" to "camera",
    "Objeto vacío" to "empty"
)

private fun iconFor(o: GameObject): String = when {
    o.camera != null -> "▣"
    o.label != null -> "T"
    o.rigidbody != null && o.rigidbody!!.s("body_type") == "dynamic" -> "●"
    o.sprite != null && o.sprite!!.s("shape") == "circle" -> "○"
    o.sprite != null -> "□"
    o.colliders.isNotEmpty() -> "◇"
    else -> "+"
}

class HierarchyPanel(private val host: EditorHost, private val model: EditorModel) {
    private val ctx = host.activity
    private val list = LinearLayout(ctx)
    private val title = ctx.label("", 14f, Ui.MUTED)
    val view: View

    init {
        list.orientation = LinearLayout.VERTICAL
        val root = LinearLayout(ctx)
        root.orientation = LinearLayout.VERTICAL

        val header = LinearLayout(ctx)
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(ctx.dp(12), ctx.dp(6), ctx.dp(8), ctx.dp(6))
        header.addView(title, lp(0, Ui.WRAP, 1f))
        header.addView(ctx.button("+ Añadir", Ui.ACCENT_DARK) { addMenu() }, lp(Ui.WRAP, Ui.WRAP))
        root.addView(header, lp(Ui.MATCH, Ui.WRAP))

        val scroll = ScrollView(ctx)
        scroll.addView(list, lp(Ui.MATCH, Ui.WRAP))
        root.addView(scroll, lp(Ui.MATCH, 0, 1f))
        view = root
    }

    private fun addMenu() {
        ctx.pick("Añadir objeto", KINDS.map { it.first }) { i ->
            model.createObject(KINDS[i].second, host.viewCenter())
            host.sceneChanged()
            host.showTab(1)
        }
    }

    fun refresh() {
        list.removeAllViews()
        val items = model.flatten()
        title.text = "Objetos (${items.size})"
        for ((o, depth) in items) list.addView(row(o, depth), lp(Ui.MATCH, Ui.WRAP))
    }

    private fun row(o: GameObject, depth: Int): View {
        val sel = o === model.selected
        val r = LinearLayout(ctx)
        r.gravity = Gravity.CENTER_VERTICAL
        r.minimumHeight = ctx.dp(48)
        r.setPadding(ctx.dp(12 + depth * 18), 0, ctx.dp(4), 0)
        if (sel) r.setBackgroundColor(Ui.ACCENT_DARK)
        val icon = ctx.label(iconFor(o), 16f, if (sel) Ui.SELECT else Ui.MUTED)
        icon.gravity = Gravity.CENTER
        r.addView(icon, lp(ctx.dp(26), Ui.WRAP))
        val name = ctx.label(o.name, 15f, if (o.active) Ui.TEXT else Ui.MUTED)
        name.setSingleLine(true)
        r.addView(name, lp(0, Ui.WRAP, 1f))
        val more = ctx.button("⋮", Color.TRANSPARENT) { objectMenu(o) }
        r.addView(more, lp(ctx.dp(48), ctx.dp(48)))
        r.setOnClickListener {
            model.select(o)
            host.selectionChanged()
            host.showTab(1)
        }
        return r
    }

    private fun objectMenu(o: GameObject) {
        val actions = ArrayList<Pair<String, () -> Unit>>()
        actions.add("Duplicar" to { model.duplicate(o); host.sceneChanged() })
        actions.add((if (o.active) "Desactivar" else "Activar") to { model.setActive(o, !o.active); host.sceneChanged() })
        actions.add("Hacer hijo de..." to { chooseParent(o) })
        if (o.parent != null) actions.add("Quitar del padre" to { model.setParent(o, null); host.sceneChanged() })
        actions.add("Eliminar" to {
            ctx.confirmDialog("Eliminar", "¿Eliminar '${o.name}' y sus hijos?", "Eliminar") {
                model.delete(o); host.sceneChanged()
            }
        })
        ctx.pick(o.name, actions.map { it.first }) { i -> actions[i].second() }
    }

    private fun chooseParent(o: GameObject) {
        fun isDescendant(x: GameObject): Boolean {
            var p: GameObject? = x
            while (p != null) { if (p === o) return true; p = p.parent }
            return false
        }
        val options = model.world.objects.filter { !isDescendant(it) }
        if (options.isEmpty()) { ctx.toast("No hay otros objetos"); return }
        ctx.pick("Hijo de...", options.map { it.name }) { i ->
            model.setParent(o, options[i])
            host.sceneChanged()
        }
    }
}

class ScriptsPanel(private val host: EditorHost, private val model: EditorModel) {
    private val ctx = host.activity
    private val list = LinearLayout(ctx)
    val view: View

    init {
        list.orientation = LinearLayout.VERTICAL
        val root = LinearLayout(ctx)
        root.orientation = LinearLayout.VERTICAL
        val header = LinearLayout(ctx)
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(ctx.dp(12), ctx.dp(6), ctx.dp(8), ctx.dp(6))
        header.addView(ctx.label("Scripts del proyecto", 14f, Ui.MUTED), lp(0, Ui.WRAP, 1f))
        header.addView(ctx.button("+ Nuevo", Ui.ACCENT_DARK) {
            ctx.askText("Nombre del script", "") { n ->
                val path = model.createScript(n)
                refresh()
                host.openScript(path)
            }
        }, lp(Ui.WRAP, Ui.WRAP))
        root.addView(header, lp(Ui.MATCH, Ui.WRAP))
        val scroll = ScrollView(ctx)
        scroll.addView(list, lp(Ui.MATCH, Ui.WRAP))
        root.addView(scroll, lp(Ui.MATCH, 0, 1f))
        view = root
    }

    fun refresh() {
        list.removeAllViews()
        val paths = model.scriptPaths()
        if (paths.isEmpty()) {
            val t = ctx.label("Aún no hay scripts. Pulsa + Nuevo para crear el primero.", 14f, Ui.MUTED)
            t.setPadding(ctx.dp(12), ctx.dp(12), ctx.dp(12), 0)
            list.addView(t)
            return
        }
        for (path in paths) {
            val r = LinearLayout(ctx)
            r.gravity = Gravity.CENTER_VERTICAL
            r.minimumHeight = ctx.dp(52)
            r.setPadding(ctx.dp(12), 0, ctx.dp(4), 0)
            val users = model.world.objects.count { o -> o.scripts.any { it.path == path } }
            val col = LinearLayout(ctx)
            col.orientation = LinearLayout.VERTICAL
            col.addView(ctx.label(path.removePrefix("scripts/"), 15f))
            col.addView(ctx.label(if (users == 0) "sin usar" else "usado en $users objeto(s)", 12f, Ui.MUTED))
            r.addView(col, lp(0, Ui.WRAP, 1f))
            r.addView(ctx.button("⋮", Color.TRANSPARENT) {
                ctx.pick(path.removePrefix("scripts/"), listOf("Editar", "Eliminar")) { i ->
                    if (i == 0) host.openScript(path)
                    else ctx.confirmDialog("Eliminar script", "Los objetos que lo usan darán error al ejecutar.", "Eliminar") {
                        model.deleteScript(path); host.sceneChanged()
                    }
                }
            }, lp(ctx.dp(48), ctx.dp(48)))
            r.setOnClickListener { host.openScript(path) }
            list.addView(r, lp(Ui.MATCH, Ui.WRAP))
        }
    }
}

class ConsolePanel(private val host: EditorHost, private val model: EditorModel) {
    private val ctx = host.activity
    private val out = TextView(ctx)
    private val scroll = ScrollView(ctx)
    val view: View

    init {
        val root = LinearLayout(ctx)
        root.orientation = LinearLayout.VERTICAL
        val header = LinearLayout(ctx)
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(ctx.dp(12), ctx.dp(6), ctx.dp(8), ctx.dp(6))
        header.addView(ctx.label("Consola (print y errores)", 14f, Ui.MUTED), lp(0, Ui.WRAP, 1f))
        header.addView(ctx.button("Limpiar") { model.clearConsole() }, lp(Ui.WRAP, Ui.WRAP))
        root.addView(header, lp(Ui.MATCH, Ui.WRAP))
        out.textSize = 12f
        out.typeface = Typeface.MONOSPACE
        out.setPadding(ctx.dp(12), ctx.dp(4), ctx.dp(12), ctx.dp(12))
        scroll.addView(out, lp(Ui.MATCH, Ui.WRAP))
        root.addView(scroll, lp(Ui.MATCH, 0, 1f))
        view = root
    }

    fun refresh() {
        val sb = SpannableStringBuilder()
        for (l in model.console) {
            val start = sb.length
            sb.append(l.text).append('\n')
            sb.setSpan(ForegroundColorSpan(if (l.isError) Ui.DANGER else Ui.TEXT), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        if (model.console.isEmpty()) {
            sb.append("Aquí aparecerá lo que imprimas con print() y los errores de tus scripts.")
            sb.setSpan(ForegroundColorSpan(Ui.MUTED), 0, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        out.text = sb
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }
}
