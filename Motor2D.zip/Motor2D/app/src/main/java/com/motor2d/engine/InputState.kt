package com.motor2d.engine

import com.motor2d.core.Vec2
import com.motor2d.script.HostObject
import com.motor2d.script.NoSuch

/**
 * Estado de entrada que rellena la capa Android (táctil, joystick en pantalla, botones, teclado).
 * Las posiciones táctiles están en coordenadas de pantalla virtual (0..ancho, 0..alto del juego).
 */
class InputState {
    var touching = false
    var touchPos = Vec2.ZERO
    var justPressed = false
    var justReleased = false
    val touches = ArrayList<Vec2>()       // todos los dedos activos (coordenadas virtuales)
    var joystick = Vec2.ZERO              // joystick en pantalla (-1..1)
    var tilt = Vec2.ZERO                  // acelerómetro (-1..1), opcional

    // Mouse (coordenadas de pantalla virtual). Con un mouse conectado el botón izquierdo también cuenta como toque.
    var mousePos = Vec2.ZERO
    var mouseWheel = 0.0
    val mouseButtons = HashSet<String>()
    val mouseJustPressed = HashSet<String>()

    val buttons = HashSet<String>()
    val buttonsJustPressed = HashSet<String>()
    val keys = HashSet<String>()
    val keysJustPressed = HashSet<String>()

    fun keyAxis(): Vec2 {
        var x = 0.0; var y = 0.0
        if ("left" in keys || "a" in keys) x -= 1.0
        if ("right" in keys || "d" in keys) x += 1.0
        if ("up" in keys || "w" in keys) y -= 1.0
        if ("down" in keys || "s" in keys) y += 1.0
        return Vec2(x, y).limitLength(1.0)
    }

    fun effectiveJoystick(): Vec2 {
        val k = keyAxis()
        return if (k.lengthSquared() > 0.0) k else joystick
    }

    fun pressButton(b: String) { if (buttons.add(b)) buttonsJustPressed.add(b) }
    fun releaseButton(b: String) { buttons.remove(b) }
    fun pressKey(k: String) { if (keys.add(k)) keysJustPressed.add(k) }
    fun releaseKey(k: String) { keys.remove(k) }

    fun touchDown(p: Vec2) { if (!touching) justPressed = true; touching = true; touchPos = p }
    fun touchMove(p: Vec2) { if (touching) touchPos = p }
    fun mouseMove(p: Vec2) { mousePos = p }
    fun mouseDown(button: String, p: Vec2) { mousePos = p; if (mouseButtons.add(button)) mouseJustPressed.add(button) }
    fun mouseUp(button: String) { mouseButtons.remove(button) }
    fun mouseScroll(amount: Double) { mouseWheel += amount }

    fun touchUp() { if (touching) justReleased = true; touching = false }

    fun endFrame() {
        justPressed = false
        justReleased = false
        buttonsJustPressed.clear()
        keysJustPressed.clear()
        mouseJustPressed.clear()
        mouseWheel = 0.0
    }

    fun reset() {
        touching = false; justPressed = false; justReleased = false; touches.clear()
        joystick = Vec2.ZERO; mouseButtons.clear(); mouseJustPressed.clear(); mouseWheel = 0.0; buttons.clear(); buttonsJustPressed.clear(); keys.clear(); keysJustPressed.clear()
    }
}

/** El objeto global `Input` visible desde los scripts. */
class InputHost(private val world: World) : HostObject {
    override val typeName = "Input"
    private val inp get() = world.input

    override fun getProp(name: String): Any? = when (name) {
        "joystick" -> inp.effectiveJoystick()
        "tilt" -> inp.tilt
        else -> NoSuch
    }

    override fun setProp(name: String, value: Any?) = false

    override fun callMethod(name: String, args: List<Any?>): Any? = when (name) {
        "is_touching" -> inp.touching
        "just_touched" -> inp.justPressed
        "just_released" -> inp.justReleased
        "mouse_position" -> inp.mousePos
        "mouse_world_position" -> world.screenToWorld(inp.mousePos)
        "mouse_wheel" -> inp.mouseWheel
        "is_mouse_button_pressed" -> args.getOrNull(0).toString().lowercase() in inp.mouseButtons
        "is_mouse_button_just_pressed", "just_clicked" -> (args.getOrNull(0)?.toString() ?: "left").lowercase() in inp.mouseJustPressed
        "touch_position" -> inp.touchPos
        "touch_world_position" -> world.screenToWorld(inp.touchPos)
        "get_touch_count" -> inp.touches.size.toLong()
        "get_joystick" -> inp.effectiveJoystick()
        "get_tilt" -> inp.tilt
        "is_button_pressed" -> args.getOrNull(0).toString().uppercase() in inp.buttons.map { it.uppercase() }
        "is_button_just_pressed" -> args.getOrNull(0).toString().uppercase() in inp.buttonsJustPressed.map { it.uppercase() }
        "is_key_pressed" -> args.getOrNull(0).toString().lowercase() in inp.keys
        "is_key_just_pressed" -> args.getOrNull(0).toString().lowercase() in inp.keysJustPressed
        else -> NoSuch
    }
}
