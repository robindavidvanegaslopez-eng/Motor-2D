package com.motor2d.engine

import com.motor2d.core.Colors
import com.motor2d.core.GdColor
import com.motor2d.core.Vec2
import com.motor2d.script.Fmt
import com.motor2d.script.HostObject
import com.motor2d.script.Interpreter
import com.motor2d.script.NoSuch
import com.motor2d.script.ScriptError
import com.motor2d.script.ScriptInstance

enum class PT { FLOAT, INT, BOOL, VEC2, COLOR, STRING, TEXT, ENUM, IMAGE, SCRIPT }

/** Definición de una propiedad editable de un componente (el Inspector se genera con esto). */
class Prop(
    val name: String,
    val label: String,
    val type: PT,
    val def: Any?,
    val options: List<String> = emptyList()
)

private fun err(msg: String): Nothing = throw ScriptError(msg)

object Coerce {
    fun toDouble(v: Any?, what: String): Double = when (v) {
        is Double -> v
        is Long -> v.toDouble()
        is Int -> v.toDouble()
        is Boolean -> if (v) 1.0 else 0.0
        else -> err("'$what' necesita un número, no ${Interpreter.typeName(v)}")
    }

    fun toVec(v: Any?, what: String): Vec2 = when (v) {
        is Vec2 -> v
        is List<*> -> if (v.size == 2) Vec2(toDouble(v[0], what), toDouble(v[1], what)) else err("'$what' necesita 2 números")
        else -> err("'$what' necesita un Vector2, no ${Interpreter.typeName(v)}")
    }

    fun toArgb(v: Any?, what: String): Int = when (v) {
        is GdColor -> v.toArgb()
        is String -> Colors.parse(v) ?: err("Color desconocido '$v' en '$what'")
        is Int -> v
        is Long -> v.toInt()
        else -> err("'$what' necesita un Color (por ejemplo Color(1,0,0) o \"red\")")
    }

    fun forProp(p: Prop, v: Any?): Any? = when (p.type) {
        PT.FLOAT -> toDouble(v, p.name)
        PT.INT -> toDouble(v, p.name).toLong()
        PT.BOOL -> Interpreter.truthy(v)
        PT.VEC2 -> toVec(v, p.name)
        PT.COLOR -> toArgb(v, p.name)
        PT.STRING, PT.TEXT, PT.IMAGE, PT.SCRIPT -> Fmt.str(v)
        PT.ENUM -> {
            val s = Fmt.str(v).lowercase()
            p.options.firstOrNull { it.lowercase() == s } ?: err("'${p.name}' debe ser uno de: ${p.options.joinToString(", ")}")
        }
    }

    /** Valor guardado -> JSON */
    fun toJson(p: Prop, v: Any?): Any? = when (p.type) {
        PT.VEC2 -> (v as Vec2).let { listOf(it.x, it.y) }
        PT.COLOR -> Colors.toHex(v as Int)
        PT.INT -> v as Long
        else -> v
    }

    /** JSON -> valor interno (tolerante con datos incompletos) */
    fun fromJson(p: Prop, j: Any?): Any? {
        if (j == null) return p.def
        return try {
            when (p.type) {
                PT.VEC2 -> toVec(j, p.name)
                PT.COLOR -> toArgb(j, p.name)
                else -> forProp(p, j)
            }
        } catch (e: ScriptError) {
            p.def
        }
    }
}

/** Convierte un valor interno al valor que ve el script. */
internal fun forScript(p: Prop, v: Any?): Any? = when (p.type) {
    PT.COLOR -> GdColor.fromArgb(v as Int)
    else -> v
}

open class Component(val type: String, val schema: List<Prop>) : HostObject {
    lateinit var owner: GameObject
    val values = LinkedHashMap<String, Any?>()

    init {
        for (p in schema) values[p.name] = p.def
    }

    override val typeName: String get() = type

    fun prop(name: String): Prop? = schema.firstOrNull { it.name == name }
    fun f(name: String): Double = values[name] as Double
    fun i(name: String): Long = values[name] as Long
    fun b(name: String): Boolean = values[name] as Boolean
    fun v(name: String): Vec2 = values[name] as Vec2
    fun c(name: String): Int = values[name] as Int
    fun s(name: String): String = values[name] as String

    override fun getProp(name: String): Any? {
        val p = prop(name) ?: return NoSuch
        return forScript(p, values[name])
    }

    override fun setProp(name: String, value: Any?): Boolean {
        val p = prop(name) ?: return false
        values[name] = Coerce.forProp(p, value)
        return true
    }

    override fun callMethod(name: String, args: List<Any?>): Any? = NoSuch

    open fun toJson(): MutableMap<String, Any?> {
        val m = LinkedHashMap<String, Any?>()
        m["type"] = type
        for (p in schema) m[p.name] = Coerce.toJson(p, values[p.name])
        return m
    }

    open fun loadJson(j: Map<String, Any?>) {
        for (p in schema) if (j.containsKey(p.name)) values[p.name] = Coerce.fromJson(p, j[p.name])
    }

    open fun copyTo(dst: Component) {
        for ((k, v) in values) dst.values[k] = v
    }
}

// ---------------------------------------------------------------------
class SpriteRenderer : Component("SpriteRenderer", SCHEMA) {
    companion object {
        val SCHEMA = listOf(
            Prop("shape", "Forma", PT.ENUM, "rect", listOf("rect", "circle", "image")),
            Prop("size", "Tamaño", PT.VEC2, Vec2(64.0, 64.0)),
            Prop("color", "Color", PT.COLOR, 0xFF4FC3F7.toInt()),
            Prop("image", "Imagen", PT.IMAGE, ""),
            Prop("frames", "Cuadros de animación (archivos separados por comas)", PT.TEXT, ""),
            Prop("fps", "Cuadros por segundo", PT.FLOAT, 8.0),
            Prop("autoplay", "Animar al empezar", PT.BOOL, true),
            Prop("loop", "Repetir la animación", PT.BOOL, true),
            Prop("flip_x", "Voltear horizontal", PT.BOOL, false),
            Prop("order", "Orden de dibujo", PT.INT, 0L),
            Prop("visible", "Visible", PT.BOOL, true)
        )
    }

    // ---- Animación por cuadros ----
    // «frames» puede ser una lista simple («a.png, b.png») o varias animaciones con nombre
    // («idle: a.png, b.png; walk: c.png, d.png, e.png»).
    private var parsedFor = "\u0000"
    private var parsed: Map<String, List<String>> = emptyMap()
    var animName = ""
    var animTime = 0.0
    var animPlaying = true

    /** Animaciones disponibles, por nombre. Una lista sin nombre se llama «default». */
    fun animations(): Map<String, List<String>> {
        val t = s("frames")
        if (t != parsedFor) {
            parsedFor = t
            val m = LinkedHashMap<String, List<String>>()
            for (part in t.split(';')) {
                val seg = part.trim()
                if (seg.isEmpty()) continue
                val colon = seg.indexOf(':')
                val name = if (colon > 0) seg.substring(0, colon).trim() else "default"
                val files = (if (colon > 0) seg.substring(colon + 1) else seg).split(',').map { it.trim() }.filter { it.isNotEmpty() }
                if (files.isNotEmpty()) m[name] = files
            }
            parsed = m
        }
        return parsed
    }

    private fun currentFrames(): List<String> {
        val a = animations()
        if (a.isEmpty()) return emptyList()
        return a[animName] ?: a.values.first()
    }

    /** Número del cuadro que toca ahora (0 si no hay animación). */
    fun frameIndex(): Int {
        val fr = currentFrames()
        if (fr.size <= 1) return 0
        val k = Math.floor(animTime * Math.max(f("fps"), 0.0)).toInt()
        return if (b("loop")) Math.floorMod(k, fr.size) else Math.min(k, fr.size - 1)
    }

    /** El archivo de imagen que hay que dibujar ahora. */
    fun currentImage(): String {
        val fr = currentFrames()
        return if (fr.isEmpty()) s("image") else fr[frameIndex()]
    }

    fun advance(dt: Double) {
        if (animPlaying && currentFrames().size > 1) animTime += dt
    }

    fun play(name: String?) {
        val n = name ?: ""
        if (n != animName || !animPlaying) { animName = n; animTime = 0.0 }
        animPlaying = true
    }

    fun stopAnimation() { animPlaying = false }

    /** Vuelve al estado de inicio (al empezar el juego). */
    fun resetAnimation() { animName = ""; animTime = 0.0; animPlaying = b("autoplay") }

    override fun callMethod(name: String, args: List<Any?>): Any? = when (name) {
        "play" -> { play(args.getOrNull(0)?.toString()); null }
        "stop" -> { stopAnimation(); null }
        "is_playing" -> animPlaying
        else -> super.callMethod(name, args)
    }
}

class Label : Component("Label", SCHEMA) {
    companion object {
        val SCHEMA = listOf(
            Prop("text", "Texto", PT.TEXT, "Texto"),
            Prop("font_size", "Tamaño de letra", PT.FLOAT, 32.0),
            Prop("color", "Color", PT.COLOR, 0xFFFFFFFF.toInt()),
            Prop("align", "Alineación", PT.ENUM, "center", listOf("left", "center", "right")),
            Prop("order", "Orden de dibujo", PT.INT, 10L),
            Prop("visible", "Visible", PT.BOOL, true)
        )
    }
}

class Camera2D : Component("Camera2D", SCHEMA) {
    companion object {
        val SCHEMA = listOf(
            Prop("zoom", "Zoom", PT.FLOAT, 1.0),
            Prop("background", "Color de fondo", PT.COLOR, 0xFF1B1F2A.toInt())
        )
    }
}

abstract class Collider(type: String, schema: List<Prop>) : Component(type, schema) {
    val isTrigger: Boolean get() = b("is_trigger")
}

class BoxCollider2D : Collider("BoxCollider2D", SCHEMA) {
    companion object {
        val SCHEMA = listOf(
            Prop("size", "Tamaño", PT.VEC2, Vec2(64.0, 64.0)),
            Prop("offset", "Desplazamiento", PT.VEC2, Vec2.ZERO),
            Prop("is_trigger", "Es disparador (sin choque)", PT.BOOL, false),
            Prop("bounciness", "Rebote (0-1)", PT.FLOAT, 0.0),
            Prop("friction", "Fricción", PT.FLOAT, 0.4)
        )
    }
}

class CircleCollider2D : Collider("CircleCollider2D", SCHEMA) {
    companion object {
        val SCHEMA = listOf(
            Prop("radius", "Radio", PT.FLOAT, 32.0),
            Prop("offset", "Desplazamiento", PT.VEC2, Vec2.ZERO),
            Prop("is_trigger", "Es disparador (sin choque)", PT.BOOL, false),
            Prop("bounciness", "Rebote (0-1)", PT.FLOAT, 0.0),
            Prop("friction", "Fricción", PT.FLOAT, 0.4)
        )
    }
}

class Rigidbody2D : Component("Rigidbody2D", SCHEMA) {
    companion object {
        val SCHEMA = listOf(
            Prop("body_type", "Tipo de cuerpo", PT.ENUM, "dynamic", listOf("dynamic", "kinematic", "static")),
            Prop("mass", "Masa", PT.FLOAT, 1.0),
            Prop("gravity_scale", "Escala de gravedad", PT.FLOAT, 1.0),
            Prop("drag", "Resistencia del aire", PT.FLOAT, 0.0),
            Prop("freeze_rotation", "Bloquear rotación", PT.BOOL, false)
        )
    }

    // Estado de simulación (no se guarda en la escena)
    var velocity = Vec2.ZERO
    var angularVelocity = 0.0   // grados por segundo
    var force = Vec2.ZERO
    var onFloor = false
    var onWall = false
    var onCeiling = false

    val isDynamic: Boolean get() = s("body_type") == "dynamic"
    val isKinematic: Boolean get() = s("body_type") == "kinematic"

    override fun getProp(name: String): Any? = when (name) {
        "velocity" -> velocity
        "angular_velocity" -> angularVelocity
        else -> super.getProp(name)
    }

    override fun setProp(name: String, value: Any?): Boolean = when (name) {
        "velocity" -> { velocity = Coerce.toVec(value, name); true }
        "angular_velocity" -> { angularVelocity = Coerce.toDouble(value, name); true }
        else -> super.setProp(name, value)
    }

    override fun callMethod(name: String, args: List<Any?>): Any? = when (name) {
        "add_force" -> { force += Coerce.toVec(args.getOrNull(0), "add_force"); null }
        "add_impulse" -> {
            if (isDynamic) velocity += Coerce.toVec(args.getOrNull(0), "add_impulse") / f("mass").coerceAtLeast(1e-6)
            null
        }
        "is_on_floor" -> onFloor
        "is_on_wall" -> onWall
        "is_on_ceiling" -> onCeiling
        "stop" -> { velocity = Vec2.ZERO; angularVelocity = 0.0; null }
        else -> NoSuch
    }
}

class ScriptComponent : Component("Script", SCHEMA) {
    companion object {
        val SCHEMA = listOf(Prop("path", "Archivo", PT.SCRIPT, ""))
    }

    /** Valores de las variables @export que el usuario cambió en el Inspector. */
    val exports = LinkedHashMap<String, Any?>()
    var instance: ScriptInstance? = null
    var failed = false

    val path: String get() = s("path")

    override fun toJson(): MutableMap<String, Any?> {
        val m = super.toJson()
        if (exports.isNotEmpty()) {
            val e = LinkedHashMap<String, Any?>()
            for ((k, v) in exports) e[k] = jsonValue(v)
            m["exports"] = e
        }
        return m
    }

    override fun loadJson(j: Map<String, Any?>) {
        super.loadJson(j)
        exports.clear()
        (j["exports"] as? Map<*, *>)?.forEach { (k, v) -> exports[k.toString()] = unjsonValue(v) }
    }

    override fun copyTo(dst: Component) {
        super.copyTo(dst)
        (dst as ScriptComponent).exports.putAll(exports)
    }

    private fun jsonValue(v: Any?): Any? = when (v) {
        is Vec2 -> mapOf("v2" to listOf(v.x, v.y))
        is GdColor -> mapOf("color" to Colors.toHex(v.toArgb()))
        else -> v
    }

    private fun unjsonValue(v: Any?): Any? {
        if (v is Map<*, *>) {
            (v["v2"] as? List<*>)?.let { if (it.size == 2) return Vec2((it[0] as Number).toDouble(), (it[1] as Number).toDouble()) }
            (v["color"] as? String)?.let { c -> Colors.parse(c)?.let { return GdColor.fromArgb(it) } }
        }
        return v
    }
}

object ComponentTypes {
    val all = listOf("SpriteRenderer", "Label", "Rigidbody2D", "BoxCollider2D", "CircleCollider2D", "Camera2D", "Script")

    fun create(type: String): Component? = when (type) {
        "SpriteRenderer" -> SpriteRenderer()
        "Label" -> Label()
        "Rigidbody2D" -> Rigidbody2D()
        "BoxCollider2D" -> BoxCollider2D()
        "CircleCollider2D" -> CircleCollider2D()
        "Camera2D" -> Camera2D()
        "Script" -> ScriptComponent()
        else -> null
    }

    fun displayName(type: String) = when (type) {
        "SpriteRenderer" -> "Sprite (dibujo)"
        "Label" -> "Texto"
        "Rigidbody2D" -> "Rigidbody 2D"
        "BoxCollider2D" -> "Collider de caja"
        "CircleCollider2D" -> "Collider de círculo"
        "Camera2D" -> "Cámara 2D"
        "Script" -> "Script"
        else -> type
    }

    /** Nombres que se aceptan en get_component("...") */
    fun canonical(name: String): String? = when (name.lowercase().replace("_", "").replace(" ", "")) {
        "sprite", "spriterenderer" -> "SpriteRenderer"
        "label", "text" -> "Label"
        "rigidbody", "rigidbody2d" -> "Rigidbody2D"
        "boxcollider", "boxcollider2d" -> "BoxCollider2D"
        "circlecollider", "circlecollider2d" -> "CircleCollider2D"
        "camera", "camera2d" -> "Camera2D"
        "script" -> "Script"
        else -> null
    }
}
