package com.motor2d.app

import android.view.KeyEvent
import com.motor2d.engine.InputState

/** Convierte las teclas del teclado o del mando en la entrada del juego (la misma en el editor y en el juego exportado). */
object GameKeys {
    fun handle(inp: InputState, keyCode: Int, down: Boolean): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) return false
        val button: String? = when (keyCode) {
            KeyEvent.KEYCODE_SPACE, KeyEvent.KEYCODE_Z, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_BUTTON_A -> "A"
            KeyEvent.KEYCODE_X, KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.KEYCODE_BUTTON_B -> "B"
            else -> null
        }
        if (button != null) { if (down) inp.pressButton(button) else inp.releaseButton(button) }
        val name: String = when (keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT -> "left"
            KeyEvent.KEYCODE_DPAD_RIGHT -> "right"
            KeyEvent.KEYCODE_DPAD_UP -> "up"
            KeyEvent.KEYCODE_DPAD_DOWN -> "down"
            KeyEvent.KEYCODE_SPACE -> "space"
            KeyEvent.KEYCODE_ENTER -> "enter"
            else -> KeyEvent.keyCodeToString(keyCode).removePrefix("KEYCODE_").lowercase()
        }
        if (down) inp.pressKey(name) else inp.releaseKey(name)
        return true
    }
}
