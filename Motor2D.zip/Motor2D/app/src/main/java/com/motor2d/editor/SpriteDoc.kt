package com.motor2d.editor

/**
 * Un sprite en edición: una lista de cuadros (todos del mismo tamaño) y la velocidad de la animación.
 * Guarda cada cuadro como un PNG en assets/ y devuelve el texto que se pone en el componente Sprite.
 */
class SpriteDoc(val name: String, val w: Int, val h: Int) {
    val frames = ArrayList<PixelImage>()
    var cur = 0
    var fps = 8.0

    private class State(val frames: List<PixelImage>, val cur: Int)
    private val undoStack = ArrayList<State>()
    private val redoStack = ArrayList<State>()

    init { frames.add(PixelImage(w, h)) }

    val image: PixelImage get() = frames[cur]
    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    private fun snapshot() = State(frames.map { it.copy() }, cur)

    private fun restore(s: State) {
        frames.clear()
        frames.addAll(s.frames.map { it.copy() })
        cur = s.cur.coerceIn(0, frames.size - 1)
    }

    /** Llamar justo antes de cada trazo o cambio: así se puede deshacer. */
    fun checkpoint() {
        undoStack.add(snapshot())
        if (undoStack.size > 40) undoStack.removeAt(0)
        redoStack.clear()
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        redoStack.add(snapshot())
        restore(undoStack.removeAt(undoStack.size - 1))
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        undoStack.add(snapshot())
        restore(redoStack.removeAt(redoStack.size - 1))
    }

    // ---------- Cuadros ----------
    fun addFrame(): Int { checkpoint(); frames.add(cur + 1, PixelImage(w, h)); cur += 1; return cur }
    fun duplicateFrame(): Int { checkpoint(); frames.add(cur + 1, frames[cur].copy()); cur += 1; return cur }

    fun deleteFrame(): Boolean {
        if (frames.size <= 1) return false
        checkpoint()
        frames.removeAt(cur)
        cur = cur.coerceAtMost(frames.size - 1)
        return true
    }

    fun moveFrame(delta: Int): Boolean {
        val to = cur + delta
        if (to < 0 || to >= frames.size) return false
        checkpoint()
        val f = frames.removeAt(cur)
        frames.add(to, f)
        cur = to
        return true
    }

    fun select(i: Int) { cur = i.coerceIn(0, frames.size - 1) }

    /** Imagen mezclada del cuadro anterior (para dibujar con «papel cebolla»); null si es el primero. */
    fun previousFrame(): PixelImage? = if (cur > 0) frames[cur - 1] else null

    // ---------- Archivos ----------
    private fun fileName(i: Int) = if (frames.size == 1) "assets/$name.png" else "assets/${name}_${i + 1}.png"

    /** Escribe los PNG en el proyecto y devuelve el texto de «frames» (vacío si solo hay un cuadro). */
    fun save(project: Project): SavedSprite {
        for (i in frames.indices) project.writeBytes(fileName(i), Png.encode(frames[i]))
        // si antes había más cuadros, quita los sobrantes para no dejar archivos huérfanos
        var k = frames.size + 1
        while (frames.size > 1 && project.exists("assets/${name}_$k.png")) { project.delete("assets/${name}_$k.png"); k++ }
        if (frames.size == 1) {
            var j = 1
            while (project.exists("assets/${name}_$j.png")) { project.delete("assets/${name}_$j.png"); j++ }
        }
        val files = frames.indices.map { fileName(it) }
        return SavedSprite(files.first(), if (files.size > 1) files.joinToString(", ") else "", fps)
    }

    companion object {
        /** Nombre de archivo seguro a partir de lo que escribe el usuario. */
        fun cleanName(raw: String): String {
            val s = raw.trim().filter { it.isLetterOrDigit() || it == '_' || it == '-' }
            return s.ifEmpty { "sprite" }.take(40)
        }

        /** Paleta inicial: 32 colores variados, pensada para pixel art. */
        val PALETTE: IntArray = intArrayOf(
            0xFF000000.toInt(), 0xFF1D2B53.toInt(), 0xFF7E2553.toInt(), 0xFF008751.toInt(),
            0xFFAB5236.toInt(), 0xFF5F574F.toInt(), 0xFFC2C3C7.toInt(), 0xFFFFF1E8.toInt(),
            0xFFFF004D.toInt(), 0xFFFFA300.toInt(), 0xFFFFEC27.toInt(), 0xFF00E436.toInt(),
            0xFF29ADFF.toInt(), 0xFF83769C.toInt(), 0xFFFF77A8.toInt(), 0xFFFFCCAA.toInt(),
            0xFF291814.toInt(), 0xFF111D35.toInt(), 0xFF422136.toInt(), 0xFF125359.toInt(),
            0xFF742F29.toInt(), 0xFF49333B.toInt(), 0xFFA28879.toInt(), 0xFFF3EF7D.toInt(),
            0xFFBE1250.toInt(), 0xFFFF6C24.toInt(), 0xFFA8E72E.toInt(), 0xFF00B543.toInt(),
            0xFF065AB5.toInt(), 0xFF754665.toInt(), 0xFFFF6E59.toInt(), 0x00000000
        )
    }
}

/** Resultado de guardar: primer archivo (para «image»), lista de cuadros (para «frames», vacía si es uno solo) y fps. */
class SavedSprite(val firstImage: String, val frames: String, val fps: Double)
