package com.motor2d.editor

import com.motor2d.core.Colors
import com.motor2d.core.GdColor
import com.motor2d.core.Vec2
import com.motor2d.engine.*
import com.motor2d.script.Fmt
import com.motor2d.script.Interpreter
import com.motor2d.script.Lexer
import com.motor2d.script.Parser
import com.motor2d.script.ScriptError
import com.motor2d.script.ScriptInstance

class ConsoleLine(val text: String, val isError: Boolean)

class ExportInfo(val name: String, val value: Any?, val overridden: Boolean)

/** Todo lo que hace el editor, sin nada de Android, para poder probarlo. */
class EditorModel(val project: Project) : LogSink {
    var world: World = World(project, this)
    var sceneName = "main"
    var selected: GameObject? = null
    var play: World? = null
    val console = ArrayList<ConsoleLine>()
    var onConsole: (() -> Unit)? = null
    var dirty = false

    private val undoStack = ArrayList<String>()
    private val redoStack = ArrayList<String>()

    val activeWorld: World get() = play ?: world
    val isPlaying: Boolean get() = play != null
    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    init { loadScene("main") }

    // ---------- Consola ----------
    override fun log(text: String, isError: Boolean) {
        console.add(ConsoleLine(text, isError))
        while (console.size > 400) console.removeAt(0)
        onConsole?.invoke()
    }

    fun clearConsole() { console.clear(); onConsole?.invoke() }

    // ---------- Escenas ----------
    fun loadScene(name: String) {
        val w = World(project, this)
        val text = project.readText("scenes/$name.json")
        if (text != null) {
            try {
                SceneIO.loadInto(w, SceneIO.parseScene(text), true)
            } catch (e: Exception) {
                log("No se pudo abrir la escena '$name': ${e.message}", true)
            }
        }
        if (w.objects.isEmpty() && text == null) {
            w.viewW = 720.0; w.viewH = 1280.0
            w.addObject(GameObject("Camara").also { it.position = Vec2(360.0, 640.0); it.addComponent(Camera2D()) })
        }
        world = w
        sceneName = name
        selected = null
        undoStack.clear(); redoStack.clear()
        dirty = false
    }

    fun save() {
        project.writeText("scenes/$sceneName.json", SceneIO.sceneToJson(world))
        dirty = false
    }

    fun newScene(rawName: String): String {
        val base = rawName.trim().filter { it.isLetterOrDigit() || it == '_' || it == '-' }.ifEmpty { "escena" }
        var n = base; var i = 2
        while (project.exists("scenes/$n.json")) { n = "$base$i"; i++ }
        save()
        val w = World(null, null)
        w.viewW = world.viewW; w.viewH = world.viewH
        w.addObject(GameObject("Camara").also { it.position = Vec2(w.viewW / 2, w.viewH / 2); it.addComponent(Camera2D()) })
        project.writeText("scenes/$n.json", SceneIO.sceneToJson(w))
        loadScene(n)
        return n
    }

    // ---------- Deshacer ----------
    private fun checkpoint() {
        undoStack.add(SceneIO.sceneToJson(world))
        if (undoStack.size > 60) undoStack.removeAt(0)
        redoStack.clear()
        dirty = true
    }

    /** Llamar antes de una edición continua (arrastrar un objeto, por ejemplo). */
    fun beginEdit() = checkpoint()

    private fun restore(json: String) {
        val selId = selected?.id
        val w = World(project, this)
        SceneIO.loadInto(w, SceneIO.parseScene(json), true)
        world = w
        selected = selId?.let { w.findById(it) }
        dirty = true
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        redoStack.add(SceneIO.sceneToJson(world))
        restore(undoStack.removeAt(undoStack.size - 1))
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        undoStack.add(SceneIO.sceneToJson(world))
        restore(redoStack.removeAt(redoStack.size - 1))
    }

    // ---------- Jerarquía ----------
    fun flatten(): List<Pair<GameObject, Int>> {
        val out = ArrayList<Pair<GameObject, Int>>()
        fun add(o: GameObject, depth: Int) {
            out.add(Pair(o, depth))
            for (c in o.children) add(c, depth + 1)
        }
        for (o in world.objects) if (o.parent == null) add(o, 0)
        return out
    }

    fun select(o: GameObject?) { selected = o }

    fun topObjectAt(p: Vec2): GameObject? {
        var best: GameObject? = null
        var bestOrder = Long.MIN_VALUE
        for (o in world.objects) {
            if (!o.isActiveInHierarchy() && !o.active) { /* los objetos inactivos también se pueden seleccionar */ }
            if (!o.containsPoint(p)) continue
            val order = (o.sprite?.i("order") ?: o.label?.i("order") ?: 0L)
            if (best == null || order >= bestOrder) { best = o; bestOrder = order }
        }
        return best
    }

    // ---------- Crear y borrar ----------
    fun createObject(kind: String, at: Vec2): GameObject {
        checkpoint()
        val o = GameObject("")
        o.position = Vec2(Math.round(at.x).toDouble(), Math.round(at.y).toDouble())
        val name: String
        when (kind) {
            "square" -> { name = "Cuadrado"; o.addComponent(SpriteRenderer()) }
            "circle" -> {
                name = "Circulo"
                o.addComponent(SpriteRenderer().also { it.values["shape"] = "circle"; it.values["color"] = 0xFFFFB74D.toInt() })
            }
            "text" -> { name = "Texto"; o.addComponent(Label()) }
            "platform" -> {
                name = "Plataforma"
                val sz = Vec2(240.0, 32.0)
                o.addComponent(SpriteRenderer().also { it.values["size"] = sz; it.values["color"] = 0xFF8D6E63.toInt() })
                o.addComponent(BoxCollider2D().also { it.values["size"] = sz })
                o.addComponent(Rigidbody2D().also { it.values["body_type"] = "static" })
            }
            "box" -> {
                name = "Caja"
                o.addComponent(SpriteRenderer().also { it.values["color"] = 0xFFA1887F.toInt() })
                o.addComponent(BoxCollider2D())
                o.addComponent(Rigidbody2D())
            }
            "ball" -> {
                name = "Pelota"
                o.addComponent(SpriteRenderer().also {
                    it.values["shape"] = "circle"; it.values["color"] = 0xFFEF5350.toInt(); it.values["size"] = Vec2(48.0, 48.0)
                })
                o.addComponent(CircleCollider2D().also { it.values["radius"] = 24.0; it.values["bounciness"] = 0.5 })
                o.addComponent(Rigidbody2D())
            }
            "trigger" -> {
                name = "Zona"
                o.addComponent(SpriteRenderer().also { it.values["color"] = 0x6600E676 })
                o.addComponent(BoxCollider2D().also { it.values["is_trigger"] = true })
            }
            "camera" -> { name = "Camara"; o.addComponent(Camera2D()) }
            else -> name = "Objeto vacio"
        }
        o.name = SceneIO.nameFor(world, name)
        world.addObject(o)
        selected = o
        return o
    }

    fun duplicate(o: GameObject): GameObject {
        checkpoint()
        val c = SceneIO.cloneSubtree(world, o)
        c.name = SceneIO.nameFor(world, o.name)
        c.position = o.position + Vec2(24.0, 24.0)
        if (o.parent != null) c.reparent(o.parent)
        selected = c
        return c
    }

    fun delete(o: GameObject) {
        checkpoint()
        fun remove(x: GameObject) {
            for (c in ArrayList(x.children)) remove(c)
            world.objects.remove(x)
            x.parent?.children?.remove(x)
            if (selected === x) selected = null
        }
        remove(o)
    }

    // ---------- Propiedades del objeto ----------
    fun rename(o: GameObject, name: String) {
        val n = name.trim()
        if (n.isEmpty() || n == o.name) return
        checkpoint(); o.name = n
    }

    fun setTag(o: GameObject, tag: String) { if (tag != o.tag) { checkpoint(); o.tag = tag.trim() } }
    fun setActive(o: GameObject, a: Boolean) { if (a != o.active) { checkpoint(); o.active = a } }

    fun setParent(o: GameObject, p: GameObject?) {
        if (o.parent === p) return
        checkpoint(); o.reparent(p)
    }

    // ---------- Componentes ----------
    fun addComponent(o: GameObject, type: String): String? {
        val single = type != "Script"
        if (single && o.findComponent(type) != null) return "Este objeto ya tiene ${ComponentTypes.displayName(type)}"
        if ((type == "BoxCollider2D" || type == "CircleCollider2D") && o.colliders.isNotEmpty())
            return "Un objeto solo puede tener un collider"
        val c = ComponentTypes.create(type) ?: return "Componente desconocido"
        checkpoint()
        // Ajusta el tamaño del collider al dibujo para no tener que escribirlo a mano
        val sp = o.sprite
        if (sp != null) {
            val sz = sp.v("size")
            if (c is BoxCollider2D) c.values["size"] = sz
            if (c is CircleCollider2D) c.values["radius"] = Math.min(sz.x, sz.y) / 2
        }
        o.addComponent(c)
        return null
    }

    /** Añade un comportamiento prefabricado: copia su script al proyecto (sin pisar uno ya editado) y prepara el objeto. */
    fun addBehavior(o: GameObject, b: Behavior): String {
        checkpoint()
        if (!project.exists(b.path)) project.writeText(b.path, b.source)
        return Behaviors.applyTo(o, b)
    }

    fun removeComponent(o: GameObject, c: Component) { checkpoint(); o.removeComponent(c) }

    fun setPosition(o: GameObject, p: Vec2) { o.position = p; dirty = true }
    fun setRotation(o: GameObject, deg: Double) { o.rotation = deg; dirty = true }
    fun setScale(o: GameObject, s: Vec2) { o.scale = s; dirty = true }

    // ---------- Texto <-> valores ----------
    fun valueToText(p: Prop, v: Any?): String = when (p.type) {
        PT.FLOAT -> Fmt.num(v as Double)
        PT.VEC2 -> (v as Vec2).let { Fmt.num(it.x) + ", " + Fmt.num(it.y) }
        PT.COLOR -> Colors.toHex(v as Int)
        PT.BOOL -> if (v as Boolean) "true" else "false"
        else -> v?.toString() ?: ""
    }

    fun parseText(p: Prop, text: String): Any? {
        val t = text.trim()
        return when (p.type) {
            PT.FLOAT -> t.replace(',', '.').toDoubleOrNull() ?: throw IllegalArgumentException("Escribe un número")
            PT.INT -> t.toLongOrNull() ?: throw IllegalArgumentException("Escribe un número entero")
            PT.BOOL -> when (t.lowercase()) {
                "true", "si", "sí", "1" -> true
                "false", "no", "0" -> false
                else -> throw IllegalArgumentException("Escribe true o false")
            }
            PT.VEC2 -> parseVec(t)
            PT.COLOR -> Colors.parse(t) ?: throw IllegalArgumentException("Color no válido. Usa por ejemplo #ff8800 o red")
            PT.ENUM -> p.options.firstOrNull { it.equals(t, true) }
                ?: throw IllegalArgumentException("Opciones: " + p.options.joinToString(", "))
            else -> text
        }
    }

    fun parseVec(t: String): Vec2 {
        val first = t.split(';', ' ').filter { it.isNotBlank() }
        val parts = if (first.size == 2) first else t.split(',').filter { it.isNotBlank() }
        if (parts.size != 2) throw IllegalArgumentException("Escribe dos números, por ejemplo 100, 50")
        val x = parts[0].trim().trimEnd(',').replace(',', '.').toDoubleOrNull()
        val y = parts[1].trim().trimEnd(',').replace(',', '.').toDoubleOrNull()
        if (x == null || y == null) throw IllegalArgumentException("Escribe dos números, por ejemplo 100, 50")
        return Vec2(x, y)
    }

    /** Cambia una propiedad de un componente desde texto. Devuelve un mensaje de error o null. */
    fun setValue(c: Component, p: Prop, text: String): String? {
        return try {
            val v = parseText(p, text)
            if (c.values[p.name] != v) { checkpoint(); c.values[p.name] = v }
            null
        } catch (e: IllegalArgumentException) { e.message }
    }

    fun setBool(c: Component, p: Prop, v: Boolean) { if (c.values[p.name] != v) { checkpoint(); c.values[p.name] = v } }

    // ---------- Variables @export de los scripts ----------
    fun exportsFor(sc: ScriptComponent): List<ExportInfo> {
        if (sc.path.isEmpty()) return emptyList()
        return try {
            val cls = world.getScriptClass(sc.path)
            val inst = ScriptInstance(cls, Interpreter(null), null)
            inst.init(emptyMap())
            cls.exports.map { m ->
                val over = sc.exports.containsKey(m.name)
                ExportInfo(m.name, if (over) sc.exports[m.name] else inst.vars[m.name], over)
            }
        } catch (e: Exception) { emptyList() }
    }

    fun exportToText(v: Any?): String = when (v) {
        is Vec2 -> Fmt.num(v.x) + ", " + Fmt.num(v.y)
        is GdColor -> Colors.toHex(v.toArgb())
        else -> Fmt.str(v)
    }

    fun setExport(sc: ScriptComponent, info: ExportInfo, text: String): String? {
        val t = text.trim()
        return try {
            val nv: Any? = when (info.value) {
                is Double -> t.replace(',', '.').toDoubleOrNull() ?: return "Escribe un número"
                is Long -> t.toLongOrNull() ?: return "Escribe un número entero"
                is Boolean -> when (t.lowercase()) { "true", "si", "sí" -> true; "false", "no" -> false; else -> return "Escribe true o false" }
                is Vec2 -> parseVec(t)
                is GdColor -> GdColor.fromArgb(Colors.parse(t) ?: return "Color no válido")
                else -> text
            }
            checkpoint(); sc.exports[info.name] = nv
            null
        } catch (e: IllegalArgumentException) { e.message }
    }

    fun resetExport(sc: ScriptComponent, name: String) { checkpoint(); sc.exports.remove(name) }

    // ---------- Scripts ----------
    fun scriptPaths(): List<String> = project.scripts()

    fun createScript(rawName: String): String {
        val base = rawName.trim().removeSuffix(".gd").filter { it.isLetterOrDigit() || it == '_' }.ifEmpty { "script" }
        var n = base; var i = 2
        while (project.exists("scripts/$n.gd")) { n = "$base$i"; i++ }
        project.writeText("scripts/$n.gd", Templates.newScript())
        return "scripts/$n.gd"
    }

    /** Comprueba la sintaxis. Devuelve el error con su línea o null si está bien. */
    fun checkScript(path: String, text: String): ScriptError? = try {
        Parser(Lexer(text, path).tokenize(), path).parseScript(); null
    } catch (e: ScriptError) { e }

    /** Guarda el script. Se guarda aunque tenga errores, y se devuelve el error para mostrarlo. */
    fun saveScript(path: String, text: String): ScriptError? {
        project.writeText(path, text)
        world.clearScriptCache()
        return checkScript(path, text)
    }

    fun deleteScript(path: String) {
        project.delete(path)
        world.clearScriptCache()
    }

    // ---------- Bloques visuales ----------
    /** Crea un script de bloques para el objeto y lo añade como componente Script. Devuelve el nombre del script de bloques. */
    fun addBlocks(o: GameObject): String {
        checkpoint()
        val base = BlockCompiler.ident(o.name, "bloques")
        var n = base
        var i = 2
        while (project.exists(Blocks.blocksPath(n))) { n = "$base$i"; i++ }
        val s = BlockScript()
        val start = BlockCatalog.create("ev_start")
        start.children.add(BlockCatalog.create("jg_print"))
        s.events.add(start)
        saveBlocks(n, s)
        o.addComponent(ScriptComponent().also { it.values["path"] = Blocks.scriptPath(n) })
        return n
    }

    fun loadBlocks(name: String): BlockScript? {
        val text = project.readText(Blocks.blocksPath(name)) ?: return null
        return try { Blocks.fromJson(text) } catch (e: Exception) { null }
    }

    /** Guarda los bloques y el GDScript que generan. Devuelve el error de sintaxis del código generado, si lo hay. */
    fun saveBlocks(name: String, s: BlockScript): ScriptError? {
        project.writeText(Blocks.blocksPath(name), Blocks.toJson(s))
        return saveScript(Blocks.scriptPath(name), BlockCompiler.compile(s).text)
    }

    /** Si el script con esa ruta se genera desde bloques, devuelve el nombre del script de bloques. */
    fun blocksNameOf(path: String): String? {
        if (!path.startsWith(Blocks.FOLDER + "/") || !path.endsWith(".gd")) return null
        val name = path.removePrefix(Blocks.FOLDER + "/").removeSuffix(".gd")
        return if (project.exists(Blocks.blocksPath(name))) name else null
    }

    // ---------- Sprites dibujados en la app ----------
    /** Guarda el sprite y lo aplica al objeto (crea el componente Sprite si no lo tiene). Tamaño: se conserva el actual si ya había uno con imagen. */
    fun applySprite(o: GameObject, doc: SpriteDoc): SavedSprite {
        checkpoint()
        val saved = doc.save(project)
        var sp = o.sprite
        val hadImage = sp != null && sp.s("image").isNotEmpty()
        if (sp == null) { sp = SpriteRenderer(); o.addComponent(sp) }
        sp.values["shape"] = "image"
        sp.values["image"] = saved.firstImage
        sp.values["frames"] = saved.frames
        sp.values["fps"] = saved.fps
        if (!hadImage) sp.values["size"] = Vec2(doc.w * 4.0, doc.h * 4.0)
        return saved
    }

    // ---------- Imágenes ----------
    fun imagePaths(): List<String> = project.images()

    fun importImage(fileName: String, data: ByteArray): String {
        val base = fileName.substringBeforeLast('.').filter { it.isLetterOrDigit() || it == '_' || it == '-' }.ifEmpty { "imagen" }
        val ext = fileName.substringAfterLast('.', "png").lowercase().let { if (it in listOf("png", "jpg", "jpeg", "webp")) it else "png" }
        var n = "$base.$ext"; var i = 2
        while (project.exists("assets/$n")) { n = "$base$i.$ext"; i++ }
        project.writeBytes("assets/$n", data)
        return "assets/$n"
    }

    // ---------- Pantalla del juego ----------
    fun setLandscape(landscape: Boolean) {
        val a = Math.max(world.viewW, world.viewH); val b = Math.min(world.viewW, world.viewH)
        checkpoint()
        if (landscape) { world.viewW = a; world.viewH = b } else { world.viewW = b; world.viewH = a }
    }

    val isLandscape: Boolean get() = world.viewW > world.viewH

    fun setGravity(g: Vec2) { checkpoint(); world.physics.gravity = g }

    // ---------- Ejecutar ----------
    fun startPlay(): Boolean {
        save()
        val json = project.readText("scenes/$sceneName.json") ?: return false
        val w = World(project, this)
        SceneIO.loadInto(w, SceneIO.parseScene(json), true)
        log("▶ Ejecutando '$sceneName'", false)
        play = w
        w.start()
        return true
    }

    fun stopPlay() {
        if (play != null) log("■ Detenido", false)
        play = null
    }

    /** Mundo ya cargado listo para usar en pruebas, sin pasar por el disco. */
    fun loadedForTest(): World = world
}
