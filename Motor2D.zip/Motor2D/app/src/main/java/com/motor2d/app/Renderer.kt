package com.motor2d.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import com.motor2d.core.Vec2
import com.motor2d.editor.Project
import com.motor2d.engine.BoxCollider2D
import com.motor2d.engine.CircleCollider2D
import com.motor2d.engine.GameObject
import com.motor2d.engine.World

/** Dibuja un World en un Canvas de Android (sin saber nada de la interfaz). */
class Renderer(private val project: Project) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val bitmaps = HashMap<String, Bitmap?>()

    fun clearCache() { bitmaps.clear() }

    private fun bitmap(path: String): Bitmap? {
        if (path.isEmpty()) return null
        if (bitmaps.containsKey(path)) return bitmaps[path]
        val data = project.readBytes(path)
        val bmp = if (data == null) null else try { BitmapFactory.decodeByteArray(data, 0, data.size) } catch (e: Exception) { null }
        bitmaps[path] = bmp
        return bmp
    }

    private fun withAlpha(color: Int, factor: Float): Int {
        val a = (Color.alpha(color) * factor).toInt().coerceIn(0, 255)
        return (color and 0x00FFFFFF) or (a shl 24)
    }

    private class Item(val o: GameObject, val order: Long)

    /** Mitad del tamaño del objeto en unidades locales (antes de aplicar la escala). */
    fun localHalfSize(o: GameObject): Vec2 {
        val sp = o.sprite
        if (sp != null) { val s = sp.v("size"); return Vec2(Math.abs(s.x) / 2, Math.abs(s.y) / 2) }
        for (c in o.colliders) {
            if (c is BoxCollider2D) { val s = c.v("size"); return Vec2(Math.abs(s.x) / 2, Math.abs(s.y) / 2) }
            if (c is CircleCollider2D) { val r = c.f("radius"); return Vec2(r, r) }
        }
        val lb = o.label
        if (lb != null) {
            text.textSize = lb.f("font_size").toFloat()
            val lines = lb.s("text").split("\n")
            var wMax = 0f
            for (l in lines) wMax = maxOf(wMax, text.measureText(l))
            val fm = text.fontMetrics
            return Vec2(wMax / 2.0 + 4.0, lines.size * (fm.descent - fm.ascent) / 2.0 + 4.0)
        }
        return Vec2(20.0, 20.0)
    }

    fun drawWorld(c: Canvas, w: World, editor: Boolean) {
        val items = ArrayList<Item>()
        for (o in w.objects) {
            if (o.destroyed) continue
            if (!editor && !o.isActiveInHierarchy()) continue
            val sp = o.sprite
            val lb = o.label
            if (sp == null && lb == null) continue
            items.add(Item(o, sp?.i("order") ?: lb?.i("order") ?: 0L))
        }
        items.sortBy { it.order }
        for (item in items) drawObject(c, item.o, editor && !item.o.isActiveInHierarchy())
    }

    private fun drawObject(c: Canvas, o: GameObject, dim: Boolean) {
        val p = o.worldPosition()
        val s = o.worldScale()
        val alpha = if (dim) 0.3f else 1f
        c.save()
        c.translate(p.x.toFloat(), p.y.toFloat())
        c.rotate(o.worldRotation().toFloat())
        c.scale(s.x.toFloat(), s.y.toFloat())

        val sp = o.sprite
        if (sp != null && sp.b("visible")) {
            val sz = sp.v("size")
            val hx = (sz.x / 2).toFloat()
            val hy = (sz.y / 2).toFloat()
            rect.set(-hx, -hy, hx, hy)
            val shape = sp.s("shape")
            if (shape == "image") {
                c.save()
                if (sp.b("flip_x")) c.scale(-1f, 1f)
                val bmp = bitmap(sp.s("image"))
                if (bmp != null) {
                    fill.color = withAlpha(Color.WHITE, alpha)
                    c.drawBitmap(bmp, null, rect, fill)
                } else {
                    fill.color = withAlpha(0xFF616161.toInt(), alpha)
                    c.drawRect(rect, fill)
                    line.color = withAlpha(Color.WHITE, alpha)
                    line.strokeWidth = 2f
                    c.drawLine(-hx, -hy, hx, hy, line)
                    c.drawLine(-hx, hy, hx, -hy, line)
                }
                c.restore()
            } else {
                fill.color = withAlpha(sp.c("color"), alpha)
                if (shape == "circle") c.drawOval(rect, fill) else c.drawRect(rect, fill)
            }
        }

        val lb = o.label
        if (lb != null && lb.b("visible")) {
            text.color = withAlpha(lb.c("color"), alpha)
            text.textSize = lb.f("font_size").toFloat().coerceAtLeast(1f)
            val align = lb.s("align")
            text.textAlign = when (align) {
                "left" -> Paint.Align.LEFT
                "right" -> Paint.Align.RIGHT
                else -> Paint.Align.CENTER
            }
            val lines = lb.s("text").split("\n")
            val fm = text.fontMetrics
            val lineH = fm.descent - fm.ascent
            var y = -lines.size * lineH / 2f - fm.ascent
            for (l in lines) {
                c.drawText(l, 0f, y, text)
                y += lineH
            }
        }
        c.restore()
    }

    /** Contornos de los colliders (solo en el editor). */
    fun drawColliders(c: Canvas, w: World, lineWidth: Float) {
        line.strokeWidth = lineWidth
        for (o in w.objects) {
            if (o.destroyed || o.colliders.isEmpty()) continue
            val p = o.worldPosition()
            val s = o.worldScale()
            c.save()
            c.translate(p.x.toFloat(), p.y.toFloat())
            c.rotate(o.worldRotation().toFloat())
            for (col in o.colliders) {
                line.color = if (col.isTrigger) 0xCCFFEB3B.toInt() else 0xCC66FF99.toInt()
                if (col is BoxCollider2D) {
                    val sz = col.v("size"); val off = col.v("offset")
                    val hx = Math.abs(sz.x * s.x) / 2; val hy = Math.abs(sz.y * s.y) / 2
                    val cx = off.x * s.x; val cy = off.y * s.y
                    rect.set((cx - hx).toFloat(), (cy - hy).toFloat(), (cx + hx).toFloat(), (cy + hy).toFloat())
                    c.drawRect(rect, line)
                } else if (col is CircleCollider2D) {
                    val off = col.v("offset")
                    val r = col.f("radius") * maxOf(Math.abs(s.x), Math.abs(s.y))
                    c.drawCircle((off.x * s.x).toFloat(), (off.y * s.y).toFloat(), r.toFloat(), line)
                }
            }
            c.restore()
        }
    }
}
