package com.motor2d.app

import android.content.Context
import com.motor2d.editor.Behavior
import com.motor2d.editor.Behaviors

/** La biblioteca de comportamientos prefabricados: son archivos .gd dentro de la app (assets/behaviors). */
object BehaviorCatalog {
    private var cache: List<Behavior>? = null

    fun load(ctx: Context): List<Behavior> {
        cache?.let { return it }
        val list = ArrayList<Behavior>()
        val names = ctx.assets.list("behaviors") ?: emptyArray()
        for (n in names) {
            if (!n.endsWith(".gd")) continue
            try {
                val text = ctx.assets.open("behaviors/$n").bufferedReader().use { it.readText() }
                list.add(Behaviors.parse(n.removeSuffix(".gd"), text))
            } catch (e: Exception) {
                // un archivo ilegible no debe impedir ver el resto
            }
        }
        val sorted = Behaviors.sorted(list)
        cache = sorted
        return sorted
    }
}
