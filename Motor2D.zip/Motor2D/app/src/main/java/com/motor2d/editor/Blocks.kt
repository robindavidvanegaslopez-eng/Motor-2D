package com.motor2d.editor

import com.motor2d.core.Json

/** Cómo se interpreta lo que el usuario escribe en un hueco de un bloque. */
enum class PKind {
    NUM,      // número o expresión: 5, velocidad * 2, position.x
    TEXT,     // texto literal (se pone entre comillas solo)
    NAME,     // nombre de objeto o etiqueta (texto literal)
    COND,     // condición: puntos > 3 and Input.is_touching()
    CHOICE,   // una opción de una lista
    COLOR,    // nombre de color («red») o #rrggbb
    IDENT     // nombre de variable o de función
}

class BParam(val name: String, val kind: PKind, val def: String, val choices: List<String> = emptyList())

enum class BKind { HAT, STATEMENT, CONTAINER }

/** Definición de un tipo de bloque: cómo se ve y qué código genera. */
class BlockDef(
    val type: String,
    val category: String,
    /** Texto con huecos: «Mover {dx} en X». */
    val label: String,
    val params: List<BParam>,
    val kind: BKind,
    /** Líneas de GDScript con {huecos}. En un contenedor, la primera línea es la cabecera. */
    val code: List<String>,
    val hasElse: Boolean = false,
    val help: String = ""
) {
    fun param(name: String): BParam? = params.firstOrNull { it.name == name }
}

/** Un bloque colocado en un script de bloques. */
class Block(val type: String) {
    val args = LinkedHashMap<String, String>()
    val children = ArrayList<Block>()
    val elseChildren = ArrayList<Block>()

    fun copy(): Block {
        val b = Block(type)
        b.args.putAll(args)
        for (c in children) b.children.add(c.copy())
        for (c in elseChildren) b.elseChildren.add(c.copy())
        return b
    }
}

class BlockScript {
    /** Variables del script con su valor inicial (como texto GDScript). */
    val vars = LinkedHashMap<String, String>()
    val events = ArrayList<Block>()
}

/** Trozo de la etiqueta de un bloque: texto fijo o un hueco editable. */
class LabelPart(val text: String?, val param: BParam?)

object BlockCatalog {
    const val EVENTS = "Eventos"
    const val CONTROL = "Control"
    const val MOVEMENT = "Movimiento"
    const val LOOKS = "Apariencia"
    const val OBJECTS = "Objetos"
    const val GAME = "Juego"
    const val VARS = "Variables"
    const val TIME = "Tiempo"

    val categories = listOf(EVENTS, CONTROL, MOVEMENT, LOOKS, OBJECTS, GAME, VARS, TIME)

    val KEYS = listOf("space", "w", "a", "s", "d", "up", "down", "left", "right", "z", "x", "c", "e", "q", "r", "f", "enter", "shift_left")
    val EASINGS = listOf("linear", "ease_in", "ease_out", "ease_in_out", "bounce")

    private fun num(n: String, d: String = "0") = BParam(n, PKind.NUM, d)
    private fun text(n: String, d: String = "") = BParam(n, PKind.TEXT, d)
    private fun name(n: String, d: String = "") = BParam(n, PKind.NAME, d)
    private fun cond(n: String, d: String = "true") = BParam(n, PKind.COND, d)
    private fun ident(n: String, d: String) = BParam(n, PKind.IDENT, d)
    private fun color(n: String, d: String = "red") = BParam(n, PKind.COLOR, d)
    private fun choice(n: String, list: List<String>) = BParam(n, PKind.CHOICE, list[0], list)

    private fun hat(type: String, label: String, vararg p: BParam, help: String = "") =
        BlockDef(type, EVENTS, label, p.toList(), BKind.HAT, emptyList(), help = help)

    private fun st(type: String, cat: String, label: String, p: List<BParam>, vararg code: String, help: String = "") =
        BlockDef(type, cat, label, p, BKind.STATEMENT, code.toList(), help = help)

    private fun box(type: String, cat: String, label: String, p: List<BParam>, header: String, hasElse: Boolean = false, help: String = "") =
        BlockDef(type, cat, label, p, BKind.CONTAINER, listOf(header), hasElse, help)

    val defs: List<BlockDef> = listOf(
        // ---------------- Eventos ----------------
        hat("ev_start", "Al empezar", help = "Se ejecuta una vez cuando empieza el juego."),
        hat("ev_frame", "En cada fotograma", help = "Se repite todo el tiempo (unas 60 veces por segundo)."),
        hat("ev_physics", "En cada paso de física", help = "Se repite 60 veces por segundo, sincronizado con la física."),
        hat("ev_touch", "Al tocar este objeto", help = "Cuando tocas o haces clic sobre este objeto."),
        hat("ev_collide", "Al chocar con {who}", name("who"), help = "Deja el nombre vacío para cualquier objeto. Dentro puedes usar «el otro objeto»."),
        hat("ev_collide_exit", "Al dejar de chocar con {who}", name("who")),
        hat("ev_trigger", "Cuando {who} entra en esta zona", name("who"), help = "Para objetos con collider disparador."),
        hat("ev_trigger_exit", "Cuando {who} sale de esta zona", name("who")),
        hat("ev_key", "Al pulsar la tecla {key}", choice("key", KEYS)),
        hat("ev_key_held", "Mientras la tecla {key} esté pulsada", choice("key", KEYS)),
        hat("ev_button", "Al pulsar el botón {button} de la pantalla", choice("button", listOf("A", "B"))),
        hat("ev_click", "Al hacer clic con el botón {button} del mouse", choice("button", listOf("left", "right", "middle"))),
        hat("ev_after", "{n} segundos después de empezar", num("n", "2")),
        hat("ev_every", "Cada {n} segundos", num("n", "1")),
        hat("ev_func", "Definir la función {name}", ident("name", "mi_funcion"), help = "Un grupo de bloques que puedes repetir con «Llamar a la función»."),

        // ---------------- Control ----------------
        box("ct_if", CONTROL, "Si {cond}", listOf(cond("cond")), "if {cond}:"),
        box("ct_ifelse", CONTROL, "Si {cond} (y si no)", listOf(cond("cond")), "if {cond}:", hasElse = true),
        box("ct_repeat", CONTROL, "Repetir {n} veces", listOf(num("n", "3")), "for {iv} in range({n}):"),
        box("ct_while", CONTROL, "Mientras {cond}", listOf(cond("cond")), "while {cond}:", help = "Cuidado: si la condición nunca cambia, el juego se detiene con un error."),
        box("ct_after", TIME, "Esperar {n} segundos y luego", listOf(num("n", "1")), "", help = "Los bloques de dentro se ejecutan después de esa espera, sin detener el resto del juego."),
        st("ct_call", CONTROL, "Llamar a la función {name}", listOf(ident("name", "mi_funcion")), "{name}()"),
        st("ct_return", CONTROL, "Salir de esta función", emptyList(), "return"),
        st("ct_quit", CONTROL, "Terminar el juego", emptyList(), "quit()"),

        // ---------------- Movimiento ----------------
        st("mv_move", MOVEMENT, "Mover {dx} en X y {dy} en Y", listOf(num("dx"), num("dy")), "position = position + Vector2({dx}, {dy})"),
        st("mv_forward", MOVEMENT, "Avanzar {n} hacia donde mira", listOf(num("n", "2")),
            "position = position + Vector2(cos(deg_to_rad(rotation)), sin(deg_to_rad(rotation))) * ({n})"),
        st("mv_goto", MOVEMENT, "Ir a X {x} Y {y}", listOf(num("x"), num("y")), "position = Vector2({x}, {y})"),
        st("mv_rotate", MOVEMENT, "Girar {deg} grados", listOf(num("deg", "5")), "rotation = rotation + ({deg})"),
        st("mv_setrot", MOVEMENT, "Poner la rotación en {deg} grados", listOf(num("deg")), "rotation = {deg}"),
        st("mv_lookat", MOVEMENT, "Mirar hacia {name}", listOf(name("name", "Jugador")),
            "if get_object({name}) != null:", "    look_at(get_object({name}))"),
        st("mv_towards", MOVEMENT, "Acercarse a {name} a velocidad {speed}", listOf(name("name", "Jugador"), num("speed", "100")),
            "if get_object({name}) != null:", "    translate(direction_to(get_object({name})) * ({speed}) * delta)",
            help = "Úsalo en «En cada fotograma»."),
        st("mv_vel", MOVEMENT, "Poner la velocidad en X {x} Y {y}", listOf(num("x"), num("y")), "velocity = Vector2({x}, {y})", help = "Necesita un Rigidbody."),
        st("mv_velx", MOVEMENT, "Poner la velocidad horizontal en {x}", listOf(num("x", "100")), "velocity = Vector2({x}, velocity.y)"),
        st("mv_vely", MOVEMENT, "Poner la velocidad vertical en {y}", listOf(num("y", "-300")), "velocity = Vector2(velocity.x, {y})"),
        st("mv_impulse", MOVEMENT, "Dar un impulso de X {x} Y {y}", listOf(num("x"), num("y", "-300")), "rigidbody.add_impulse(Vector2({x}, {y}))"),
        st("mv_jump", MOVEMENT, "Saltar con fuerza {n}", listOf(num("n", "600")), "velocity = Vector2(velocity.x, -({n}))"),
        st("mv_joy_top", MOVEMENT, "Moverse con el joystick o las teclas a velocidad {n} (vista superior)", listOf(num("n", "250")),
            "velocity = Input.joystick * ({n})", help = "Funciona con joystick en pantalla y con WASD o flechas."),
        st("mv_joy_plat", MOVEMENT, "Caminar con el joystick o las teclas a velocidad {n} (plataformas)", listOf(num("n", "250")),
            "velocity = Vector2(Input.joystick.x * ({n}), velocity.y)"),
        st("mv_tween", MOVEMENT, "Mover suavemente a X {x} Y {y} en {s} s ({ease})", listOf(num("x"), num("y"), num("s", "1"), choice("ease", EASINGS)),
            "tween_to(\"position\", Vector2({x}, {y}), {s}, \"{ease}\")"),
        st("mv_tween_rot", MOVEMENT, "Girar suavemente a {deg}° en {s} s ({ease})", listOf(num("deg", "90"), num("s", "1"), choice("ease", EASINGS)),
            "tween_to(\"rotation\", {deg}, {s}, \"{ease}\")"),
        st("mv_tween_scale", MOVEMENT, "Cambiar el tamaño suavemente a {k} en {s} s ({ease})", listOf(num("k", "2"), num("s", "1"), choice("ease", EASINGS)),
            "tween_to(\"scale\", Vector2({k}, {k}), {s}, \"{ease}\")"),

        // ---------------- Apariencia ----------------
        st("ap_color", LOOKS, "Cambiar el color a {color}", listOf(color("color")), "set_color({color})"),
        st("ap_random_color", LOOKS, "Cambiar a un color al azar", emptyList(), "set_color(Color(randf(), randf(), randf()))"),
        st("ap_tween_color", LOOKS, "Cambiar suavemente al color {color} en {s} s", listOf(color("color", "blue"), num("s", "1")),
            "tween_to(\"color\", Color({color}), {s})"),
        st("ap_show", LOOKS, "Mostrar", emptyList(), "visible = true"),
        st("ap_hide", LOOKS, "Ocultar", emptyList(), "visible = false"),
        st("ap_scale", LOOKS, "Cambiar el tamaño a {k}", listOf(num("k", "1")), "scale = Vector2({k}, {k})"),
        st("ap_text", LOOKS, "Escribir el texto «{text}»", listOf(text("text", "Hola")), "set_text({text})", help = "Para objetos con el componente Texto."),
        st("ap_text_value", LOOKS, "Escribir el valor de {expr}", listOf(num("expr", "puntos")), "set_text(str({expr}))"),

        // ---------------- Objetos ----------------
        st("ob_spawn", OBJECTS, "Crear una copia de {name} en X {x} Y {y}", listOf(name("name", "Bala"), num("x"), num("y")),
            "instantiate({name}, Vector2({x}, {y}))", help = "El objeto original puede estar desactivado: sirve de plantilla."),
        st("ob_spawn_here", OBJECTS, "Crear una copia de {name} aquí", listOf(name("name", "Bala")), "instantiate({name}, global_position)"),
        st("ob_destroy", OBJECTS, "Eliminar este objeto", emptyList(), "destroy(self)"),
        st("ob_destroy_other", OBJECTS, "Eliminar el otro objeto", emptyList(), "destroy(other)", help = "Solo en «Al chocar» o «Cuando entra en esta zona»."),
        st("ob_destroy_named", OBJECTS, "Eliminar el objeto {name}", listOf(name("name")),
            "if get_object({name}) != null:", "    destroy(get_object({name}))"),
        st("ob_tag", OBJECTS, "Poner la etiqueta {tag}", listOf(text("tag", "enemigo")), "tag = {tag}"),
        st("ob_call", OBJECTS, "Llamar a la función {fn} del objeto {name}", listOf(ident("fn", "hurt"), name("name", "Jugador")),
            "if get_object({name}) != null and get_object({name}).has_method(\"{fn}\"):", "    get_object({name}).{fn}()"),

        // ---------------- Juego ----------------
        st("jg_score", GAME, "Sumar {n} puntos al marcador {obj}", listOf(num("n", "1"), name("obj", "Puntos")),
            "if get_object({obj}) != null and get_object({obj}).has_method(\"add\"):", "    get_object({obj}).add({n})",
            help = "El marcador es un objeto con el comportamiento «Marcador de puntos»."),
        st("jg_scene", GAME, "Cargar la escena {name}", listOf(name("name", "main")), "load_scene({name})"),
        st("jg_reload", GAME, "Reiniciar la escena", emptyList(), "reload_scene()"),
        st("jg_print", GAME, "Escribir en la consola «{text}»", listOf(text("text", "Hola")), "print({text})"),
        st("jg_print_value", GAME, "Escribir en la consola el valor de {expr}", listOf(num("expr", "puntos")), "print({expr})"),
        st("jg_gravity", GAME, "Cambiar la gravedad a X {x} Y {y}", listOf(num("x"), num("y", "900")), "Physics.gravity = Vector2({x}, {y})"),

        // ---------------- Variables ----------------
        st("va_set", VARS, "Poner {var} en {value}", listOf(ident("var", "puntos"), num("value")), "{var} = {value}"),
        st("va_change", VARS, "Sumar {value} a {var}", listOf(num("value", "1"), ident("var", "puntos")), "{var} += {value}"),
        st("va_random", VARS, "Poner {var} en un número al azar entre {a} y {b}", listOf(ident("var", "azar"), num("a", "1"), num("b", "6")),
            "{var} = randi_range({a}, {b})"),

        // ---------------- Tiempo ----------------
        st("ti_after_fn", TIME, "Dentro de {n} segundos llamar a la función {fn}", listOf(num("n", "2"), ident("fn", "mi_funcion")),
            "after({n}, \"{fn}\")"),
        st("ti_every_fn", TIME, "Cada {n} segundos llamar a la función {fn}", listOf(num("n", "1"), ident("fn", "mi_funcion")),
            "every({n}, \"{fn}\")", help = "Ponlo en «Al empezar»: si lo pones en «En cada fotograma» se crearían miles de repeticiones.")
    )

    private val byType: Map<String, BlockDef> = defs.associateBy { it.type }

    fun def(type: String): BlockDef? = byType[type]

    fun inCategory(cat: String): List<BlockDef> = defs.filter { it.category == cat }

    /** Un bloque nuevo con los valores por defecto. */
    fun create(type: String): Block {
        val d = byType[type] ?: throw IllegalArgumentException("Bloque desconocido: $type")
        val b = Block(type)
        for (p in d.params) b.args[p.name] = p.def
        return b
    }

    /** Parte la etiqueta en texto y huecos para dibujarla. */
    fun parts(d: BlockDef): List<LabelPart> {
        val out = ArrayList<LabelPart>()
        var i = 0
        val s = d.label
        while (i < s.length) {
            val open = s.indexOf('{', i)
            if (open < 0) { out.add(LabelPart(s.substring(i), null)); break }
            if (open > i) out.add(LabelPart(s.substring(i, open), null))
            val close = s.indexOf('}', open)
            if (close < 0) { out.add(LabelPart(s.substring(open), null)); break }
            val p = d.param(s.substring(open + 1, close))
            if (p != null) out.add(LabelPart(null, p)) else out.add(LabelPart(s.substring(open, close + 1), null))
            i = close + 1
        }
        return out
    }

    /** La etiqueta con los valores puestos, en texto plano. */
    fun describe(b: Block): String {
        val d = byType[b.type] ?: return b.type
        val sb = StringBuilder()
        for (p in parts(d)) {
            if (p.text != null) sb.append(p.text) else sb.append(b.args[p.param!!.name] ?: p.param.def)
        }
        return sb.toString()
    }

    /** Condiciones listas para insertar en un hueco de condición. */
    val CONDITION_PRESETS: List<Pair<String, String>> = listOf(
        "Joystick o flecha a la derecha" to "Input.joystick.x > 0.3",
        "Joystick o flecha a la izquierda" to "Input.joystick.x < -0.3",
        "Joystick o flecha hacia arriba" to "Input.joystick.y < -0.3",
        "Joystick o flecha hacia abajo" to "Input.joystick.y > 0.3",
        "Botón A pulsado" to "Input.is_button_pressed(\"A\")",
        "Botón B pulsado" to "Input.is_button_pressed(\"B\")",
        "Tecla espacio pulsada" to "Input.is_key_pressed(\"space\")",
        "Estoy tocando la pantalla" to "Input.is_touching()",
        "Clic izquierdo del mouse pulsado" to "Input.is_mouse_button_pressed(\"left\")",
        "Estoy en el suelo" to "rigidbody.is_on_floor()",
        "Estoy cayendo" to "velocity.y > 0",
        "Mi posición X es mayor que 500" to "position.x > 500",
        "Cerca del objeto Jugador (menos de 200)" to "get_object(\"Jugador\") != null and distance_to(get_object(\"Jugador\")) < 200",
        "Al azar (50 % de las veces)" to "randf() < 0.5",
        "La variable puntos es mayor que 10" to "puntos > 10",
        "El otro objeto se llama Jugador" to "other.name == \"Jugador\"",
        "El otro objeto tiene la etiqueta enemigo" to "other.tag == \"enemigo\""
    )
}

object Blocks {
    const val FOLDER = "scripts/bloques"

    fun blocksPath(name: String) = "$FOLDER/$name.blocks"
    fun scriptPath(name: String) = "$FOLDER/$name.gd"

    // ---------- Guardado ----------
    fun toJson(s: BlockScript): String {
        val root = LinkedHashMap<String, Any?>()
        root["version"] = 1L
        root["vars"] = LinkedHashMap<String, Any?>(s.vars)
        root["events"] = s.events.map { blockToMap(it) }
        return Json.stringify(root, true)
    }

    private fun blockToMap(b: Block): Map<String, Any?> {
        val m = LinkedHashMap<String, Any?>()
        m["type"] = b.type
        if (b.args.isNotEmpty()) m["args"] = LinkedHashMap<String, Any?>(b.args)
        if (b.children.isNotEmpty()) m["children"] = b.children.map { blockToMap(it) }
        if (b.elseChildren.isNotEmpty()) m["else"] = b.elseChildren.map { blockToMap(it) }
        return m
    }

    /** Lee un script de bloques. Los bloques de un tipo desconocido se ignoran. */
    fun fromJson(text: String): BlockScript {
        val s = BlockScript()
        val root = Json.parseObject(text)
        (root["vars"] as? Map<*, *>)?.forEach { (k, v) -> s.vars[k.toString()] = v?.toString() ?: "0" }
        for (m in (root["events"] as? List<*>) ?: emptyList<Any?>()) mapToBlock(m)?.let { s.events.add(it) }
        return s
    }

    private fun mapToBlock(m: Any?): Block? {
        val map = m as? Map<*, *> ?: return null
        val type = map["type"]?.toString() ?: return null
        val def = BlockCatalog.def(type) ?: return null
        val b = BlockCatalog.create(type)
        (map["args"] as? Map<*, *>)?.forEach { (k, v) -> if (def.param(k.toString()) != null) b.args[k.toString()] = v?.toString() ?: "" }
        for (c in (map["children"] as? List<*>) ?: emptyList<Any?>()) mapToBlock(c)?.let { b.children.add(it) }
        for (c in (map["else"] as? List<*>) ?: emptyList<Any?>()) mapToBlock(c)?.let { b.elseChildren.add(it) }
        return b
    }
}
