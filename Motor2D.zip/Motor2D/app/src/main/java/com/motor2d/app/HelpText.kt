package com.motor2d.app

/** Resumen de lo que se puede usar en los scripts (GDScript simplificado). */
object HelpText {
    val TEXT = """
BIBLIOTECA DE COMPORTAMIENTOS
Selecciona un objeto > Inspector > + Añadir componente > ★ Comportamiento prefabricado. Hay más de 70 (movimiento, combate, monedas, puertas, cámara...). Sus variables se cambian en «Variables del script». Si falta algo, añade un Script y prográmalo tú.

SCRIPTS (estilo GDScript)

Cada script se añade a un objeto con el componente Script. Dentro del script, 'position', 'rotation', 'name', etc. son del objeto al que está pegado.

FUNCIONES QUE SE LLAMAN SOLAS
func _ready():                 al empezar
func _process(delta):          cada fotograma
func _physics_process(delta):  60 veces por segundo
func _on_collision_enter(other)   choca con 'other'
func _on_collision_exit(other)
func _on_trigger_enter(other)     entra en una zona
func _on_trigger_exit(other)
func _on_touched():            tocan este objeto

VARIABLES
var vidas = 3
@export var velocidad = 200.0   (se cambia en el Inspector)
const MAX = 10
Tipos: números, true/false, "texto", [listas], {diccionarios}, Vector2(x, y), Color(r, g, b)

CONTROL
if / elif / else, for i in range(10), while, match, break, continue, pass, return

OBJETO (el del script)
position, global_position, rotation, scale, name, tag, active, visible, velocity
rigidbody, sprite, label, camera, collider
translate(v), rotate(grados), look_at(obj), distance_to(obj), direction_to(obj)
get_component("rigidbody"), has_component("label")
set_color(c), set_text("hola"), get_children(), get_parent()
otro.has_method("hurt")        ¿el otro objeto tiene esa función?

OTROS OBJETOS Y ESCENA
get_object("Nombre")
find_objects_with_tag("enemigo")
instantiate("Nombre", posicion)   copia un objeto
destroy(objeto)
load_scene("nivel2"), reload_scene(), quit()
screen_size, screen_to_world(p), world_to_screen(p)
otro.funcion()  llama a una función del script de otro objeto
otro.variable   lee o cambia una variable de su script

ENTRADA
Input.joystick                    Vector2 de -1 a 1
Input.is_button_pressed("A")      botones A y B en pantalla
Input.is_button_just_pressed("A")
Input.is_key_pressed("space")     teclado (w a s d, left, right, up, down, space)
Input.is_touching(), Input.just_touched()
Input.touch_position(), Input.touch_world_position()
Input.tilt

FÍSICA (Rigidbody)
rb.velocity, rb.angular_velocity
rb.add_force(v), rb.add_impulse(v), rb.stop()
rb.is_on_floor(), rb.is_on_wall(), rb.is_on_ceiling()
Physics.gravity
Tipos de cuerpo: dynamic (se mueve con física), kinematic (lo mueves tú), static (fijo)
Collider con 'Es disparador' no choca, solo avisa con _on_trigger_enter.

MATEMÁTICAS Y UTILIDADES
abs, min, max, clamp, lerp, sign, sqrt, pow, floor, ceil, round, sin, cos, tan
deg_to_rad, rad_to_deg, randf(), randi_range(a, b), randf_range(a, b)
range(n), len(x), str(x), int(x), float(x), print(...)
Vector2: length(), normalized(), distance_to(v), direction_to(v), lerp(v, t), rotated(rad)
Time.time

EJEMPLO
extends Node2D
@export var speed = 300.0
func _process(delta):
    var rb = rigidbody
    rb.velocity = Vector2(Input.joystick.x * speed, rb.velocity.y)
    if Input.is_button_just_pressed("A") and rb.is_on_floor():
        rb.velocity = Vector2(rb.velocity.x, -700)
""".trimStart()
}
