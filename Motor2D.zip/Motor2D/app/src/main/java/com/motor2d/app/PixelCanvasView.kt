package com.motor2d.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import com.motor2d.editor.SpriteDoc

/** El lienzo de píxeles: dibuja el cuadro actual ampliado y recibe los trazos del dedo o del mouse. */
class PixelCanvasView(context: Context, private val doc: SpriteDoc) : View(context) {

    enum class Tool { PENCIL, ERASER, FILL, LINE, RECT, RECT_FILL, OVAL, OVAL_FILL, PICK }

    var tool = Tool.PENCIL
    var color: Int = 0xFF000000.toInt()
    var mirrorX = false
    var mirrorY = false
    var showGrid = true
    var onionSkin = true
    /** Mientras se prueba la animación no se puede dibujar. */
    var locked = false

    var onChanged: (() -> Unit)? = null
    var onColorPicked: ((Int) -> Unit)? = null

    private var scale = 10f
    private var offX = 0f
    private var offY = 0f
    private var fitted = false

    private val imgPaint = Paint()
    private val onionPaint = Paint().apply { alpha = 90 }
    private val fillPaint = Paint()
    private val gridPaint = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 1f; color = 0x33FFFFFF }
    private val borderPaint = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 2f; color = 0xFF8A94A6.toInt() }
    private val bmp: Bitmap = Bitmap.createBitmap(doc.w, doc.h, Bitmap.Config.ARGB_8888)
    private val onionBmp: Bitmap = Bitmap.createBitmap(doc.w, doc.h, Bitmap.Config.ARGB_8888)
    private val dst = RectF()

    private fun density(): Float = resources.displayMetrics.density

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (!fitted && w > 0 && h > 0) { fitted = true; fit() }
    }

    fun fit() {
        if (width <= 0 || height <= 0) return
        scale = (minOf(width.toFloat() / doc.w, height.toFloat() / doc.h) * 0.92f).coerceAtLeast(1f)
        offX = (width - doc.w * scale) / 2f
        offY = (height - doc.h * scale) / 2f
        invalidate()
    }

    // ---------- Dibujo ----------
    override fun onDraw(c: Canvas) {
        c.drawColor(Ui.BG)
        dst.set(offX, offY, offX + doc.w * scale, offY + doc.h * scale)

        // Fondo de ajedrez para ver la transparencia
        fillPaint.color = 0xFF2E3544.toInt()
        c.drawRect(dst, fillPaint)
        fillPaint.color = 0xFF232938.toInt()
        val cell = 4
        var cy = 0
        while (cy * cell < doc.h) {
            var cx = 0
            while (cx * cell < doc.w) {
                if ((cx + cy) % 2 == 1) {
                    val l = offX + cx * cell * scale
                    val t = offY + cy * cell * scale
                    val r = offX + minOf((cx + 1) * cell, doc.w) * scale
                    val b = offY + minOf((cy + 1) * cell, doc.h) * scale
                    c.drawRect(l, t, r, b, fillPaint)
                }
                cx++
            }
            cy++
        }

        val prev = if (onionSkin && !locked) doc.previousFrame() else null
        if (prev != null) {
            onionBmp.setPixels(prev.px, 0, doc.w, 0, 0, doc.w, doc.h)
            c.drawBitmap(onionBmp, null, dst, onionPaint)
        }
        val img = doc.image
        bmp.setPixels(img.px, 0, doc.w, 0, 0, doc.w, doc.h)
        c.drawBitmap(bmp, null, dst, imgPaint)

        if (showGrid && scale >= 8f * density()) {
            for (x in 0..doc.w) c.drawLine(offX + x * scale, offY, offX + x * scale, offY + doc.h * scale, gridPaint)
            for (y in 0..doc.h) c.drawLine(offX, offY + y * scale, offX + doc.w * scale, offY + y * scale, gridPaint)
        }
        c.drawRect(dst, borderPaint)

        // Líneas de simetría
        if (mirrorX || mirrorY) {
            val p = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 2f; color = Color.argb(160, 255, 80, 120) }
            if (mirrorX) c.drawLine(offX + doc.w * scale / 2f, offY, offX + doc.w * scale / 2f, offY + doc.h * scale, p)
            if (mirrorY) c.drawLine(offX, offY + doc.h * scale / 2f, offX + doc.w * scale, offY + doc.h * scale / 2f, p)
        }
    }

    // ---------- Gestos ----------
    private enum class Mode { NONE, DRAW, PAN, PINCH }

    private var mode = Mode.NONE
    private var strokeStarted = false
    private var startIx = 0
    private var startIy = 0
    private var lastIx = 0
    private var lastIy = 0
    private var base: IntArray? = null
    private var lastX = 0f
    private var lastY = 0f
    private var pinchDist = 1f

    private fun ix(x: Float): Int = Math.floor(((x - offX) / scale).toDouble()).toInt()
    private fun iy(y: Float): Int = Math.floor(((y - offY) / scale).toDouble()).toInt()

    private fun beginStroke(x: Float, y: Float) {
        val px = ix(x)
        val py = iy(y)
        if (tool != Tool.PICK) doc.checkpoint()
        strokeStarted = true
        startIx = px; startIy = py; lastIx = px; lastIy = py
        base = doc.image.px.copyOf()
        applyTool(px, py, true)
    }

    private fun applyTool(px: Int, py: Int, first: Boolean) {
        val img = doc.image
        when (tool) {
            Tool.PENCIL -> {
                if (first) img.plot(px, py, color, mirrorX, mirrorY)
                else img.line(lastIx, lastIy, px, py, color, mirrorX, mirrorY)
            }
            Tool.ERASER -> {
                if (first) img.plot(px, py, 0, mirrorX, mirrorY)
                else img.line(lastIx, lastIy, px, py, 0, mirrorX, mirrorY)
            }
            Tool.FILL -> if (first && img.inside(px, py)) img.fill(px, py, color)
            Tool.PICK -> if (img.inside(px, py)) {
                val c = img.get(px, py)
                if ((c ushr 24) != 0) { color = c; onColorPicked?.invoke(c) }
            }
            Tool.LINE, Tool.RECT, Tool.RECT_FILL, Tool.OVAL, Tool.OVAL_FILL -> {
                val b = base
                if (b != null) System.arraycopy(b, 0, img.px, 0, b.size)
                when (tool) {
                    Tool.LINE -> img.line(startIx, startIy, px, py, color, mirrorX, mirrorY)
                    Tool.RECT -> img.rect(startIx, startIy, px, py, color, false, mirrorX, mirrorY)
                    Tool.RECT_FILL -> img.rect(startIx, startIy, px, py, color, true, mirrorX, mirrorY)
                    Tool.OVAL -> img.ellipse(startIx, startIy, px, py, color, false, mirrorX, mirrorY)
                    else -> img.ellipse(startIx, startIy, px, py, color, true, mirrorX, mirrorY)
                }
            }
        }
        lastIx = px
        lastIy = py
        invalidate()
    }

    private fun endStroke() {
        if (strokeStarted && tool != Tool.PICK) onChanged?.invoke()
        strokeStarted = false
        base = null
    }

    /** Un segundo dedo cancela el trazo en curso: se deshace para no dejar un punto suelto. */
    private fun cancelStroke() {
        if (strokeStarted && tool != Tool.PICK) doc.undo()
        strokeStarted = false
        base = null
        invalidate()
    }

    private fun zoomAt(fx: Float, fy: Float, factor: Float) {
        val newScale = (scale * factor).coerceIn(2f, 160f * density())
        val k = newScale / scale
        offX = fx - (fx - offX) * k
        offY = fy - (fy - offY) * k
        scale = newScale
        invalidate()
    }

    private fun pinchSpan(e: MotionEvent): Float =
        Math.hypot((e.getX(0) - e.getX(1)).toDouble(), (e.getY(0) - e.getY(1)).toDouble()).toFloat().coerceAtLeast(1f)

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (locked) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.x; lastY = e.y
                val mouse = e.getToolType(0) == MotionEvent.TOOL_TYPE_MOUSE
                val otherButton = mouse && e.buttonState != 0 && (e.buttonState and MotionEvent.BUTTON_PRIMARY) == 0
                if (otherButton) {
                    mode = Mode.PAN
                } else {
                    mode = Mode.DRAW
                    strokeStarted = false
                    startIx = ix(e.x); startIy = iy(e.y)
                }
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (e.pointerCount == 2) {
                    if (mode == Mode.DRAW) cancelStroke()
                    mode = Mode.PINCH
                    pinchDist = pinchSpan(e)
                    lastX = (e.getX(0) + e.getX(1)) / 2f
                    lastY = (e.getY(0) + e.getY(1)) / 2f
                }
            }
            MotionEvent.ACTION_MOVE -> {
                when (mode) {
                    Mode.DRAW -> {
                        val px = ix(e.x)
                        val py = iy(e.y)
                        if (!strokeStarted) {
                            beginStroke(e.x, e.y)
                        } else if (px != lastIx || py != lastIy) {
                            applyTool(px, py, false)
                        }
                    }
                    Mode.PAN -> {
                        offX += e.x - lastX
                        offY += e.y - lastY
                        lastX = e.x; lastY = e.y
                        invalidate()
                    }
                    Mode.PINCH -> if (e.pointerCount >= 2) {
                        val mx = (e.getX(0) + e.getX(1)) / 2f
                        val my = (e.getY(0) + e.getY(1)) / 2f
                        offX += mx - lastX
                        offY += my - lastY
                        val d = pinchSpan(e)
                        zoomAt(mx, my, d / pinchDist)
                        pinchDist = d
                        lastX = mx; lastY = my
                    }
                    Mode.NONE -> {}
                }
            }
            MotionEvent.ACTION_UP -> {
                if (mode == Mode.DRAW) {
                    if (!strokeStarted) beginStroke(e.x, e.y)   // un toque simple dibuja un píxel
                    endStroke()
                }
                mode = Mode.NONE
            }
            MotionEvent.ACTION_POINTER_UP -> {
                // al soltar un dedo del zoom no se vuelve a dibujar hasta el siguiente toque
                if (mode == Mode.PINCH && e.pointerCount <= 2) mode = Mode.NONE
            }
            MotionEvent.ACTION_CANCEL -> {
                if (mode == Mode.DRAW) cancelStroke()
                mode = Mode.NONE
            }
        }
        return true
    }

    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_SCROLL) {
            val v = e.getAxisValue(MotionEvent.AXIS_VSCROLL)
            if (v != 0f) {
                zoomAt(e.x, e.y, if (v > 0f) 1.15f else 1f / 1.15f)
                return true
            }
        }
        return super.onGenericMotionEvent(e)
    }
}
