package com.motor2d.app

import android.app.Activity
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.motor2d.editor.BKind
import com.motor2d.editor.BParam
import com.motor2d.editor.Block
import com.motor2d.editor.BlockCatalog
import com.motor2d.editor.BlockCompiler
import com.motor2d.editor.BlockScript
import com.motor2d.editor.EditorModel
import com.motor2d.editor.PKind

/**
 * Editor de bloques a pantalla completa: se arma la lógica del objeto tocando «+» y rellenando huecos.
 * Cada cambio se guarda solo y se convierte a GDScript (se puede ver con el botón { }).
 */
class BlocksEditor(
    private val activity: Activity,
    private val model: EditorModel,
    val name: String,
    private val onClose: () -> Unit,
    private val onRun: () -> Unit
) {
    val view: View
    private val script: BlockScript = model.loadBlocks(name) ?: BlockScript()
    private val content = LinearLayout(activity)
    private val scroll = ScrollView(activity)
    private val status = TextView(activity)
    private val title = TextView(activity)
    private val codeToggle: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val saveTask = Runnable { saveNow() }
    private var showCode = false
    private var pendingSave = false

    init {
        val root = LinearLayout(activity)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)
        root.isClickable = true   // que los toques no atraviesen hacia el editor de atrás

        val bar = LinearLayout(activity)
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(Ui.PANEL)
        bar.setPadding(activity.dp(6), activity.dp(4), activity.dp(6), activity.dp(4))
        bar.addView(activity.button("←") { close() }, lp(Ui.WRAP, Ui.WRAP))
        title.text = "Bloques · $name"
        title.textSize = 15f
        title.setTextColor(Ui.TEXT)
        title.setSingleLine(true)
        title.setPadding(activity.dp(8), 0, activity.dp(4), 0)
        bar.addView(title, lp(0, Ui.WRAP, 1f))
        bar.addView(activity.button("x =") { variablesDialog() }, lp(Ui.WRAP, Ui.WRAP).also { it.leftMargin = activity.dp(4) })
        codeToggle = activity.button("{ }") { toggleCode() }
        bar.addView(codeToggle, lp(Ui.WRAP, Ui.WRAP).also { it.leftMargin = activity.dp(4) })
        bar.addView(activity.button("▶", Ui.ACCENT, 0xFF04202D.toInt()) { saveNow(); onRun() }, lp(Ui.WRAP, Ui.WRAP).also { it.leftMargin = activity.dp(4) })
        root.addView(bar, lp(Ui.MATCH, Ui.WRAP))

        content.orientation = LinearLayout.VERTICAL
        content.setPadding(activity.dp(10), activity.dp(10), activity.dp(10), activity.dp(80))
        scroll.addView(content, android.widget.FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        root.addView(scroll, lp(Ui.MATCH, 0, 1f))

        status.textSize = 12f
        status.setPadding(activity.dp(12), activity.dp(6), activity.dp(12), activity.dp(6))
        status.setBackgroundColor(Ui.PANEL)
        status.setTextColor(Ui.MUTED)
        root.addView(status, lp(Ui.MATCH, Ui.WRAP))

        view = root
        rebuild()
        saveNow()
    }

    // ---------- Guardado ----------
    private fun changed() {
        pendingSave = true
        handler.removeCallbacks(saveTask)
        handler.postDelayed(saveTask, 400)
    }

    fun saveNow() {
        handler.removeCallbacks(saveTask)
        pendingSave = false
        val err = model.saveBlocks(name, script)
        if (err == null) {
            status.text = "✓ Guardado y convertido a código"
            status.setTextColor(Ui.OK)
        } else {
            status.text = "⚠ " + err.describe()
            status.setTextColor(Ui.DANGER)
        }
    }

    fun close() {
        saveNow()
        handler.removeCallbacks(saveTask)
        onClose()
    }

    // ---------- Vista ----------
    private fun toggleCode() {
        showCode = !showCode
        codeToggle.text = if (showCode) "▦" else "{ }"
        rebuild()
    }

    private fun rebuild() {
        content.removeAllViews()
        if (showCode) {
            val t = TextView(activity)
            t.typeface = Typeface.MONOSPACE
            t.textSize = 12f
            t.setTextColor(Ui.TEXT)
            t.setTextIsSelectable(true)
            t.text = BlockCompiler.compile(script).text
            content.addView(t, lp(Ui.MATCH, Ui.WRAP))
            return
        }
        if (script.events.isEmpty()) {
            content.addView(
                activity.label("Empieza añadiendo un evento: por ejemplo «Al empezar» o «Al pulsar la tecla». Dentro de cada evento pones los bloques que quieres que hagan.", 14f, Ui.MUTED),
                lp(Ui.MATCH, Ui.WRAP).also { it.bottomMargin = activity.dp(12) }
            )
        }
        for (ev in script.events) {
            content.addView(blockView(ev, script.events), lp(Ui.MATCH, Ui.WRAP).also { it.bottomMargin = activity.dp(10) })
        }
        content.addView(
            activity.button("+ Añadir evento", Ui.ACCENT_DARK) { addMenu(script.events, true) },
            lp(Ui.MATCH, Ui.WRAP)
        )
    }

    private fun colorOf(category: String): Int = when (category) {
        BlockCatalog.EVENTS -> 0xFFB8860B.toInt()
        BlockCatalog.CONTROL -> 0xFFD2691E.toInt()
        BlockCatalog.MOVEMENT -> 0xFF3F7FD9.toInt()
        BlockCatalog.LOOKS -> 0xFF8E5BC7.toInt()
        BlockCatalog.OBJECTS -> 0xFF2E9A68.toInt()
        BlockCatalog.GAME -> 0xFFD6475F.toInt()
        BlockCatalog.VARS -> 0xFF14989A.toInt()
        BlockCatalog.TIME -> 0xFFA86BBE.toInt()
        else -> Ui.PANEL2
    }

    /** Dibuja un bloque con sus huecos y, si es un evento o contenedor, sus bloques de dentro. */
    private fun blockView(b: Block, siblings: MutableList<Block>): View {
        val def = BlockCatalog.def(b.type)
        if (def == null) return activity.label("(bloque desconocido: ${b.type})", 13f, Ui.DANGER)
        val color = colorOf(def.category)

        val card = LinearLayout(activity)
        card.orientation = LinearLayout.VERTICAL
        card.background = roundBg(color, activity.dpf(10f))
        card.setPadding(activity.dp(10), activity.dp(8), activity.dp(8), activity.dp(8))
        card.setOnLongClickListener { blockMenu(b, siblings); true }

        val head = LinearLayout(activity)
        head.gravity = Gravity.CENTER_VERTICAL
        val flow = FlowLayout(activity)
        flow.hGap = activity.dp(4)
        flow.vGap = activity.dp(4)
        for (part in BlockCatalog.parts(def)) {
            val txt = part.text
            val prm = part.param
            if (txt != null) {
                val t = TextView(activity)
                t.text = txt.trim()
                t.textSize = 14f
                t.setTextColor(0xFFFFFFFF.toInt())
                t.setTypeface(Typeface.DEFAULT, Typeface.BOLD)
                t.setPadding(0, activity.dp(10), 0, activity.dp(10))
                if (txt.trim().isNotEmpty()) flow.addView(t)
            } else if (prm != null) {
                flow.addView(paramView(b, prm))
            }
        }
        head.addView(flow, lp(0, Ui.WRAP, 1f))
        val more = activity.button("⋮", 0x33000000) { blockMenu(b, siblings) }
        head.addView(more, lp(Ui.WRAP, Ui.WRAP))
        card.addView(head, lp(Ui.MATCH, Ui.WRAP))

        if (def.help.isNotEmpty()) {
            val h = TextView(activity)
            h.text = def.help
            h.textSize = 11f
            h.setTextColor(0xCCFFFFFF.toInt())
            card.addView(h, lp(Ui.MATCH, Ui.WRAP))
        }

        if (def.kind == BKind.HAT || def.kind == BKind.CONTAINER) {
            card.addView(childrenView(b.children, def.kind == BKind.HAT), lp(Ui.MATCH, Ui.WRAP).also { it.topMargin = activity.dp(6) })
            if (def.hasElse) {
                val s = TextView(activity)
                s.text = "si no"
                s.textSize = 14f
                s.setTextColor(0xFFFFFFFF.toInt())
                s.setTypeface(Typeface.DEFAULT, Typeface.BOLD)
                s.setPadding(0, activity.dp(8), 0, activity.dp(4))
                card.addView(s, lp(Ui.WRAP, Ui.WRAP))
                card.addView(childrenView(b.elseChildren, false), lp(Ui.MATCH, Ui.WRAP))
            }
        }
        return card
    }

    private fun childrenView(list: MutableList<Block>, isEvent: Boolean): View {
        val box = LinearLayout(activity)
        box.orientation = LinearLayout.VERTICAL
        box.setBackgroundColor(0x22000000)
        box.setPadding(activity.dp(8), activity.dp(6), activity.dp(6), activity.dp(6))
        for (c in list) {
            box.addView(blockView(c, list), lp(Ui.MATCH, Ui.WRAP).also { it.bottomMargin = activity.dp(6) })
        }
        val label = if (list.isEmpty() && isEvent) "+ Añadir el primer bloque" else "+ Añadir bloque"
        box.addView(activity.button(label, 0x44000000) { addMenu(list, false) }, lp(Ui.MATCH, Ui.WRAP))
        return box
    }

    // ---------- Huecos ----------
    private fun field(initial: String, hint: String, number: Boolean, onText: (String) -> Unit): EditText {
        val e = EditText(activity)
        e.setText(initial)
        e.hint = hint
        e.setHintTextColor(Ui.MUTED)
        e.setTextColor(0xFF101418.toInt())
        e.textSize = 14f
        e.setSingleLine(true)
        e.minWidth = activity.dp(56)
        e.minHeight = activity.dp(40)
        e.setPadding(activity.dp(8), activity.dp(2), activity.dp(8), activity.dp(2))
        e.background = roundBg(0xFFF3F5F9.toInt(), activity.dpf(8f))
        e.setSelectAllOnFocus(true)
        if (number) e.inputType = InputType.TYPE_CLASS_TEXT
        e.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) { onText(s?.toString() ?: ""); changed() }
        })
        return e
    }

    private fun chip(text: String, onClick: () -> Unit): TextView {
        val t = TextView(activity)
        t.text = text
        t.textSize = 14f
        t.setTextColor(0xFF101418.toInt())
        t.gravity = Gravity.CENTER
        t.minHeight = activity.dp(40)
        t.setPadding(activity.dp(10), activity.dp(4), activity.dp(10), activity.dp(4))
        t.background = roundBg(0xFFF3F5F9.toInt(), activity.dpf(8f))
        t.isClickable = true
        t.setOnClickListener { onClick() }
        return t
    }

    private fun paramView(b: Block, p: BParam): View {
        val cur = b.args[p.name] ?: p.def
        return when (p.kind) {
            PKind.CHOICE -> {
                lateinit var c: TextView
                c = chip(cur + " ▾") {
                    activity.pick(p.name, p.choices) { i ->
                        b.args[p.name] = p.choices[i]
                        c.text = p.choices[i] + " ▾"
                        changed()
                    }
                }
                c
            }
            PKind.COLOR -> {
                val row = LinearLayout(activity)
                row.gravity = Gravity.CENTER_VERTICAL
                val e = field(cur, "red o #ff0000", false) { b.args[p.name] = it }
                row.addView(e, lp(Ui.WRAP, Ui.WRAP))
                row.addView(chip("🎨") {
                    activity.pickColor("Color") { col ->
                        val hex = String.format("#%06x", col and 0xFFFFFF)
                        b.args[p.name] = hex
                        e.setText(hex)
                        changed()
                    }
                }, lp(Ui.WRAP, Ui.WRAP).also { it.leftMargin = activity.dp(4) })
                row
            }
            PKind.COND -> {
                val row = LinearLayout(activity)
                row.gravity = Gravity.CENTER_VERTICAL
                val e = field(cur, "condición", false) { b.args[p.name] = it }
                row.addView(e, lp(Ui.WRAP, Ui.WRAP))
                row.addView(chip("▾") {
                    val presets = BlockCatalog.CONDITION_PRESETS
                    activity.pick("Condiciones frecuentes", presets.map { it.first }) { i ->
                        b.args[p.name] = presets[i].second
                        e.setText(presets[i].second)
                        changed()
                    }
                }, lp(Ui.WRAP, Ui.WRAP).also { it.leftMargin = activity.dp(4) })
                row
            }
            PKind.TEXT, PKind.NAME -> field(cur, if (p.kind == PKind.NAME) "nombre" else "texto", false) { b.args[p.name] = it }
            PKind.IDENT -> field(cur, "nombre", false) { b.args[p.name] = it }
            PKind.NUM -> field(cur, "número", false) { b.args[p.name] = it }
        }
    }

    // ---------- Menús ----------
    private fun addMenu(list: MutableList<Block>, events: Boolean) {
        if (events) {
            pickBlock(list, BlockCatalog.EVENTS)
            return
        }
        val cats = BlockCatalog.categories.filter { it != BlockCatalog.EVENTS }
        activity.pick("¿Qué tipo de bloque?", cats) { ci -> pickBlock(list, cats[ci]) }
    }

    private fun pickBlock(list: MutableList<Block>, category: String) {
        val defs = BlockCatalog.inCategory(category)
        val items = defs.map { d ->
            val shown = BlockCatalog.describe(BlockCatalog.create(d.type))
            if (d.help.isNotEmpty()) shown + "\n" + d.help else shown
        }
        activity.pick(category, items) { i ->
            list.add(BlockCatalog.create(defs[i].type))
            rebuild()
            changed()
        }
    }

    private fun blockMenu(b: Block, siblings: MutableList<Block>) {
        val idx = siblings.indexOf(b)
        if (idx < 0) return
        val items = ArrayList<String>()
        items.add("Duplicar")
        if (idx > 0) items.add("Subir")
        if (idx < siblings.size - 1) items.add("Bajar")
        items.add("Eliminar")
        activity.pick(BlockCatalog.describe(b), items) { i ->
            when (items[i]) {
                "Duplicar" -> siblings.add(idx + 1, b.copy())
                "Subir" -> { siblings.removeAt(idx); siblings.add(idx - 1, b) }
                "Bajar" -> { siblings.removeAt(idx); siblings.add(idx + 1, b) }
                "Eliminar" -> siblings.removeAt(idx)
            }
            rebuild()
            changed()
        }
    }

    // ---------- Variables ----------
    private fun variablesDialog() {
        val names = script.vars.keys.toList()
        val items = ArrayList<String>()
        items.add("+ Nueva variable...")
        items.addAll(names.map { it + " = " + script.vars[it] })
        activity.pick("Variables de este objeto", items) { i ->
            if (i == 0) {
                activity.askText("Nombre = valor inicial", "puntos = 0") { t -> setVar(t, null) }
            } else {
                val old = names[i - 1]
                activity.askText("Nombre = valor (vacío para borrar)", old + " = " + script.vars[old]) { t -> setVar(t, old) }
            }
        }
    }

    private fun setVar(text: String, old: String?) {
        if (old != null) script.vars.remove(old)
        if (text.isBlank()) { rebuild(); changed(); return }
        val n = BlockCompiler.ident(text.substringBefore('=').trim(), "")
        val v = text.substringAfter('=', "0").trim().ifEmpty { "0" }
        if (n.isEmpty()) {
            activity.toast("Escribe un nombre para la variable")
        } else {
            script.vars[n] = v
        }
        rebuild()
        changed()
    }
}
