package com.motor2d.engine

import com.motor2d.core.GdColor
import com.motor2d.core.Vec2
import com.motor2d.script.NoSuch
import com.motor2d.script.ScriptError

/**
 * Tiempos del juego: temporizadores («después de N segundos», «cada N segundos»)
 * y tweens (animar una propiedad suavemente hasta un valor).
 */
class TimerSystem(private val w: World) {

    private class Tm(val id: Long, val owner: GameObject, var left: Double, val interval: Double, val repeat: Boolean, val fn: String)

    private class Tw(
        val target: GameObject, val prop: String, val from: Any?, val to: Any?,
        val dur: Double, val ease: String, var t: Double
    )

    private val timers = ArrayList<Tm>()
    private val tweens = ArrayList<Tw>()
    private var nextId = 1L

    fun clear() { timers.clear(); tweens.clear() }

    val activeCount: Int get() = timers.size + tweens.size

    fun after(owner: GameObject, seconds: Double, fn: String): Long {
        val id = nextId++
        timers.add(Tm(id, owner, Math.max(seconds, 0.0), 0.0, false, fn))
        return id
    }

    fun every(owner: GameObject, seconds: Double, fn: String): Long {
        if (seconds <= 0.0) throw ScriptError("every: el tiempo debe ser mayor que 0")
        val id = nextId++
        timers.add(Tm(id, owner, seconds, seconds, true, fn))
        return id
    }

    fun cancel(id: Long) { timers.removeAll { it.id == id } }

    fun cancelAll(owner: GameObject) { timers.removeAll { it.owner === owner } }

    fun tween(target: GameObject, prop: String, to: Any?, seconds: Double, ease: String) {
        val from = readProp(target, prop)
        val dest = convert(prop, from, to)
        tweens.removeAll { it.target === target && it.prop == prop }
        if (seconds <= 0.0) { writeProp(target, prop, dest); return }
        tweens.add(Tw(target, prop, from, dest, seconds, ease, 0.0))
    }

    fun update(dt: Double) {
        if (timers.isNotEmpty()) {
            for (t in ArrayList(timers)) {
                if (t.owner.destroyed) { timers.remove(t); continue }
                if (!t.owner.isActiveInHierarchy()) continue
                t.left -= dt
                var fired = 0
                while (t.left <= 0.0 && fired < 5) {
                    fired++
                    if (t.repeat) t.left += t.interval else { timers.remove(t); t.left = 1.0 }
                    w.callFunction(t.owner, t.fn)
                    if (w.error != null) return
                    if (!t.repeat) break
                }
                if (t.repeat && t.left <= 0.0) t.left = t.interval
            }
        }
        if (tweens.isNotEmpty()) {
            for (tw in ArrayList(tweens)) {
                if (tw.target.destroyed) { tweens.remove(tw); continue }
                tw.t += dt
                val k = if (tw.t >= tw.dur) 1.0 else ease(tw.ease, tw.t / tw.dur)
                writeProp(tw.target, tw.prop, lerp(tw.from, tw.to, k))
                if (tw.t >= tw.dur) tweens.remove(tw)
            }
        }
    }

    // ---------- Propiedades ----------
    private fun readProp(o: GameObject, prop: String): Any? {
        if (prop == "color") {
            val c = o.sprite?.c("color") ?: o.label?.c("color") ?: throw ScriptError("tween: el objeto no tiene dibujo ni texto con color")
            return GdColor.fromArgb(c)
        }
        val v = o.getProp(prop)
        if (v === NoSuch || v == null) throw ScriptError("tween: no se puede animar '$prop' (usa position, rotation, scale o color)")
        return v
    }

    private fun writeProp(o: GameObject, prop: String, v: Any?) {
        if (prop == "color") { o.callMethod("set_color", listOf(v)); return }
        o.setProp(prop, v)
    }

    private fun convert(prop: String, from: Any?, to: Any?): Any? = when (from) {
        is Vec2 -> Coerce.toVec(to, prop)
        is GdColor -> to as? GdColor ?: throw ScriptError("tween: el destino de 'color' debe ser un Color")
        else -> Coerce.toDouble(to, prop)
    }

    private fun lerp(a: Any?, b: Any?, k: Double): Any? = when (a) {
        is Vec2 -> { val bb = b as Vec2; Vec2(a.x + (bb.x - a.x) * k, a.y + (bb.y - a.y) * k) }
        is GdColor -> {
            val bb = b as GdColor
            GdColor(a.r + (bb.r - a.r) * k, a.g + (bb.g - a.g) * k, a.b + (bb.b - a.b) * k, a.a + (bb.a - a.a) * k)
        }
        else -> { val x = Coerce.toDouble(a, "tween"); x + (Coerce.toDouble(b, "tween") - x) * k }
    }

    companion object {
        val EASINGS = listOf("linear", "ease_in", "ease_out", "ease_in_out", "bounce")

        /** Curva de 0..1 a 0..1. */
        fun ease(name: String, t0: Double): Double {
            val t = t0.coerceIn(0.0, 1.0)
            return when (name) {
                "ease_in" -> t * t
                "ease_out" -> 1.0 - (1.0 - t) * (1.0 - t)
                "ease_in_out" -> if (t < 0.5) 2.0 * t * t else 1.0 - Math.pow(-2.0 * t + 2.0, 2.0) / 2.0
                "bounce" -> bounce(t)
                else -> t
            }
        }

        private fun bounce(x: Double): Double {
            val n1 = 7.5625; val d1 = 2.75
            return when {
                x < 1.0 / d1 -> n1 * x * x
                x < 2.0 / d1 -> { val t = x - 1.5 / d1; n1 * t * t + 0.75 }
                x < 2.5 / d1 -> { val t = x - 2.25 / d1; n1 * t * t + 0.9375 }
                else -> { val t = x - 2.625 / d1; n1 * t * t + 0.984375 }
            }
        }
    }
}
