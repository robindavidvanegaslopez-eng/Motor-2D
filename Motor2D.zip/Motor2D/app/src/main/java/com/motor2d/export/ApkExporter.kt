package com.motor2d.export

import java.io.File
import java.io.OutputStream
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.cert.X509Certificate
import java.util.zip.ZipFile

/**
 * Genera un APK de juego a partir del APK de la propia app (plantilla):
 * parchea el AndroidManifest binario, añade los archivos del juego, quita la firma antigua, alinea (estilo zipalign)
 * y firma con v1 (JAR, SHA-256withRSA) + v2 (APK Signature Scheme v2).
 */
object ApkExporter {
    /** Alineamiento de las .so STORED. 4096 como pidió el encargo (16384 serviría también para dispositivos de páginas de 16 KB). */
    const val SO_ALIGNMENT = 4096
    const val DEFAULT_ALIGNMENT = 4

    private const val MANIFEST = "AndroidManifest.xml"
    private const val ARSC = "resources.arsc"

    /** Ficheros de firma de META-INF (raíz) que se descartan; el resto de META-INF (p.ej. *.version) se conserva. */
    internal fun isSignatureFile(name: String): Boolean {
        if (name == "META-INF/" ) return true
        if (!name.startsWith("META-INF/")) return false
        val rest = name.substring(9)
        if (rest.contains('/')) return false
        val up = rest.uppercase()
        return up == "MANIFEST.MF" || up.endsWith(".SF") || up.endsWith(".RSA") || up.endsWith(".DSA") ||
            up.endsWith(".EC") || up.startsWith("SIG-")
    }

    internal fun patchManifest(manifest: ByteArray, cfg: ExportConfig): ByteArray {
        // los nombres relativos (".app.MainActivity") se fijan al paquete viejo antes de cambiarlo
        var m = if (cfg.oldPackageName != cfg.packageName) AxmlPatcher.qualifyClassNames(manifest, cfg.oldPackageName) else manifest
        m = AxmlPatcher.rebasePackagePrefix(m, cfg.oldPackageName, cfg.packageName)
        m = AxmlPatcher.replaceStrings(m, mapOf(cfg.oldPackageName to cfg.packageName), strict = true)
        if (cfg.oldAppName.isNotEmpty() && cfg.oldAppName != cfg.appName)
            m = AxmlPatcher.replaceStrings(m, mapOf(cfg.oldAppName to cfg.appName), strict = false)
        // garantiza la etiqueta aunque sea una referencia a recurso (@string/app_name) en vez de texto literal
        m = AxmlPatcher.setAttribute(m, "application", "label", cfg.appName, strict = true)
        m = AxmlPatcher.setManifestVersionName(m, cfg.versionName, strict = false)
        return m
    }

    private fun checkExtraName(n: String) {
        // los caracteres de control (CR/LF sobre todo) inyectarían cabeceras en META-INF/MANIFEST.MF
        require(n.none { it < ' ' || it == '\u007f' }) { "Nombre de archivo con caracteres de control: '${n.replace(Regex("[\\u0000-\\u001f\\u007f]"), "?")}'" }
        require(n.isNotEmpty() && !n.startsWith("/") && !n.endsWith("/") && !n.contains('\\') && !n.contains('\u0000')) { "Nombre de archivo inválido: '$n'" }
        require(n.split('/').none { it.isEmpty() || it == "." || it == ".." }) { "Nombre de archivo inválido: '$n'" }
        require(!n.startsWith("META-INF/")) { "Los extras no pueden estar en META-INF/: '$n'" }
        require(n != MANIFEST) { "Los extras no pueden sustituir $MANIFEST" }
    }

    fun export(
        templateApk: File, out: OutputStream, extraFiles: Map<String, ByteArray>, cfg: ExportConfig,
        privateKey: PrivateKey, certificate: X509Certificate
    ) {
        require(cfg.packageName.isValidPackageName()) { "Nombre de paquete inválido: '${cfg.packageName}'" }
        require(cfg.oldPackageName.isNotEmpty()) { "oldPackageName vacío" }
        require(cfg.appName.isNotEmpty()) { "appName vacío" }
        require(cfg.appName.none { it < ' ' || it == '\u007f' }) { "appName con caracteres de control" }
        require(cfg.versionName.none { it < ' ' || it == '\u007f' }) { "versionName con caracteres de control" }
        require(privateKey.algorithm.equals("RSA", ignoreCase = true)) { "Solo se admiten claves RSA (la clave es ${privateKey.algorithm})" }
        for (k in extraFiles.keys) checkExtraName(k)

        val sha = MessageDigest.getInstance("SHA-256")
        ZipFile(templateApk).use { zf ->
            val zip = ZipWriter((templateApk.length() + extraFiles.values.sumOf { it.size.toLong() } + 65536L)
                .coerceAtMost(Int.MAX_VALUE - 8L).toInt())
            val v1 = ArrayList<V1Signer.Entry>()
            val seen = HashSet<String>()

            fun put(name: String, method: Int, data: ByteArray) {
                val align = if (method == ZipWriter.STORED) (if (name.endsWith(".so")) SO_ALIGNMENT else DEFAULT_ALIGNMENT) else 1
                zip.add(name, method, data, align)
                v1.add(V1Signer.Entry(name, sha.digest(data)))
            }

            var hasManifest = false
            for (e in zf.entries()) {
                val name = e.name
                if (e.isDirectory || isSignatureFile(name)) continue
                if (name in extraFiles) continue // los extras sustituyen
                if (!seen.add(name)) continue
                var data = zf.getInputStream(e).use { it.readBytes() }
                if (name == MANIFEST) { data = patchManifest(data, cfg); hasManifest = true }
                val method = if (name == ARSC) ZipWriter.STORED
                else if (e.method == java.util.zip.ZipEntry.STORED) ZipWriter.STORED else ZipWriter.DEFLATED
                put(name, method, data)
            }
            if (!hasManifest) throw IllegalArgumentException("La plantilla no contiene $MANIFEST")
            for (name in extraFiles.keys.sorted()) put(name, if (name == ARSC) ZipWriter.STORED else ZipWriter.DEFLATED, extraFiles.getValue(name))

            // firma v1
            val (mf, sf, rsa) = V1Signer.sign(v1, privateKey, certificate)
            zip.add("META-INF/MANIFEST.MF", ZipWriter.DEFLATED, mf)
            zip.add("META-INF/CERT.SF", ZipWriter.DEFLATED, sf)
            zip.add("META-INF/CERT.RSA", ZipWriter.DEFLATED, rsa)

            // firma v2: el bloque se inserta justo antes del directorio central
            val cdOffset = zip.cdOffset
            val cd = zip.buildCentralDirectory()
            val eocdUnsigned = zip.buildEocd(cd.size, cdOffset)
            val block = V2Signer.buildSigningBlock(zip.buf.array, cdOffset, cd, eocdUnsigned, privateKey, certificate)
            if (cdOffset.toLong() + block.size + cd.size + ZipWriter.EOCD_SIZE > Int.MAX_VALUE) throw IllegalStateException("APK demasiado grande")
            val eocd = zip.buildEocd(cd.size, cdOffset + block.size)
            out.write(zip.buf.array, 0, cdOffset)
            out.write(block)
            out.write(cd)
            out.write(eocd)
            out.flush()
        }
    }
}
