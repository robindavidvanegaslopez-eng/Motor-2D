package com.motor2d.app

import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import com.motor2d.editor.EditorModel
import com.motor2d.editor.PixelImage
import com.motor2d.editor.SpriteDoc
import com.motor2d.engine.GameObject

/** Miniatura de un cuadro de la animación. */
private class FrameThumb(val act: MainActivity, val img: PixelImage) : View(act) {
    var selected = false
    private val bmp: Bitmap = Bitmap.createBitmap(img.w, img.h, Bitmap.Config.ARGB_8888)
    private val p = Paint()
    private val dst = RectF()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.style = Paint.Style.FILL
        p.color = 0xFF2E3544.toInt()
        c.drawRect(0f, 0f, w, h, p)
        bmp.setPixels(img.px, 0, img.w, 0, 0, img.w, img.h)
        val s = minOf((w - 8f) / img.w, (h - 8f) / img.h)
        val iw = img.w * s
        val ih = img.h * s
        dst.set((w - iw) / 2f, (h - ih) / 2f, (w + iw) / 2f, (h + ih) / 2f)
        c.drawBitmap(bmp, null, dst, null)
        p.style = Paint.Style.STROKE
        p.strokeWidth = if (selected) 4f else 2f
        p.color = if (selected) Ui.ACCENT else Ui.PANEL2
        c.drawRect(1f, 1f, w - 1f, h - 1f, p)
    }
}

/**
 * Editor de sprites a pantalla completa: lienzo de píxeles, herramientas, paleta y animación por cuadros.
 * Funciona con el dedo y con mouse + teclado (B lápiz, E borrador, G cubo, L línea, R rectángulo, O óvalo, I cuentagotas,
 * Ctrl+Z / Ctrl+Y deshacer y rehacer, [ ] cuadro anterior y siguiente, Ctrl+S guardar).
 */
class SpriteEditor(
    private val act: MainActivity,
    private val model: EditorModel,
    private val target: GameObject,
    private val doc: SpriteDoc,
    private val onClose: (Boolean) -> Unit
) {
    private val root = LinearLayout(act)
    val view: View get() = root

    private val canvas = PixelCanvasView(act, doc)
    private val body = LinearLayout(act)
    private val panel = LinearLayout(act)
    private val toolButtons = ArrayList<Pair<PixelCanvasView.Tool, TextView>>()
    private val toggleButtons = HashMap<String, TextView>()
    private val paletteRow = LinearLayout(act)
    private val framesRow = LinearLayout(act)
    private val info = TextView(act)
    private val fpsField = act.input(Fmt.fps(doc.fps), "fps", true)
    private lateinit var undoBtn: TextView
    private lateinit var redoBtn: TextView
    private lateinit var playBtn: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var playing = false
    private var playIndex = 0
    private var changed = false
    private var savedOnce = false
    private var currentColor: Int = SpriteDoc.PALETTE[8]

    private object Fmt {
        fun fps(v: Double): String = if (v == Math.floor(v)) v.toLong().toString() else v.toString()
    }

    init {
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)
        root.isClickable = true
        root.addView(buildTopBar(), lp(Ui.MATCH, Ui.WRAP))

        canvas.color = currentColor
        canvas.onChanged = { changed = true; refreshState() }
        canvas.onColorPicked = { c -> currentColor = c; buildPalette(); setTool(PixelCanvasView.Tool.PENCIL) }

        panel.orientation = LinearLayout.VERTICAL
        panel.setBackgroundColor(Ui.PANEL)
        panel.addView(buildTools(), lp(Ui.MATCH, Ui.WRAP))
        panel.addView(buildPaletteScroll(), lp(Ui.MATCH, Ui.WRAP))
        panel.addView(buildFramesBar(), lp(Ui.MATCH, Ui.WRAP))

        body.addView(canvas)
        body.addView(panel)
        root.addView(body, lp(Ui.MATCH, 0, 1f))
        info.textSize = 12f
        info.setTextColor(Ui.MUTED)
        info.setPadding(act.dp(10), act.dp(2), act.dp(10), act.dp(4))
        root.addView(info, lp(Ui.MATCH, Ui.WRAP))

        applyOrientation()
        setTool(PixelCanvasView.Tool.PENCIL)
        buildPalette()
        buildFrames()
        refreshState()
    }

    // ---------- Construcción ----------
    private fun buildTopBar(): View {
        val bar = LinearLayout(act)
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(Ui.PANEL)
        bar.setPadding(act.dp(6), act.dp(4), act.dp(6), act.dp(4))
        bar.addView(act.button("←") { tryClose() }, lp(Ui.WRAP, Ui.WRAP))
        val t = act.label("Sprite · " + doc.name + " (" + doc.w + "×" + doc.h + ")", 15f)
        t.setSingleLine(true)
        t.setPadding(act.dp(10), 0, act.dp(4), 0)
        bar.addView(t, lp(0, Ui.WRAP, 1f))
        undoBtn = act.button("↩") { stopPlaying(); doc.undo(); changed = true; refreshAll() }
        redoBtn = act.button("↪") { stopPlaying(); doc.redo(); changed = true; refreshAll() }
        bar.addView(undoBtn, lp(Ui.WRAP, Ui.WRAP))
        bar.addView(redoBtn, lp(Ui.WRAP, Ui.WRAP).also { it.leftMargin = act.dp(4) })
        playBtn = act.button("▶", Ui.PANEL2) { togglePlay() }
        bar.addView(playBtn, lp(Ui.WRAP, Ui.WRAP).also { it.leftMargin = act.dp(4) })
        bar.addView(act.button("Aplicar", Ui.ACCENT, 0xFF04202D.toInt()) { saveAndApply(true) },
            lp(Ui.WRAP, Ui.WRAP).also { it.leftMargin = act.dp(6) })
        bar.addView(act.button("⋮") { moreMenu() }, lp(Ui.WRAP, Ui.WRAP).also { it.leftMargin = act.dp(4) })
        return bar
    }

    private fun buildTools(): View {
        val sv = HorizontalScrollView(act)
        sv.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(act)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(act.dp(4), act.dp(4), act.dp(4), act.dp(2))
        val tools = listOf(
            PixelCanvasView.Tool.PENCIL to "✎ Lápiz",
            PixelCanvasView.Tool.ERASER to "⌫ Borrar",
            PixelCanvasView.Tool.FILL to "▨ Cubo",
            PixelCanvasView.Tool.PICK to "⌖ Gota",
            PixelCanvasView.Tool.LINE to "╱ Línea",
            PixelCanvasView.Tool.RECT to "▭ Rect.",
            PixelCanvasView.Tool.RECT_FILL to "■ Rect. lleno",
            PixelCanvasView.Tool.OVAL to "◯ Óvalo",
            PixelCanvasView.Tool.OVAL_FILL to "● Óvalo lleno"
        )
        for (pair in tools) {
            val tool = pair.first
            val b = act.button(pair.second) { stopPlaying(); setTool(tool) }
            toolButtons.add(Pair(tool, b))
            row.addView(b, lp(Ui.WRAP, Ui.WRAP).also { it.rightMargin = act.dp(4) })
        }
        row.addView(toggle("mx", "↔ Espejo") { canvas.mirrorX = !canvas.mirrorX; canvas.mirrorX })
        row.addView(toggle("my", "↕ Espejo") { canvas.mirrorY = !canvas.mirrorY; canvas.mirrorY })
        row.addView(toggle("grid", "# Cuadrícula") { canvas.showGrid = !canvas.showGrid; canvas.showGrid })
        row.addView(toggle("onion", "◐ Cebolla") { canvas.onionSkin = !canvas.onionSkin; canvas.onionSkin })
        row.addView(act.button("⤢ Ajustar") { canvas.fit() }, lp(Ui.WRAP, Ui.WRAP))
        sv.addView(row)
        refreshToggleLook()
        return sv
    }

    private fun toggle(key: String, text: String, flip: () -> Boolean): View {
        val b = act.button(text) { flip(); refreshToggleLook(); canvas.invalidate() }
        toggleButtons[key] = b
        val holder = LinearLayout(act)
        holder.addView(b, lp(Ui.WRAP, Ui.WRAP).also { it.rightMargin = act.dp(4) })
        return holder
    }

    private fun refreshToggleLook() {
        val states = mapOf("mx" to canvas.mirrorX, "my" to canvas.mirrorY, "grid" to canvas.showGrid, "onion" to canvas.onionSkin)
        for (e in toggleButtons.entries) {
            val on = states[e.key] == true
            e.value.background = roundBg(if (on) Ui.ACCENT_DARK else Ui.PANEL2, act.dpf(10f))
        }
    }

    private fun buildPaletteScroll(): View {
        val sv = HorizontalScrollView(act)
        sv.isHorizontalScrollBarEnabled = false
        paletteRow.gravity = Gravity.CENTER_VERTICAL
        paletteRow.setPadding(act.dp(4), act.dp(2), act.dp(4), act.dp(2))
        sv.addView(paletteRow)
        return sv
    }

    private fun swatch(color: Int, selected: Boolean, onTap: () -> Unit): View {
        val v = View(act)
        val bg = if ((color ushr 24) == 0) roundBg(0xFF3A4254.toInt(), act.dpf(6f), if (selected) Ui.ACCENT else Ui.MUTED, act.dp(if (selected) 3 else 1))
        else roundBg(color, act.dpf(6f), if (selected) Ui.ACCENT else Ui.MUTED, act.dp(if (selected) 3 else 1))
        v.background = bg
        v.setOnClickListener { onTap() }
        return v
    }

    private fun buildPalette() {
        paletteRow.removeAllViews()
        val cur = swatch(currentColor, true) {}
        paletteRow.addView(cur, lp(act.dp(44), act.dp(44)).also { it.rightMargin = act.dp(8) })
        for (c in SpriteDoc.PALETTE) {
            val v = swatch(c, c == currentColor) { selectColor(c) }
            paletteRow.addView(v, lp(act.dp(34), act.dp(34)).also { it.rightMargin = act.dp(4) })
        }
        paletteRow.addView(act.button("Más…") { act.pickColor("Color") { c -> selectColor(c) } }, lp(Ui.WRAP, act.dp(34)).also { it.rightMargin = act.dp(4) })
        paletteRow.addView(act.button("#hex") {
            act.askText("Color (RRGGBB o AARRGGBB)", "") { t ->
                val c = parseHex(t)
                if (c == null) act.toast("Escribe un color como FF8800") else selectColor(c)
            }
        }, lp(Ui.WRAP, act.dp(34)))
    }

    private fun parseHex(raw: String): Int? {
        val s = raw.trim().removePrefix("#")
        if (s.length != 6 && s.length != 8) return null
        val v = try { java.lang.Long.parseLong(s, 16) } catch (e: NumberFormatException) { return null }
        return if (s.length == 6) (0xFF000000L or v).toInt() else v.toInt()
    }

    private fun selectColor(c: Int) {
        currentColor = c
        canvas.color = c
        if ((c ushr 24) == 0) setTool(PixelCanvasView.Tool.ERASER)
        else if (canvas.tool == PixelCanvasView.Tool.ERASER || canvas.tool == PixelCanvasView.Tool.PICK) setTool(PixelCanvasView.Tool.PENCIL)
        buildPalette()
    }

    private fun buildFramesBar(): View {
        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL
        val sv = HorizontalScrollView(act)
        sv.isHorizontalScrollBarEnabled = false
        framesRow.gravity = Gravity.CENTER_VERTICAL
        framesRow.setPadding(act.dp(4), act.dp(2), act.dp(4), act.dp(2))
        sv.addView(framesRow)
        box.addView(sv, lp(Ui.MATCH, Ui.WRAP))

        val ctl = LinearLayout(act)
        ctl.gravity = Gravity.CENTER_VERTICAL
        ctl.setPadding(act.dp(4), 0, act.dp(4), act.dp(4))
        ctl.addView(act.button("+ Cuadro") { stopPlaying(); doc.addFrame(); changed = true; refreshAll() }, lp(Ui.WRAP, Ui.WRAP))
        ctl.addView(act.button("⧉") { stopPlaying(); doc.duplicateFrame(); changed = true; refreshAll() }, lp(Ui.WRAP, Ui.WRAP).also { it.leftMargin = act.dp(4) })
        ctl.addView(act.button("🗑") {
            stopPlaying()
            if (!doc.deleteFrame()) act.toast("Tiene que quedar al menos un cuadro") else { changed = true; refreshAll() }
        }, lp(Ui.WRAP, Ui.WRAP).also { it.leftMargin = act.dp(4) })
        ctl.addView(act.button("◀") { stopPlaying(); if (doc.moveFrame(-1)) { changed = true; refreshAll() } }, lp(Ui.WRAP, Ui.WRAP).also { it.leftMargin = act.dp(4) })
        ctl.addView(act.button("▶") { stopPlaying(); if (doc.moveFrame(1)) { changed = true; refreshAll() } }, lp(Ui.WRAP, Ui.WRAP).also { it.leftMargin = act.dp(4) })
        val fpsLabel = act.label("fps", 12f, Ui.MUTED)
        fpsLabel.setPadding(act.dp(10), 0, act.dp(4), 0)
        ctl.addView(fpsLabel, lp(Ui.WRAP, Ui.WRAP))
        fpsField.commitOn { t ->
            val v = t.trim().replace(',', '.').toDoubleOrNull()
            if (v == null || v < 0.5 || v > 60.0) { act.toast("Usa un número entre 1 y 60"); fpsField.setText(Fmt.fps(doc.fps)) }
            else { doc.fps = v; changed = true }
        }
        ctl.addView(fpsField, lp(act.dp(64), Ui.WRAP))
        box.addView(ctl, lp(Ui.MATCH, Ui.WRAP))
        return box
    }

    private fun buildFrames() {
        framesRow.removeAllViews()
        for (i in doc.frames.indices) {
            val t = FrameThumb(act, doc.frames[i])
            t.selected = i == doc.cur
            t.setOnClickListener { stopPlaying(); doc.select(i); refreshAll() }
            framesRow.addView(t, lp(act.dp(54), act.dp(54)).also { it.rightMargin = act.dp(4) })
        }
    }

    // ---------- Estado ----------
    private fun setTool(t: PixelCanvasView.Tool) {
        canvas.tool = t
        for (p in toolButtons) {
            p.second.background = roundBg(if (p.first == t) Ui.ACCENT_DARK else Ui.PANEL2, act.dpf(10f))
        }
    }

    private fun refreshState() {
        undoBtn.alpha = if (doc.canUndo) 1f else 0.35f
        redoBtn.alpha = if (doc.canRedo) 1f else 0.35f
        info.text = "Cuadro " + (doc.cur + 1) + " de " + doc.frames.size + "  ·  " + (if (changed) "sin aplicar" else "aplicado") +
            "  ·  dos dedos o rueda: zoom  ·  clic derecho: mover"
        for (i in 0 until framesRow.childCount) {
            val v = framesRow.getChildAt(i)
            if (v is FrameThumb) { v.selected = i == doc.cur; v.invalidate() }
        }
    }

    private fun refreshAll() {
        buildFrames()
        canvas.invalidate()
        refreshState()
    }

    private fun applyOrientation() {
        val land = act.resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        if (land) {
            body.orientation = LinearLayout.HORIZONTAL
            canvas.layoutParams = lp(0, Ui.MATCH, 3f)
            panel.layoutParams = lp(0, Ui.MATCH, 2f)
        } else {
            body.orientation = LinearLayout.VERTICAL
            canvas.layoutParams = lp(Ui.MATCH, 0, 1f)
            panel.layoutParams = lp(Ui.MATCH, Ui.WRAP)
        }
        body.requestLayout()
        canvas.post { canvas.fit() }
    }

    fun onConfigurationChanged() { applyOrientation() }

    // ---------- Animación ----------
    private val ticker = object : Runnable {
        override fun run() {
            if (!playing) return
            playIndex = (playIndex + 1) % doc.frames.size
            doc.select(playIndex)
            canvas.invalidate()
            refreshState()
            handler.postDelayed(this, (1000.0 / Math.max(doc.fps, 0.5)).toLong())
        }
    }

    private fun togglePlay() {
        if (playing) { stopPlaying(); return }
        if (doc.frames.size < 2) { act.toast("Añade más cuadros para ver la animación"); return }
        playing = true
        playIndex = doc.cur
        canvas.locked = true
        playBtn.text = "■"
        playBtn.background = roundBg(Ui.DANGER, act.dpf(10f))
        handler.postDelayed(ticker, (1000.0 / Math.max(doc.fps, 0.5)).toLong())
    }

    private fun stopPlaying() {
        if (!playing) return
        playing = false
        handler.removeCallbacks(ticker)
        canvas.locked = false
        playBtn.text = "▶"
        playBtn.background = roundBg(Ui.PANEL2, act.dpf(10f))
        refreshAll()
    }

    // ---------- Menú ----------
    private fun moreMenu() {
        stopPlaying()
        val items = ArrayList<Pair<String, () -> Unit>>()
        items.add("Voltear horizontal" to { doc.checkpoint(); doc.image.flipH(); changed = true; refreshAll() })
        items.add("Voltear vertical" to { doc.checkpoint(); doc.image.flipV(); changed = true; refreshAll() })
        if (doc.w == doc.h) items.add("Girar 90°" to {
            doc.checkpoint()
            val r = doc.image.rotated90()
            System.arraycopy(r.px, 0, doc.image.px, 0, r.px.size)
            changed = true; refreshAll()
        })
        items.add("Mover dibujo ←" to { doc.checkpoint(); doc.image.shift(-1, 0); changed = true; refreshAll() })
        items.add("Mover dibujo →" to { doc.checkpoint(); doc.image.shift(1, 0); changed = true; refreshAll() })
        items.add("Mover dibujo ↑" to { doc.checkpoint(); doc.image.shift(0, -1); changed = true; refreshAll() })
        items.add("Mover dibujo ↓" to { doc.checkpoint(); doc.image.shift(0, 1); changed = true; refreshAll() })
        items.add("Limpiar este cuadro" to { doc.checkpoint(); doc.image.clear(); changed = true; refreshAll() })
        items.add("Guardar sin cerrar" to { saveAndApply(false) })
        act.pick("Más opciones", items.map { it.first }) { i -> items[i].second() }
    }

    // ---------- Guardar y cerrar ----------
    private fun saveAndApply(close: Boolean) {
        stopPlaying()
        try {
            model.applySprite(target, doc)
            changed = false
            savedOnce = true
            refreshState()
            act.toast("Sprite aplicado a «" + target.name + "»")
            if (close) onClose(true)
        } catch (e: Exception) {
            act.toast("No se pudo guardar: " + (e.message ?: "error"))
        }
    }

    fun tryClose() {
        stopPlaying()
        if (!changed) { onClose(savedOnce); return }
        AlertDialog.Builder(act)
            .setTitle("Hay cambios sin aplicar")
            .setMessage("¿Quieres guardar el sprite y aplicarlo al objeto?")
            .setPositiveButton("Guardar y aplicar") { _, _ -> saveAndApply(true) }
            .setNegativeButton("Descartar") { _, _ -> onClose(savedOnce) }
            .setNeutralButton("Seguir editando", null)
            .show()
    }

    fun dispose() {
        playing = false
        handler.removeCallbacks(ticker)
    }

    // ---------- Teclado (PC) ----------
    fun onKey(keyCode: Int, ctrl: Boolean, shift: Boolean): Boolean {
        if (ctrl) {
            when (keyCode) {
                KeyEvent.KEYCODE_Z -> { if (shift) doc.redo() else doc.undo(); changed = true; refreshAll(); return true }
                KeyEvent.KEYCODE_Y -> { doc.redo(); changed = true; refreshAll(); return true }
                KeyEvent.KEYCODE_S -> { saveAndApply(false); return true }
            }
            return false
        }
        val tool: PixelCanvasView.Tool? = when (keyCode) {
            KeyEvent.KEYCODE_B -> PixelCanvasView.Tool.PENCIL
            KeyEvent.KEYCODE_E -> PixelCanvasView.Tool.ERASER
            KeyEvent.KEYCODE_G -> PixelCanvasView.Tool.FILL
            KeyEvent.KEYCODE_L -> PixelCanvasView.Tool.LINE
            KeyEvent.KEYCODE_R -> if (shift) PixelCanvasView.Tool.RECT_FILL else PixelCanvasView.Tool.RECT
            KeyEvent.KEYCODE_O -> if (shift) PixelCanvasView.Tool.OVAL_FILL else PixelCanvasView.Tool.OVAL
            KeyEvent.KEYCODE_I -> PixelCanvasView.Tool.PICK
            else -> null
        }
        if (tool != null) { stopPlaying(); setTool(tool); return true }
        when (keyCode) {
            KeyEvent.KEYCODE_LEFT_BRACKET -> { stopPlaying(); doc.select(doc.cur - 1); refreshAll(); return true }
            KeyEvent.KEYCODE_RIGHT_BRACKET -> { stopPlaying(); doc.select(doc.cur + 1); refreshAll(); return true }
            KeyEvent.KEYCODE_SPACE -> { togglePlay(); return true }
            KeyEvent.KEYCODE_X -> { canvas.mirrorX = !canvas.mirrorX; refreshToggleLook(); canvas.invalidate(); return true }
            KeyEvent.KEYCODE_F -> { canvas.fit(); return true }
        }
        return false
    }

    companion object {
        private const val MAX_SIDE = 256

        /** Abre el sprite que ya tiene el objeto (todos sus cuadros) o null si no tiene imagen editable. */
        fun loadExisting(model: EditorModel, o: GameObject): SpriteDoc? {
            val sp = o.sprite ?: return null
            val first = sp.s("image")
            if (first.isEmpty()) return null
            val framesText = sp.s("frames")
            val paths = ArrayList<String>()
            if (framesText.isNotBlank() && !framesText.contains(':') && !framesText.contains(';')) {
                for (part in framesText.split(',')) { val t = part.trim(); if (t.isNotEmpty()) paths.add(t) }
            }
            if (paths.isEmpty()) paths.add(first)
            val images = ArrayList<PixelImage>()
            for (path in paths) {
                val data = model.project.readBytes(path) ?: continue
                val bmp = try { BitmapFactory.decodeByteArray(data, 0, data.size) } catch (e: Exception) { null } ?: continue
                images.add(fromBitmap(bmp))
            }
            if (images.isEmpty()) return null
            val w = images[0].w
            val h = images[0].h
            if (w > MAX_SIDE || h > MAX_SIDE) return null
            val base = paths[0].substringAfterLast('/').substringBeforeLast('.').let { n ->
                if (paths.size > 1 && n.matches(Regex(".*_1"))) n.removeSuffix("_1") else n
            }
            val d = SpriteDoc(SpriteDoc.cleanName(base), w, h)
            d.frames.clear()
            for (img in images) d.frames.add(if (img.w == w && img.h == h) img else img.resizedCanvas(w, h))
            d.cur = 0
            d.fps = sp.f("fps").let { if (it >= 0.5) it else 8.0 }
            return d
        }

        private fun fromBitmap(b: Bitmap): PixelImage {
            val px = IntArray(b.width * b.height)
            b.getPixels(px, 0, b.width, 0, 0, b.width, b.height)
            return PixelImage(b.width, b.height, px)
        }
    }
}
