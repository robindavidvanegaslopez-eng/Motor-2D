package com.motor2d.app

import android.content.Context
import android.view.View
import android.view.ViewGroup

/** Coloca sus hijos en fila y salta a la línea siguiente cuando no caben (para las etiquetas de los bloques). */
class FlowLayout(context: Context) : ViewGroup(context) {
    var hGap = 0
    var vGap = 0

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val maxW = (View.MeasureSpec.getSize(widthSpec) - paddingLeft - paddingRight).coerceAtLeast(1)
        var x = 0
        var y = 0
        var rowH = 0
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            if (c.visibility == View.GONE) continue
            c.measure(
                View.MeasureSpec.makeMeasureSpec(maxW, View.MeasureSpec.AT_MOST),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            val w = c.measuredWidth
            val h = c.measuredHeight
            if (x > 0 && x + w > maxW) {
                y += rowH + vGap
                x = 0
                rowH = 0
            }
            x += w + hGap
            if (h > rowH) rowH = h
        }
        val total = y + rowH + paddingTop + paddingBottom
        setMeasuredDimension(View.MeasureSpec.getSize(widthSpec), total)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val maxW = (r - l - paddingLeft - paddingRight).coerceAtLeast(1)
        var x = 0
        var y = 0
        var rowH = 0
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            if (c.visibility == View.GONE) continue
            val w = c.measuredWidth
            val h = c.measuredHeight
            if (x > 0 && x + w > maxW) {
                y += rowH + vGap
                x = 0
                rowH = 0
            }
            c.layout(paddingLeft + x, paddingTop + y, paddingLeft + x + w, paddingTop + y + h)
            x += w + hGap
            if (h > rowH) rowH = h
        }
    }
}
