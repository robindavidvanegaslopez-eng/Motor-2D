package com.motor2d.editor

import java.io.ByteArrayOutputStream
import java.util.zip.CRC32
import java.util.zip.Deflater

/** Una imagen de píxeles (ARGB) con las herramientas de dibujo del editor de sprites. Sin dependencias de Android. */
class PixelImage(val w: Int, val h: Int, val px: IntArray = IntArray(w * h)) {
    init { require(w in 1..MAX && h in 1..MAX && px.size == w * h) { "Tamaño de imagen no válido" } }

    fun inside(x: Int, y: Int) = x in 0 until w && y in 0 until h
    fun get(x: Int, y: Int): Int = if (inside(x, y)) px[y * w + x] else 0
    fun set(x: Int, y: Int, c: Int) { if (inside(x, y)) px[y * w + x] = c }
    fun copy() = PixelImage(w, h, px.copyOf())
    fun clear() = px.fill(0)
    fun isEmpty() = px.all { (it ushr 24) == 0 }

    /** Pinta un punto; con simetría también en el espejo horizontal y/o vertical. */
    fun plot(x: Int, y: Int, c: Int, mirrorX: Boolean = false, mirrorY: Boolean = false) {
        set(x, y, c)
        if (mirrorX) set(w - 1 - x, y, c)
        if (mirrorY) set(x, h - 1 - y, c)
        if (mirrorX && mirrorY) set(w - 1 - x, h - 1 - y, c)
    }

    /** Relleno de un color (vecinos en cruz). */
    fun fill(x: Int, y: Int, c: Int) {
        if (!inside(x, y)) return
        val target = get(x, y)
        if (target == c) return
        val stack = ArrayDeque<Int>()
        stack.add(y * w + x)
        while (stack.isNotEmpty()) {
            val i = stack.removeLast()
            if (px[i] != target) continue
            px[i] = c
            val cx = i % w
            val cy = i / w
            if (cx > 0) stack.add(i - 1)
            if (cx < w - 1) stack.add(i + 1)
            if (cy > 0) stack.add(i - w)
            if (cy < h - 1) stack.add(i + w)
        }
    }

    /** Línea de Bresenham. */
    fun line(x0: Int, y0: Int, x1: Int, y1: Int, c: Int, mx: Boolean = false, my: Boolean = false) {
        var x = x0; var y = y0
        val dx = Math.abs(x1 - x0); val dy = -Math.abs(y1 - y0)
        val sx = if (x0 < x1) 1 else -1
        val sy = if (y0 < y1) 1 else -1
        var err = dx + dy
        while (true) {
            plot(x, y, c, mx, my)
            if (x == x1 && y == y1) break
            val e2 = 2 * err
            if (e2 >= dy) { err += dy; x += sx }
            if (e2 <= dx) { err += dx; y += sy }
        }
    }

    fun rect(x0: Int, y0: Int, x1: Int, y1: Int, c: Int, filled: Boolean, mx: Boolean = false, my: Boolean = false) {
        val ax = Math.min(x0, x1); val bx = Math.max(x0, x1)
        val ay = Math.min(y0, y1); val by = Math.max(y0, y1)
        for (y in ay..by) for (x in ax..bx) {
            if (filled || x == ax || x == bx || y == ay || y == by) plot(x, y, c, mx, my)
        }
    }

    /** Elipse inscrita en el rectángulo entre las dos esquinas. */
    fun ellipse(x0: Int, y0: Int, x1: Int, y1: Int, c: Int, filled: Boolean, mx: Boolean = false, my: Boolean = false) {
        val ax = Math.min(x0, x1); val bx = Math.max(x0, x1)
        val ay = Math.min(y0, y1); val by = Math.max(y0, y1)
        val cx = (ax + bx) / 2.0; val cy = (ay + by) / 2.0
        val rx = (bx - ax) / 2.0 + 0.5; val ry = (by - ay) / 2.0 + 0.5
        fun inEllipse(x: Int, y: Int): Boolean {
            val nx = (x - cx) / rx; val ny = (y - cy) / ry
            return nx * nx + ny * ny <= 1.0
        }
        for (y in ay..by) for (x in ax..bx) {
            if (!inEllipse(x, y)) continue
            val edge = !inEllipse(x - 1, y) || !inEllipse(x + 1, y) || !inEllipse(x, y - 1) || !inEllipse(x, y + 1)
            if (filled || edge) plot(x, y, c, mx, my)
        }
    }

    fun flipH() { for (y in 0 until h) for (x in 0 until w / 2) { val a = y * w + x; val b = y * w + (w - 1 - x); val t = px[a]; px[a] = px[b]; px[b] = t } }
    fun flipV() { for (y in 0 until h / 2) for (x in 0 until w) { val a = y * w + x; val b = (h - 1 - y) * w + x; val t = px[a]; px[a] = px[b]; px[b] = t } }

    /** Gira 90° a la derecha: devuelve una imagen nueva (el ancho y el alto se intercambian). */
    fun rotated90(): PixelImage {
        val r = PixelImage(h, w)
        for (y in 0 until h) for (x in 0 until w) r.px[x * h + (h - 1 - y)] = px[y * w + x]
        return r
    }

    /** Desplaza la imagen (lo que sale por un lado entra por el contrario). */
    fun shift(dx: Int, dy: Int) {
        val old = px.copyOf()
        for (y in 0 until h) for (x in 0 until w) px[Math.floorMod(y + dy, h) * w + Math.floorMod(x + dx, w)] = old[y * w + x]
    }

    /** Copia la imagen a otro tamaño sin deformar: se queda en la esquina superior izquierda. */
    fun resizedCanvas(nw: Int, nh: Int): PixelImage {
        val r = PixelImage(nw, nh)
        for (y in 0 until Math.min(h, nh)) for (x in 0 until Math.min(w, nw)) r.px[y * nw + x] = px[y * w + x]
        return r
    }

    companion object { const val MAX = 256 }
}

/** Codificador PNG (RGBA de 8 bits). Solo hace falta java.util.zip, así que funciona igual en Android y en JVM. */
object Png {
    private val SIGNATURE = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)

    private fun chunk(out: ByteArrayOutputStream, type: String, data: ByteArray) {
        fun int(v: Int) { out.write(v ushr 24); out.write(v ushr 16); out.write(v ushr 8); out.write(v) }
        int(data.size)
        val t = type.toByteArray(Charsets.US_ASCII)
        out.write(t)
        out.write(data)
        val crc = CRC32()
        crc.update(t); crc.update(data)
        int(crc.value.toInt())
    }

    fun encode(img: PixelImage): ByteArray {
        val raw = ByteArray((img.w * 4 + 1) * img.h)
        var o = 0
        for (y in 0 until img.h) {
            raw[o++] = 0   // filtro: ninguno
            for (x in 0 until img.w) {
                val c = img.px[y * img.w + x]
                raw[o++] = (c ushr 16).toByte()
                raw[o++] = (c ushr 8).toByte()
                raw[o++] = c.toByte()
                raw[o++] = (c ushr 24).toByte()
            }
        }
        val deflater = Deflater(Deflater.BEST_COMPRESSION)
        deflater.setInput(raw); deflater.finish()
        val z = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        while (!deflater.finished()) { val n = deflater.deflate(buf); z.write(buf, 0, n) }
        deflater.end()

        val out = ByteArrayOutputStream()
        out.write(SIGNATURE)
        val ihdr = ByteArray(13)
        fun put(i: Int, v: Int) { ihdr[i] = (v ushr 24).toByte(); ihdr[i + 1] = (v ushr 16).toByte(); ihdr[i + 2] = (v ushr 8).toByte(); ihdr[i + 3] = v.toByte() }
        put(0, img.w); put(4, img.h)
        ihdr[8] = 8    // bits por canal
        ihdr[9] = 6    // RGBA
        chunk(out, "IHDR", ihdr)
        chunk(out, "IDAT", z.toByteArray())
        chunk(out, "IEND", ByteArray(0))
        return out.toByteArray()
    }
}
