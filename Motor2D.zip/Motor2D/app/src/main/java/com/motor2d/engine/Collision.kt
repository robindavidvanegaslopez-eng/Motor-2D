package com.motor2d.engine

import com.motor2d.core.Vec2
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Cuerpo simulado (objeto con Rigidbody2D no estático). */
class Body(val obj: GameObject, val rb: Rigidbody2D) {
    var x = 0.0; var y = 0.0            // posición del objeto (mundo)
    var angle = 0.0                     // radianes
    var vx = 0.0; var vy = 0.0
    var w = 0.0                         // rad/s
    var invMass = 0.0
    var invI = 0.0
    var kinematic = false
    var gravityScale = 1.0
    var drag = 0.0
}

/** Forma de colisión en coordenadas del mundo. */
class Shape(val obj: GameObject, val collider: Collider, val body: Body?) {
    var isBox = true
    var cx = 0.0; var cy = 0.0          // centro
    var angle = 0.0
    var hx = 0.0; var hy = 0.0          // semiejes (caja)
    var r = 0.0                         // radio (círculo)
    var ux = 1.0; var uy = 0.0          // eje X local en el mundo
    var trigger = false
    var bounce = 0.0
    var friction = 0.4
    var minX = 0.0; var minY = 0.0; var maxX = 0.0; var maxY = 0.0

    fun update(ox: Double, oy: Double, rot: Double, sx: Double, sy: Double) {
        val off = collider.v("offset")
        val c = Math.cos(rot); val s = Math.sin(rot)
        val offx = off.x * sx; val offy = off.y * sy
        cx = ox + offx * c - offy * s
        cy = oy + offx * s + offy * c
        angle = rot
        ux = c; uy = s
        if (collider is BoxCollider2D) {
            isBox = true
            val sz = collider.v("size")
            hx = abs(sz.x * sx) / 2.0; hy = abs(sz.y * sy) / 2.0
            val ex = abs(c) * hx + abs(s) * hy
            val ey = abs(s) * hx + abs(c) * hy
            minX = cx - ex; maxX = cx + ex; minY = cy - ey; maxY = cy + ey
        } else {
            isBox = false
            r = collider.f("radius") * max(abs(sx), abs(sy))
            minX = cx - r; maxX = cx + r; minY = cy - r; maxY = cy + r
        }
        trigger = collider.isTrigger
        bounce = collider.f("bounciness").coerceIn(0.0, 1.0)
        friction = collider.f("friction").coerceAtLeast(0.0)
    }
}

class Contact(val x: Double, val y: Double, val penetration: Double)

/** Normal (nx, ny) apunta de A hacia B. */
class Manifold(val a: Shape, val b: Shape, val nx: Double, val ny: Double, val contacts: List<Contact>)

object Collision {
    fun collide(a: Shape, b: Shape): Manifold? {
        if (a.maxX < b.minX || b.maxX < a.minX || a.maxY < b.minY || b.maxY < a.minY) return null
        return when {
            !a.isBox && !b.isBox -> circleCircle(a, b)
            !a.isBox && b.isBox -> circleBox(a, b)
            a.isBox && !b.isBox -> circleBox(b, a)?.let { Manifold(a, b, -it.nx, -it.ny, it.contacts) }
            else -> boxBox(a, b)
        }
    }

    private fun circleCircle(a: Shape, b: Shape): Manifold? {
        val dx = b.cx - a.cx; val dy = b.cy - a.cy
        val dist = sqrt(dx * dx + dy * dy)
        val rs = a.r + b.r
        if (dist >= rs) return null
        val nx: Double; val ny: Double
        if (dist > 1e-9) { nx = dx / dist; ny = dy / dist } else { nx = 0.0; ny = 1.0 }
        val pen = rs - dist
        val k = a.r - pen / 2.0
        return Manifold(a, b, nx, ny, listOf(Contact(a.cx + nx * k, a.cy + ny * k, pen)))
    }

    /** a = círculo, b = caja. Normal de círculo a caja. */
    private fun circleBox(c: Shape, bx: Shape): Manifold? {
        // Centro del círculo en el sistema local de la caja
        val dx = c.cx - bx.cx; val dy = c.cy - bx.cy
        val lx = dx * bx.ux + dy * bx.uy
        val ly = -dx * bx.uy + dy * bx.ux
        val clx = lx.coerceIn(-bx.hx, bx.hx)
        val cly = ly.coerceIn(-bx.hy, bx.hy)
        val outLx: Double; val outLy: Double; val pen: Double
        val pLx: Double; val pLy: Double
        if (clx == lx && cly == ly) {
            // Centro dentro de la caja
            val ddx = bx.hx - abs(lx); val ddy = bx.hy - abs(ly)
            if (ddx < ddy) {
                outLx = if (lx >= 0) 1.0 else -1.0; outLy = 0.0; pen = ddx + c.r
                pLx = outLx * bx.hx; pLy = ly
            } else {
                outLx = 0.0; outLy = if (ly >= 0) 1.0 else -1.0; pen = ddy + c.r
                pLx = lx; pLy = outLy * bx.hy
            }
        } else {
            val ex = lx - clx; val ey = ly - cly
            val dist = sqrt(ex * ex + ey * ey)
            if (dist >= c.r) return null
            outLx = ex / dist; outLy = ey / dist; pen = c.r - dist
            pLx = clx; pLy = cly
        }
        // normal hacia afuera de la caja (mundo)
        val onx = outLx * bx.ux - outLy * bx.uy
        val ony = outLx * bx.uy + outLy * bx.ux
        val px = bx.cx + pLx * bx.ux - pLy * bx.uy
        val py = bx.cy + pLx * bx.uy + pLy * bx.ux
        // normal del círculo hacia la caja = -onormal
        return Manifold(c, bx, -onx, -ony, listOf(Contact(px, py, pen)))
    }

    // ---- caja contra caja (SAT + recorte de la cara incidente) ----
    // Cara 0: +x local, 1: +y local, 2: -x local, 3: -y local. (la normal de cada cara en mundo)
    private fun normalX(s: Shape, f: Int): Double = when (f) { 0 -> s.ux; 1 -> -s.uy; 2 -> -s.ux; else -> s.uy }
    private fun normalY(s: Shape, f: Int): Double = when (f) { 0 -> s.uy; 1 -> s.ux; 2 -> -s.uy; else -> -s.ux }
    private fun halfAlongNormal(s: Shape, f: Int) = if (f == 0 || f == 2) s.hx else s.hy
    private fun halfAlongTangent(s: Shape, f: Int) = if (f == 0 || f == 2) s.hy else s.hx

    private val corners = DoubleArray(8)
    private fun fillCorners(s: Shape, out: DoubleArray) {
        val ax = s.ux * s.hx; val ay = s.uy * s.hx    // medio eje X
        val bx = -s.uy * s.hy; val by = s.ux * s.hy    // medio eje Y
        out[0] = s.cx - ax - bx; out[1] = s.cy - ay - by
        out[2] = s.cx + ax - bx; out[3] = s.cy + ay - by
        out[4] = s.cx + ax + bx; out[5] = s.cy + ay + by
        out[6] = s.cx - ax + bx; out[7] = s.cy - ay + by
    }

    private class Sep(var sep: Double, var face: Int)

    /** Mayor separación de las caras de A respecto a los vértices de B. */
    private fun maxSeparation(a: Shape, b: Shape, res: Sep) {
        fillCorners(b, corners)
        var best = -Double.MAX_VALUE
        var bestF = 0
        for (f in 0 until 4) {
            val nx = normalX(a, f); val ny = normalY(a, f)
            val h = halfAlongNormal(a, f)
            val px = a.cx + nx * h; val py = a.cy + ny * h
            var minD = Double.MAX_VALUE
            for (k in 0 until 4) {
                val d = (corners[k * 2] - px) * nx + (corners[k * 2 + 1] - py) * ny
                if (d < minD) minD = d
            }
            if (minD > best) { best = minD; bestF = f }
        }
        res.sep = best; res.face = bestF
    }

    private fun boxBox(a: Shape, b: Shape): Manifold? {
        val sa = Sep(0.0, 0); val sb = Sep(0.0, 0)
        maxSeparation(a, b, sa)
        if (sa.sep > 0) return null
        maxSeparation(b, a, sb)
        if (sb.sep > 0) return null

        val refIsA = !(sb.sep > sa.sep + 0.01)
        val ref = if (refIsA) a else b
        val inc = if (refIsA) b else a
        val rf = if (refIsA) sa.face else sb.face

        val rnx = normalX(ref, rf); val rny = normalY(ref, rf)
        val rh = halfAlongNormal(ref, rf)
        val rcx = ref.cx + rnx * rh; val rcy = ref.cy + rny * rh        // centro de la cara de referencia
        val tx = -rny; val ty = rnx                                      // tangente
        val tw = halfAlongTangent(ref, rf)
        val lo = (rcx * tx + rcy * ty) - tw
        val hi = (rcx * tx + rcy * ty) + tw

        // Cara incidente: la más opuesta a la normal de referencia
        var incF = 0
        var minDot = Double.MAX_VALUE
        for (f in 0 until 4) {
            val d = normalX(inc, f) * rnx + normalY(inc, f) * rny
            if (d < minDot) { minDot = d; incF = f }
        }
        val inx = normalX(inc, incF); val iny = normalY(inc, incF)
        val ih = halfAlongNormal(inc, incF)
        val icx = inc.cx + inx * ih; val icy = inc.cy + iny * ih
        val itx = -iny; val ity = inx
        val itw = halfAlongTangent(inc, incF)
        val p1x = icx - itx * itw; val p1y = icy - ity * itw
        val p2x = icx + itx * itw; val p2y = icy + ity * itw

        // Recortar el segmento incidente contra los lados de la cara de referencia
        val d1 = p1x * tx + p1y * ty
        val d2 = p2x * tx + p2y * ty
        var s0 = 0.0; var s1 = 1.0
        if (abs(d2 - d1) < 1e-12) {
            if (d1 < lo || d1 > hi) return null
        } else {
            val sLo = (lo - d1) / (d2 - d1)
            val sHi = (hi - d1) / (d2 - d1)
            s0 = max(0.0, min(sLo, sHi)); s1 = min(1.0, max(sLo, sHi))
            if (s0 > s1) return null
        }
        val contacts = ArrayList<Contact>(2)
        for (s in doubleArrayOf(s0, s1)) {
            val px = p1x + (p2x - p1x) * s; val py = p1y + (p2y - p1y) * s
            val sep = (px - rcx) * rnx + (py - rcy) * rny
            if (sep <= 0.001) contacts.add(Contact(px, py, max(0.0, -sep)))
            if (s0 == s1) break
        }
        if (contacts.isEmpty()) return null
        val nx = if (refIsA) rnx else -rnx
        val ny = if (refIsA) rny else -rny
        return Manifold(a, b, nx, ny, contacts)
    }
}
