package com.motor2d.core

/**
 * Lector/escritor JSON mínimo y sin dependencias.
 * Valores: null, Boolean, Long, Double, String, List<Any?>, Map<String, Any?>.
 */
object Json {
    class JsonError(msg: String) : Exception(msg)

    fun parse(text: String): Any? {
        val p = Parser(text)
        p.skipWs()
        val v = p.value()
        p.skipWs()
        if (p.i < text.length) throw JsonError("Texto extra al final del JSON (posición ${p.i})")
        return v
    }

    @Suppress("UNCHECKED_CAST")
    fun parseObject(text: String): Map<String, Any?> =
        (parse(text) as? Map<String, Any?>) ?: throw JsonError("Se esperaba un objeto JSON")

    private class Parser(val s: String) {
        var i = 0
        fun skipWs() {
            while (i < s.length && s[i].isWhitespace()) i++
        }

        fun value(): Any? {
            if (i >= s.length) throw JsonError("JSON incompleto")
            return when (val c = s[i]) {
                '{' -> obj()
                '[' -> arr()
                '"' -> str()
                't' -> lit("true", true)
                'f' -> lit("false", false)
                'n' -> lit("null", null)
                else -> if (c == '-' || c.isDigit()) num() else throw JsonError("Carácter inesperado '$c' en posición $i")
            }
        }

        fun lit(w: String, v: Any?): Any? {
            if (!s.startsWith(w, i)) throw JsonError("Valor inválido en posición $i")
            i += w.length
            return v
        }

        fun num(): Any {
            val st = i
            if (s[i] == '-') i++
            while (i < s.length && (s[i].isDigit() || s[i] == '.' || s[i] == 'e' || s[i] == 'E' || s[i] == '+' || s[i] == '-')) i++
            val t = s.substring(st, i)
            return if (t.contains('.') || t.contains('e') || t.contains('E')) t.toDouble()
            else t.toLongOrNull() ?: t.toDouble()
        }

        fun str(): String {
            i++ // "
            val sb = StringBuilder()
            while (true) {
                if (i >= s.length) throw JsonError("Cadena sin cerrar")
                val c = s[i++]
                when (c) {
                    '"' -> return sb.toString()
                    '\\' -> {
                        val e = s[i++]
                        when (e) {
                            'n' -> sb.append('\n'); 't' -> sb.append('\t'); 'r' -> sb.append('\r')
                            'b' -> sb.append('\b'); 'f' -> sb.append('\u000c')
                            'u' -> {
                                sb.append(s.substring(i, i + 4).toInt(16).toChar()); i += 4
                            }
                            else -> sb.append(e)
                        }
                    }
                    else -> sb.append(c)
                }
            }
        }

        fun arr(): List<Any?> {
            i++
            val out = ArrayList<Any?>()
            skipWs()
            if (s[i] == ']') { i++; return out }
            while (true) {
                skipWs()
                out.add(value())
                skipWs()
                when (s[i++]) {
                    ',' -> continue
                    ']' -> return out
                    else -> throw JsonError("Se esperaba ',' o ']' en posición ${i - 1}")
                }
            }
        }

        fun obj(): Map<String, Any?> {
            i++
            val out = LinkedHashMap<String, Any?>()
            skipWs()
            if (s[i] == '}') { i++; return out }
            while (true) {
                skipWs()
                if (s[i] != '"') throw JsonError("Se esperaba una clave en posición $i")
                val k = str()
                skipWs()
                if (s[i++] != ':') throw JsonError("Se esperaba ':' en posición ${i - 1}")
                skipWs()
                out[k] = value()
                skipWs()
                when (s[i++]) {
                    ',' -> continue
                    '}' -> return out
                    else -> throw JsonError("Se esperaba ',' o '}' en posición ${i - 1}")
                }
            }
        }
    }

    fun stringify(v: Any?, pretty: Boolean = true): String {
        val sb = StringBuilder()
        write(sb, v, if (pretty) 0 else -1)
        return sb.toString()
    }

    private fun indent(sb: StringBuilder, n: Int) {
        sb.append('\n')
        repeat(n) { sb.append("  ") }
    }

    private fun write(sb: StringBuilder, v: Any?, lvl: Int) {
        when (v) {
            null -> sb.append("null")
            is Boolean -> sb.append(v.toString())
            is Int, is Long -> sb.append(v.toString())
            is Double -> sb.append(
                if (v.isNaN() || v.isInfinite()) "0"
                else if (v == Math.rint(v) && Math.abs(v) < 1e15) v.toLong().toString() + ".0"
                else v.toString()
            )
            is String -> quote(sb, v)
            is Map<*, *> -> {
                if (v.isEmpty()) { sb.append("{}"); return }
                sb.append('{')
                var first = true
                for ((k, x) in v) {
                    if (!first) sb.append(',')
                    first = false
                    if (lvl >= 0) indent(sb, lvl + 1)
                    quote(sb, k.toString()); sb.append(if (lvl >= 0) ": " else ":")
                    write(sb, x, if (lvl >= 0) lvl + 1 else -1)
                }
                if (lvl >= 0) indent(sb, lvl)
                sb.append('}')
            }
            is List<*> -> {
                if (v.isEmpty()) { sb.append("[]"); return }
                // Listas cortas de números en una sola línea
                val simple = v.all { it is Number || it is Boolean || it is String && it.length < 24 } && v.size <= 8
                sb.append('[')
                var first = true
                for (x in v) {
                    if (!first) sb.append(if (simple && lvl >= 0) ", " else ",")
                    first = false
                    if (lvl >= 0 && !simple) indent(sb, lvl + 1)
                    write(sb, x, if (lvl >= 0) lvl + 1 else -1)
                }
                if (lvl >= 0 && !simple) indent(sb, lvl)
                sb.append(']')
            }
            else -> quote(sb, v.toString())
        }
    }

    private fun quote(sb: StringBuilder, s: String) {
        sb.append('"')
        for (c in s) {
            when (c) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                else -> if (c < ' ') sb.append(String.format("\\u%04x", c.code)) else sb.append(c)
            }
        }
        sb.append('"')
    }
}
