package com.motor2d.app

import android.view.KeyEvent
import android.view.View
import android.widget.FrameLayout
import com.motor2d.editor.EditorModel
import com.motor2d.editor.Project

/** El juego exportado: ocupa toda la pantalla, sin editor. Atrás cierra el juego. */
class GameScreen(private val act: MainActivity, project: Project, private val onExit: () -> Unit) : Screen {
    private val model = EditorModel(project)
    private val renderer = Renderer(project)
    private val sceneView = SceneView(act, model, renderer)
    private val root = FrameLayout(act)
    override val view: View get() = root

    /** true si el juego está pensado en horizontal. */
    val landscape: Boolean get() = model.isLandscape

    init {
        root.setBackgroundColor(0xFF000000.toInt())
        root.addView(sceneView, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        sceneView.onStopRequested = { onExit() }
        if (!model.startPlay()) {
            act.toast("No se pudo iniciar el juego")
        } else {
            sceneView.keepScreenOn = true
            sceneView.startLoop()
        }
    }

    override fun onBack(): Boolean { onExit(); return true }

    override fun onKey(keyCode: Int, down: Boolean): Boolean {
        val w = model.play ?: return false
        if (down && keyCode == KeyEvent.KEYCODE_ESCAPE) { onExit(); return true }
        return GameKeys.handle(w.input, keyCode, down)
    }
}
