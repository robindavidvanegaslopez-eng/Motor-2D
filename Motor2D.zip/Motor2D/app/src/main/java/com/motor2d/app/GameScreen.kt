package com.motor2d.app

import android.content.pm.ActivityInfo
import android.view.KeyEvent
import android.view.View
import android.widget.FrameLayout
import com.motor2d.editor.EditorModel
import com.motor2d.editor.Project

/** El juego exportado: ocupa toda la pantalla, sin editor. Atrás o Esc cierran el juego. */
class GameScreen(private val act: MainActivity, project: Project, startScene: String) : Screen {
    private val model = EditorModel(project)
    private val renderer = Renderer(project)
    private val sceneView = SceneView(act, model, renderer)
    private val root = FrameLayout(act)
    override val view: View get() = root

    init {
        root.setBackgroundColor(0xFF000000.toInt())
        root.addView(sceneView, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        if (startScene.isNotEmpty() && project.exists("scenes/$startScene.json")) model.loadScene(startScene)
        act.requestedOrientation = if (model.isLandscape) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        sceneView.onStopRequested = { act.finish() }
        if (!model.startPlay()) {
            act.toast("No se pudo iniciar el juego")
        } else {
            sceneView.keepScreenOn = true
            sceneView.startLoop()
        }
    }

    override fun onBack(): Boolean { act.finish(); return true }

    override fun onKey(keyCode: Int, down: Boolean): Boolean {
        val w = model.play ?: return false
        if (down && keyCode == KeyEvent.KEYCODE_ESCAPE) { act.finish(); return true }
        return GameKeys.handle(w.input, keyCode, down)
    }
}
