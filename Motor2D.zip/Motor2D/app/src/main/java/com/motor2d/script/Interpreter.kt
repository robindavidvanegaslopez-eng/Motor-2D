package com.motor2d.script

import com.motor2d.core.GdColor
import com.motor2d.core.Vec2

/** Una instancia de script (el "componente Script" de un objeto). */
class ScriptInstance(val cls: ScriptClass, val interp: Interpreter, val owner: HostObject?) {
    val vars = HashMap<String, Any?>()
    var initialized = false
    var readyDone = false

    /** Evalúa los valores iniciales de las variables (excepto @onready). */
    fun init(overrides: Map<String, Any?> = emptyMap()) {
        interp.runIn(this) { frame ->
            for (m in cls.members) {
                if (m.isOnReady) { vars[m.name] = null; continue }
                if (m.isExport && overrides.containsKey(m.name)) {
                    vars[m.name] = overrides[m.name]
                } else {
                    vars[m.name] = if (m.init != null) interp.eval(m.init, frame) else null
                }
            }
        }
        initialized = true
    }

    fun initOnReady() {
        interp.runIn(this) { frame ->
            for (m in cls.members) {
                if (m.isOnReady && m.init != null) vars[m.name] = interp.eval(m.init, frame)
            }
        }
    }

    fun hasFunc(name: String) = cls.funcs.containsKey(name)

    fun call(name: String, args: List<Any?> = emptyList()): Any? {
        val f = cls.funcs[name] ?: return NoSuch
        return interp.callFunction(this, f, args)
    }
}

class Frame(val inst: ScriptInstance?) {
    val locals = HashMap<String, Any?>(8)
}

private class Signal(val kind: Int, val value: Any? = null)
private val BREAK = Signal(1)
private val CONTINUE = Signal(2)

class Interpreter(val globalHost: GlobalHost?) {
    var out: (String) -> Unit = { println(it) }
    var rng = java.util.Random()
    /** Presupuesto de operaciones por fotograma: evita que un bucle infinito congele la app. */
    var budget = 5_000_000
    private var depth = 0
    private var curLine = 0
    private var curScript = ""

    val globals = HashMap<String, Any?>().apply {
        put("PI", Math.PI); put("TAU", Math.PI * 2); put("INF", Double.POSITIVE_INFINITY)
        put("NAN", Double.NaN)
        put("Vector2", VectorStatics)
        put("Color", ColorStatics)
    }

    fun fail(msg: String): Nothing = throw ScriptError(msg, curLine, curScript)

    fun <R> runIn(inst: ScriptInstance, block: (Frame) -> R): R {
        val oldLine = curLine; val oldScript = curScript
        curScript = inst.cls.name
        try {
            return block(Frame(inst))
        } finally {
            curLine = oldLine; curScript = oldScript
        }
    }

    // ---------- Llamadas ----------
    fun callFunction(inst: ScriptInstance, f: FuncDecl, args: List<Any?>): Any? {
        if (args.size > f.params.size) fail("La función '${f.name}' recibe ${f.params.size} argumentos pero se le pasaron ${args.size}")
        if (--budget <= 0) fail("El script tardó demasiado (¿hay un bucle infinito?)")
        if (depth > 150) fail("Recursión demasiado profunda en '${f.name}'")
        val frame = Frame(inst)
        val oldLine = curLine; val oldScript = curScript
        curScript = inst.cls.name
        depth++
        try {
            for ((i, prm) in f.params.withIndex()) {
                frame.locals[prm.name] = when {
                    i < args.size -> args[i]
                    prm.default != null -> eval(prm.default, frame)
                    else -> fail("Falta el argumento '${prm.name}' al llamar a '${f.name}'")
                }
            }
            val sig = execBlock(f.body, frame)
            return if (sig is Signal && sig.kind == 3) sig.value else null
        } finally {
            depth--
            curLine = oldLine; curScript = oldScript
        }
    }

    // ---------- Sentencias ----------
    private fun execBlock(block: List<Stmt>, frame: Frame): Signal? {
        for (s in block) {
            val sig = exec(s, frame)
            if (sig != null) return sig
        }
        return null
    }

    private fun exec(s: Stmt, frame: Frame): Signal? {
        try {
            return execInner(s, frame)
        } catch (e: ScriptError) {
            // Errores lanzados por el motor (sin línea): se les añade la línea de la sentencia
            if (e.line == 0) throw ScriptError(e.message ?: "error", s.line, curScript)
            throw e
        }
    }

    private fun execInner(s: Stmt, frame: Frame): Signal? {
        curLine = s.line
        when (s) {
            is ExprS -> eval(s.e, frame)
            is VarS -> frame.locals[s.name] = if (s.init != null) eval(s.init, frame) else null
            is AssignS -> execAssign(s, frame)
            is IfS -> {
                for (i in s.conds.indices) {
                    if (truthy(eval(s.conds[i], frame))) return execBlock(s.blocks[i], frame)
                }
                if (s.elseBlock != null) return execBlock(s.elseBlock, frame)
            }
            is WhileS -> {
                while (truthy(eval(s.cond, frame))) {
                    if (--budget <= 0) fail("El script tardó demasiado (¿hay un bucle infinito?)")
                    val sig = execBlock(s.body, frame)
                    if (sig != null) {
                        if (sig === BREAK) break
                        if (sig === CONTINUE) continue
                        return sig
                    }
                    curLine = s.line
                }
            }
            is ForS -> {
                val it = eval(s.iter, frame)
                val seq: List<Any?> = when (it) {
                    is List<*> -> it
                    is Map<*, *> -> it.keys.toList()
                    is String -> it.map { c -> c.toString() }
                    is Long -> (0 until it).toList()
                    is Double -> (0 until it.toLong()).toList()
                    else -> fail("No se puede recorrer con 'for' un valor de tipo ${typeName(it)}")
                }
                // Copia para poder modificar la lista original dentro del bucle
                val snapshot = if (it is List<*>) ArrayList(seq) else seq
                for (x in snapshot) {
                    if (--budget <= 0) fail("El script tardó demasiado (¿hay un bucle infinito?)")
                    frame.locals[s.v] = x
                    val sig = execBlock(s.body, frame)
                    if (sig != null) {
                        if (sig === BREAK) break
                        if (sig === CONTINUE) continue
                        return sig
                    }
                }
            }
            is ReturnS -> return Signal(3, if (s.e != null) eval(s.e, frame) else null)
            is BreakS -> return BREAK
            is ContinueS -> return CONTINUE
            is PassS -> {}
            is MatchS -> {
                val subj = eval(s.subject, frame)
                for ((pats, body) in s.cases) {
                    for (pt in pats) {
                        val wildcard = pt is NameE && pt.id == "_"
                        if (wildcard || Ops.equals(subj, eval(pt, frame))) return execBlock(body, frame)
                    }
                }
            }
        }
        return null
    }

    private fun execAssign(s: AssignS, frame: Frame) {
        val rhs = eval(s.value, frame)
        val v: Any? = if (s.op == "=") rhs else {
            val cur = eval(s.target, frame)
            Ops.binary(this, s.op.dropLast(1), cur, rhs)
        }
        assignTo(s.target, v, frame)
    }

    private fun assignTo(target: Expr, value: Any?, frame: Frame) {
        when (target) {
            is NameE -> setName(target.id, value, frame)
            is MemberE -> {
                val base = if (target.obj is SelfE) frame.inst?.owner else eval(target.obj, frame)
                when (base) {
                    is Vec2 -> {
                        val d = Ops.toDouble(this, value)
                        val nv = when (target.name) {
                            "x" -> Vec2(d, base.y); "y" -> Vec2(base.x, d)
                            else -> fail("Vector2 solo tiene x e y")
                        }
                        assignTo(target.obj, nv, frame)
                    }
                    is GdColor -> {
                        val d = Ops.toDouble(this, value)
                        val nv = when (target.name) {
                            "r" -> base.copy(r = d); "g" -> base.copy(g = d)
                            "b" -> base.copy(b = d); "a" -> base.copy(a = d)
                            else -> fail("Color solo tiene r, g, b, a")
                        }
                        assignTo(target.obj, nv, frame)
                    }
                    is HostObject -> if (!base.setProp(target.name, value))
                        fail("'${base.typeName}' no tiene la propiedad '${target.name}' (o no se puede cambiar)")
                    is MutableMap<*, *> -> @Suppress("UNCHECKED_CAST") (base as MutableMap<Any?, Any?>).put(target.name, value)
                    null -> fail("No se puede asignar '${target.name}' en un valor nulo")
                    else -> fail("No se puede asignar '${target.name}' en un valor de tipo ${typeName(base)}")
                }
            }
            is IndexE -> {
                val base = eval(target.obj, frame)
                val idx = eval(target.index, frame)
                when (base) {
                    is MutableList<*> -> {
                        @Suppress("UNCHECKED_CAST") val l = base as MutableList<Any?>
                        var i = Ops.toLong(this, idx).toInt()
                        if (i < 0) i += l.size
                        if (i < 0 || i >= l.size) fail("Índice $i fuera de rango (tamaño ${l.size})")
                        l[i] = value
                    }
                    is MutableMap<*, *> -> @Suppress("UNCHECKED_CAST") (base as MutableMap<Any?, Any?>).put(Ops.key(idx), value)
                    is Vec2 -> {
                        val d = Ops.toDouble(this, value)
                        val nv = when (Ops.toLong(this, idx).toInt()) {
                            0 -> Vec2(d, base.y); 1 -> Vec2(base.x, d)
                            else -> fail("Índice de Vector2 fuera de rango")
                        }
                        assignTo(target.obj, nv, frame)
                    }
                    else -> fail("No se puede asignar por índice en ${typeName(base)}")
                }
            }
            else -> fail("No se puede asignar aquí")
        }
    }

    private fun setName(id: String, value: Any?, frame: Frame) {
        if (frame.locals.containsKey(id)) { frame.locals[id] = value; return }
        val inst = frame.inst
        if (inst != null) {
            if (inst.vars.containsKey(id)) {
                val m = inst.cls.members.firstOrNull { it.name == id }
                if (m != null && m.isConst) fail("'$id' es una constante y no se puede cambiar")
                inst.vars[id] = value; return
            }
            val owner = inst.owner
            if (owner != null && owner.setProp(id, value)) return
        }
        fail("La variable '$id' no existe (decláralo con 'var $id')")
    }

    // ---------- Expresiones ----------
    fun eval(e: Expr, frame: Frame): Any? {
        when (e) {
            is Lit -> return e.value
            is NameE -> return lookupName(e, frame)
            is SelfE -> return frame.inst?.owner
            is ArrayE -> {
                val l = ArrayList<Any?>(e.items.size)
                for (x in e.items) l.add(eval(x, frame))
                return l
            }
            is DictE -> {
                val m = LinkedHashMap<Any?, Any?>()
                for ((k, v) in e.pairs) m[Ops.key(eval(k, frame))] = eval(v, frame)
                return m
            }
            is UnaryE -> {
                val v = eval(e.e, frame)
                curLine = if (e.line > 0) e.line else curLine
                return when (e.op) {
                    "not" -> !truthy(v)
                    "-" -> when (v) {
                        is Long -> -v; is Double -> -v; is Vec2 -> -v
                        else -> fail("No se puede negar un valor de tipo ${typeName(v)}")
                    }
                    "+" -> v
                    "~" -> if (v is Long) v.inv() else fail("'~' solo funciona con enteros")
                    else -> fail("Operador desconocido ${e.op}")
                }
            }
            is BinaryE -> {
                val l = eval(e.l, frame)
                val r = eval(e.r, frame)
                if (e.line > 0) curLine = e.line
                return Ops.binary(this, e.op, l, r)
            }
            is LogicE -> {
                val l = eval(e.l, frame)
                return if (e.isAnd) { if (!truthy(l)) l else eval(e.r, frame) } else { if (truthy(l)) l else eval(e.r, frame) }
            }
            is TernaryE -> return if (truthy(eval(e.cond, frame))) eval(e.a, frame) else eval(e.b, frame)
            is MemberE -> {
                val base = if (e.obj is SelfE) frame.inst?.owner else eval(e.obj, frame)
                if (e.line > 0) curLine = e.line
                return getMember(base, e.name)
            }
            is IndexE -> {
                val base = eval(e.obj, frame)
                val idx = eval(e.index, frame)
                if (e.line > 0) curLine = e.line
                return Ops.index(this, base, idx)
            }
            is CallE -> return evalCall(e, frame)
        }
    }

    private fun lookupName(e: NameE, frame: Frame): Any? {
        val id = e.id
        val loc = frame.locals
        val v = loc[id]
        if (v != null || loc.containsKey(id)) return v
        val inst = frame.inst
        if (inst != null) {
            val iv = inst.vars[id]
            if (iv != null || inst.vars.containsKey(id)) return iv
            val owner = inst.owner
            if (owner != null) {
                val pv = owner.getProp(id)
                if (pv !== NoSuch) return pv
            }
        }
        val g = globals[id]
        if (g != null || globals.containsKey(id)) return g
        if (globalHost != null) {
            val hv = globalHost.getGlobal(id)
            if (hv !== NoSuch) return hv
        }
        if (e.line > 0) curLine = e.line
        fail("No existe '$id' (revisa que esté escrito igual y declarado con 'var')")
    }

    fun getMember(base: Any?, name: String): Any? {
        when (base) {
            is HostObject -> {
                val v = base.getProp(name)
                if (v === NoSuch) fail("'${base.typeName}' no tiene la propiedad '$name'")
                return v
            }
            is Vec2 -> return when (name) {
                "x" -> base.x; "y" -> base.y
                else -> fail("Vector2 no tiene la propiedad '$name'")
            }
            is GdColor -> return when (name) {
                "r" -> base.r; "g" -> base.g; "b" -> base.b; "a" -> base.a
                else -> fail("Color no tiene la propiedad '$name'")
            }
            is Map<*, *> -> return base[name]
            null -> fail("Se intentó leer '$name' de un valor nulo (null)")
            else -> fail("El valor de tipo ${typeName(base)} no tiene la propiedad '$name'")
        }
    }

    private fun evalCall(e: CallE, frame: Frame): Any? {
        val args = ArrayList<Any?>(e.args.size)
        val callee = e.callee
        if (callee is NameE) {
            for (a in e.args) args.add(eval(a, frame))
            curLine = if (e.line > 0) e.line else curLine
            val id = callee.id
            val inst = frame.inst
            if (inst != null) {
                val f = inst.cls.funcs[id]
                if (f != null) return callFunction(inst, f, args)
            }
            val b = Builtins.call(this, id, args)
            if (b !== NoSuch) return b
            val owner = inst?.owner
            if (owner != null) {
                val r = owner.callMethod(id, args)
                if (r !== NoSuch) return r
            }
            if (globalHost != null) {
                val r = globalHost.callGlobal(id, args)
                if (r !== NoSuch) return r
            }
            fail("No existe la función '$id'")
        }
        if (callee is MemberE) {
            val base = if (callee.obj is SelfE) frame.inst?.owner else eval(callee.obj, frame)
            // self.mi_funcion() → función del propio script
            if (callee.obj is SelfE && frame.inst != null) {
                val f = frame.inst.cls.funcs[callee.name]
                if (f != null) {
                    for (a in e.args) args.add(eval(a, frame))
                    return callFunction(frame.inst, f, args)
                }
            }
            for (a in e.args) args.add(eval(a, frame))
            curLine = if (e.line > 0) e.line else curLine
            return callMethod(base, callee.name, args)
        }
        fail("Esto no se puede llamar como función")
    }

    fun callMethod(base: Any?, name: String, args: List<Any?>): Any? {
        val r: Any? = when (base) {
            is HostObject -> base.callMethod(name, args)
            is Vec2 -> Methods.vec2(this, base, name, args)
            is String -> Methods.string(this, base, name, args)
            is MutableList<*> -> @Suppress("UNCHECKED_CAST") Methods.list(this, base as MutableList<Any?>, name, args)
            is MutableMap<*, *> -> @Suppress("UNCHECKED_CAST") Methods.map(this, base as MutableMap<Any?, Any?>, name, args)
            null -> fail("Se intentó llamar a '$name()' sobre un valor nulo (null)")
            else -> NoSuch
        }
        if (r === NoSuch) fail("'${typeName(base)}' no tiene el método '$name()'")
        return r
    }

    companion object {
        fun truthy(v: Any?): Boolean = when (v) {
            null -> false
            is Boolean -> v
            is Long -> v != 0L
            is Double -> v != 0.0
            is String -> v.isNotEmpty()
            is List<*> -> v.isNotEmpty()
            is Map<*, *> -> v.isNotEmpty()
            else -> true
        }

        fun typeName(v: Any?): String = when (v) {
            null -> "null"
            is Boolean -> "bool"
            is Long -> "int"
            is Double -> "float"
            is String -> "String"
            is Vec2 -> "Vector2"
            is GdColor -> "Color"
            is List<*> -> "Array"
            is Map<*, *> -> "Dictionary"
            is HostObject -> v.typeName
            else -> v.javaClass.simpleName
        }
    }
}
