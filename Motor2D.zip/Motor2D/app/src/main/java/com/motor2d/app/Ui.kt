package com.motor2d.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** Colores y piezas de interfaz comunes. Toda la interfaz se construye con código, sin XML. */
object Ui {
    val BG = 0xFF12151C.toInt()
    val PANEL = 0xFF1B2029.toInt()
    val PANEL2 = 0xFF283040.toInt()
    val FIELD = 0xFF0E1117.toInt()
    val ACCENT = 0xFF4FC3F7.toInt()
    val ACCENT_DARK = 0xFF0B5C80.toInt()
    val TEXT = 0xFFE6EAF2.toInt()
    val MUTED = 0xFF8A94A6.toInt()
    val DANGER = 0xFFEF5350.toInt()
    val OK = 0xFF66BB6A.toInt()
    val SELECT = 0xFFFFB74D.toInt()

    const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

fun roundBg(color: Int, radiusPx: Float, strokeColor: Int = 0, strokePx: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = radiusPx
    if (strokePx > 0) g.setStroke(strokePx, strokeColor)
    return g
}

fun lp(w: Int, h: Int, weight: Float = 0f): LinearLayout.LayoutParams = LinearLayout.LayoutParams(w, h, weight)

fun Context.label(text: CharSequence, sizeSp: Float = 14f, color: Int = Ui.TEXT, bold: Boolean = false): TextView {
    val t = TextView(this)
    t.text = text
    t.textSize = sizeSp
    t.setTextColor(color)
    if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD)
    return t
}

/** Botón de texto con esquinas redondeadas y un mínimo de 44 dp de alto para tocar cómodo. */
fun Context.button(text: String, bg: Int = Ui.PANEL2, fg: Int = Ui.TEXT, onClick: () -> Unit): TextView {
    val t = TextView(this)
    t.text = text
    t.textSize = 14f
    t.setTextColor(fg)
    t.gravity = Gravity.CENTER
    t.minHeight = dp(44)
    t.minWidth = dp(44)
    t.setPadding(dp(14), dp(6), dp(14), dp(6))
    t.background = roundBg(bg, dpf(10f))
    t.isClickable = true
    t.setOnClickListener { onClick() }
    t.setOnTouchListener { v, e ->
        when (e.action) {
            MotionEvent.ACTION_DOWN -> v.alpha = 0.6f
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.alpha = 1f
        }
        false
    }
    return t
}

fun Context.input(text: String, hint: String = "", number: Boolean = false): EditText {
    val e = EditText(this)
    e.setText(text)
    e.hint = hint
    e.setHintTextColor(Ui.MUTED)
    e.setTextColor(Ui.TEXT)
    e.textSize = 14f
    e.setSingleLine(true)
    e.minHeight = dp(44)
    e.setPadding(dp(10), dp(4), dp(10), dp(4))
    e.background = roundBg(Ui.FIELD, dpf(8f), Ui.PANEL2, dp(1))
    e.imeOptions = EditorInfo.IME_ACTION_DONE
    e.setSelectAllOnFocus(true)
    if (number) {
        e.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
    }
    return e
}

fun Context.hideKeyboard(v: View) {
    val m = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    m.hideSoftInputFromWindow(v.windowToken, 0)
}

/** Llama a `cb` cuando el usuario termina de escribir (Listo en el teclado o al salir del campo). */
fun EditText.commitOn(cb: (String) -> Unit) {
    var last = text.toString()
    fun fire() {
        val s = text.toString()
        if (s != last) { last = s; cb(s) }
    }
    setOnEditorActionListener { _, actionId, _ ->
        if (actionId == EditorInfo.IME_ACTION_DONE) {
            fire(); clearFocus(); context.hideKeyboard(this); true
        } else false
    }
    setOnFocusChangeListener { _, has -> if (!has) fire() }
}

fun Context.toast(msg: String) { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }

fun Activity.pick(title: String, items: List<String>, onPick: (Int) -> Unit) {
    AlertDialog.Builder(this)
        .setTitle(title)
        .setItems(items.toTypedArray()) { _, which -> onPick(which) }
        .setNegativeButton("Cancelar", null)
        .show()
}

fun Activity.askText(title: String, initial: String, onOk: (String) -> Unit) {
    val e = input(initial)
    val box = LinearLayout(this)
    box.setPadding(dp(20), dp(8), dp(20), 0)
    box.addView(e, lp(Ui.MATCH, Ui.WRAP))
    val d = AlertDialog.Builder(this)
        .setTitle(title)
        .setView(box)
        .setPositiveButton("Aceptar") { _, _ -> onOk(e.text.toString()) }
        .setNegativeButton("Cancelar", null)
        .create()
    d.show()
    e.requestFocus()
}

fun Activity.confirmDialog(title: String, message: String, okText: String = "Aceptar", onOk: () -> Unit) {
    AlertDialog.Builder(this)
        .setTitle(title)
        .setMessage(message)
        .setPositiveButton(okText) { _, _ -> onOk() }
        .setNegativeButton("Cancelar", null)
        .show()
}

val PALETTE = listOf(
    0xFFFFFFFF.toInt(), 0xFFBDBDBD.toInt(), 0xFF757575.toInt(), 0xFF212121.toInt(), 0xFF000000.toInt(), 0x00000000,
    0xFFEF5350.toInt(), 0xFFFF7043.toInt(), 0xFFFFB74D.toInt(), 0xFFFDD835.toInt(), 0xFFD4E157.toInt(), 0xFF66BB6A.toInt(),
    0xFF26A69A.toInt(), 0xFF4FC3F7.toInt(), 0xFF42A5F5.toInt(), 0xFF5C6BC0.toInt(), 0xFFAB47BC.toInt(), 0xFFEC407A.toInt(),
    0xFF8D6E63.toInt(), 0xFF4E8F4E.toInt(), 0xFF37474F.toInt(), 0xFF1E2A3A.toInt(), 0xFF1B1F2A.toInt(), 0xFF6D4C41.toInt()
)

/** Cuadrícula de colores; devuelve el color elegido como ARGB. */
fun Activity.pickColor(title: String, onPick: (Int) -> Unit) {
    val grid = LinearLayout(this)
    grid.orientation = LinearLayout.VERTICAL
    grid.setPadding(dp(16), dp(8), dp(16), dp(8))
    var dialog: AlertDialog? = null
    var i = 0
    while (i < PALETTE.size) {
        val row = LinearLayout(this)
        for (j in i until minOf(i + 6, PALETTE.size)) {
            val col = PALETTE[j]
            val sw = View(this)
            val bg = roundBg(col, dpf(8f), Ui.MUTED, dp(1))
            sw.background = bg
            sw.setOnClickListener { dialog?.dismiss(); onPick(col) }
            val p = lp(0, dp(44), 1f)
            p.setMargins(dp(3), dp(3), dp(3), dp(3))
            row.addView(sw, p)
        }
        grid.addView(row, lp(Ui.MATCH, Ui.WRAP))
        i += 6
    }
    dialog = AlertDialog.Builder(this).setTitle(title).setView(grid).setNegativeButton("Cancelar", null).show()
}
