package com.motor2d.editor

import com.motor2d.engine.ProjectFiles
import java.io.File

/** Un proyecto de juego: una carpeta con scenes/, scripts/ y assets/. */
class Project(val dir: File) : ProjectFiles {
    val name: String get() = dir.name

    private fun resolve(path: String): File? {
        val file = File(dir, path).canonicalFile
        return if (file.path.startsWith(dir.canonicalPath + File.separator)) file else null
    }

    override fun readText(path: String): String? = try {
        resolve(path)?.takeIf { it.isFile }?.readText()
    } catch (e: Exception) { null }

    fun readBytes(path: String): ByteArray? = try {
        resolve(path)?.takeIf { it.isFile }?.readBytes()
    } catch (e: Exception) { null }

    fun writeText(path: String, text: String) {
        val f = resolve(path) ?: throw IllegalArgumentException("Ruta no válida: $path")
        f.parentFile?.mkdirs()
        f.writeText(text)
    }

    fun writeBytes(path: String, data: ByteArray) {
        val f = resolve(path) ?: throw IllegalArgumentException("Ruta no válida: $path")
        f.parentFile?.mkdirs()
        f.writeBytes(data)
    }

    fun exists(path: String) = resolve(path)?.isFile == true

    fun delete(path: String) { resolve(path)?.delete() }

    /** Archivos de una subcarpeta con alguna de las extensiones, como "scripts/player.gd". */
    fun list(sub: String, vararg exts: String): List<String> {
        val d = File(dir, sub)
        val files = d.listFiles() ?: return emptyList()
        return files.filter { it.isFile && exts.any { e -> it.name.lowercase().endsWith(e) } }
            .map { "$sub/${it.name}" }
            .sorted()
    }

    fun scripts() = list("scripts", ".gd")
    fun scenes() = list("scenes", ".json").map { it.removePrefix("scenes/").removeSuffix(".json") }
    fun images() = list("assets", ".png", ".jpg", ".jpeg", ".webp")
}

class ProjectStore(val root: File) {
    init { root.mkdirs() }

    fun names(): List<String> =
        (root.listFiles() ?: emptyArray()).filter { it.isDirectory }.map { it.name }.sortedBy { it.lowercase() }

    fun open(name: String): Project? {
        val d = File(root, name)
        return if (d.isDirectory) Project(d) else null
    }

    fun cleanName(raw: String): String {
        val s = raw.trim().filter { it.isLetterOrDigit() || it == ' ' || it == '_' || it == '-' }.trim()
        return if (s.isEmpty()) "Proyecto" else s.take(40)
    }

    fun uniqueName(raw: String): String {
        val base = cleanName(raw)
        if (!File(root, base).exists()) return base
        var i = 2
        while (File(root, "$base $i").exists()) i++
        return "$base $i"
    }

    fun create(rawName: String, template: String): Project {
        val p = Project(File(root, uniqueName(rawName)).also { it.mkdirs() })
        Templates.apply(p, template)
        return p
    }

    fun delete(name: String) { File(root, name).deleteRecursively() }
}
