package com.motor2d.app

import android.view.View

/** Una pantalla completa de la app (lista de proyectos, editor, juego exportado...). */
interface Screen {
    val view: View

    /** Devuelve true si la pantalla gestionó el botón Atrás. */
    fun onBack(): Boolean = false

    fun onPause() {}

    fun onConfigurationChanged() {}

    /** Teclas del teclado o mando mientras se ejecuta el juego. Devuelve true si se consumió. */
    fun onKey(keyCode: Int, down: Boolean): Boolean = false

    /** Igual que [onKey] pero con las teclas Ctrl y Mayús, para los atajos de teclado del editor. */
    fun onKeyEvent(keyCode: Int, down: Boolean, ctrl: Boolean, shift: Boolean): Boolean = onKey(keyCode, down)
}
