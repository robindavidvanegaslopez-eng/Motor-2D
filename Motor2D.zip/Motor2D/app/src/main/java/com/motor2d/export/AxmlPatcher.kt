package com.motor2d.export

import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Error de formato al leer/escribir un AXML (manifiesto binario de Android). */
class AxmlException(message: String) : IllegalArgumentException(message)

/**
 * Editor mínimo del AndroidManifest.xml binario (AXML, RES_XML_TYPE 0x0003).
 *
 * Solo reescribe el chunk de string pool (0x0001). El resto de chunks (resource map, namespaces,
 * elementos...) se conservan byte a byte salvo ediciones puntuales de ATRIBUTOS de tamaño fijo
 * (setAttribute / rebasePackagePrefix), que solo cambian campos de 4 bytes dentro de la entrada
 * del atributo. Los índices de cadena existentes no cambian nunca (las cadenas nuevas se añaden
 * al final del pool).
 */
object AxmlPatcher {
    const val ANDROID_NS = "http://schemas.android.com/apk/res/android"

    /**
     * Sustituye las cadenas del pool cuyo contenido sea EXACTAMENTE una clave de [replacements].
     * Con [strict] = true lanza [AxmlException] si alguna clave no aparece en el pool.
     */
    fun replaceStrings(manifest: ByteArray, replacements: Map<String, String>, strict: Boolean = true): ByteArray {
        val doc = AxmlDoc.parse(manifest)
        val found = HashSet<String>()
        for (i in 0 until doc.pool.count) {
            val s = doc.pool.text[i]
            val r = replacements[s] ?: continue
            found.add(s)
            doc.pool.set(i, r)
        }
        if (strict) {
            val missing = replacements.keys.filter { it !in found }
            if (missing.isNotEmpty()) throw AxmlException("Cadenas no encontradas en el manifiesto: $missing")
        }
        return doc.build()
    }

    /** Devuelve todas las cadenas del pool (en orden de índice). */
    fun readStrings(manifest: ByteArray): List<String> = AxmlDoc.parse(manifest).pool.text.toList()

    /**
     * Fija el valor de texto del atributo [attrName] del primer elemento [element].
     * [androidNs] = true para atributos android:xxx, false para atributos sin espacio de nombres (p.ej. package).
     * Funciona aunque el valor actual sea una referencia a recurso (@string/...): pasa a ser una cadena literal.
     * Si la cadena actual la comparte otro uso, se añade una cadena nueva en vez de modificarla.
     * Devuelve el manifiesto sin cambios si no existe y [strict] es false.
     */
    fun setAttribute(
        manifest: ByteArray, element: String, attrName: String, value: String,
        androidNs: Boolean = true, strict: Boolean = true
    ): ByteArray {
        val doc = AxmlDoc.parse(manifest)
        val a = doc.attributes().firstOrNull {
            it.element == element && it.name == attrName && (if (androidNs) it.ns == ANDROID_NS else it.ns == null)
        }
        if (a == null) {
            if (strict) throw AxmlException("Atributo $attrName no encontrado en <$element>")
            return manifest
        }
        doc.setAttrString(a, value)
        return doc.build()
    }

    fun setManifestVersionName(manifest: ByteArray, versionName: String, strict: Boolean = false): ByteArray =
        setAttribute(manifest, "manifest", "versionName", versionName, true, strict)

    /**
     * Reescribe las referencias que dependen del nombre de paquete y deben ser únicas por app instalada:
     * nombres de permisos (<permission>, <uses-permission>...), android:authorities de providers y
     * atributos android:permission/readPermission/writePermission. Una cadena cuyo valor (o cada token separado por ';'
     * en authorities) sea [oldPkg] o empiece por "[oldPkg]." pasa a usar [newPkg]. NO toca nombres de clase
     * (android:name de activity/service/receiver/provider/application).
     * Sin esto, instalar la app exportada junto al editor falla (INSTALL_FAILED_DUPLICATE_PERMISSION /
     * CONFLICTING_PROVIDER) con permisos tipo <oldPkg>.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION de androidx.
     */
    fun rebasePackagePrefix(manifest: ByteArray, oldPkg: String, newPkg: String): ByteArray {
        if (oldPkg == newPkg) return manifest
        val doc = AxmlDoc.parse(manifest)
        fun tok(t: String) = when {
            t == oldPkg -> newPkg
            t.startsWith("$oldPkg.") -> newPkg + t.substring(oldPkg.length)
            else -> t
        }
        var changed = false
        for (a in doc.attributes()) {
            if (a.ns != ANDROID_NS) continue
            val candidate = (a.name == "name" && a.element in PERMISSION_ELEMENTS) ||
                a.name == "authorities" || a.name == "permission" ||
                a.name == "readPermission" || a.name == "writePermission"
            if (!candidate) continue
            val cur = doc.attrStringValue(a) ?: continue
            val nv = cur.split(';').joinToString(";") { tok(it) }
            if (nv != cur) { doc.setAttrString(a, nv); changed = true }
        }
        return if (changed) doc.build() else manifest
    }

    /**
     * Convierte los nombres de clase RELATIVOS del manifiesto (".app.MainActivity" o "Main") en nombres totalmente
     * cualificados usando [pkg] (el paquete ACTUAL del manifiesto). Android resuelve los nombres relativos contra el
     * atributo package; si luego se cambia el paquete sin esto, la activity pasaría a buscarse en el paquete nuevo
     * (ClassNotFoundException al arrancar). Afecta a android:name de application/activity/activity-alias/service/
     * receiver/provider/instrumentation y a backupAgent, manageSpaceActivity, parentActivityName, targetActivity,
     * zygotePreloadName y appComponentFactory. Los nombres ya cualificados no se tocan.
     */
    fun qualifyClassNames(manifest: ByteArray, pkg: String): ByteArray {
        val doc = AxmlDoc.parse(manifest)
        var changed = false
        for (a in doc.attributes()) {
            if (a.ns != ANDROID_NS) continue
            val isClass = (a.name == "name" && a.element in CLASS_ELEMENTS) || a.name in CLASS_ATTRS
            if (!isClass) continue
            val cur = doc.attrStringValue(a) ?: continue
            val q = when {
                cur.isEmpty() -> cur
                cur.startsWith(".") -> pkg + cur
                !cur.contains('.') -> "$pkg.$cur"
                else -> cur
            }
            if (q != cur) { doc.setAttrString(a, q); changed = true }
        }
        return if (changed) doc.build() else manifest
    }

    private val CLASS_ELEMENTS = setOf("application", "activity", "activity-alias", "service", "receiver", "provider", "instrumentation")
    private val CLASS_ATTRS = setOf("backupAgent", "manageSpaceActivity", "parentActivityName", "targetActivity", "zygotePreloadName", "appComponentFactory")

    private val PERMISSION_ELEMENTS = setOf(
        "permission", "uses-permission", "uses-permission-sdk-23", "uses-permission-sdk-m",
        "permission-group", "permission-tree"
    )
}

internal class Attr(
    val element: String, val ns: String?, val name: String,
    /** Posición del atributo dentro de AxmlDoc.tail. */
    val pos: Int
)

/** Documento AXML: pool de cadenas modelado + resto de chunks (tail) como bytes mutables. */
internal class AxmlDoc(val pool: StringPool, val tail: ByteArray) {

    companion object {
        const val RES_XML_TYPE = 0x0003
        const val RES_STRING_POOL_TYPE = 0x0001
        const val NO_INDEX = -1

        fun parse(data: ByteArray): AxmlDoc {
            if (data.size < 8) throw AxmlException("No es un AXML: archivo demasiado corto (${data.size} bytes)")
            val bb = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
            val type = bb.getShort(0).toInt() and 0xffff
            val headerSize = bb.getShort(2).toInt() and 0xffff
            val size = bb.getInt(4)
            if (type != RES_XML_TYPE) throw AxmlException("No es un AXML: tipo de cabecera 0x${type.toString(16)} (se esperaba 0x3)")
            if (headerSize != 8) throw AxmlException("Cabecera AXML con headerSize=$headerSize (se esperaba 8)")
            if (size < 8 || size > data.size) throw AxmlException("Tamaño de archivo AXML incoherente: cabecera=$size, real=${data.size}")
            if (size % 4 != 0) throw AxmlException("Tamaño de archivo AXML no múltiplo de 4: $size")
            // Primer chunk: string pool
            if (size < 8 + 8) throw AxmlException("AXML sin string pool")
            val pType = bb.getShort(8).toInt() and 0xffff
            if (pType != RES_STRING_POOL_TYPE) throw AxmlException("El primer chunk no es un string pool (tipo 0x${pType.toString(16)})")
            val pSize = bb.getInt(12)
            if (pSize < 28 || pSize % 4 != 0 || pSize.toLong() > size - 8L) throw AxmlException("Tamaño de string pool inválido: $pSize")
            val pool = StringPool.parse(data, 8, pSize)
            val tail = data.copyOfRange(8 + pSize, size)
            val doc = AxmlDoc(pool, tail)
            doc.validateChunks()
            return doc
        }
    }

    /** Recorre los chunks de la cola comprobando tamaños. */
    private fun chunks(): List<IntArray> { // [start, type, headerSize, size]
        val out = ArrayList<IntArray>()
        val bb = ByteBuffer.wrap(tail).order(ByteOrder.LITTLE_ENDIAN)
        var p = 0
        while (p < tail.size) {
            if (tail.size - p < 8) throw AxmlException("Chunk truncado en offset ${p + 8 + pool.chunkSize}")
            val type = bb.getShort(p).toInt() and 0xffff
            val hs = bb.getShort(p + 2).toInt() and 0xffff
            val sz = bb.getInt(p + 4)
            if (sz < 8 || sz < hs || sz % 4 != 0 || sz.toLong() > tail.size - p.toLong())
                throw AxmlException("Chunk 0x${type.toString(16)} con tamaño inválido $sz")
            out.add(intArrayOf(p, type, hs, sz))
            p += sz
        }
        return out
    }

    private fun validateChunks() { chunks() }

    private fun i32(p: Int) = ByteBuffer.wrap(tail).order(ByteOrder.LITTLE_ENDIAN).getInt(p)
    private fun u16(p: Int) = ByteBuffer.wrap(tail).order(ByteOrder.LITTLE_ENDIAN).getShort(p).toInt() and 0xffff
    private fun putI32(p: Int, v: Int) { ByteBuffer.wrap(tail).order(ByteOrder.LITTLE_ENDIAN).putInt(p, v) }

    private fun str(idx: Int): String? =
        if (idx == NO_INDEX) null else if (idx in 0 until pool.count) pool.text[idx] else throw AxmlException("Índice de cadena fuera de rango: $idx")

    /** Lista todos los atributos de todos los elementos de inicio. */
    fun attributes(): List<Attr> {
        val res = ArrayList<Attr>()
        for ((start, type, hs, size) in chunks()) {
            if (type != 0x0102) continue
            if (hs < 16 || size < hs + 20) throw AxmlException("Elemento de inicio truncado")
            val ext = start + hs
            val elName = str(i32(ext + 4)) ?: ""
            val attrStart = u16(ext + 8)
            val attrSize = u16(ext + 10)
            val attrCount = u16(ext + 12)
            if (attrSize < 20) throw AxmlException("attributeSize inválido: $attrSize")
            if (ext + attrStart + attrCount.toLong() * attrSize > start + size)
                throw AxmlException("Atributos fuera del chunk de elemento <$elName>")
            for (k in 0 until attrCount) {
                val ap = ext + attrStart + k * attrSize
                res.add(Attr(elName, str(i32(ap)), str(i32(ap + 4)) ?: "", ap))
            }
        }
        return res
    }

    /** Valor de texto si el atributo es de tipo cadena (0x03). */
    fun attrStringValue(a: Attr): String? {
        val dataType = tail[a.pos + 15].toInt() and 0xff
        if (dataType != 0x03) return null
        return str(i32(a.pos + 16))
    }

    /** Nº de usos de la cadena [idx] en el documento (cada atributo cuenta una vez). */
    private fun refCount(idx: Int): Int {
        var n = 0
        for ((start, type, hs, size) in chunks()) {
            when (type) {
                0x0100, 0x0101 -> {
                    if (i32(start + hs) == idx) n++
                    if (i32(start + hs + 4) == idx) n++
                }
                0x0103 -> {
                    if (i32(start + hs) == idx) n++
                    if (i32(start + hs + 4) == idx) n++
                }
                0x0104 -> if (i32(start + hs) == idx) n++
                0x0102 -> {
                    val ext = start + hs
                    if (i32(ext) == idx) n++
                    if (i32(ext + 4) == idx) n++
                    val attrStart = u16(ext + 8); val attrSize = u16(ext + 10); val cnt = u16(ext + 12)
                    for (k in 0 until cnt) {
                        val ap = ext + attrStart + k * attrSize
                        var used = i32(ap) == idx || i32(ap + 4) == idx || i32(ap + 8) == idx
                        if ((tail[ap + 15].toInt() and 0xff) == 0x03 && i32(ap + 16) == idx) used = true
                        if (used) n++
                    }
                }
            }
        }
        return n
    }

    fun setAttrString(a: Attr, value: String) {
        val dataType = tail[a.pos + 15].toInt() and 0xff
        val cur = i32(a.pos + 16)
        val idx: Int
        if (dataType == 0x03 && cur in 0 until pool.count && refCount(cur) == 1) {
            pool.set(cur, value)
            idx = cur
        } else {
            idx = pool.add(value)
        }
        putI32(a.pos + 8, idx)                       // rawValue
        ByteBuffer.wrap(tail).order(ByteOrder.LITTLE_ENDIAN).putShort(a.pos + 12, 8) // typedValue.size
        tail[a.pos + 14] = 0                         // res0
        tail[a.pos + 15] = 0x03                      // TYPE_STRING
        putI32(a.pos + 16, idx)
    }

    fun build(): ByteArray {
        val poolBytes = pool.serialize()
        val total = 8 + poolBytes.size + tail.size
        val out = ByteBuffer.allocate(total).order(ByteOrder.LITTLE_ENDIAN)
        out.putShort(RES_XML_TYPE.toShort()).putShort(8).putInt(total)
        out.put(poolBytes).put(tail)
        return out.array()
    }
}

/** String pool (RES_STRING_POOL_TYPE) editable. Conserva las entradas sin cambios byte a byte. */
internal class StringPool(
    val utf8: Boolean,
    private var flags: Int,
    private val headerSize: Int,
    private val raw: MutableList<ByteArray>,
    val text: MutableList<String>,
    private val styleOffsets: IntArray,
    private val styleData: ByteArray,
    val chunkSize: Int
) {
    val count get() = raw.size
    private var modified = false

    fun set(i: Int, s: String) {
        if (text[i] == s) return
        raw[i] = encode(s); text[i] = s; modified = true
    }

    fun add(s: String): Int {
        raw.add(encode(s)); text.add(s); modified = true
        return raw.size - 1
    }

    fun encode(s: String): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        if (utf8) {
            val b = s.toByteArray(Charsets.UTF_8)
            val chars = s.length
            if (chars > 0x7fff) throw AxmlException("Cadena demasiado larga para un pool UTF-8 (${chars} caracteres, máx. 32767)")
            if (b.size > 0x7fff) throw AxmlException("Cadena demasiado larga para un pool UTF-8 (${b.size} bytes, máx. 32767)")
            writeLen8(out, chars); writeLen8(out, b.size)
            out.write(b); out.write(0)
        } else {
            val n = s.length
            if (n > 0x7fffffff) throw AxmlException("Cadena demasiado larga")
            if (n > 0x7fff) {
                val hi = (n ushr 16) or 0x8000
                out.write(hi and 0xff); out.write((hi ushr 8) and 0xff)
                out.write(n and 0xff); out.write((n ushr 8) and 0xff)
            } else {
                out.write(n and 0xff); out.write((n ushr 8) and 0xff)
            }
            for (c in s) { out.write(c.code and 0xff); out.write((c.code ushr 8) and 0xff) }
            out.write(0); out.write(0)
        }
        return out.toByteArray()
    }

    private fun writeLen8(out: java.io.ByteArrayOutputStream, n: Int) {
        if (n > 0x7f) { out.write((n ushr 8) or 0x80); out.write(n and 0xff) } else out.write(n)
    }

    fun serialize(): ByteArray {
        val sc = raw.size
        val stc = styleOffsets.size
        val stringsStart = headerSize + 4 * sc + 4 * stc
        var blobLen = 0
        for (r in raw) blobLen += r.size
        val blobPadded = (blobLen + 3) and 3.inv()
        val styleLen = (styleData.size + 3) and 3.inv()
        val total = stringsStart + blobPadded + styleLen
        val bb = ByteBuffer.allocate(total).order(ByteOrder.LITTLE_ENDIAN)
        // SORTED_FLAG: tras sustituir ya no se garantiza el orden
        val newFlags = if (modified) flags and 0x1.inv() else flags
        bb.putShort(AxmlDoc.RES_STRING_POOL_TYPE.toShort()).putShort(headerSize.toShort()).putInt(total)
        bb.putInt(sc).putInt(stc).putInt(newFlags)
        bb.putInt(stringsStart).putInt(if (stc > 0) stringsStart + blobPadded else 0)
        while (bb.position() < headerSize) bb.put(0)
        var off = 0
        for (r in raw) { bb.putInt(off); off += r.size }
        for (o in styleOffsets) bb.putInt(o)
        for (r in raw) bb.put(r)
        bb.position(stringsStart + blobPadded)
        bb.put(styleData)
        return bb.array()
    }

    companion object {
        fun parse(data: ByteArray, base: Int, size: Int): StringPool {
            val bb = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
            val end = base + size
            val headerSize = bb.getShort(base + 2).toInt() and 0xffff
            if (headerSize < 28 || headerSize > size) throw AxmlException("headerSize de string pool inválido: $headerSize")
            val sc = bb.getInt(base + 8)
            val stc = bb.getInt(base + 12)
            val flags = bb.getInt(base + 16)
            val stringsStart = bb.getInt(base + 20)
            val stylesStart = bb.getInt(base + 24)
            if (sc < 0 || stc < 0 || stc > sc) throw AxmlException("Recuento de cadenas/estilos inválido ($sc/$stc)")
            val tableEnd = headerSize.toLong() + 4L * sc + 4L * stc
            if (tableEnd > size) throw AxmlException("Tabla de offsets fuera del string pool")
            val utf8 = (flags and 0x100) != 0
            if (sc > 0 && (stringsStart < tableEnd || stringsStart >= size)) throw AxmlException("stringsStart inválido: $stringsStart")
            val raw = ArrayList<ByteArray>(sc)
            val text = ArrayList<String>(sc)
            val strBase = base + stringsStart
            for (i in 0 until sc) {
                val off = bb.getInt(base + headerSize + 4 * i)
                if (off < 0 || strBase.toLong() + off >= end) throw AxmlException("Offset de cadena $i fuera del pool")
                var p = strBase + off
                val start = p
                val s: String
                if (utf8) {
                    fun len8(): Int {
                        if (p >= end) throw AxmlException("Cadena $i truncada")
                        val b = data[p++].toInt() and 0xff
                        if (b and 0x80 != 0) {
                            if (p >= end) throw AxmlException("Cadena $i truncada")
                            return ((b and 0x7f) shl 8) or (data[p++].toInt() and 0xff)
                        }
                        return b
                    }
                    len8() // longitud en unidades UTF-16 (informativa); la longitud real es la de bytes
                    val bytes = len8()
                    if (p.toLong() + bytes + 1 > end) throw AxmlException("Cadena $i fuera del pool")
                    s = String(data, p, bytes, Charsets.UTF_8)
                    p += bytes
                    if (data[p].toInt() != 0) throw AxmlException("Cadena $i sin terminador nulo")
                    p += 1
                } else {
                    fun u16(): Int {
                        if (p + 2 > end) throw AxmlException("Cadena $i truncada")
                        val v = (data[p].toInt() and 0xff) or ((data[p + 1].toInt() and 0xff) shl 8); p += 2; return v
                    }
                    var n = u16()
                    if (n and 0x8000 != 0) n = ((n and 0x7fff) shl 16) or u16()
                    if (p.toLong() + 2L * n + 2 > end) throw AxmlException("Cadena $i fuera del pool")
                    s = String(data, p, n * 2, Charsets.UTF_16LE)
                    p += n * 2
                    if (data[p].toInt() != 0 || data[p + 1].toInt() != 0) throw AxmlException("Cadena $i sin terminador nulo")
                    p += 2
                }
                raw.add(data.copyOfRange(start, p))
                text.add(s)
            }
            val styleOffsets = IntArray(stc) { bb.getInt(base + headerSize + 4 * sc + 4 * it) }
            var styleData = ByteArray(0)
            if (stc > 0) {
                if (stylesStart < 0 || stylesStart > size) throw AxmlException("stylesStart inválido: $stylesStart")
                styleData = data.copyOfRange(base + stylesStart, end)
            }
            return StringPool(utf8, flags, headerSize, raw, text, styleOffsets, styleData, size)
        }
    }
}
