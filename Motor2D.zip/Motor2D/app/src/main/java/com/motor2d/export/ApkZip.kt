package com.motor2d.export

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.CRC32
import java.util.zip.Deflater
import java.util.zip.DeflaterOutputStream

/** ByteArrayOutputStream que expone su buffer para no copiarlo (el APK puede ocupar decenas de MB). */
internal class ZipBuf(initial: Int) : ByteArrayOutputStream(initial) {
    val array: ByteArray get() = buf
}

/**
 * Escritor ZIP mínimo para APK: sin descriptores de datos, sin Zip64, nombres UTF-8, relleno de alineamiento
 * estilo zipalign (campo extra 0xD935) para entradas STORED. Las entradas se escriben en el orden de llamada.
 */
internal class ZipWriter(initialCapacity: Int) {
    companion object {
        const val STORED = 0
        const val DEFLATED = 8
        const val DOS_DATE = 0x0021 // 1980-01-01
        const val DOS_TIME = 0
        const val EOCD_SIZE = 22
    }

    private class Rec(val name: ByteArray, val method: Int, val crc: Long, val csize: Int, val usize: Int, val offset: Int, val flags: Int)

    val buf = ZipBuf(initialCapacity)
    private val recs = ArrayList<Rec>()
    val entryCount get() = recs.size

    private fun le(n: Int) = ByteBuffer.allocate(n).order(ByteOrder.LITTLE_ENDIAN)

    /**
     * Añade una entrada. [align] > 1 solo se aplica a entradas STORED: el inicio de los datos queda en un múltiplo de [align].
     */
    fun add(name: String, method: Int, data: ByteArray, align: Int = 1) {
        require(method == STORED || method == DEFLATED)
        val nameBytes = name.toByteArray(Charsets.UTF_8)
        require(nameBytes.isNotEmpty() && nameBytes.size <= 0xffff) { "Nombre de entrada inválido: $name" }
        if (recs.size >= 0xffff) throw IllegalStateException("Demasiadas entradas (máx. 65535 sin Zip64)")
        val crc = CRC32().also { it.update(data) }.value
        val payload: ByteArray = if (method == DEFLATED) {
            val bo = ByteArrayOutputStream(maxOf(64, data.size / 2))
            val def = Deflater(Deflater.DEFAULT_COMPRESSION, true)
            try { DeflaterOutputStream(bo, def, 64 * 1024).use { it.write(data) } } finally { def.end() }
            bo.toByteArray()
        } else data
        val offset = buf.size()
        if (offset.toLong() + payload.size + 1024L + nameBytes.size > Int.MAX_VALUE) throw IllegalStateException("APK demasiado grande")
        var extra = ByteArray(0)
        if (method == STORED && align > 1) {
            val dataStart = offset.toLong() + 30 + nameBytes.size
            var pad = ((align - dataStart % align) % align).toInt()
            // el registro de relleno ocupa >= 6 bytes (id 2 + tamaño 2 + alineamiento 2)
            while (pad in 1..5) pad += align
            if (pad > 0) {
                val e = le(pad)
                e.putShort(0xD935.toShort()).putShort((pad - 4).toShort()).putShort(align.coerceAtMost(0xffff).toShort())
                extra = e.array()
            }
        }
        val ascii = nameBytes.all { it >= 0 }
        val flags = if (ascii) 0 else 0x0800
        val h = le(30)
        h.putInt(0x04034b50).putShort(20).putShort(flags.toShort()).putShort(method.toShort())
        h.putShort(DOS_TIME.toShort()).putShort(DOS_DATE.toShort())
        h.putInt(crc.toInt()).putInt(payload.size).putInt(data.size)
        h.putShort(nameBytes.size.toShort()).putShort(extra.size.toShort())
        buf.write(h.array()); buf.write(nameBytes); buf.write(extra); buf.write(payload)
        recs.add(Rec(nameBytes, method, crc, payload.size, data.size, offset, flags))
    }

    /** Offset de inicio del directorio central (= fin de los datos de las entradas). */
    val cdOffset get() = buf.size()

    fun buildCentralDirectory(): ByteArray {
        val bo = ByteArrayOutputStream()
        for (r in recs) {
            val c = le(46)
            c.putInt(0x02014b50).putShort(20).putShort(20).putShort(r.flags.toShort()).putShort(r.method.toShort())
            c.putShort(DOS_TIME.toShort()).putShort(DOS_DATE.toShort())
            c.putInt(r.crc.toInt()).putInt(r.csize).putInt(r.usize)
            c.putShort(r.name.size.toShort()).putShort(0).putShort(0) // nombre, extra, comentario
            c.putShort(0).putShort(0).putInt(0)                       // disco, attrs internos, attrs externos
            c.putInt(r.offset)
            bo.write(c.array()); bo.write(r.name)
        }
        return bo.toByteArray()
    }

    fun buildEocd(cdSize: Int, cdOffset: Int): ByteArray {
        val e = le(EOCD_SIZE)
        e.putInt(0x06054b50).putShort(0).putShort(0).putShort(recs.size.toShort()).putShort(recs.size.toShort())
        e.putInt(cdSize).putInt(cdOffset).putShort(0)
        return e.array()
    }
}
