package com.motor2d.export

import java.security.MessageDigest
import java.text.Normalizer

/** Parámetros de la exportación. [oldPackageName]/[oldAppName] son los valores que lleva el manifiesto de la plantilla. */
class ExportConfig(
    val packageName: String,
    val appName: String,
    val versionName: String = "1.0",
    val oldPackageName: String,
    val oldAppName: String
)

private val JAVA_KEYWORDS = setOf(
    "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class", "const", "continue",
    "default", "do", "double", "else", "enum", "extends", "final", "finally", "float", "for", "goto", "if",
    "implements", "import", "instanceof", "int", "interface", "long", "native", "new", "package", "private",
    "protected", "public", "return", "short", "static", "strictfp", "super", "switch", "synchronized", "this",
    "throw", "throws", "transient", "try", "void", "volatile", "while", "true", "false", "null", "_"
)

/** Al menos dos segmentos separados por '.', cada uno [a-z][a-z0-9_]*, sin palabras reservadas de Java, máx. 255 caracteres. */
fun String.isValidPackageName(): Boolean {
    if (length < 3 || length > 255) return false
    val segs = split('.')
    if (segs.size < 2) return false
    for (s in segs) {
        if (s.isEmpty() || s in JAVA_KEYWORDS) return false
        if (s[0] !in 'a'..'z') return false
        for (c in s) if (c !in 'a'..'z' && c !in '0'..'9' && c != '_') return false
    }
    return true
}

/**
 * Sugiere un nombre de paquete "com.motor2d.game.<slug>" a partir del nombre del juego (determinista).
 * Mayúsculas, acentos, espacios y guiones se normalizan ("Niño Ágil" -> nino_agil), por lo que nombres que solo
 * difieran en eso dan el mismo paquete. Si el nombre pierde información real (símbolos, emojis, otro alfabeto,
 * truncado) se añade un sufijo de 8 hex del hash SHA-256 del nombre exacto para que siga siendo único.
 */
fun suggestPackageName(gameName: String): String {
    val trimmed = gameName.trim()
    val nfd = Normalizer.normalize(trimmed, Normalizer.Form.NFD)
    val noMarks = StringBuilder()
    for (c in nfd) if (Character.getType(c) != Character.NON_SPACING_MARK.toInt()) noMarks.append(c)
    var lossy = false
    val slug = StringBuilder()
    var lastUnderscore = true // evita '_' inicial
    for (c in noMarks.toString().lowercase()) {
        when {
            c in 'a'..'z' || c in '0'..'9' -> { slug.append(c); lastUnderscore = false }
            c == ' ' || c == '_' || c == '-' || c == '.' -> if (!lastUnderscore) { slug.append('_'); lastUnderscore = true }
            else -> { lossy = true; if (!lastUnderscore) { slug.append('_'); lastUnderscore = true } }
        }
    }
    var s = slug.toString().trimEnd('_')
    if (s.length > 40) { s = s.substring(0, 40).trimEnd('_'); lossy = true }
    if (s.isEmpty()) { s = "game"; lossy = true }
    if (s[0] in '0'..'9') s = "g$s"
    if (lossy) {
        val h = MessageDigest.getInstance("SHA-256").digest(trimmed.toByteArray(Charsets.UTF_8))
        s += "_" + h.take(4).joinToString("") { "%02x".format(it.toInt() and 0xff) }
    }
    val pkg = "com.motor2d.game.$s"
    check(pkg.isValidPackageName()) { "paquete sugerido inválido: $pkg" }
    return pkg
}
