package com.motor2d.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import com.motor2d.core.Vec2
import com.motor2d.editor.EditorModel
import com.motor2d.engine.BoxCollider2D
import com.motor2d.engine.CircleCollider2D
import com.motor2d.engine.GameObject

/**
 * La vista principal: en modo edición muestra la escena (mover, seleccionar, zoom);
 * en modo juego ejecuta el mundo y dibuja el joystick y los botones A y B.
 */
class SceneView(context: Context, private val model: EditorModel, private val renderer: Renderer) : View(context) {
    var camCenter = Vec2(640.0, 360.0)
    var camZoom = 0.5
    var snap = false
    var showControls = true

    var onSelectionChanged: (() -> Unit)? = null
    var onTransformChanged: (() -> Unit)? = null
    var onStopRequested: (() -> Unit)? = null
    var onEditEnd: (() -> Unit)? = null

    private fun dpf(v: Float): Float = context.dpf(v)

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val tmpRect = RectF()
    private val slop = ViewConfiguration.get(context).scaledTouchSlop.toFloat()
    private var framed = false

    // ---------- Bucle del juego ----------
    private var running = false
    private var lastNs = 0L
    private val tick = object : Runnable {
        override fun run() {
            val w = model.play
            if (w == null || !isAttachedToWindow) { running = false; return }
            val now = System.nanoTime()
            val dt = if (lastNs == 0L) 0.0 else (now - lastNs) / 1e9
            lastNs = now
            w.update(dt)
            if (w.stopRequested) { running = false; onStopRequested?.invoke(); return }
            invalidate()
            postOnAnimation(this)
        }
    }

    fun startLoop() {
        if (running) return
        running = true
        lastNs = 0L
        resetControls()
        postOnAnimation(tick)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (model.isPlaying) startLoop()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (!framed && w > 0 && h > 0) { framed = true; frameGame() }
    }

    // ---------- Cámara del editor ----------
    fun frameGame() {
        val w = model.world
        if (width == 0 || height == 0) return
        val cam = w.camera()
        camCenter = cam.center
        camZoom = minOf(width / w.viewW, height / w.viewH) * 0.85
    }

    fun focusSelected() {
        val o = model.selected ?: return
        camCenter = o.worldPosition()
        invalidate()
    }

    private fun s2w(x: Float, y: Float) = Vec2((x - width / 2.0) / camZoom + camCenter.x, (y - height / 2.0) / camZoom + camCenter.y)
    private fun w2s(p: Vec2) = Vec2((p.x - camCenter.x) * camZoom + width / 2.0, (p.y - camCenter.y) * camZoom + height / 2.0)

    private fun toWorld(o: GameObject, local: Vec2): Vec2 =
        o.worldPosition() + (local * o.worldScale()).rotated(Math.toRadians(o.worldRotation()))

    private fun toLocal(o: GameObject, world: Vec2): Vec2 {
        val l = (world - o.worldPosition()).rotated(-Math.toRadians(o.worldRotation()))
        val s = o.worldScale()
        return Vec2(if (s.x == 0.0) 0.0 else l.x / s.x, if (s.y == 0.0) 0.0 else l.y / s.y)
    }

    // ---------- Dibujo ----------
    override fun onDraw(c: Canvas) {
        if (model.isPlaying) drawPlay(c) else drawEdit(c)
    }

    private fun drawPlay(c: Canvas) {
        val w = model.play ?: return
        val vw = w.viewW
        val vh = w.viewH
        val s = minOf(width / vw, height / vh).toFloat()
        val ox = ((width - vw * s) / 2.0).toFloat()
        val oy = ((height - vh * s) / 2.0).toFloat()
        c.drawColor(Color.BLACK)
        c.save()
        c.clipRect(ox, oy, ox + (vw * s).toFloat(), oy + (vh * s).toFloat())
        c.translate(ox, oy)
        c.scale(s, s)
        val cam = w.camera()
        c.drawColor(cam.background)
        c.translate((vw / 2).toFloat(), (vh / 2).toFloat())
        c.scale(cam.zoom.toFloat(), cam.zoom.toFloat())
        c.translate(-cam.center.x.toFloat(), -cam.center.y.toFloat())
        renderer.drawWorld(c, w, false)
        c.restore()

        if (showControls) drawControls(c)
        drawPlayMessages(c)
    }

    private fun drawPlayMessages(c: Canvas) {
        val w = model.play ?: return
        textPaint.textSize = dpf(12f)
        textPaint.textAlign = Paint.Align.LEFT
        textPaint.setShadowLayer(3f, 1f, 1f, Color.BLACK)
        val lines = model.console.takeLast(5)
        var y = dpf(18f)
        for (l in lines) {
            textPaint.color = if (l.isError) Ui.DANGER else 0xCCFFFFFF.toInt()
            c.drawText(l.text.take(90), dpf(10f), y, textPaint)
            y += dpf(15f)
        }
        textPaint.clearShadowLayer()
        val err = w.error
        if (err != null) {
            paint.color = 0xE6B71C1C.toInt()
            c.drawRect(0f, height - dpf(70f), width.toFloat(), height.toFloat(), paint)
            textPaint.color = Color.WHITE
            textPaint.textSize = dpf(13f)
            c.drawText("Error en el script. Pulsa Detener para corregirlo.", dpf(12f), height - dpf(44f), textPaint)
            c.drawText(err.describe().take(80), dpf(12f), height - dpf(22f), textPaint)
        }
    }

    // ---------- Controles en pantalla (modo juego) ----------
    private var joyId = -1
    private var joyBase = Vec2.ZERO
    private var joyPos = Vec2.ZERO
    private var aId = -1
    private var bId = -1
    private var gameId = -1

    private fun resetControls() { joyId = -1; aId = -1; bId = -1; gameId = -1 }

    private fun joyRadius() = dpf(60f)
    private fun aCenter() = Vec2(width - dpf(80.0f).toDouble(), height - dpf(100f).toDouble())
    private fun bCenter() = Vec2(width - dpf(170f).toDouble(), height - dpf(60f).toDouble())
    private fun aRadius() = dpf(42f)
    private fun bRadius() = dpf(32f)
    private fun inJoyZone(x: Float, y: Float) = x < width * 0.4f && y > height * 0.4f

    private fun drawControls(c: Canvas) {
        stroke.strokeWidth = dpf(3f)
        val base = if (joyId >= 0) joyBase else Vec2(dpf(100f).toDouble(), height - dpf(100f).toDouble())
        val knob = if (joyId >= 0) joyPos else base
        stroke.color = 0x66FFFFFF
        c.drawCircle(base.x.toFloat(), base.y.toFloat(), joyRadius(), stroke)
        paint.color = if (joyId >= 0) 0x88FFFFFF.toInt() else 0x44FFFFFF
        c.drawCircle(knob.x.toFloat(), knob.y.toFloat(), joyRadius() * 0.45f, paint)

        val a = aCenter(); val b = bCenter()
        paint.color = if (aId >= 0) 0xAA4FC3F7.toInt() else 0x554FC3F7
        c.drawCircle(a.x.toFloat(), a.y.toFloat(), aRadius(), paint)
        paint.color = if (bId >= 0) 0xAAFFB74D.toInt() else 0x55FFB74D
        c.drawCircle(b.x.toFloat(), b.y.toFloat(), bRadius(), paint)
        textPaint.color = Color.WHITE
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.textSize = dpf(20f)
        c.drawText("A", a.x.toFloat(), a.y.toFloat() + dpf(7f), textPaint)
        c.drawText("B", b.x.toFloat(), b.y.toFloat() + dpf(7f), textPaint)
    }

    private fun gameTouchPos(x: Float, y: Float): Vec2 {
        val w = model.play!!
        val s = minOf(width / w.viewW, height / w.viewH)
        val ox = (width - w.viewW * s) / 2.0
        val oy = (height - w.viewH * s) / 2.0
        return Vec2((x - ox) / s, (y - oy) / s)
    }

    private fun playTouch(e: MotionEvent): Boolean {
        val w = model.play ?: return true
        val inp = w.input
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                val id = e.getPointerId(i)
                val x = e.getX(i); val y = e.getY(i)
                var used = false
                if (showControls) {
                    val a = aCenter(); val b = bCenter()
                    if (Math.hypot(x - a.x, y - a.y) <= aRadius() + dpf(10f)) { aId = id; inp.pressButton("A"); used = true }
                    else if (Math.hypot(x - b.x, y - b.y) <= bRadius() + dpf(10f)) { bId = id; inp.pressButton("B"); used = true }
                    else if (joyId < 0 && inJoyZone(x, y)) {
                        joyId = id; joyBase = Vec2(x.toDouble(), y.toDouble()); joyPos = joyBase; used = true
                    }
                }
                if (!used && gameId < 0) {
                    gameId = id
                    inp.touchDown(gameTouchPos(x, y))
                }
                refreshTouches(e, -1)
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) {
                    val id = e.getPointerId(i)
                    val x = e.getX(i); val y = e.getY(i)
                    if (id == joyId) {
                        var d = Vec2(x - joyBase.x, y - joyBase.y)
                        val r = joyRadius().toDouble()
                        if (d.length() > r) d = d.normalized() * r
                        joyPos = joyBase + d
                        inp.joystick = d / r
                    } else if (id == gameId) {
                        inp.touchMove(gameTouchPos(x, y))
                    }
                }
                refreshTouches(e, -1)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                val idx = if (e.actionMasked == MotionEvent.ACTION_CANCEL) -1 else e.actionIndex
                val ids = if (idx >= 0) listOf(e.getPointerId(idx)) else (0 until e.pointerCount).map { e.getPointerId(it) }
                for (id in ids) {
                    if (id == joyId) { joyId = -1; inp.joystick = Vec2.ZERO }
                    if (id == aId) { aId = -1; inp.releaseButton("A") }
                    if (id == bId) { bId = -1; inp.releaseButton("B") }
                    if (id == gameId) { gameId = -1; inp.touchUp() }
                }
                refreshTouches(e, idx)
            }
        }
        invalidate()
        return true
    }

    private fun refreshTouches(e: MotionEvent, skipIndex: Int) {
        val inp = model.play?.input ?: return
        inp.touches.clear()
        for (i in 0 until e.pointerCount) {
            if (i == skipIndex) continue
            inp.touches.add(gameTouchPos(e.getX(i), e.getY(i)))
        }
    }

    // ---------- Edición ----------
    private fun drawEdit(c: Canvas) {
        val w = model.world
        val cam = w.camera()
        c.drawColor(cam.background)
        c.save()
        c.translate(width / 2f, height / 2f)
        c.scale(camZoom.toFloat(), camZoom.toFloat())
        c.translate(-camCenter.x.toFloat(), -camCenter.y.toFloat())

        drawGrid(c)
        renderer.drawWorld(c, w, true)
        renderer.drawColliders(c, w, (1.5 / camZoom).toFloat())

        // Marco de lo que verá el jugador
        stroke.color = 0x88FFFFFF.toInt()
        stroke.strokeWidth = (2.0 / camZoom).toFloat()
        val hw = (w.viewW / cam.zoom / 2).toFloat()
        val hh = (w.viewH / cam.zoom / 2).toFloat()
        tmpRect.set(cam.center.x.toFloat() - hw, cam.center.y.toFloat() - hh, cam.center.x.toFloat() + hw, cam.center.y.toFloat() + hh)
        c.drawRect(tmpRect, stroke)
        c.restore()

        drawSelection(c)
        drawNames(c)
    }

    private fun drawGrid(c: Canvas) {
        val step = if (camZoom > 0.35) 100.0 else 500.0
        val left = s2w(0f, 0f); val right = s2w(width.toFloat(), height.toFloat())
        stroke.strokeWidth = (1.0 / camZoom).toFloat()
        stroke.color = 0x22FFFFFF
        var x = Math.floor(left.x / step) * step
        while (x <= right.x) { c.drawLine(x.toFloat(), left.y.toFloat(), x.toFloat(), right.y.toFloat(), stroke); x += step }
        var y = Math.floor(left.y / step) * step
        while (y <= right.y) { c.drawLine(left.x.toFloat(), y.toFloat(), right.x.toFloat(), y.toFloat(), stroke); y += step }
        stroke.strokeWidth = (2.0 / camZoom).toFloat()
        stroke.color = 0x55FF5252
        c.drawLine(0f, left.y.toFloat(), 0f, right.y.toFloat(), stroke)
        stroke.color = 0x5566BB6A
        c.drawLine(left.x.toFloat(), 0f, right.x.toFloat(), 0f, stroke)
    }

    private fun handleScreenPos(o: GameObject): Vec2 {
        val h = renderer.localHalfSize(o)
        return w2s(toWorld(o, Vec2(h.x, h.y)))
    }

    private fun drawSelection(c: Canvas) {
        val o = model.selected ?: return
        val h = renderer.localHalfSize(o)
        val corners = listOf(Vec2(-h.x, -h.y), Vec2(h.x, -h.y), Vec2(h.x, h.y), Vec2(-h.x, h.y)).map { w2s(toWorld(o, it)) }
        path.reset()
        path.moveTo(corners[0].x.toFloat(), corners[0].y.toFloat())
        for (i in 1 until 4) path.lineTo(corners[i].x.toFloat(), corners[i].y.toFloat())
        path.close()
        stroke.color = Ui.SELECT
        stroke.strokeWidth = dpf(2f)
        c.drawPath(path, stroke)
        if (resizable(o)) {
            val hp = corners[2]
            paint.color = Ui.SELECT
            val r = dpf(8f)
            c.drawRect(hp.x.toFloat() - r, hp.y.toFloat() - r, hp.x.toFloat() + r, hp.y.toFloat() + r, paint)
        }
    }

    private fun drawNames(c: Canvas) {
        textPaint.textSize = dpf(12f)
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.setShadowLayer(3f, 1f, 1f, Color.BLACK)
        for (o in model.world.objects) {
            val selected = o === model.selected
            val bare = o.sprite == null && o.label == null
            if (!selected && !bare) continue
            val p = w2s(o.worldPosition())
            if (bare) {
                stroke.color = if (o.camera != null) Ui.ACCENT else 0xFFFFFFFF.toInt()
                stroke.strokeWidth = dpf(2f)
                val r = dpf(8f)
                c.drawLine(p.x.toFloat() - r, p.y.toFloat(), p.x.toFloat() + r, p.y.toFloat(), stroke)
                c.drawLine(p.x.toFloat(), p.y.toFloat() - r, p.x.toFloat(), p.y.toFloat() + r, stroke)
            }
            textPaint.color = if (selected) Ui.SELECT else 0xFFFFFFFF.toInt()
            val h = renderer.localHalfSize(o)
            val top = w2s(toWorld(o, Vec2(0.0, -h.y)))
            c.drawText(o.name + if (o.camera != null) " (camara)" else "", top.x.toFloat(), top.y.toFloat() - dpf(8f), textPaint)
        }
        textPaint.clearShadowLayer()
    }

    private fun resizable(o: GameObject) = o.sprite != null || o.colliders.isNotEmpty()

    // ---------- Gestos del editor ----------
    private enum class Mode { NONE, PAN, DRAG, RESIZE, PINCH }

    private var mode = Mode.NONE
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var moved = false
    private var dragObj: GameObject? = null
    private var dragStartWorld = Vec2.ZERO
    private var dragObjStart = Vec2.ZERO
    private var pinchDist = 1f
    private var pinchMidX = 0f
    private var pinchMidY = 0f

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (model.isPlaying) return playTouch(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y; lastX = e.x; lastY = e.y
                moved = false
                val sel = model.selected
                val hp = if (sel != null && resizable(sel)) handleScreenPos(sel) else null
                if (sel != null && hp != null && Math.hypot(e.x - hp.x, e.y - hp.y) <= dpf(26f)) {
                    mode = Mode.RESIZE
                    dragObj = sel
                    model.beginEdit()
                } else {
                    val hit = model.topObjectAt(s2w(e.x, e.y))
                    if (hit != null) {
                        if (hit !== sel) { model.select(hit); onSelectionChanged?.invoke() }
                        mode = Mode.DRAG
                        dragObj = hit
                        dragStartWorld = s2w(e.x, e.y)
                        dragObjStart = hit.worldPosition()
                    } else {
                        mode = Mode.PAN
                    }
                }
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (e.pointerCount == 2) {
                    mode = Mode.PINCH
                    pinchDist = dist(e).coerceAtLeast(1f)
                    pinchMidX = (e.getX(0) + e.getX(1)) / 2f
                    pinchMidY = (e.getY(0) + e.getY(1)) / 2f
                }
            }
            MotionEvent.ACTION_MOVE -> {
                when (mode) {
                    Mode.PINCH -> if (e.pointerCount >= 2) {
                        val d = dist(e).coerceAtLeast(1f)
                        val mx = (e.getX(0) + e.getX(1)) / 2f
                        val my = (e.getY(0) + e.getY(1)) / 2f
                        val before = s2w(pinchMidX, pinchMidY)
                        camZoom = (camZoom * d / pinchDist).coerceIn(0.03, 6.0)
                        // mantiene el punto bajo los dedos
                        val after = s2w(mx, my)
                        camCenter = Vec2(camCenter.x + (before.x - after.x), camCenter.y + (before.y - after.y))
                        pinchDist = d; pinchMidX = mx; pinchMidY = my
                    }
                    Mode.PAN -> {
                        if (Math.hypot(e.x - downX, e.y - downY) > slop) moved = true
                        camCenter = Vec2(camCenter.x - (e.x - lastX) / camZoom, camCenter.y - (e.y - lastY) / camZoom)
                    }
                    Mode.DRAG -> {
                        val o = dragObj
                        if (o != null) {
                            if (!moved && Math.hypot(e.x - downX, e.y - downY) > slop) { moved = true; model.beginEdit() }
                            if (moved) {
                                val cur = s2w(e.x, e.y)
                                var np = dragObjStart + (cur - dragStartWorld)
                                np = if (snap) Vec2(Math.round(np.x / 8.0) * 8.0, Math.round(np.y / 8.0) * 8.0)
                                else Vec2(Math.round(np.x).toDouble(), Math.round(np.y).toDouble())
                                o.setWorldPosition(np)
                                model.dirty = true
                                onTransformChanged?.invoke()
                            }
                        }
                    }
                    Mode.RESIZE -> {
                        val o = dragObj
                        if (o != null) { applyResize(o, s2w(e.x, e.y)); onTransformChanged?.invoke() }
                    }
                    Mode.NONE -> {}
                }
                lastX = e.x; lastY = e.y
                invalidate()
            }
            MotionEvent.ACTION_POINTER_UP -> {
                if (mode == Mode.PINCH) {
                    mode = Mode.NONE
                    // el dedo que queda sigue moviendo la cámara sin saltos
                    val rest = if (e.actionIndex == 0) 1 else 0
                    if (rest < e.pointerCount) { lastX = e.getX(rest); lastY = e.getY(rest); mode = Mode.PAN; moved = true }
                }
            }
            MotionEvent.ACTION_UP -> {
                if (mode == Mode.PAN && !moved && model.selected != null) {
                    model.select(null)
                    onSelectionChanged?.invoke()
                }
                if ((mode == Mode.DRAG && moved) || mode == Mode.RESIZE) onEditEnd?.invoke()
                mode = Mode.NONE
                dragObj = null
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> { mode = Mode.NONE; dragObj = null }
        }
        return true
    }

    private fun dist(e: MotionEvent): Float = Math.hypot((e.getX(0) - e.getX(1)).toDouble(), (e.getY(0) - e.getY(1)).toDouble()).toFloat()

    private fun applyResize(o: GameObject, worldPt: Vec2) {
        val loc = toLocal(o, worldPt)
        fun q(v: Double): Double = Math.max(4.0, if (snap) Math.round(v / 8.0) * 8.0 else Math.round(v).toDouble())
        var nx = q(Math.abs(loc.x) * 2)
        var ny = q(Math.abs(loc.y) * 2)
        val sp = o.sprite
        if (sp != null) {
            val old = sp.v("size")
            if (sp.s("shape") == "circle") { val d = Math.max(nx, ny); nx = d; ny = d }
            sp.values["size"] = Vec2(nx, ny)
            o.get<BoxCollider2D>()?.let { if (it.v("size") == old) it.values["size"] = Vec2(nx, ny) }
            o.get<CircleCollider2D>()?.let {
                if (Math.abs(it.f("radius") - Math.min(old.x, old.y) / 2) < 0.01) it.values["radius"] = Math.min(nx, ny) / 2
            }
        } else {
            val bc = o.get<BoxCollider2D>()
            val cc = o.get<CircleCollider2D>()
            if (bc != null) bc.values["size"] = Vec2(nx, ny)
            else if (cc != null) cc.values["radius"] = Math.max(nx, ny) / 2
        }
        model.dirty = true
    }
}
